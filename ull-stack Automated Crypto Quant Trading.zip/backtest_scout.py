﻿import pandas as pd
import numpy as np
import joblib
import os
from layers.layer4_feature_engineer import FeatureEngineer
from layers.layer3_data_clean import DataCleaner

# 配置
FILES = {
    "BTC-USDT": "BTC_USDT_15m.csv",
    "ETH-USDT": "ETH_USDT_15m.csv",
    "SOL-USDT": "SOL_USDT_15m.csv",
}
USDT_PER_TRADE = 3
FEE_RATE = 0.0005
OSC_MAX_DAILY = 10
OSC_COOLDOWN_SEC = 600
ML_THRESHOLD = 0.52

# 加载模型
ml_ensemble = joblib.load("ml_lib/trained_models/ensemble_model.pkl")
scaler = joblib.load("ml_lib/transformers/scaler.pkl")
selector = joblib.load("ml_lib/transformers/selector.pkl")
feature_engineer = FeatureEngineer()
data_cleaner = DataCleaner()

def calc_rsi(series, period=14):
    delta = series.diff()
    gain = delta.where(delta > 0, 0).rolling(period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

def backtest_scout(df_raw, asset):
    # 生成特征
    df = data_cleaner.clean_klines(df_raw)
    df_feat = feature_engineer.calculate_features(df)
    # 合并原始OHLCV和特征
    df_full = pd.concat([df.reset_index(drop=True), df_feat.reset_index(drop=True)], axis=1)
    # 统一时间戳列
    if 'timestamp' in df_full.columns:
        df_full['timestamp'] = pd.to_datetime(df_full['timestamp'], unit='ms', errors='coerce')
    
    trades = []
    pos = None
    daily_count = 0
    last_day = None
    last_exit_time = 0

    for i in range(50, len(df_full)):
        row = df_full.iloc[i]
        current_price = row['close']
        current_time = row.get('timestamp', i)

        # 日切重置
        day = str(current_time)[:10] if current_time is not None else str(i)
        if day != last_day:
            daily_count = 0
            last_day = day

        # 持仓管理
        if pos is not None:
            pnl_pct = (current_price - pos['entry']) / pos['entry']
            hold_bars = i - pos['entry_idx']
            if pnl_pct >= 0.004 or pnl_pct <= -0.0025 or hold_bars >= 3:
                pnl = USDT_PER_TRADE * pnl_pct - USDT_PER_TRADE * FEE_RATE * 2
                trades.append({
                    'asset': asset,
                    'entry_time': pos['entry_time'],
                    'exit_time': current_time,
                    'entry_price': pos['entry'],
                    'exit_price': current_price,
                    'pnl': pnl,
                    'reason': '止盈' if pnl_pct >= 0.004 else ('止损' if pnl_pct <= -0.0025 else '超时')
                })
                pos = None
                continue

        # 开仓条件
        if pos is None and daily_count < OSC_MAX_DAILY:
            # 计算指标
            close_series = df_full['close'].iloc[:i+1]
            rsi_series = calc_rsi(close_series)
            rsi_now = rsi_series.iloc[-1]
            rsi_prev = rsi_series.iloc[-2] if len(rsi_series) > 1 else rsi_now
            rsi_prev5 = rsi_series.iloc[-6] if len(rsi_series) > 5 else rsi_now

            vol_now = df_full['volume'].iloc[i]
            vol_ma20 = df_full['volume'].iloc[max(0,i-20):i+1].mean()

            # 布林带
            window = 20
            bb_mid = df_full['close'].rolling(window).mean().iloc[i]
            bb_std = df_full['close'].rolling(window).std().iloc[i]
            bb_lower = bb_mid - 2 * bb_std
            bb_upper = bb_mid + 2 * bb_std
            bb_pos = (current_price - bb_lower) / (bb_upper - bb_lower) if bb_upper > bb_lower else 0.5

            trigger = False
            reason = ""
            if rsi_now <= 42 and rsi_now > rsi_prev and rsi_prev5 <= 42:
                trigger = True
                reason = "RSI超卖反弹"
            elif vol_now > vol_ma20 * 1.3 and current_price > df_full['close'].iloc[i-1] and bb_pos < 0.35:
                trigger = True
                reason = "放量反弹"
            elif current_price <= bb_lower * 1.02 and bb_pos < 0.25:
                trigger = True
                reason = "触及下轨"

            if trigger:
                # 特征列
                feature_cols = [c for c in df_full.columns if c not in ['timestamp','datetime'] and pd.api.types.is_numeric_dtype(df_full[c])]
                X = df_full[feature_cols].iloc[i:i+1].dropna()
                if len(X) > 0:
                    try:
                        X_scaled = pd.DataFrame(scaler.transform(X), columns=X.columns)
                        X_selected = pd.DataFrame(selector.transform(X_scaled), columns=X_scaled.columns[selector.get_support()])
                        p_up = ml_ensemble.predict_proba(X_selected)[0][1]
                    except:
                        p_up = 0.5  # 若特征不匹配则中性
                    if p_up > ML_THRESHOLD:
                        pos = {'entry': current_price, 'entry_idx': i, 'entry_time': current_time}
                        daily_count += 1

    return trades

all_trades = []
for asset, file in FILES.items():
    if os.path.exists(file):
        print(f"回测 {asset}...")
        df_raw = pd.read_csv(file)
        trades = backtest_scout(df_raw, asset)
        all_trades.extend(trades)
        print(f"  完成 {len(trades)} 笔交易")
    else:
        print(f"文件不存在: {file}")

if all_trades:
    df_trades = pd.DataFrame(all_trades)
    total_pnl = df_trades['pnl'].sum()
    wins = (df_trades['pnl'] > 0).sum()
    losses = (df_trades['pnl'] <= 0).sum()
    win_rate = wins / len(df_trades) * 100
    print("\n========== 回测结果 ==========")
    print(f"总交易: {len(df_trades)} 笔")
    print(f"总盈亏: {total_pnl:.4f} USDT")
    print(f"胜率: {win_rate:.1f}% ({wins}胜/{losses}负)")
    print("\n按品种:")
    for asset in FILES.keys():
        asset_trades = df_trades[df_trades['asset'] == asset]
        if len(asset_trades) > 0:
            pnl = asset_trades['pnl'].sum()
            wr = (asset_trades['pnl'] > 0).sum() / len(asset_trades) * 100
            print(f"  {asset}: {len(asset_trades)}笔 | 盈亏: {pnl:.4f} | 胜率: {wr:.1f}%")
else:
    print("无交易产生。")
