﻿from pathlib import Path
import py_compile

p = Path("layers/polymarket_clob.py")

s = p.read_text(
    encoding="utf-8-sig"
)

# ============================================================
# 防止重复注入
# ============================================================

if "_final_discover_btc_updown" in s:

    print(
        "[INFO] final discovery method already injected"
    )

else:

    patch = r'''

# ============================================================
# FINAL POLYMARKET BTC 15M DISCOVERY
# ============================================================
#
# 采用“函数 + 类属性绑定”的方式注入，
# 避免修改类内部缩进导致的方法消失问题。
#
# 15m窗口：
#     btc-updown-15m-<unix_timestamp>
#
# timestamp 才是预测窗口起点。
# market.startDate 只视为市场元数据，不用于窗口判断。
# ============================================================

def _final_discover_btc_updown(
    self,
    window="15m",
):
    import datetime as _dt
    import re as _re
    import time as _time

    if str(window).lower() != "15m":

        logger.warning(
            "Polymarket discovery optimized for 15m, requested={}",
            window,
        )

    now = _time.time()

    # ========================================================
    # Cache
    # ========================================================

    try:

        with self._lock:

            cached = (
                self._market_cache.get(
                    "market"
                )
            )

            cached_ts = float(
                self._market_cache.get(
                    "ts",
                    0.0,
                )
            )

        if cached:

            cached_slug = str(
                cached.get(
                    "slug",
                    ""
                )
            )

            m = _re.search(
                r"btc-updown-15m-(\d{10})$",
                cached_slug.lower(),
            )

            if m:

                cached_start = float(
                    m.group(1)
                )

                cached_end = (
                    cached_start
                    + 900.0
                )

                if (
                    cached_start
                    <= now
                    <
                    cached_end
                    and
                    now - cached_ts
                    < float(
                        self.refresh_sec
                    )
                ):

                    return cached

    except Exception:
        pass

    # ========================================================
    # 当前15m窗口
    # ========================================================

    bucket = (
        int(now)
        // 900
    ) * 900

    def _normalize(
        market,
        event=None,
        slug_hint="",
    ):

        if not isinstance(
            market,
            dict,
        ):
            return None

        event = (
            event
            if isinstance(
                event,
                dict,
            )
            else {}
        )

        slug = str(
            market.get(
                "slug"
            )
            or event.get(
                "slug"
            )
            or slug_hint
            or ""
        ).lower()

        match = _re.search(
            r"btc-updown-15m-(\d{10})$",
            slug,
        )

        if not match:
            return None

        start_ts = float(
            match.group(1)
        )

        end_ts = (
            start_ts
            + 900.0
        )

        # 当前真实预测窗口
        if not (
            start_ts
            <= now
            <
            end_ts
        ):
            return None

        # 状态
        if market.get(
            "closed"
        ) is True:
            return None

        if market.get(
            "archived"
        ) is True:
            return None

        # Token
        token_raw = (
            market.get(
                "clobTokenIds"
            )
            or
            market.get(
                "clob_token_ids"
            )
        )

        try:

            token_raw = (
                self._jsonish(
                    token_raw
                )
            )

        except Exception:
            pass

        if not isinstance(
            token_raw,
            list,
        ):
            return None

        token_ids = [
            str(x)
            for x in token_raw
            if x
        ]

        if len(
            token_ids
        ) < 2:

            return None

        # Outcomes
        outcomes = (
            market.get(
                "outcomes"
            )
        )

        try:

            outcomes = (
                self._jsonish(
                    outcomes
                )
            )

        except Exception:
            pass

        if not isinstance(
            outcomes,
            list,
        ):

            outcomes = [
                "Up",
                "Down",
            ]

        outcomes = [
            str(x)
            for x in outcomes
        ]

        # 保证Up/Down顺序
        ordered = (
            token_ids[:2]
        )

        lowered = [
            x.lower()
            for x in outcomes
        ]

        up_index = next(
            (
                i
                for i, x
                in enumerate(
                    lowered
                )
                if x
                in {
                    "up",
                    "yes",
                }
            ),
            None,
        )

        down_index = next(
            (
                i
                for i, x
                in enumerate(
                    lowered
                )
                if x
                in {
                    "down",
                    "no",
                }
            ),
            None,
        )

        if (
            up_index is not None
            and
            down_index is not None
            and
            up_index
            < len(
                token_ids
            )
            and
            down_index
            < len(
                token_ids
            )
        ):

            ordered = [
                token_ids[
                    up_index
                ],
                token_ids[
                    down_index
                ],
            ]

        start_dt = (
            _dt.datetime.fromtimestamp(
                start_ts,
                tz=_dt.timezone.utc,
            )
        )

        end_dt = (
            _dt.datetime.fromtimestamp(
                end_ts,
                tz=_dt.timezone.utc,
            )
        )

        return {
            "condition_id":
                (
                    market.get(
                        "conditionId"
                    )
                    or
                    market.get(
                        "condition_id"
                    )
                ),

            "market_id":
                market.get(
                    "id"
                ),

            "event_id":
                event.get(
                    "id"
                ),

            "slug":
                (
                    market.get(
                        "slug"
                    )
                    or
                    event.get(
                        "slug"
                    )
                    or
                    slug
                ),

            "question":
                (
                    market.get(
                        "question"
                    )
                    or
                    event.get(
                        "title"
                    )
                    or
                    "Bitcoin Up or Down"
                ),

            # 预测窗口
            "start_time":
                start_dt.isoformat(),

            "end_time":
                end_dt.isoformat(),

            "window_start_ts":
                start_ts,

            "window_end_ts":
                end_ts,

            "token_ids":
                ordered,

            "outcomes":
                outcomes[:2],

            "duration_sec":
                900.0,

            "volume":
                float(
                    market.get(
                        "volumeNum"
                    )
                    or
                    market.get(
                        "volume"
                    )
                    or
                    0.0
                ),

            "raw":
                market,
        }

    def _accept(
        result,
        source,
    ):

        if not result:
            return None

        with self._lock:

            self._market_cache = {
                "ts":
                    now,
                "market":
                    result,
            }

        logger.success(
            "Polymarket LIVE BTC 15m discovered via {}: {} | start={} | end={} | tokens={}",
            source,
            result.get(
                "slug"
            ),
            result.get(
                "start_time"
            ),
            result.get(
                "end_time"
            ),
            len(
                result.get(
                    "token_ids",
                    []
                )
            ),
        )

        return result

    # ========================================================
    # 1. 最可靠：直接访问当前15m event slug
    # ========================================================

    event_url = (
        "https://gamma-api.polymarket.com/events/slug/{}"
    )

    for ts in (
        bucket,
        bucket - 900,
        bucket + 900,
    ):

        slug = (
            f"btc-updown-15m-{ts}"
        )

        try:

            payload = (
                self._get_json(
                    event_url.format(
                        slug
                    )
                )
            )

            if not isinstance(
                payload,
                dict,
            ):
                continue

            markets = (
                payload.get(
                    "markets"
                )
                or
                []
            )

            if not isinstance(
                markets,
                list,
            ):

                markets = []

            if (
                not markets
                and
                (
                    payload.get(
                        "clobTokenIds"
                    )
                    or
                    payload.get(
                        "clob_token_ids"
                    )
                )
            ):

                markets = [
                    payload
                ]

            for market in markets:

                result = _normalize(
                    market,
                    payload,
                    slug,
                )

                if result:

                    return _accept(
                        result,
                        "event-slug",
                    )

        except Exception as exc:

            logger.debug(
                "Polymarket event-slug {} failed: {}",
                slug,
                exc,
            )

    # ========================================================
    # 2. public-search fallback
    # ========================================================

    search_url = (
        "https://gamma-api.polymarket.com/public-search"
    )

    for query in (
        "Bitcoin Up or Down",
        "BTC Up or Down",
    ):

        try:

            payload = (
                self._get_json(
                    search_url,
                    {
                        "q":
                            query,
                        "limit_per_type":
                            100,
                        "page":
                            1,
                    },
                )
            )

            stack = [
                payload
            ]

            visited = set()

            while stack:

                obj = stack.pop()

                if isinstance(
                    obj,
                    dict,
                ):

                    if (
                        "clobTokenIds"
                        in obj
                        or
                        "clob_token_ids"
                        in obj
                    ):

                        obj_id = id(
                            obj
                        )

                        if obj_id not in visited:

                            visited.add(
                                obj_id
                            )

                            result = (
                                _normalize(
                                    obj
                                )
                            )

                            if result:

                                return _accept(
                                    result,
                                    "public-search",
                                )

                    for value in obj.values():

                        if isinstance(
                            value,
                            (
                                dict,
                                list,
                            ),
                        ):

                            stack.append(
                                value
                            )

                elif isinstance(
                    obj,
                    list,
                ):

                    stack.extend(
                        obj
                    )

        except Exception as exc:

            logger.debug(
                "Polymarket public-search {} failed: {}",
                query,
                exc,
            )

    # ========================================================
    # 3. /markets fallback
    # ========================================================

    try:

        payload = (
            self._get_json(
                self.GAMMA_URL,
                {
                    "closed":
                        "false",
                    "active":
                        "true",
                    "limit":
                        100,
                    "order":
                        "endDate",
                    "ascending":
                        "false",
                },
            )
        )

        if isinstance(
            payload,
            list,
        ):

            for market in payload:

                result = _normalize(
                    market
                )

                if result:

                    return _accept(
                        result,
                        "markets",
                    )

    except Exception as exc:

        logger.debug(
            "Polymarket /markets failed: {}",
            exc,
        )

    logger.warning(
        "Polymarket: API reachable but current BTC 15m market not found"
    )

    return None


# ============================================================
# 将模块函数绑定为PolymarketCLOB类方法
# ============================================================

PolymarketCLOB.discover_btc_updown = (
    _final_discover_btc_updown
)

'''

    s = s.rstrip() + "\n\n" + patch

    p.write_text(
        s,
        encoding="utf-8",
    )

# ============================================================
# 编译
# ============================================================

py_compile.compile(
    str(p),
    doraise=True,
)

# ============================================================
# 运行时验证
# ============================================================

import importlib
import layers.polymarket_clob as mod

mod = importlib.reload(
    mod
)

cls = mod.PolymarketCLOB

print()
print("=" * 72)
print("POLYMARKET METHOD RESTORE CHECK")
print("=" * 72)
print(
    "MODULE =",
    mod.__file__,
)
print(
    "DISCOVER =",
    hasattr(
        cls,
        "discover_btc_updown",
    ),
)

if not hasattr(
    cls,
    "discover_btc_updown",
):

    raise RuntimeError(
        "discover_btc_updown 绑定失败"
    )

print(
    "METHOD =",
    cls.discover_btc_updown,
)

print(
    "SYNTAX = PASS"
)

print(
    "=" * 72
)
