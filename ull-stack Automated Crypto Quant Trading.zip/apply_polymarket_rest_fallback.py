﻿from pathlib import Path
import py_compile
import shutil
from datetime import datetime

ROOT = Path.cwd()

P = ROOT / "layers" / "polymarket_clob.py"

if not P.exists():
    raise RuntimeError(
        f"找不到文件: {P}"
    )

STAMP = datetime.now().strftime(
    "%Y%m%d_%H%M%S"
)

BACKUP_DIR = ROOT / "_FINAL_BACKUP"
BACKUP_DIR.mkdir(
    exist_ok=True
)

BACKUP = (
    BACKUP_DIR
    / f"polymarket_clob_before_rest_fallback_{STAMP}.py"
)

shutil.copy2(
    P,
    BACKUP
)

print(
    "[BACKUP]",
    BACKUP
)

source = P.read_text(
    encoding="utf-8-sig"
)

MARKER = "# FINAL_PM_REST_FALLBACK_V1"

if MARKER in source:

    print(
        "[INFO] REST fallback already installed"
    )

else:

    patch = r'''
# FINAL_PM_REST_FALLBACK_V1
#
# WSS正常：
#     WSS realtime book
#
# WSS断开或长时间没有有效数据：
#     REST /book fallback every 5s
#
# WSS恢复：
#     自动停止REST fallback
#
# Shadow health：
#     WSS fresh OR REST fallback fresh
#

_PM_ORIGINAL_START = PolymarketCLOB.start
_PM_ORIGINAL_STOP = PolymarketCLOB.stop
_PM_ORIGINAL_HEALTH = PolymarketCLOB.health_snapshot


def _final_rest_fallback_loop(self):
    interval = max(
        3.0,
        float(
            getattr(
                self,
                "rest_fallback_interval_sec",
                5.0,
            )
        ),
    )

    stop_event = getattr(
        self,
        "_rest_fallback_stop",
        None,
    )

    if stop_event is None:
        return

    fallback_active = False
    last_poll = 0.0

    while not (
        self._stop.is_set()
        or
        stop_event.is_set()
    ):

        if stop_event.wait(
            1.0
        ):
            break

        now = time.time()

        with self._lock:

            connected = bool(
                self._connected
            )

            last_ws = float(
                self._last_ws_activity
                or
                0.0
            )

            tokens = list(
                self._subscribed_assets
            )

        ws_dead = (
            not connected
            or
            last_ws <= 0.0
            or
            (
                now
                - last_ws
                >
                float(
                    self.ws_stale_sec
                )
            )
        )

        if not ws_dead:

            if fallback_active:

                logger.info(
                    "Polymarket REST fallback stopped; WSS stream healthy"
                )

                fallback_active = False

            continue

        if not tokens:
            continue

        if (
            now
            - last_poll
            <
            interval
        ):
            continue

        last_poll = now

        if not fallback_active:

            logger.warning(
                "Polymarket WSS stale/disconnected; activating REST /book fallback every {:.1f}s",
                interval,
            )

            fallback_active = True

        success = self.initial_sync(
            tokens
        )

        logger.debug(
            "Polymarket REST fallback sync: {}/{} books",
            success,
            len(tokens),
        )


def _final_start(
    self,
    token_ids,
):

    # 默认5秒兜底
    self.rest_fallback_interval_sec = float(
        getattr(
            self,
            "rest_fallback_interval_sec",
            5.0,
        )
    )

    _PM_ORIGINAL_START(
        self,
        token_ids,
    )

    with self._lock:

        stop_event = getattr(
            self,
            "_rest_fallback_stop",
            None,
        )

        if stop_event is None:

            stop_event = (
                threading.Event()
            )

            self._rest_fallback_stop = (
                stop_event
            )

        if stop_event.is_set():

            stop_event.clear()

        thread = getattr(
            self,
            "_rest_fallback_thread",
            None,
        )

    if not (
        thread
        and
        thread.is_alive()
    ):

        thread = threading.Thread(
            target=_final_rest_fallback_loop,
            args=(self,),
            name="polymarket-rest-fallback",
            daemon=True,
        )

        with self._lock:

            self._rest_fallback_thread = (
                thread
            )

        thread.start()


def _final_stop(
    self,
):

    stop_event = getattr(
        self,
        "_rest_fallback_stop",
        None,
    )

    if stop_event is not None:

        stop_event.set()

    thread = getattr(
        self,
        "_rest_fallback_thread",
        None,
    )

    _PM_ORIGINAL_STOP(
        self
    )

    if (
        thread
        and
        thread.is_alive()
    ):

        thread.join(
            timeout=1.5
        )


def _final_health(
    self,
    max_book_age_sec=30.0,
):

    health = _PM_ORIGINAL_HEALTH(
        self,
        max_book_age_sec,
    )

    now = time.time()

    with self._lock:

        rest_timestamp = float(
            self._last_clob_ok
            or
            0.0
        )

        ws_timestamp = float(
            self._last_ws_activity
            or
            0.0
        )

        connected = bool(
            self._connected
        )

    rest_age = (
        now
        - rest_timestamp
        if rest_timestamp > 0
        else None
    )

    ws_age = (
        now
        - ws_timestamp
        if ws_timestamp > 0
        else None
    )

    rest_fresh = (
        rest_age is not None
        and
        rest_age <= 10.0
    )

    wss_fresh = (
        connected
        and
        ws_age is not None
        and
        ws_age <= float(
            self.ws_stale_sec
        )
    )

    status_ok = bool(
        health.get(
            "status",
            {}
        ).get(
            "ok",
            False,
        )
    )

    books_fresh = bool(
        health.get(
            "books_fresh",
            False,
        )
    )

    if wss_fresh:

        transport = "WSS"

    elif rest_fresh:

        transport = "REST_FALLBACK"

    else:

        transport = "STALE"

    health[
        "wss_stream_fresh"
    ] = wss_fresh

    health[
        "rest_fallback_fresh"
    ] = rest_fresh

    health[
        "rest_fallback_age_sec"
    ] = rest_age

    health[
        "transport"
    ] = transport

    # 核心：
    # WSS 或 REST 任意一个是fresh，
    # 且订单簿和Data API正常，
    # Shadow都可以继续使用。
    health[
        "fresh"
    ] = bool(
        books_fresh
        and
        status_ok
        and
        (
            wss_fresh
            or
            rest_fresh
        )
    )

    return health


PolymarketCLOB.start = (
    _final_start
)

PolymarketCLOB.stop = (
    _final_stop
)

PolymarketCLOB.health_snapshot = (
    _final_health
)
'''

    P.write_text(
        source.rstrip()
        + "\n\n"
        + patch
        + "\n",
        encoding="utf-8",
    )

    print(
        "[PATCH] REST fallback injected"
    )


# ------------------------------------------------------------
# 编译
# ------------------------------------------------------------

py_compile.compile(
    str(P),
    doraise=True
)

print(
    "[PASS] polymarket_clob.py syntax"
)


# ------------------------------------------------------------
# 运行时验证
# ------------------------------------------------------------

import importlib
import layers.polymarket_clob as module

module = importlib.reload(
    module
)

klass = module.PolymarketCLOB

print()
print(
    "=" * 72
)

print(
    "POLYMARKET REST FALLBACK CHECK"
)

print(
    "=" * 72
)

print(
    "MODULE=",
    module.__file__
)

print(
    "DISCOVER=",
    hasattr(
        klass,
        "discover_btc_updown"
    )
)

print(
    "START=",
    hasattr(
        klass,
        "start"
    )
)

print(
    "STOP=",
    hasattr(
        klass,
        "stop"
    )
)

print(
    "HEALTH=",
    hasattr(
        klass,
        "health_snapshot"
    )
)

print(
    "REST_FALLBACK=",
    "_FINAL_PM_REST_FALLBACK_V1"
    in source
)

if not hasattr(
    klass,
    "discover_btc_updown",
):

    raise RuntimeError(
        "discover_btc_updown不存在"
    )

print(
    "=" * 72
)

print(
    "POLYMARKET REST FALLBACK PATCH SUCCESS"
)

print(
    "=" * 72
)

print(
    "WSS healthy -> use WSS"
)

print(
    "WSS stale -> REST /book every 5s"
)

print(
    "WSS recovery -> automatically stop fallback"
)

print(
    "Shadow fresh -> WSS OR REST_FALLBACK"
)

print(
    "=" * 72
)
