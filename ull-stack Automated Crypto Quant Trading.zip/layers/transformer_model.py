﻿# layers/transformer_model.py
import torch
import torch.nn as nn
import numpy as np

class TransformerPredictor:
    def __init__(self, model_path):
        checkpoint = torch.load(model_path, map_location=torch.device('cpu'), weights_only=False)
        self.scaler_mean = checkpoint['scaler_mean']
        self.scaler_scale = checkpoint['scaler_scale']
        self.seq_len = checkpoint['seq_len']
        self.model = Informer(input_dim=3, d_model=32, n_heads=4, n_layers=2, dropout=0.2)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.model.eval()

    def predict(self, df):
        df = df.copy()
        df['returns'] = df['close'].pct_change()
        df['vol_ratio'] = df['volume'] / df['volume'].rolling(20).mean()
        typical_price = (df['high'] + df['low'] + df['close']) / 3
        vwap = (typical_price * df['volume']).cumsum() / df['volume'].cumsum()
        df['vwap_deviation'] = (df['close'] - vwap) / vwap
        df = df.dropna().tail(self.seq_len)
        if len(df) < self.seq_len:
            return 0.5
        X = df[['returns', 'vol_ratio', 'vwap_deviation']].values
        X = (X - self.scaler_mean) / (self.scaler_scale + 1e-9)
        X_tensor = torch.tensor(X, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            prob = self.model(X_tensor).item()
        return prob

class Informer(nn.Module):
    def __init__(self, input_dim=3, d_model=32, n_heads=4, n_layers=2, dropout=0.2):
        super().__init__()
        self.input_proj = nn.Linear(input_dim, d_model)
        self.pos_embed = nn.Parameter(torch.randn(1, 100, d_model) * 0.02)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads, dropout=dropout, batch_first=True
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.fc = nn.Sequential(
            nn.Linear(d_model, 16),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(16, 1)
        )

    def forward(self, x):
        x = self.input_proj(x)
        x = x + self.pos_embed[:, :x.size(1), :]
        x = self.encoder(x)
        x = x.mean(dim=1)
        return torch.sigmoid(self.fc(x)).squeeze()
