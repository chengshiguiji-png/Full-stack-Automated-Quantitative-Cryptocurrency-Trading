﻿"""
第16层：多资产多策略配置层（修正版）
"""
import numpy as np
import pandas as pd
from loguru import logger

class MultiAssetAllocator:
    def __init__(self, config=None):
        self.config = config or {}
        self.blacklist = self.config.get("blacklist", ["TRX", "XRP"])
        self.correlation_matrix = None
        self.asset_volatility = {}
        self.position_limits = self.config.get("position_limits", {
            "BTC": 0.3, "ETH": 0.25, "BNB": 0.2, "SOL": 0.15
        })
        self.default_limit = self.config.get("default_limit", 0.1)   # 新增默认上限
        self.asset_strategies = {}

    def update_correlation_matrix(self, price_data: pd.DataFrame):
        if price_data.empty:
            return
        self.correlation_matrix = price_data.pct_change().corr()
        logger.info(f"相关性矩阵已更新，维度 {self.correlation_matrix.shape}")

    def calculate_allocation(self, total_capital: float, risk_budget: float, market_data: dict) -> dict:
        available_assets = []
        for asset, vol in market_data.get("volatilities", {}).items():
            if asset in self.blacklist:
                continue
            if vol > market_data.get("max_volatility", 0.08):
                logger.info(f"{asset} 波动率过高({vol:.2%})，自动降杠杆")
                vol = min(vol, 0.08)
            self.asset_volatility[asset] = vol
            available_assets.append(asset)
        if not available_assets:
            return {}
        inv_vol = np.array([1.0 / self.asset_volatility[a] for a in available_assets])
        weights = inv_vol / inv_vol.sum()
        for i, asset in enumerate(available_assets):
            limit = self.position_limits.get(asset, self.default_limit)
            if weights[i] > limit:
                weights[i] = limit
        weights = weights / weights.sum()
        allocation = {asset: weights[i] for i, asset in enumerate(available_assets)}
        if self.correlation_matrix is not None:
            avg_corr = self.correlation_matrix.loc[available_assets, available_assets].values.mean()
            total_risk_adjust = 0.8 if avg_corr > 0.6 else 1.0
        else:
            total_risk_adjust = 1.0
        logger.info(f"资金分配: {allocation}, 风险调整因子={total_risk_adjust:.2f}")
        return allocation

    def get_position_size(self, asset: str, total_capital: float, allocation: dict, price: float) -> float:
        if asset not in allocation:
            return 0.0
        capital_in_asset = total_capital * allocation[asset]
        size = capital_in_asset / price
        logger.debug(f"{asset} 分配资金 {capital_in_asset:.2f}，价格 {price:.2f}，数量 {size:.4f}")
        return size

    def register_strategy(self, asset: str, strategy_func):
        self.asset_strategies[asset] = strategy_func
        logger.info(f"资产 {asset} 已绑定策略")

if __name__ == "__main__":
    print("=== 测试第16层（修正版）：多资产多策略配置 ===")
    allocator = MultiAssetAllocator(config={"blacklist": ["TRX"], "position_limits": {"BTC": 0.4, "ETH": 0.3}, "default_limit": 0.1})
    dates = pd.date_range("2025-01-01", periods=100)
    price_data = pd.DataFrame({
        "BTC": 50000 + np.cumsum(np.random.randn(100)) * 500,
        "ETH": 3000 + np.cumsum(np.random.randn(100)) * 50,
        "BNB": 600 + np.cumsum(np.random.randn(100)) * 10,
        "SOL": 100 + np.cumsum(np.random.randn(100)) * 5,
    }, index=dates)
    allocator.update_correlation_matrix(price_data)
    market_data = {
        "volatilities": {"BTC": 0.04, "ETH": 0.05, "BNB": 0.06, "SOL": 0.09, "TRX": 0.12},
        "max_volatility": 0.08
    }
    allocation = allocator.calculate_allocation(total_capital=100000, risk_budget=0.02, market_data=market_data)
    print("资金分配比例:", allocation)
    btc_size = allocator.get_position_size("BTC", 100000, allocation, price=50000)
    print(f"BTC 应开仓数量: {btc_size:.4f} BTC")
    def dummy_strategy(signal):
        return {"action": "BUY"}
    allocator.register_strategy("BTC", dummy_strategy)
    print("第16层测试完成")
