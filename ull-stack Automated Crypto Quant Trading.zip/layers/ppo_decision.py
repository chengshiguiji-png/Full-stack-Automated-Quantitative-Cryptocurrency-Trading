﻿# layers/ppo_decision.py
import numpy as np
from stable_baselines3 import PPO
from loguru import logger

class PPODecision:
    def __init__(self, model_path="ml_lib/trained_models/ppo_trading_model.zip"):
        self.model = PPO.load(model_path)
        logger.info("PPO 模型已加载")

    def predict(self, df_feat, current_price, regime, sentiment):
        returns = df_feat['close'].pct_change().dropna().values[-20:]
        vol_ratio = (df_feat['volume'] / df_feat['volume'].rolling(20).mean()).dropna().values[-20:]
        typical_price = (df_feat['high'] + df_feat['low'] + df_feat['close']) / 3
        vwap = (typical_price * df_feat['volume']).cumsum() / df_feat['volume'].cumsum()
        vwap_dev = ((df_feat['close'] - vwap) / vwap).dropna().values[-20:]

        obs = []
        for i in range(20):
            obs.append(returns[i] if i < len(returns) else 0)
            obs.append(vol_ratio[i] if i < len(vol_ratio) else 0)
            obs.append(vwap_dev[i] if i < len(vwap_dev) else 0)
        obs.append(0)

        deterministic = (regime != "narrow_range")
        action, _ = self.model.predict(np.array(obs, dtype=np.float32), deterministic=deterministic)
        # 窄幅震荡中放宽：有30%概率直接通过
        if regime == "narrow_range" and action == 0 and np.random.random() < 0.3:
            logger.debug("窄幅震荡PPO放宽通过")
            return True
        return action == 1