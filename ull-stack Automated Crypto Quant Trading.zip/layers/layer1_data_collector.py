# -*- coding: utf-8 -*-
"""第1层：OKX REST 行情采集。

原则：
- 默认使用配置指定的 K 线周期（策略默认为 15m）。
- 只把已确认 K 线交给信号层。
- REST 请求使用连接复用、指数退避和明确超时。
"""
from __future__ import annotations

import time
from typing import Optional

import requests
from loguru import logger


class DataCollector:
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self.session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(pool_connections=8, pool_maxsize=8)
        self.session.mount("https://", adapter)
        self.base_url = self.config.get("base_url", "https://www.okx.com")
        self.max_retries = int(self.config.get("max_retries", 4))
        self.timeout = tuple(self.config.get("timeout", (5, 10)))

    def fetch_klines_rest(self, symbol: str = "BTC-USDT", interval: str = "15m", limit: int = 200, end_ts: int = None):
        """返回按时间升序排列的 K 线；超过300根时自动分页。

        新增 end_ts：不传时行为不变（从"现在"往回拉最近 limit 根）。
        传入一个毫秒时间戳时，改为拉取"早于 end_ts"的 limit 根K线——
        这是跑分月历史窗口回测（比如单独测2026年5月/6月/7月/8月/9月）的前提。
        之前这里完全没有这个参数，意味着不管你以为自己在测哪个月，
        实际上每次都只能拿到"运行这一刻往前数的最近N根"，跟你想验证的历史区间对不上。
        """
        target=max(1,int(limit)); per_page=min(target,300); url=f"{self.base_url}/api/v5/market/history-candles" if target>300 else f"{self.base_url}/api/v5/market/candles"
        keys=["ts","open","high","low","close","vol","volCcy","volCcyQuote","confirm"]; collected=[]; after=int(end_ts) if end_ts else None
        while len(collected)<target:
            params={"instId":symbol,"bar":interval,"limit":str(min(per_page,target-len(collected)))}
            if after is not None: params["after"]=str(after)
            page=None
            for retry in range(self.max_retries+1):
                try:
                    resp=self.session.get(url,params=params,timeout=self.timeout)
                    if resp.status_code==429:
                        time.sleep(min(30,2**retry)); continue
                    resp.raise_for_status(); payload=resp.json()
                    if payload.get("code") not in (None,"0"): raise ValueError(f"OKX K线接口错误: {payload}")
                    page=[dict(zip(keys,row)) for row in (payload.get("data") or [])]; break
                except (requests.RequestException,ValueError,TypeError) as exc:
                    logger.warning("REST 获取 %s %s 失败(%s/%s): %s",symbol,interval,retry+1,self.max_retries+1,exc)
                    if retry<self.max_retries: time.sleep(min(15,2**retry))
            if not page: break
            collected.extend(page); oldest=min(int(r["ts"]) for r in page)
            if after==oldest or len(page)<2: break
            after=oldest
        unique={int(r["ts"]):r for r in collected}; result=[unique[k] for k in sorted(unique)]
        return result[-target:] if result else None

    def fetch_funding_rate_history(self, symbol: str = "BTC-USDT", limit: int = 300, end_ts: int = None):
        """获取历史资金费率（OKX永续合约公开接口，免费、不需要API key）。

        2026-09新增：这是"15m纯技术指标测不出alpha，要不要加另类数据"这个问题里，
        成本最低、最该先试的一步——资金费率完全免费，不需要 Glassnode/CryptoQuant
        那种订阅。用现货交易对(BTC-USDT)对应的永续合约(BTC-USDT-SWAP)的资金费率
        历史，返回按时间升序排列的 [{"timestamp":毫秒, "funding_rate":float}, ...]，
        跟K线走同一套分页/退避逻辑。传 end_ts 时只取该时间之前的数据，避免用到
        比回测窗口更晚的资金费率造成前视偏差。
        """
        inst_id = symbol if symbol.endswith("-SWAP") else f"{symbol}-SWAP"
        target = max(1, int(limit)); per_page = min(target, 100)
        url = f"{self.base_url}/api/v5/public/funding-rate-history"
        collected = []; before = int(end_ts) if end_ts else None
        while len(collected) < target:
            params = {"instId": inst_id, "limit": str(min(per_page, target - len(collected)))}
            if before is not None:
                params["before"] = str(before)
            page = None
            for retry in range(self.max_retries + 1):
                try:
                    resp = self.session.get(url, params=params, timeout=self.timeout)
                    if resp.status_code == 429:
                        time.sleep(min(30, 2 ** retry)); continue
                    resp.raise_for_status(); payload = resp.json()
                    if payload.get("code") not in (None, "0"):
                        raise ValueError(f"OKX 资金费率接口错误: {payload}")
                    page = payload.get("data") or []
                    break
                except (requests.RequestException, ValueError, TypeError) as exc:
                    logger.warning("获取 {} 资金费率历史失败({}/{}): {}", inst_id, retry + 1, self.max_retries + 1, exc)
                    if retry < self.max_retries:
                        time.sleep(min(15, 2 ** retry))
            if not page:
                break
            collected.extend(page)
            oldest = min(int(r["fundingTime"]) for r in page)
            if before == oldest or len(page) < 2:
                break
            before = oldest
        if not collected:
            logger.warning("{} 资金费率历史获取为空（这不影响主流程——funding_rate特征只是可选项，"
                           "拿不到就退回不使用它，量化模型的其余64列特征照常工作）", inst_id)
            return None
        unique = {int(r["fundingTime"]): float(r["fundingRate"]) for r in collected}
        rows = [{"timestamp": ts, "funding_rate": rate} for ts, rate in sorted(unique.items())]
        return rows[-target:]

    def fetch_ticker(self, symbol: str = "BTC-USDT") -> Optional[float]:
        url = f"{self.base_url}/api/v5/market/ticker"
        try:
            resp = self.session.get(url, params={"instId": symbol}, timeout=self.timeout)
            resp.raise_for_status()
            payload = resp.json()
            rows = payload.get("data") or []
            if not rows:
                return None
            last = float(rows[0].get("last", 0))
            return last if last > 0 else None
        except (requests.RequestException, ValueError, TypeError) as exc:
            logger.warning("获取 %s ticker 失败: %s", symbol, exc)
            return None
