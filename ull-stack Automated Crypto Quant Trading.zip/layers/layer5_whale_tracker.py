﻿# layers/layer5_whale_tracker.py - 免费链上巨鲸监控（Etherscan）
import requests, time
from loguru import logger

class WhaleTracker:
    def __init__(self):
        self.etherscan_key = "UGVSQMEZIUJPQX888FI2U9GS8Q74DDMN9V"
        self.cache = {"time": 0, "signal": 0.0}
        self.cache_ttl = 300

    def get_signal(self):
        if time.time() - self.cache["time"] < self.cache_ttl:
            return self.cache["signal"]

        sig = self._check_eth_whales()
        if sig is not None:
            self.cache = {"time": time.time(), "signal": sig}
            if sig != 0:
                logger.info(f"巨鲸综合信号: {sig:.2f}")
            return sig
        return self.cache["signal"]

    def _check_eth_whales(self):
        try:
            usdt_contract = "0xdac17f958d2ee523a2206206994597c13d831ec7"
            url = f"https://api.etherscan.io/api?module=account&action=tokentx&contractaddress={usdt_contract}&page=1&offset=30&sort=desc&apikey={self.etherscan_key}"
            resp = requests.get(url, timeout=10)
            if resp.status_code != 200:
                return None
            data = resp.json()
            txs = data.get("result", [])
            if not isinstance(txs, list):
                return None

            exchange_addrs = {
                "0x28c6c06298d514db089934071355e5743bf21d60": "Binance",
                "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance",
                "0xf977814e90da44bfa03b6295a0616a897441acec": "Binance",
                "0x47ac0fb4f2d84898e4d9e7b4dab3c24507a6d503": "Binance",
                "0xbe0eb53f46cd790cd13851d5eff43d12404d33e8": "Binance",
                "0xc365c3315cf926351ccaf13fa7d19c8c4058c8e1": "Binance",
                "0x6262998ced04146fa42253a5c0af90ca02dfd2a3": "Crypto.com",
                "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Coinbase",
            }

            inflow = 0.0
            outflow = 0.0
            for tx in txs:
                value = float(tx.get("value", 0)) / 1e6
                if value < 1000000:
                    continue
                to_addr = tx.get("to", "").lower()
                from_addr = tx.get("from", "").lower()
                is_to_exchange = any(ea.lower() == to_addr for ea in exchange_addrs)
                is_from_exchange = any(ea.lower() == from_addr for ea in exchange_addrs)
                if is_to_exchange:
                    inflow += value
                elif is_from_exchange:
                    outflow += value

            total = inflow + outflow
            if total > 0:
                signal = (outflow - inflow) / total
                return max(-1, min(1, signal))
        except Exception as e:
            logger.debug(f"ETH巨鲸监控失败: {e}")
        return None
