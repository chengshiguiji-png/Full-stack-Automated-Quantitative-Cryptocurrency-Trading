
def clamp(x, min_val, max_val):
    return max(min_val, min(x, max_val))

def compute_edge(model_up, model_down, market_up, market_down):
    if market_up is None or market_down is None:
        return {"market_up": None, "market_down": None, "edge_up": None, "edge_down": None}
    total = market_up + market_down
    mkt_up = market_up / total if total > 0 else None
    mkt_down = market_down / total if total > 0 else None
    edge_up = model_up - mkt_up if mkt_up is not None else None
    edge_down = model_down - mkt_down if mkt_down is not None else None
    return {
        "market_up": clamp(mkt_up, 0, 1) if mkt_up is not None else None,
        "market_down": clamp(mkt_down, 0, 1) if mkt_down is not None else None,
        "edge_up": edge_up,
        "edge_down": edge_down
    }

def decide(remaining_minutes, edge_up, edge_down, model_up=None, model_down=None):
    phase = "EARLY" if remaining_minutes > 10 else "MID" if remaining_minutes > 5 else "LATE"
    threshold = 0.05 if phase == "EARLY" else 0.1 if phase == "MID" else 0.2
    min_prob = 0.55 if phase == "EARLY" else 0.6 if phase == "MID" else 0.65
    if edge_up is None or edge_down is None:
        return {"action": "NO_TRADE", "side": None, "phase": phase, "reason": "missing_market_data"}
    best_side = "UP" if edge_up > edge_down else "DOWN"
    best_edge = edge_up if best_side == "UP" else edge_down
    best_model = model_up if best_side == "UP" else model_down
    if best_edge < threshold:
        return {"action": "NO_TRADE", "side": None, "phase": phase, "reason": f"edge_below_{threshold}"}
    if best_model is not None and best_model < min_prob:
        return {"action": "NO_TRADE", "side": None, "phase": phase, "reason": f"prob_below_{min_prob}"}
    strength = "STRONG" if best_edge >= 0.2 else "GOOD" if best_edge >= 0.1 else "OPTIONAL"
    return {"action": "ENTER", "side": best_side, "phase": phase, "strength": strength, "edge": best_edge}
