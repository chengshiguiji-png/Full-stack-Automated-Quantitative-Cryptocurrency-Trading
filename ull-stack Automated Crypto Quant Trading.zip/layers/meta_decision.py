﻿# layers/meta_decision.py
import pandas as pd
import numpy as np
import xgboost as xgb
import os, pickle
from loguru import logger

class MetaDecision:
    def __init__(self, trades_csv="live_trades.csv"):
        self.trades_csv = trades_csv
        self.model = None
        self.last_train_size = 0
        self._train_if_needed()

    def _train_if_needed(self):
        if not os.path.exists(self.trades_csv):
            return
        df = pd.read_csv(self.trades_csv)
        sells = df[df['side'] == 'SELL'].dropna(subset=['pnl_usdt'])
        if len(sells) < 10:
            return
        if len(sells) == self.last_train_size:
            return

        # 用已平仓记录训练，但特征需要和当前6个评分对接。
        # 这里只是占位，实际训练需要历史评分数据。暂时返回None。
        pass

    def predict(self, features: dict) -> bool:
        """features包含6个分数，返回是否开仓"""
        # 默认回退到加权评分
        total = (0.30 * features['confidence'] + 0.20 * features['regime'] +
                 0.15 * features['sentiment'] + 0.15 * features['momentum'] +
                 0.10 * features['volume'] + 0.10 * features['hour'])
        return total >= 0.60
