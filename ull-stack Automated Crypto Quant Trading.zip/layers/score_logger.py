﻿# layers/score_logger.py
import csv, os
from datetime import datetime

SCORE_LOG_FILE = "score_log.csv"

def log_scores(asset, direction, scores, total_score, threshold, passed, regime, pnl=None):
    """记录每轮评分的详细数据，用于训练 XGBoost 元决策器"""
    file_exists = os.path.isfile(SCORE_LOG_FILE)
    with open(SCORE_LOG_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow([
                "timestamp", "asset", "direction", "regime",
                "confidence_score", "regime_score", "sentiment_score",
                "momentum_score", "volume_score", "hour_score", "trend_5m_score",
                "total_score", "threshold", "passed", "pnl"
            ])
        writer.writerow([
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"), asset, direction, regime,
            scores.get('confidence', 0), scores.get('regime', 0), scores.get('sentiment', 0),
            scores.get('momentum', 0), scores.get('volume', 0), scores.get('hour', 0),
            scores.get('trend_5m', 0),
            round(total_score, 4), threshold, passed,
            round(pnl, 4) if pnl is not None else ""
        ])
