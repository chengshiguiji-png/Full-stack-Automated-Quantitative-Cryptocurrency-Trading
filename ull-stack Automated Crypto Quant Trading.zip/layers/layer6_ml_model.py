# -*- coding: utf-8 -*-
"""第6层：多模型 ML 集成。

最终生产原则：
1. 禁止预测阶段自动生成模拟训练数据。
2. 缺失模型不得自动伪造。
3. 保留 DataFrame feature names，避免 LightGBM/sklearn 特征名警告。
4. 兼容旧版 numpy 拟合模型。
5. 模型之间按实际存在模型重新归一化权重。
6. 技术面、情绪、微结构不直接篡改 ML 概率。
"""
from __future__ import annotations

import os
from typing import Dict, Optional

import joblib
import numpy as np
import pandas as pd
from loguru import logger
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
import lightgbm as lgb


class MLModelEnsemble:
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

        self.models = {
            "random_forest": None,
            "logistic": None,
            "lightgbm": None,
        }

        self.model_weights = self.config.get(
            "model_weights",
            self.config.get(
                "model_weight",
                {
                    "random_forest": 0.33,
                    "logistic": 0.33,
                    "lightgbm": 0.34,
                },
            ),
        )

        self.version = "v3.0"
        self.model_dir = self.config.get(
            "model_dir",
            "ml_lib/trained_models",
        )

        os.makedirs(self.model_dir, exist_ok=True)
        self.loaded_from_artifact = False

    @staticmethod
    def _normalize_weights(weights: Dict[str, float], available):
        vals = {
            k: max(0.0, float(weights.get(k, 0.0)))
            for k in available
        }

        total = sum(vals.values())

        if total <= 0:
            w = 1.0 / len(available)
            return {k: w for k in available}

        return {
            k: v / total
            for k, v in vals.items()
        }

    def train(self, X, y):
        if X is None or y is None:
            raise ValueError(
                "训练必须显式提供真实 X/y，不允许自动生成模拟数据"
            )

        X_fit = (
            X.copy()
            if isinstance(X, pd.DataFrame)
            else np.asarray(X)
        )

        y_arr = np.asarray(y)

        if len(X_fit) < 100:
            raise ValueError("训练样本不足100")

        if len(np.unique(y_arr)) < 2:
            raise ValueError("训练标签只有一个类别")

        logger.info(
            "训练 ML ensemble，样本={} 特征={}",
            X_fit.shape[0],
            X_fit.shape[1],
        )

        self.models["random_forest"] = RandomForestClassifier(
            n_estimators=300,
            max_depth=6,
            min_samples_leaf=5,
            class_weight="balanced_subsample",
            random_state=42,
            n_jobs=-1,
        ).fit(X_fit, y_arr)

        self.models["logistic"] = LogisticRegression(
            max_iter=2000,
            class_weight="balanced",
            random_state=42,
        ).fit(X_fit, y_arr)

        self.models["lightgbm"] = lgb.LGBMClassifier(
            n_estimators=250,
            learning_rate=0.04,
            max_depth=5,
            num_leaves=31,
            min_child_samples=30,
            subsample=0.85,
            colsample_bytree=0.85,
            reg_alpha=0.2,
            reg_lambda=1.0,
            random_state=42,
            verbose=-1,
        ).fit(X_fit, y_arr)

        self.loaded_from_artifact = False

        return self.models

    @staticmethod
    def _expected_feature_names(model):
        # sklearn
        names = getattr(model, "feature_names_in_", None)

        if names is not None and len(names):
            return [str(x) for x in names]

        # LightGBM
        booster = getattr(model, "booster_", None)

        if booster is not None:
            try:
                names = booster.feature_name()

                if names:
                    return [str(x) for x in names]
            except Exception:
                pass

        return None

    @classmethod
    def _predict_model_proba(cls, model, X):
        """
        保持已训练模型的feature-name语义。

        - 老的numpy模型继续收到ndarray。
        - 用feature names训练的LightGBM/sklearn模型收到
          同样名字的DataFrame。
        """
        expected = cls._expected_feature_names(
            model
        )

        if isinstance(
            X,
            pd.DataFrame,
        ):

            if expected:

                if (
                    X.shape[1]
                    != len(expected)
                ):
                    raise ValueError(
                        "模型特征数不匹配: "
                        f"X={X.shape[1]} "
                        f"expected={len(expected)}"
                    )

                frame = X.copy()

                frame.columns = (
                    expected
                )

                return (
                    model.predict_proba(
                        frame
                    )[:, 1]
                )

            return (
                model.predict_proba(
                    X.to_numpy()
                )[:, 1]
            )

        array = np.asarray(
            X
        )

        if expected:

            if (
                array.ndim != 2
                or
                array.shape[1]
                != len(expected)
            ):
                raise ValueError(
                    "模型特征数不匹配: "
                    f"X={array.shape} "
                    f"expected={len(expected)}"
                )

            frame = pd.DataFrame(
                array,
                columns=expected,
            )

            return (
                model.predict_proba(
                    frame
                )[:, 1]
            )

        return (
            model.predict_proba(
                array
            )[:, 1]
        )

    def load_models(self):
        loaded = False

        for name in self.models:
            path = os.path.join(
                self.model_dir,
                f"{name}_{self.version}.pkl",
            )

            if os.path.exists(path):
                try:
                    self.models[name] = joblib.load(path)
                    loaded = True

                    logger.info(
                        "加载模型成功: {}",
                        path,
                    )

                except Exception as exc:
                    logger.error(
                        "加载模型失败 {}: {}",
                        path,
                        exc,
                    )

        self.loaded_from_artifact = loaded
        return loaded

    def predict_proba(self, X):
        available = [
            (name, model)
            for name, model in self.models.items()
            if model is not None
        ]

        if not available:
            raise RuntimeError(
                "没有已加载模型；请先训练或加载已验证的模型 artifact"
            )

        probs = []
        names = []

        for name, model in available:
            try:
                p = self._predict_model_proba(model, X)
                probs.append(np.asarray(p, dtype=float))
                names.append(name)

            except Exception as exc:
                logger.warning(
                    "模型 {} 预测失败: {}",
                    name,
                    exc,
                )

        if not probs:
            raise RuntimeError(
                "所有模型预测均失败"
            )

        weights = self._normalize_weights(
            self.model_weights,
            names,
        )

        return np.sum(
            [
                weights[name] * p
                for name, p in zip(names, probs)
            ],
            axis=0,
        )

    def predict_components(self, X):
        result = {}

        for name, model in self.models.items():
            if model is None:
                continue

            try:
                p = self._predict_model_proba(model, X)

                result[name] = float(p[0])

            except Exception as exc:
                logger.debug(
                    "组件模型 {} 预测失败: {}",
                    name,
                    exc,
                )

        return result

    def save_models(self):
        os.makedirs(self.model_dir, exist_ok=True)

        for name, model in self.models.items():
            if model is not None:
                joblib.dump(
                    model,
                    os.path.join(
                        self.model_dir,
                        f"{name}_{self.version}.pkl",
                    ),
                )

    @staticmethod
    def evaluate_binary(y_true, p_up):
        y_true = np.asarray(y_true)

        p_up = np.clip(
            np.asarray(p_up),
            1e-6,
            1 - 1e-6,
        )

        pred = (
            p_up >= 0.5
        ).astype(int)

        return {
            "accuracy": float(
                (pred == y_true).mean()
            ),
            "logloss": float(
                log_loss(y_true, p_up)
            ),
        }
