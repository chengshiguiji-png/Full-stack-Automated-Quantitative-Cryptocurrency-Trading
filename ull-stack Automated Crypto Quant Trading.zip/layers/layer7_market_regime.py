# -*- coding: utf-8 -*-
"""第7层：市场状态识别。
状态识别只描述市场，不再偷偷修改 ML 模型权重。

2026-09 第一轮修复：加了长窗口(480根/5天)趋势确认，解决"慢阴跌式单边"被误判成
narrow_range/wide_range的问题。

2026-09 第二轮修复（本次）：接入 ADX(14) 和 Kaufman Efficiency Ratio(14) 作为
第二套独立信号，跟原来基于 pct_change 的规则做"双确认"，并新增 transition
（过渡区，不开新仓）状态。

关于阈值：ADX 教科书阈值(20/25)是给股票/外汇设计的，直接套用在15分钟加密货币上
明显偏松——我们用你系统里BTC/ETH/SOL共11个月的15m真实历史数据算过：
ADX(14) 的中位数本身就有 23~25，P70在30~31，P85在37~39；
Efficiency Ratio 的中位数只有0.22，P70在0.33~0.34，P85在0.46~0.47。
也就是说教科书的"ADX>25=趋势"套到这里，会把接近一半的K线都判成趋势，
门槛太松；而ER的教科书阈值(0.6)本身就已经在这个数据集的90分位以上，相当克制。
所以下面的默认阈值是按这11个月真实分布的 P70/P85 校准的，不是照抄教科书数字——
但这只是一个起点，强烈建议你用自己最新几个月的数据重新算一遍分布再校准
（下面 calibrate_thresholds_from_series 这个函数就是干这个用的）。
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from loguru import logger


def calibrate_thresholds_from_series(adx_series: pd.Series, er_series: pd.Series) -> dict:
    """用一段历史 ADX/ER 序列算出建议阈值（P30/P70/P85分位）。
    自己重新校准时调用一次，把结果抄进 config.yaml 的 regime 段落即可。"""
    adx_series = adx_series.dropna()
    er_series = er_series.dropna()
    return {
        "adx_range": round(float(adx_series.quantile(0.30)), 1),
        "adx_trend": round(float(adx_series.quantile(0.70)), 1),
        "adx_strong": round(float(adx_series.quantile(0.85)), 1),
        "er_range": round(float(er_series.quantile(0.30)), 3),
        "er_trend": round(float(er_series.quantile(0.70)), 3),
        "er_strong": round(float(er_series.quantile(0.85)), 3),
    }


class MarketRegimeDetector:
    def __init__(self, config=None):
        self.config = config or {}
        self.default_weights = self.config.get("model_weights", {
            "random_forest": 0.33, "logistic": 0.33, "lightgbm": 0.34
        })
        # 2026-09 第三轮修复：以前 trend48/trend192 是硬编码的"48根K线"/"192根K线"，
        # 在15m下正好是12小时/48小时；如果直接照搬到4h周期（为了做"15m没有alpha，
        # 4h是否有救"这次的对照实验），48根K线会变成8天、192根会变成32天——
        # "strong_up"的实际含义完全变了，不再是同一件事，对照实验就不成立了。
        # 现在按 market.timeframe 换算成"以小时为单位的真实窗口"，两个周期下
        # strong_up/narrow_range 说的是同一个真实世界的时间跨度，只是K线粒度不同。
        timeframe = str((self.config.get("market") or {}).get("timeframe", "15m"))
        bars_per_hour = {"1m": 60, "5m": 12, "15m": 4, "30m": 2, "1h": 1, "4h": 0.25, "1d": 1 / 24}.get(timeframe, 4)
        self.short_window_hours = float(self.config.get("short_window_hours", 12))
        self.medium_window_hours = float(self.config.get("medium_window_hours", 48))
        self.short_window_bars = max(2, round(self.short_window_hours * bars_per_hour))
        self.medium_window_bars = max(self.short_window_bars + 1, round(self.medium_window_hours * bars_per_hour))
        self.long_trend_bars = int(self.config.get("long_trend_bars", round(120 * bars_per_hour)))  # 默认5天，按周期换算
        self.long_trend_threshold = float(self.config.get("long_trend_threshold", 0.02))

        rc = (self.config.get("regime") or {})
        self.adx_period = int(rc.get("adx_period", 14))
        self.er_period = int(rc.get("er_period", 14))
        # 下面这组默认值是按BTC/ETH/SOL真实15m数据的P30/P70/P85校准的，见文件顶部说明。
        self.adx_range = float(rc.get("adx_range", 18.0))
        self.adx_trend = float(rc.get("adx_trend", 30.0))
        self.adx_strong = float(rc.get("adx_strong", 38.0))
        self.er_range = float(rc.get("er_range", 0.12))
        self.er_trend = float(rc.get("er_trend", 0.33))
        self.er_strong = float(rc.get("er_strong", 0.46))
        # True: 要求 ADX 和 ER 同时确认才算趋势(更保守，趋势信号更少但更可信)
        # False(默认): 两者任一确认即可(更灵敏，跟原有基于trend48/trend192的规则做OR组合)
        self.require_dual_confirmation = bool(rc.get("require_dual_confirmation", False))

    def _compute_adx(self, df: pd.DataFrame) -> float:
        period = self.adx_period
        h, l, c = df["high"], df["low"], df["close"]
        if len(df) < period * 2:
            return float("nan")
        up_move = h.diff()
        down_move = -l.diff()
        plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
        minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)
        prev_c = c.shift(1)
        tr = pd.concat([(h - l).abs(), (h - prev_c).abs(), (l - prev_c).abs()], axis=1).max(axis=1)
        atr = tr.ewm(alpha=1 / period, adjust=False).mean()
        plus_di = 100 * pd.Series(plus_dm, index=df.index).ewm(alpha=1 / period, adjust=False).mean() / atr.replace(0, np.nan)
        minus_di = 100 * pd.Series(minus_dm, index=df.index).ewm(alpha=1 / period, adjust=False).mean() / atr.replace(0, np.nan)
        dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
        adx = dx.ewm(alpha=1 / period, adjust=False).mean()
        val = adx.iloc[-1]
        return float(val) if pd.notna(val) else float("nan")

    def _compute_er(self, close: pd.Series) -> float:
        n = self.er_period
        if len(close) < n + 1:
            return float("nan")
        change = abs(close.iloc[-1] - close.iloc[-(n + 1)])
        volatility = close.diff().abs().iloc[-n:].sum()
        if volatility <= 0:
            return float("nan")
        return float(change / volatility)

    def detect_regime(self, df: pd.DataFrame) -> dict:
        if df is None or len(df) < 60:
            return self._default_result()
        close = df["close"]
        ret = close.pct_change().dropna()
        vol20 = float(ret.rolling(20).std().iloc[-1])
        vol96 = float(ret.rolling(96).std().iloc[-1]) if len(ret) >= 96 else vol20
        sw, mw = self.short_window_bars, self.medium_window_bars
        trend48 = float(close.iloc[-1] / close.iloc[-(sw + 1)] - 1) if len(close) >= sw + 1 else 0.0
        trend192 = float(close.iloc[-1] / close.iloc[-(mw + 1)] - 1) if len(close) >= mw + 1 else trend48
        n_long = min(self.long_trend_bars, len(close) - 1)
        trend_long = float(close.iloc[-1] / close.iloc[-(n_long + 1)] - 1) if n_long > 0 else trend48
        vol_ma = df["volume"].rolling(20).mean().iloc[-1]
        volume_surge = float(df["volume"].iloc[-1] / vol_ma) if vol_ma and vol_ma > 0 else 1.0

        adx = self._compute_adx(df)
        er = self._compute_er(close)
        adx_ok = pd.notna(adx)
        er_ok = pd.notna(er)

        adx_confirms_trend = adx_ok and adx >= self.adx_trend
        er_confirms_trend = er_ok and er >= self.er_trend
        adx_confirms_strong = adx_ok and adx >= self.adx_strong
        er_confirms_strong = er_ok and er >= self.er_strong
        adx_confirms_range = adx_ok and adx <= self.adx_range
        er_confirms_range = er_ok and er <= self.er_range

        if self.require_dual_confirmation:
            trend_confirmed = (adx_confirms_trend and er_confirms_trend) if (adx_ok and er_ok) else False
            strong_confirmed = (adx_confirms_strong and er_confirms_strong) if (adx_ok and er_ok) else False
            range_confirmed = (adx_confirms_range and er_confirms_range) if (adx_ok and er_ok) else False
        else:
            trend_confirmed = adx_confirms_trend or er_confirms_trend
            strong_confirmed = adx_confirms_strong or er_confirms_strong
            range_confirmed = (adx_confirms_range or er_confirms_range) if (adx_ok or er_ok) else False

        long_up = trend_long > self.long_trend_threshold
        long_down = trend_long < -self.long_trend_threshold

        rule_strong_up = (trend48 > 0.012 and trend192 > 0) or (long_up and trend192 >= 0)
        rule_strong_down = (trend48 < -0.012 and trend192 < 0) or (long_down and trend192 <= 0)
        rule_trend = abs(trend48) > 0.006

        rc = self.config.get("regime") or {}
        # ⚠️ 这四个波动率量级阈值(以及下面trend48/trend192用到的0.012/0.006/0.004/0.008
        # 涨跌幅阈值本身不受影响，因为那些是"真实世界百分比涨跌"，已经通过上面的
        # short_window_bars/medium_window_bars换算成同样的墙钟时间了)是按15m下
        # 20根K线滚动标准差校准的——如果切到4h，同样20根K线覆盖的是80小时而不是5小时，
        # 同一个数字(0.006)不再代表同样的"波动剧烈程度"。这四个阈值目前还是硬编码默认值，
        # 没有像ADX/ER那样重新用4h真实数据校准过（没有4h的历史数据）。
        # 测4h之前强烈建议：用一段4h真实数据算一遍vol20的P30/P70分布，把下面这几个
        # config.regime.vol_* 覆盖成校准后的数值，否则4h的regime判断可能不准。
        vol_extreme = float(rc.get("vol_extreme_threshold", 0.012))
        vol_volatile = float(rc.get("vol_volatile_threshold", 0.006))
        vol_narrow = float(rc.get("vol_narrow_threshold", 0.0012))
        vol_wide = float(rc.get("vol_wide_threshold", 0.003))

        if vol20 > vol_extreme and volume_surge > 2.0 and abs(trend48) > 0.035:
            regime = "extreme_liquidation"
        elif vol20 > vol_volatile:
            regime = "volatile"
        elif rule_strong_up:
            # 规则本身(trend48/trend192/长窗口)已经判定单边上涨；
            # ADX/ER 双确认成立时升级为 strong_up_confirmed（第17层会因此彻底取消固定止盈），
            # 否则仍然是 strong_up（第17层只放宽移动止损倍数，保留止盈上限，更保守）。
            regime = "strong_up_confirmed" if strong_confirmed else "strong_up"
        elif rule_strong_down:
            regime = "strong_down_confirmed" if strong_confirmed else "strong_down"
        elif rule_trend:
            regime = "trend"
        elif trend_confirmed and not long_up and not long_down:
            # trend48/trend192都不够强，但ADX或ER单独确认了趋势——
            # 归入普通"trend"而不是直接升级到strong，避免仅凭ADX/ER单一读数就大幅改变风控。
            regime = "trend"
        elif self.adx_range > 0 and self.er_range > 0 and adx_ok and er_ok and adx <= self.adx_range and er <= self.er_range and not long_up and not long_down:
            # ADX 和 ER 都明确落在"低效率/低方向性"区间 -> 更有把握的窄幅震荡
            regime = "narrow_range"
        elif vol20 < vol_narrow and abs(trend48) < 0.004 and not long_up and not long_down:
            regime = "narrow_range"
        elif abs(trend48) < 0.008 and vol20 < vol_wide and not long_up and not long_down:
            regime = "wide_range"
        elif adx_ok and er_ok and not range_confirmed and not trend_confirmed:
            # 落在 ADX/ER 的中间地带、规则法也判不出明确方向 —— 对应你提出的"过渡区"，
            # 第10层会在这个状态下直接禁止开新仓，但不影响已有持仓的正常止损/止盈管理。
            regime = "transition"
        else:
            regime = "noise"

        return {
            "market_regime": regime,
            "regime_scores": {regime: 1.0},
            "adjusted_weights": dict(self.default_weights),
            "volatility": vol20,
            "trend_strength": abs(trend48),
            "trend_signed": trend48,
            "trend_long": trend_long,
            "volume_surge": volume_surge,
            "volatility_ratio": vol20 / vol96 if vol96 > 0 else 1.0,
            "adx": adx if adx_ok else None,
            "efficiency_ratio": er if er_ok else None,
            "trend_confirmed": bool(trend_confirmed),
            "strong_confirmed": bool(strong_confirmed),
        }

    def _default_result(self):
        return {
            "market_regime": "narrow_range",
            "regime_scores": {"narrow_range": 1.0},
            "adjusted_weights": dict(self.default_weights),
            "volatility": 0.0,
            "trend_strength": 0.0,
            "trend_signed": 0.0,
            "trend_long": 0.0,
            "volume_surge": 1.0,
            "volatility_ratio": 1.0,
            "adx": None,
            "efficiency_ratio": None,
            "trend_confirmed": False,
            "strong_confirmed": False,
        }
