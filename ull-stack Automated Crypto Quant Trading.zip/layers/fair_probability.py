# -*- coding: utf-8 -*-
"""Transparent probability model for short-horizon BTC Up/Down markets."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional


@dataclass
class FairProbabilityConfig:
    min_sigma: float = 0.00005
    annual_seconds: float = 365.0 * 24.0 * 3600.0
    momentum_weight: float = 0.10
    flow_weight: float = 0.08
    cross_exchange_weight: float = 0.07
    regime_weight: float = 0.05
    uncertainty_floor: float = 0.015
    uncertainty_scale: float = 0.15


def _normal_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


class FairProbabilityModel:
    """Estimate P(terminal BTC price > reference price).

    This is intentionally deterministic and explainable.  It is a first-stage
    model, not a claim that Binance/OKX are the resolution oracle.
    """

    def __init__(self, config: Optional[dict] = None):
        raw = config or {}
        self.cfg = FairProbabilityConfig(
            **{k: raw[k] for k in FairProbabilityConfig.__dataclass_fields__ if k in raw}
        )

    def base_probability(
        self,
        current_price: float,
        reference_price: float,
        seconds_to_expiry: float,
        sigma_annualized: float,
        drift_annualized: float = 0.0,
    ) -> float:
        if current_price <= 0 or reference_price <= 0:
            return 0.5
        t = max(float(seconds_to_expiry), 1.0) / self.cfg.annual_seconds
        sigma = max(abs(float(sigma_annualized)), self.cfg.min_sigma)
        vol_term = sigma * math.sqrt(t)
        if vol_term <= 1e-12:
            return 1.0 if current_price > reference_price else 0.0
        z = (math.log(reference_price / current_price) - drift_annualized * t) / vol_term
        return _clamp(1.0 - _normal_cdf(z), 0.001, 0.999)

    def estimate(
        self,
        *,
        current_price: float,
        reference_price: float,
        seconds_to_expiry: float,
        sigma_annualized: float,
        momentum: float = 0.0,
        flow_imbalance: float = 0.0,
        cross_exchange_return: float = 0.0,
        regime_bias: float = 0.0,
        volatility_shock: float = 0.0,
    ) -> dict:
        base = self.base_probability(
            current_price, reference_price, seconds_to_expiry, sigma_annualized
        )
        # Inputs are normalized externally to roughly [-1, 1].  Keep the
        # adjustment small so the diffusion model remains the anchor.
        adjustment = (
            self.cfg.momentum_weight * _clamp(momentum, -1, 1)
            + self.cfg.flow_weight * _clamp(flow_imbalance, -1, 1)
            + self.cfg.cross_exchange_weight * _clamp(cross_exchange_return, -1, 1)
            + self.cfg.regime_weight * _clamp(regime_bias, -1, 1)
        )
        # Volatility shocks increase uncertainty rather than directly forcing
        # direction.  This avoids turning high volatility into a fake alpha.
        fair = _clamp(base + adjustment, 0.001, 0.999)
        uncertainty = _clamp(
            self.cfg.uncertainty_floor
            + self.cfg.uncertainty_scale * abs(fair - base)
            + 0.5 * self.cfg.uncertainty_scale * max(0.0, 1.0 - min(1.0, seconds_to_expiry / 900.0))
            + 0.03 * _clamp(volatility_shock, 0.0, 1.0),
            0.0,
            0.30,
        )
        conservative_up = _clamp(fair - uncertainty)
        return {
            "base_probability": base,
            "fair_probability": fair,
            "uncertainty": uncertainty,
            "conservative_up": conservative_up,
        }
