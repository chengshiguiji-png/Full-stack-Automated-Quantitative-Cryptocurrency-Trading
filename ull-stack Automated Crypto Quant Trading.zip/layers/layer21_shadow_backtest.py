﻿# layers/layer21_shadow_backtest.py
"""
层21：回测沙盒与影子测试
- 在不实际下单的情况下，使用真实行情模拟策略信号
- 模拟滑点、手续费、延迟
- 记录影子账户权益曲线，与实盘对比
- 新策略上线前必须通过影子测试
"""
import time
import threading
import pandas as pd
import numpy as np
from datetime import datetime
from loguru import logger

class ShadowBacktest:
    def __init__(self, config, symbol="BTC-USDT", initial_capital=100000, fee_rate=0.001, slippage=0.0005, latency_ms=200):
        self.config = config
        self.symbol = symbol
        self.initial_capital = initial_capital
        self.capital = initial_capital
        self.fee_rate = fee_rate
        self.slippage = slippage
        self.latency_ms = latency_ms
        self.position = 0.0
        self.entry_price = 0.0
        self.trades = []
        self.equity_curve = []
        self.lock = threading.Lock()

    def simulate_order(self, side: str, price: float, size: float):
        """模拟订单成交（含滑点和手续费）"""
        time.sleep(self.latency_ms / 1000.0)
        if side.upper() == "BUY":
            fill_price = price * (1 + self.slippage)
        else:
            fill_price = price * (1 - self.slippage)
        return fill_price

    def update(self, signal: dict, current_price: float, timestamp=None):
        """根据信号更新影子账户"""
        with self.lock:
            direction = signal.get("direction", "HOLD")
            if direction == "BUY" and self.position == 0:
                # 用固定金额买入
                usdt_size = min(500, self.capital * 0.05)
                if usdt_size < 10:
                    return
                fill_price = self.simulate_order("BUY", current_price, usdt_size)
                coin_amount = usdt_size / fill_price
                cost = usdt_size * (1 + self.fee_rate)
                if self.capital >= cost:
                    self.capital -= cost
                    self.position = coin_amount
                    self.entry_price = fill_price
                    self.trades.append({
                        "timestamp": timestamp or datetime.now().isoformat(),
                        "side": "BUY",
                        "price": fill_price,
                        "size": coin_amount,
                        "usdt_size": usdt_size
                    })
                    logger.debug(f"影子账户 {self.symbol} 买入 {coin_amount:.6f} @ {fill_price:.2f}")
            elif direction == "SELL" and self.position > 0:
                fill_price = self.simulate_order("SELL", current_price, self.position)
                income = self.position * fill_price * (1 - self.fee_rate)
                pnl = income - (self.position * self.entry_price)
                self.capital += income
                self.trades.append({
                    "timestamp": timestamp or datetime.now().isoformat(),
                    "side": "SELL",
                    "price": fill_price,
                    "size": self.position,
                    "pnl": pnl
                })
                logger.debug(f"影子账户 {self.symbol} 卖出, 盈亏: {pnl:.2f}")
                self.position = 0.0
                self.entry_price = 0.0

    def get_equity(self, current_price: float) -> float:
        """当前总权益"""
        return self.capital + self.position * current_price

    def record_equity(self, current_price: float, timestamp=None):
        """记录权益点"""
        equity = self.get_equity(current_price)
        self.equity_curve.append({
            "timestamp": timestamp or datetime.now().isoformat(),
            "equity": equity
        })

    def get_stats(self):
        """返回影子账户简要统计"""
        total_trades = len([t for t in self.trades if t["side"] == "SELL"])
        if total_trades == 0:
            win_rate = 0
        else:
            wins = sum(1 for t in self.trades if t["side"] == "SELL" and t.get("pnl", 0) > 0)
            win_rate = wins / total_trades
        return {
            "total_trades": total_trades,
            "win_rate": win_rate,
            "capital": self.capital,
            "position": self.position
        }

    def run_parallel(self, signal_queue, price_source, stop_event):
        """
        在独立线程中运行影子测试（从队列获取信号，从price_source获取价格）
        signal_queue: 线程安全队列，接收信号字典
        price_source: 函数，返回当前价格
        stop_event: threading.Event，用于停止
        """
        logger.info(f"影子测试启动: {self.symbol}")
        while not stop_event.is_set():
            try:
                if not signal_queue.empty():
                    signal = signal_queue.get(timeout=1)
                    current_price = price_source(self.symbol)
                    if current_price:
                        self.update(signal, current_price)
                        self.record_equity(current_price)
                else:
                    # 即使无信号，也定时记录权益
                    current_price = price_source(self.symbol)
                    if current_price:
                        self.record_equity(current_price)
                    time.sleep(1)
            except Exception as e:
                logger.error(f"影子测试异常: {e}")
                time.sleep(1)
        logger.info(f"影子测试停止: {self.symbol}")
