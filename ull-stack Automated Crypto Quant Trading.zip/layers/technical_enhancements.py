
import numpy as np
import pandas as pd

def ema(values, period):
    if not isinstance(values, (pd.Series, list, np.ndarray)) or len(values) < period:
        return None
    k = 2 / (period + 1)
    prev = values[0]
    for i in range(1, len(values)):
        prev = values[i] * k + prev * (1 - k)
    return prev

def compute_vwap_series(df):
    typical_price = (df['high'] + df['low'] + df['close']) / 3
    cum_vol = df['volume'].cumsum()
    cum_pv = (typical_price * df['volume']).cumsum()
    return cum_pv / cum_vol

def compute_heiken_ashi(df):
    ha = pd.DataFrame(index=df.index)
    ha['close'] = (df['open'] + df['high'] + df['low'] + df['close']) / 4
    ha['open'] = (df['open'].shift(1) + df['close'].shift(1)) / 2
    ha['open'].iloc[0] = (df['open'].iloc[0] + df['close'].iloc[0]) / 2
    ha['high'] = df[['high', 'open', 'close']].max(axis=1)
    ha['low'] = df[['low', 'open', 'close']].min(axis=1)

    color = np.where(ha['close'] >= ha['open'], 'green', 'red')
    consec_count = 0
    consec_color = None
    if len(color) > 0:
        consec_color = color[-1]
        for c in reversed(color):
            if c == consec_color:
                consec_count += 1
            else:
                break
    return ha, consec_color, consec_count

def compute_rsi_slope(close, period=14):
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(window=period).mean()
    avg_loss = loss.rolling(window=period).mean()
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    rsi_slope = rsi.diff(3)
    return rsi.iloc[-1], rsi_slope.iloc[-1]

def compute_macd(closes, fast=12, slow=26, signal=9):
    if not isinstance(closes, (pd.Series, list, np.ndarray)) or len(closes) < slow + signal:
        return None
    closes_list = list(closes)
    fast_ema = ema(closes_list, fast)
    slow_ema = ema(closes_list, slow)
    if fast_ema is None or slow_ema is None:
        return None

    macd_line = fast_ema - slow_ema

    macd_series = []
    for i in range(len(closes_list)):
        sub = closes_list[:i+1]
        f = ema(sub, fast)
        s = ema(sub, slow)
        if f is not None and s is not None:
            macd_series.append(f - s)

    signal_line = ema(macd_series, signal)
    if signal_line is None:
        return None

    hist = macd_line - signal_line

    prev_hist = None
    if len(macd_series) >= signal + 1:
        prev_macd_series = macd_series[:-1]
        prev_signal = ema(prev_macd_series, signal)
        if prev_signal is not None:
            prev_hist = macd_series[-2] - prev_signal

    return {
        "macd": macd_line,
        "signal": signal_line,
        "hist": hist,
        "hist_delta": hist - prev_hist if prev_hist is not None else None
    }

def count_vwap_crosses(close, vwap_series, lookback=20):
    if len(close) < lookback or len(vwap_series) < lookback:
        return 0
    crosses = 0
    recent_close = close[-lookback:]
    recent_vwap = vwap_series[-lookback:]
    for i in range(1, len(recent_close)):
        prev_diff = recent_close[i-1] - recent_vwap[i-1]
        cur_diff = recent_close[i] - recent_vwap[i]
        if prev_diff == 0:
            continue
        if (prev_diff > 0 and cur_diff < 0) or (prev_diff < 0 and cur_diff > 0):
            crosses += 1
    return crosses

def apply_time_awareness(prob_up, time_left_min, total_min=15):
    if time_left_min is None:
        return prob_up
    ratio = time_left_min / total_min
    return prob_up * ratio + 0.5 * (1 - ratio)
