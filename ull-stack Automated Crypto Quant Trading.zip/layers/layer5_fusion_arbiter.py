﻿from loguru import logger
from collections import defaultdict

class SentimentFusionArbiter:
    def __init__(self):
        self.last_fused = 0.0
        self.trackers = defaultdict(lambda: {"correct": 0, "total": 0})

    def update_accuracy(self, name, signal, is_profit):
        if signal is None: return
        prediction = signal > 0
        self.trackers[name]["total"] += 1
        if (prediction and is_profit) or (not prediction and not is_profit):
            self.trackers[name]["correct"] += 1

    def get_weight(self, name, base_weight):
        t = self.trackers[name]
        if t["total"] < 5:
            return base_weight
        acc = t["correct"] / t["total"]
        return base_weight * (0.5 + acc)

    def fuse(self, v4_score, v4_confidence, external_score, external_confidence, market_regime):
        # 窄幅震荡中 V4 和外部情绪权重各50%
        w_v4_base = 0.5 if market_regime in ("narrow_range","ultra_narrow") else 0.7
        w_ext_base = 0.5 if market_regime in ("narrow_range","ultra_narrow") else 0.3
        w_v4 = self.get_weight("v4", w_v4_base)
        w_ext = self.get_weight("external", w_ext_base)
        total_w = w_v4 + w_ext
        w_v4 /= total_w
        w_ext /= total_w

        conflict = (v4_score > 0 and external_score < 0) or (v4_score < 0 and external_score > 0)
        conflict_penalty = 0.7 if conflict else 1.0

        fused_score = w_v4 * v4_score + w_ext * external_score
        fused_confidence = (w_v4 * v4_confidence + w_ext * external_confidence) * conflict_penalty

        alpha = 0.3
        self.last_fused = alpha * fused_score + (1 - alpha) * self.last_fused
        smoothed_score = self.last_fused

        if conflict:
            logger.info(f"情绪冲突！V4({v4_score:.2f}) vs 外部({external_score:.2f})，"
                        f"动态权重(V4:{w_v4:.2f}, 外:{w_ext:.2f}) 融合 -> {smoothed_score:.2f}")
        else:
            logger.debug(f"情绪一致，融合 -> {smoothed_score:.2f} (V4:{w_v4:.2f}, 外:{w_ext:.2f})")

        return {"fused_sentiment": smoothed_score, "fused_confidence": fused_confidence}