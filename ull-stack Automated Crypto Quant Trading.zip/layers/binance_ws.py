import os
import json
import threading
import time
import websocket
from loguru import logger

class BinanceTradeStream:
    def __init__(self, symbol="btcusdt", on_update=None):
        self.symbol = symbol.lower()
        self.ws_url = f"wss://stream.binance.com:9443/ws/{self.symbol}@trade"
        self.ws = None
        self.last_price = None
        self.last_ts = None
        self._running = False
        self._thread = None
        self.on_update = on_update
        self.proxy_host = None
        self.proxy_port = None
        self._parse_proxy_from_env()

    def _parse_proxy_from_env(self):
        proxy = os.environ.get("HTTPS_PROXY") or os.environ.get("HTTP_PROXY") or os.environ.get("ALL_PROXY")
        if not proxy:
            return
        try:
            from urllib.parse import urlparse
            parsed = urlparse(proxy)
            self.proxy_host = parsed.hostname
            self.proxy_port = parsed.port
            self.proxy_type = parsed.scheme
        except Exception as e:
            logger.warning(f"Failed to parse proxy from env: {e}")

    def _on_message(self, ws, message):
        try:
            data = json.loads(message)
            price = float(data.get("p", 0))
            if price > 0:
                self.last_price = price
                self.last_ts = time.time()
                if self.on_update:
                    self.on_update(price, self.last_ts)
        except Exception as e:
            logger.error(f"Binance WS message error: {e}")

    def _on_error(self, ws, error):
        logger.warning(f"Binance WS error: {error}")

    def _on_close(self, ws, close_status_code, close_msg):
        logger.warning("Binance WS closed, reconnecting...")
        if self._running:
            time.sleep(5)
            self._connect()

    def _on_open(self, ws):
        logger.info("Binance WS connected")

    def _connect(self):
        kwargs = {
            "on_message": self._on_message,
            "on_error": self._on_error,
            "on_close": self._on_close,
            "on_open": self._on_open,
        }
        if self.proxy_host and self.proxy_port:
            kwargs["http_proxy_host"] = self.proxy_host
            kwargs["http_proxy_port"] = self.proxy_port
            if hasattr(self, "proxy_type") and self.proxy_type.startswith("socks"):
                try:
                    import socks
                    kwargs["proxy_type"] = socks.SOCKS5
                except ImportError:
                    logger.warning("Need PySocks for socks5 proxy, falling back to HTTP proxy")
        self.ws = websocket.WebSocketApp(self.ws_url, **kwargs)
        self.ws.run_forever()

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._connect, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False
        if self.ws:
            self.ws.close()

    def get_last(self):
        return {"price": self.last_price, "ts": self.last_ts}
