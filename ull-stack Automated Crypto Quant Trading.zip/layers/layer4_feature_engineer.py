# -*- coding: utf-8 -*-
"""第4层：因果、固定命名的特征工程。
所有特征只使用当前及历史数据，不读取未来信息。
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from loguru import logger


class FeatureEngineer:
    def __init__(self, config=None):
        self.config = config or {}

    def calculate_features(self, df: pd.DataFrame, funding_df: pd.DataFrame = None) -> pd.DataFrame:
        if df is None or df.empty:
            return pd.DataFrame()
        df = df.sort_values("timestamp").reset_index(drop=True).copy()
        close, high, low, volume = df["close"], df["high"], df["low"], df["volume"]
        ret = close.pct_change()

        # 基础/动量
        df["ret_1"] = close.pct_change(1)
        df["ret_3"] = close.pct_change(3)
        df["ret_12"] = close.pct_change(12)
        df["roc_24"] = close.pct_change(24)
        df["momentum_accel"] = df["ret_3"] - df["ret_3"].shift(3)

        # RSI（保留旧接口 rsi，并提供主策略常用别名 rsi_14）
        delta = close.diff()
        gain = delta.clip(lower=0).rolling(14, min_periods=14).mean()
        loss = (-delta.clip(upper=0)).rolling(14, min_periods=14).mean()
        rs = gain / loss.replace(0, np.nan)
        df["rsi_14"] = (100 - 100 / (1 + rs)).fillna(50.0)
        df["rsi"] = df["rsi_14"]
        df["rsi_slope"] = df["rsi_14"].diff(3)

        # EMA / MACD
        ema12 = close.ewm(span=12, adjust=False).mean()
        ema26 = close.ewm(span=26, adjust=False).mean()
        df["macd"] = ema12 - ema26
        df["macd_signal"] = df["macd"].ewm(span=9, adjust=False).mean()
        df["macd_hist"] = df["macd"] - df["macd_signal"]
        df["macd_hist_delta"] = df["macd_hist"].diff()

        # Bollinger
        mid = close.rolling(20, min_periods=20).mean()
        std = close.rolling(20, min_periods=20).std()
        df["bb_mid"] = mid
        df["bb_middle"] = mid
        df["bb_upper"] = mid + 2 * std
        df["bb_lower"] = mid - 2 * std
        df["bb_width"] = (df["bb_upper"] - df["bb_lower"]) / mid.replace(0, np.nan)
        df["bb_pos"] = (close - df["bb_lower"]) / (df["bb_upper"] - df["bb_lower"]).replace(0, np.nan)

        # ATR
        prev_close = close.shift(1)
        tr = pd.concat([(high - low), (high - prev_close).abs(), (low - prev_close).abs()], axis=1).max(axis=1)
        df["atr_14"] = tr.rolling(14, min_periods=14).mean()
        df["atr"] = df["atr_14"]
        df["atr_pct_14"] = df["atr_14"] / close
        df["atr_pct"] = df["atr_pct_14"]

        # 旧模型使用的列名别名
        df["volatility_5"] = ret.rolling(5, min_periods=5).std()
        df["volatility_10"] = ret.rolling(10, min_periods=10).std()
        df["volatility_20"] = ret.rolling(20, min_periods=20).std()

        # 波动率（年化不是必须，另保留原始尺度）
        for p in (5, 10, 20, 48, 96):
            df[f"volatility_{p}"] = ret.rolling(p, min_periods=p).std()
        df["volatility"] = df["volatility_20"]
        df["volatility_ratio"] = df["volatility_20"] / df["volatility_96"].replace(0, np.nan)

        # 兼容原模型特征命名
        roll_low = low.rolling(14, min_periods=14).min()
        roll_high = high.rolling(14, min_periods=14).max()
        df["stoch_k"] = 100 * (close - roll_low) / (roll_high - roll_low).replace(0, np.nan)
        tp20 = (high + low + close) / 3
        sma20 = tp20.rolling(20, min_periods=20).mean()
        mad20 = tp20.rolling(20, min_periods=20).apply(lambda x: np.mean(np.abs(x - np.mean(x))), raw=True)
        df["cci"] = (tp20 - sma20) / (0.015 * mad20 + 1e-12)
        df["obv"] = (np.sign(close.diff()).fillna(0) * volume).cumsum()

        # 成交量
        vol_ma20 = volume.rolling(20, min_periods=20).mean()
        df["vol_ratio_20"] = volume / vol_ma20.replace(0, np.nan)
        df["vol_ratio"] = df["vol_ratio_20"]
        df["quote_volume"] = pd.to_numeric(df.get("quote_volume", volume * close), errors="coerce")

        # 价量/订单流估计（不是盘口，明确标记为 proxy）
        bar_range = (high - low).replace(0, np.nan)
        close_pos = ((close - low) / bar_range).clip(0, 1).fillna(0.5)
        df["close_position"] = close_pos
        df["signed_volume"] = volume * (2 * close_pos - 1)
        df["order_flow_imbalance"] = df["signed_volume"].rolling(20, min_periods=20).mean()
        df["cumulative_delta"] = df["signed_volume"].cumsum()

        # VWAP：使用当前窗口累积，避免启动时跨越未知历史；主策略保留 vwap/vwap_gap
        tp = (high + low + close) / 3
        vwap_num = (tp * volume).rolling(96, min_periods=1).sum()
        vwap_den = volume.rolling(96, min_periods=1).sum()
        df["vwap"] = vwap_num / vwap_den.replace(0, np.nan)
        df["vwap_gap"] = (close - df["vwap"]) / df["vwap"].replace(0, np.nan)

        # 统计与趋势
        df["ema_gap_20"] = close / close.ewm(span=20, adjust=False).mean() - 1
        df["trend_48"] = close / close.shift(48) - 1
        long_trend = int(self.config.get("long_trend_period", 96))
        long_trend = max(48, min(long_trend, 192))
        df[f"trend_{long_trend}"] = close / close.shift(long_trend) - 1
        df["range_pct"] = (high - low) / close
        df["return_skew_20"] = ret.rolling(20, min_periods=20).skew()
        df["return_kurt_20"] = ret.rolling(20, min_periods=20).kurt()
        df["corr_price_volume_20"] = close.rolling(20, min_periods=20).corr(volume)
        df["return_skew"] = df["return_skew_20"]
        df["return_kurt"] = df["return_kurt_20"]
        df["corr_price_volume"] = df["corr_price_volume_20"]

        # 对兼容旧代码提供常用列
        if "sar" not in df.columns:
            df["sar"] = low.rolling(5, min_periods=1).min()

        # 资金费率特征（免费数据源，OKX永续合约公开接口）——2026-09新增，验证是否对
        # 方向预测有增量信息。用 merge_asof(direction="backward") 保证每根K线只用
        # "当时已经公布"的资金费率，不会用到未来才公布的值，不引入前视偏差。
        # funding_df 为 None（默认）时完全不影响原有特征集，向后兼容。
        if funding_df is not None and not funding_df.empty:
            fdf = funding_df.sort_values("timestamp")
            df = pd.merge_asof(df, fdf[["timestamp", "funding_rate"]], on="timestamp", direction="backward")
            df["funding_rate"] = df["funding_rate"].ffill().fillna(0.0)
            fr_mean = df["funding_rate"].rolling(96, min_periods=20).mean()
            fr_std = df["funding_rate"].rolling(96, min_periods=20).std()
            df["funding_rate_zscore"] = ((df["funding_rate"] - fr_mean) / fr_std.replace(0, np.nan)).fillna(0.0)
        # funding_df 为 None（默认）时完全不新增这两列，特征总数、SelectKBest的候选集
        # 都跟以前完全一样，100%向后兼容——不会因为这次改动就让已有的训练结果对不上。

        logger.debug("特征工程完成: {} 行, {} 列", len(df), len(df.columns))
        return df

    # 兼容旧接口
    def _calculate_rsi(self, prices, window=14):
        delta = prices.diff()
        gain = delta.clip(lower=0).rolling(window).mean()
        loss = (-delta.clip(upper=0)).rolling(window).mean()
        rs = gain / loss.replace(0, np.nan)
        return 100 - 100 / (1 + rs)
