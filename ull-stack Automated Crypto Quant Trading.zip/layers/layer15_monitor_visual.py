# -*- coding: utf-8 -*-
"""第15层：监控、告警与人工熔断。"""
from __future__ import annotations

import json
import os
import secrets
from datetime import datetime
from loguru import logger


class MonitorSystem:
    def __init__(self, config=None):
        self.config = config or {}
        self.alert_webhook = self.config.get("alert_webhook")
        self.health_scores = []
        self.trade_log = []
        self.error_log = []
        self.emergency_stop = False

    def log_trade(self, trade_info):
        payload = dict(trade_info)
        payload["timestamp"] = datetime.now().isoformat()
        self.trade_log.append(payload)
        os.makedirs("logs/trade_log", exist_ok=True)
        with open(f"logs/trade_log/{datetime.now().date()}.json", "a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False, default=str) + "\n")

    def log_error(self, error_info):
        payload = dict(error_info)
        payload["timestamp"] = datetime.now().isoformat()
        self.error_log.append(payload)
        logger.error("错误记录: %s", payload)
        os.makedirs("logs/error_log", exist_ok=True)
        with open(f"logs/error_log/{datetime.now().date()}.json", "a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False, default=str) + "\n")
        self._send_alert(f"错误告警: {payload.get('message', '')}")

    def _send_alert(self, message: str):
        logger.warning("⚠️ %s", message)
        # Webhook 在原系统中只是占位；本版本不在监控线程中做阻塞请求。

    def calculate_health_score(self, daily_pnl, sharpe, max_drawdown):
        score = 50.0
        score += max(-25, min(25, float(daily_pnl) * 1000))
        score += max(-20, min(20, (float(sharpe) - 1) * 10))
        dd = abs(float(max_drawdown))
        score += 20 if dd < 0.05 else 10 if dd < 0.10 else -20
        score = max(0, min(100, score))
        self.health_scores.append({"date": datetime.now().date().isoformat(), "score": score})
        if score < 40:
            self._send_alert(f"策略健康度过低: {score:.0f}")
        return score

    def emergency_action(self, action: str, auth_token: str | None = None):
        configured = os.environ.get("QUANT_ADMIN_TOKEN") or self.config.get("admin_token")
        if not configured or not auth_token or not secrets.compare_digest(str(auth_token), str(configured)):
            return {"success": False, "message": "权限校验失败"}
        if action == "pause":
            self.emergency_stop = True
            self._send_alert("策略已全局暂停")
            return {"success": True, "message": "策略已暂停"}
        if action == "resume":
            self.emergency_stop = False
            self._send_alert("策略已恢复")
            return {"success": True, "message": "策略已恢复"}
        if action == "status":
            return {"success": True, "status": "paused" if self.emergency_stop else "running"}
        return {"success": False, "message": "未知操作"}

    def get_visualization_data(self):
        return {
            "health_scores": self.health_scores[-30:],
            "trade_count": len(self.trade_log),
            "error_count": len(self.error_log),
            "emergency_stop": self.emergency_stop,
            "last_update": datetime.now().isoformat(),
        }
