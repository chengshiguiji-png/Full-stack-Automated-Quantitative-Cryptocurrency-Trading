# -*- coding: utf-8 -*-
"""Read-only multi-venue market-data bus for shadow research.

Owns public WebSocket feeds only.  It never places orders and never makes a
trade decision.  The bus keeps separate price tapes per venue so volatility
and returns cannot accidentally mix Binance and OKX observations.
"""
from __future__ import annotations

import json
import math
import threading
import time
from collections import deque
from typing import Any, Optional

from loguru import logger

try:
    import websocket
except ImportError:  # pragma: no cover
    websocket = None


class MarketDataBus:
    BINANCE_WS = "wss://stream.binance.com:9443/ws"
    OKX_WS = "wss://ws.okx.com:8443/ws/v5/public"

    def __init__(self, symbol: str = "BTC-USDT", history_size: int = 2000):
        self.symbol = symbol
        self.binance_symbol = symbol.replace("-", "").lower()
        self.okx_symbol = symbol
        self.history_size = int(history_size)
        self.state: dict[str, Any] = {
            "timestamp": 0.0,
            "binance": {"price": None, "bid": None, "ask": None, "trade_ts": None},
            "okx": {"price": None, "bid": None, "ask": None, "trade_ts": None, "bids": [], "asks": []},
            "polymarket": {},
        }
        self._history: dict[str, deque[tuple[float, float]]] = {
            "binance": deque(maxlen=self.history_size),
            "okx": deque(maxlen=self.history_size),
        }
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._threads: list[threading.Thread] = []
        self._sockets: list[Any] = []
        self.polymarket = None

    def _update(self, venue: str, values: dict[str, Any]) -> None:
        with self._lock:
            self.state[venue].update(values)
            self.state["timestamp"] = time.time()
            price = self.state[venue].get("price")
            if price is not None and float(price) > 0:
                ts = float(values.get("trade_ts") or time.time())
                self._history[venue].append((ts, float(price)))

    def _binance_loop(self) -> None:
        if websocket is None:
            logger.error("websocket-client is not installed")
            return
        # One connection can subscribe to both trade and bookTicker.
        url = f"wss://stream.binance.com:9443/stream?streams={self.binance_symbol}@trade/{self.binance_symbol}@bookTicker"
        while not self._stop.is_set():
            try:
                def on_message(_ws, message):
                    data = json.loads(message)
                    # Combined-stream payloads wrap the event under `data`.
                    if isinstance(data.get("data"), dict):
                        data = data["data"]
                    event = data.get("e")
                    if event == "trade":
                        self._update("binance", {
                            "price": float(data["p"]),
                            "trade_ts": float(data.get("T", int(time.time() * 1000))) / 1000.0,
                        })
                    elif event == "bookTicker":
                        bid = float(data["b"])
                        ask = float(data["a"])
                        self._update("binance", {
                            "bid": bid,
                            "ask": ask,
                            "price": (bid + ask) / 2.0,
                            "book_ts": float(data.get("E", int(time.time() * 1000))) / 1000.0,
                        })

                ws = websocket.WebSocketApp(url, on_message=on_message)
                self._sockets.append(ws)
                ws.run_forever(ping_interval=20, ping_timeout=10)
            except Exception as exc:
                logger.warning("Binance WS error: {}", exc)
            if not self._stop.is_set():
                self._stop.wait(2.0)

    def _okx_loop(self) -> None:
        if websocket is None:
            return
        while not self._stop.is_set():
            try:
                def on_open(ws):
                    ws.send(json.dumps({
                        "op": "subscribe",
                        "args": [
                            {"channel": "trades", "instId": self.okx_symbol},
                            {"channel": "books5", "instId": self.okx_symbol},
                        ],
                    }))

                def on_message(_ws, message):
                    data = json.loads(message)
                    arg = data.get("arg", {})
                    channel = arg.get("channel")
                    for item in data.get("data", []):
                        if channel == "trades":
                            self._update("okx", {
                                "price": float(item.get("px")),
                                "trade_ts": float(item.get("ts", int(time.time() * 1000))) / 1000.0,
                            })
                        elif channel == "books5":
                            bids = [(float(x[0]), float(x[1])) for x in item.get("bids", []) if len(x) >= 2]
                            asks = [(float(x[0]), float(x[1])) for x in item.get("asks", []) if len(x) >= 2]
                            values: dict[str, Any] = {"bids": bids, "asks": asks}
                            if bids:
                                values["bid"] = bids[0][0]
                            if asks:
                                values["ask"] = asks[0][0]
                            if bids and asks:
                                values["price"] = (bids[0][0] + asks[0][0]) / 2.0
                            values["book_ts"] = float(item.get("ts", int(time.time() * 1000))) / 1000.0
                            self._update("okx", values)

                ws = websocket.WebSocketApp(self.OKX_WS, on_open=on_open, on_message=on_message)
                self._sockets.append(ws)
                ws.run_forever(ping_interval=20, ping_timeout=10)
            except Exception as exc:
                logger.warning("OKX WS error: {}", exc)
            if not self._stop.is_set():
                self._stop.wait(2.0)

    def attach_polymarket(self, provider: Any) -> None:
        self.polymarket = provider

        def callback(event: dict[str, Any]) -> None:
            with self._lock:
                event_type = str(event.get("type", "event"))
                self.state["polymarket"][event_type] = event
                self.state["polymarket"]["timestamp"] = time.time()

        provider.on_update = callback

    def start(self, enable_binance: bool = True, enable_okx: bool = True) -> None:
        self._stop.clear()
        if enable_binance:
            t = threading.Thread(target=self._binance_loop, name="md-binance", daemon=True)
            t.start(); self._threads.append(t)
        if enable_okx:
            t = threading.Thread(target=self._okx_loop, name="md-okx", daemon=True)
            t.start(); self._threads.append(t)

    def stop(self) -> None:
        self._stop.set()
        for ws in self._sockets:
            try:
                ws.close()
            except Exception:
                pass
        self._sockets.clear()
        for t in self._threads:
            if t.is_alive():
                t.join(timeout=0.2)
        self._threads.clear()

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return json.loads(json.dumps(self.state, default=str))

    def _return(self, venue: str, lookback_sec: float) -> float:
        now = time.time()
        with self._lock:
            tape = list(self._history[venue])
            current = self.state[venue].get("price")
        if not current or len(tape) < 2:
            return 0.0
        target = now - float(lookback_sec)
        prior = min(tape, key=lambda x: abs(x[0] - target))
        if prior[1] <= 0:
            return 0.0
        return float(current) / prior[1] - 1.0

    def venue_return(self, venue: str, lookback_sec: float = 5.0) -> float:
        return max(-0.05, min(0.05, self._return(venue, lookback_sec)))

    def binance_return(self, lookback_sec: float = 5.0) -> float:
        return self.venue_return("binance", lookback_sec)

    def okx_return(self, lookback_sec: float = 5.0) -> float:
        return self.venue_return("okx", lookback_sec)

    def okx_flow_imbalance(self) -> float:
        with self._lock:
            bids = list(self.state["okx"].get("bids") or [])
            asks = list(self.state["okx"].get("asks") or [])
        bid = sum(max(0.0, q) for _, q in bids)
        ask = sum(max(0.0, q) for _, q in asks)
        total = bid + ask
        return (bid - ask) / total if total > 0 else 0.0

    def realized_vol_annualized(self, venue: str = "binance", lookback_sec: float = 60.0) -> float:
        with self._lock:
            cutoff = time.time() - float(lookback_sec)
            points = [(ts, px) for ts, px in self._history[venue] if ts >= cutoff and px > 0]
        if len(points) < 3:
            return 0.50
        returns = [math.log(b / a) for (_, a), (_, b) in zip(points, points[1:]) if a > 0 and b > 0]
        if len(returns) < 2:
            return 0.50
        mean = sum(returns) / len(returns)
        var = sum((x - mean) ** 2 for x in returns) / max(1, len(returns) - 1)
        # Returns are irregularly timed; normalize by median observation gap.
        gaps = [b[0] - a[0] for a, b in zip(points, points[1:]) if b[0] > a[0]]
        dt_sec = max(0.05, min(10.0, sorted(gaps)[len(gaps) // 2] if gaps else 1.0))
        per_second = math.sqrt(max(var, 0.0) / dt_sec)
        return max(0.05, min(5.0, per_second * math.sqrt(365.0 * 24.0 * 3600.0)))

    def cross_exchange_return(self, lookback_sec: float = 5.0) -> float:
        """Normalized Binance-vs-OKX lead/lag disagreement, not a price signal by itself."""
        br = self.binance_return(lookback_sec)
        orr = self.okx_return(lookback_sec)
        return max(-1.0, min(1.0, (br - orr) / 0.002))

    def feature_snapshot(self) -> dict[str, float]:
        """Return bounded, model-ready short-horizon features."""
        return {
            "binance_return_1s": self.binance_return(1.0),
            "binance_return_3s": self.binance_return(3.0),
            "binance_return_5s": self.binance_return(5.0),
            "binance_return_10s": self.binance_return(10.0),
            "okx_return_1s": self.okx_return(1.0),
            "okx_return_5s": self.okx_return(5.0),
            "okx_flow_imbalance": self.okx_flow_imbalance(),
            "cross_exchange_return": self.cross_exchange_return(5.0),
            "realized_vol_60s": self.realized_vol_annualized("binance", 60.0),
        }
