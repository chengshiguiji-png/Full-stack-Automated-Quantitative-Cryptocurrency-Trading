# -*- coding: utf-8 -*-
"""Read-only Polymarket Alpha Engine.

Turns a fair probability estimate and a CLOB order book into a conservative,
fee-aware, executable edge.  This module never places orders.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class AlphaConfig:
    # Conservative defaults for paper/shadow validation.
    fee_rate: float = 0.07
    slippage_bps: float = 2.0
    latency_bps: float = 1.0
    min_net_edge: float = 0.025
    min_liquidity: float = 10.0
    max_spread: float = 0.08
    max_book_age_sec: float = 3.0
    uncertainty_multiplier: float = 1.0
    max_depth_levels: int = 10


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


def _walk_asks(asks: list[tuple[float, float]], size: float) -> tuple[Optional[float], float]:
    """Return VWAP and filled size when buying from asks."""
    remaining = max(float(size), 0.0)
    if remaining <= 0:
        return None, 0.0
    cost = 0.0
    filled = 0.0
    for price, qty in asks:
        take = min(float(qty), remaining)
        if take <= 0:
            continue
        cost += float(price) * take
        filled += take
        remaining -= take
        if remaining <= 1e-12:
            break
    return (cost / filled if filled > 0 else None), filled


class PolymarketAlphaEngine:
    """Evaluate YES and NO opportunities using executable prices."""

    def __init__(self, config: Optional[dict[str, Any]] = None):
        raw = config or {}
        fields = AlphaConfig.__dataclass_fields__
        self.cfg = AlphaConfig(**{k: raw[k] for k in fields if k in raw})

    def _cost_bps(self) -> float:
        return self.cfg.slippage_bps + self.cfg.latency_bps

    def _evaluate_side(
        self,
        *,
        side: str,
        fair_probability: float,
        uncertainty: float,
        asks: list[tuple[float, float]],
        requested_size: float,
        book_age_sec: float,
    ) -> dict[str, Any]:
        # For NO, probability is P(down) and the NO book is already expressed
        # in NO-token prices, so the same executable-price math applies.
        fair = _clamp(fair_probability if side == "YES" else 1.0 - fair_probability)
        conservative_fair = _clamp(fair - self.cfg.uncertainty_multiplier * max(0.0, uncertainty))
        vwap, filled = _walk_asks(asks[: self.cfg.max_depth_levels], requested_size)

        if vwap is None:
            return self._result(side, fair, conservative_fair, None, 0.0, 0.0, filled, "NO_LIQUIDITY")

        spread = None
        # Caller may provide this through book metadata; edge calculation does
        # not need midpoint, but spread remains a hard execution-quality gate.
        gross_edge = conservative_fair - vwap
        # Polymarket crypto taker fee is charged in USDC as
        # C * feeRate * p * (1-p), not as a flat percentage of notional.
        fee = float(filled) * self.cfg.fee_rate * vwap * (1.0 - vwap)
        market_cost = vwap * self._cost_bps() / 10_000.0
        fee_per_share = fee / max(float(filled), 1e-12)
        net_edge = gross_edge - fee_per_share - market_cost

        reason = "OK"
        tradeable = True
        if filled + 1e-12 < requested_size:
            tradeable = False
            reason = "INSUFFICIENT_DEPTH"
        elif book_age_sec > self.cfg.max_book_age_sec:
            tradeable = False
            reason = "STALE_BOOK"
        elif net_edge < self.cfg.min_net_edge:
            tradeable = False
            reason = "EDGE_TOO_SMALL"

        return self._result(
            side, fair, conservative_fair, vwap, gross_edge, net_edge,
            filled, reason, tradeable=tradeable, fee=fee, market_cost=market_cost,
        )

    @staticmethod
    def _result(
        side: str,
        fair: float,
        conservative_fair: float,
        executable_price: Optional[float],
        gross_edge: float,
        net_edge: float,
        filled_size: float,
        reason: str,
        *,
        tradeable: bool = False,
        fee: float = 0.0,
        market_cost: float = 0.0,
    ) -> dict[str, Any]:
        return {
            "side": side,
            "fair_probability": fair,
            "conservative_fair": conservative_fair,
            "executable_price": executable_price,
            "gross_edge": gross_edge,
            "fee": fee,
            "market_cost": market_cost,
            "net_edge": net_edge,
            "filled_size": filled_size,
            "tradeable": tradeable,
            "reason": reason,
        }

    def evaluate(
        self,
        *,
        fair_probability: float,
        uncertainty: float,
        yes_book: dict[str, Any],
        no_book: dict[str, Any],
        requested_size: float = 10.0,
        timestamp: Optional[float] = None,
    ) -> dict[str, Any]:
        """Evaluate both sides and return the best executable opportunity.

        The input books are expected to contain ``asks`` as ``[(price,size),
        ...]`` plus ``best_bid``, ``best_ask`` and ``timestamp`` where known.
        """
        now = __import__("time").time() if timestamp is None else float(timestamp)
        results = []
        for side, book in (("YES", yes_book), ("NO", no_book)):
            asks = list(book.get("asks") or [])
            best_ask = book.get("best_ask")
            best_bid = book.get("best_bid")
            book_ts = float(book.get("timestamp") or 0.0)
            age = max(0.0, now - book_ts) if book_ts > 0 else float("inf")
            spread = (float(best_ask) - float(best_bid)) if best_ask is not None and best_bid is not None else None
            result = self._evaluate_side(
                side=side,
                fair_probability=fair_probability,
                uncertainty=uncertainty,
                asks=asks,
                requested_size=requested_size,
                book_age_sec=age,
            )
            result.update({"book_age_sec": age, "spread": spread, "best_ask": best_ask, "best_bid": best_bid})
            if spread is None:
                result["tradeable"] = False
                result["reason"] = "NO_TWO_SIDED_BOOK"
            elif spread > self.cfg.max_spread:
                result["tradeable"] = False
                result["reason"] = "SPREAD_TOO_WIDE"
            results.append(result)

        # Never trade when the conservative estimates do not provide a clear
        # positive edge. Tie -> NO_TRADE to avoid arbitrary direction choice.
        candidates = [r for r in results if r["tradeable"]]
        candidates.sort(key=lambda r: r["net_edge"], reverse=True)
        best = candidates[0] if candidates else None
        return {
            "tradeable": best is not None,
            "direction": best["side"] if best else "NO_TRADE",
            "net_edge": best["net_edge"] if best else 0.0,
            "best": best,
            "yes": results[0],
            "no": results[1],
            "requested_size": float(requested_size),
        }
