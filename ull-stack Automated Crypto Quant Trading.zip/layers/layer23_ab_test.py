# -*- coding: utf-8 -*-
"""第23层：模型候选验证。
只接受外部提供的真实 OOS 统计，不做随机替换。
"""
from __future__ import annotations


class ModelABTest:
    def __init__(self, model_name="ensemble_model"):
        self.model_name = model_name
        self.stats = {
            "new_model": {"correct": 0, "total": 0},
            "old_model": {"correct": 0, "total": 0},
        }
        self.min_samples = 100
        self.improvement_threshold = 0.02

    def has_new_model(self):
        return False

    def update_accuracy(self, predicted_up, actual_up, is_new_model=True):
        key = "new_model" if is_new_model else "old_model"
        self.stats[key]["total"] += 1
        self.stats[key]["correct"] += int(bool(predicted_up) == bool(actual_up))

    def evaluate_and_replace(self):
        new, old = self.stats["new_model"], self.stats["old_model"]
        if new["total"] < self.min_samples or old["total"] < self.min_samples:
            return False
        new_acc = new["correct"] / new["total"]
        old_acc = old["correct"] / old["total"]
        return new_acc >= old_acc + self.improvement_threshold
