# -*- coding: utf-8 -*-
"""Polymarket read-only realtime market-data adapter.

Gamma -> active BTC Up/Down market discovery
CLOB REST -> initial orderbook snapshot
CLOB Market WSS -> realtime book/trade updates
Data API v2 /status -> health/lag monitoring

This module is read-only and never places Polymarket orders.
"""

from __future__ import annotations

import datetime as dt
import json
import os
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional
from urllib.parse import urlparse

import requests
from loguru import logger

try:
    import websocket
except ImportError:
    websocket = None


@dataclass
class Book:
    bids: list[tuple[float, float]] = field(default_factory=list)
    asks: list[tuple[float, float]] = field(default_factory=list)
    timestamp: float = 0.0
    server_timestamp: Optional[float] = None
    hash: Optional[str] = None
    min_order_size: Optional[float] = None
    tick_size: Optional[float] = None

    @property
    def best_bid(self) -> Optional[float]:
        return self.bids[0][0] if self.bids else None

    @property
    def best_ask(self) -> Optional[float]:
        return self.asks[0][0] if self.asks else None

    @property
    def spread(self) -> Optional[float]:
        if self.best_bid is None or self.best_ask is None:
            return None
        return max(0.0, self.best_ask - self.best_bid)

    @property
    def midpoint(self) -> Optional[float]:
        if self.best_bid is None or self.best_ask is None:
            return None
        return (self.best_bid + self.best_ask) / 2.0


class PolymarketCLOB:
    GAMMA_URL = "https://gamma-api.polymarket.com/markets"
    GAMMA_EVENT_SLUG_URL = "https://gamma-api.polymarket.com/events/slug/{slug}"
    BOOK_URL = "https://clob.polymarket.com/book"
    STATUS_URL = "https://data-api.polymarket.com/v2/status"
    WS_URL = "wss://ws-subscriptions-clob.polymarket.com/ws/market"

    def __init__(
        self,
        refresh_sec=30.0,
        request_timeout=10.0,
        proxy_url=None,
        ws_stale_sec=30.0,
        status_interval_sec=20.0,
        status_max_lag_sec=30.0,
    ):
        self.refresh_sec = float(refresh_sec)
        self.request_timeout = float(request_timeout)
        self.http_retries = 4
        self.ws_stale_sec = float(ws_stale_sec)
        self.status_interval_sec = float(status_interval_sec)
        self.status_max_lag_sec = float(status_max_lag_sec)

        self.proxy_url = (
            proxy_url
            if proxy_url is not None
            else os.getenv(
                "POLYMARKET_PROXY",
                "http://127.0.0.1:12450",
            )
        ).strip()

        self.session = requests.Session()
        self.session.trust_env = False

        if self.proxy_url:
            self.session.proxies.update({
                "http": self.proxy_url,
                "https": self.proxy_url,
            })

        self._lock = threading.RLock()
        self._stop = threading.Event()

        self._market_cache = {
            "ts": 0.0,
            "market": None,
        }

        self.books: dict[str, Book] = {}
        self.last_trades: dict[str, dict[str, Any]] = {}

        self._subscribed_assets: list[str] = []

        self._ws = None
        self._ws_thread = None
        self._watchdog_thread = None

        self._connected = False
        self._last_ws_activity = 0.0
        self._last_market_event = 0.0
        self._last_ws_error = None
        self._last_ws_close = None

        self._status_checked = 0.0

        self._status = {
            "ok": False,
            "age_seconds": None,
            "lag_seconds": None,
            "worst": None,
            "checked_at": None,
            "error": None,
        }

        self._last_gamma_ok = 0.0
        self._last_clob_ok = 0.0

        self.on_update: Optional[
            Callable[[dict[str, Any]], None]
        ] = None

        logger.info(
            "Polymarket network proxy={}",
            self._masked_proxy(),
        )

    def _masked_proxy(self):
        if not self.proxy_url:
            return "DIRECT"

        try:
            p = urlparse(self.proxy_url)

            if p.hostname and p.port:
                return (
                    f"{p.scheme}://"
                    f"{p.hostname}:"
                    f"{p.port}"
                )

            if p.hostname:
                return (
                    f"{p.scheme}://"
                    f"{p.hostname}"
                )

        except Exception:
            pass

        return "configured"

    @staticmethod
    def _jsonish(value):
        if isinstance(value, (list, dict)):
            return value

        if isinstance(value, str):
            try:
                return json.loads(value)
            except Exception:
                return value

        return value

    @staticmethod
    def _parse_dt(value):
        if not value:
            return None

        try:
            parsed = dt.datetime.fromisoformat(
                str(value).replace(
                    "Z",
                    "+00:00",
                )
            )

            if parsed.tzinfo is None:
                parsed = parsed.replace(
                    tzinfo=dt.timezone.utc
                )

            return parsed

        except Exception:
            return None

    @staticmethod
    def _epoch(value):
        try:
            x = float(value)

            if x > 10_000_000_000:
                x /= 1000.0

            return x

        except Exception:
            return None

    # ============================================================
    # HTTP retry layer
    # ============================================================

    def _get_json(
        self,
        url,
        params=None,
    ):
        last_error = None

        for attempt in range(
            1,
            self.http_retries + 1,
        ):
            try:
                response = self.session.get(
                    url,
                    params=params,
                    timeout=self.request_timeout,
                )

                response.raise_for_status()

                return response.json()

            except Exception as exc:
                last_error = exc

                if attempt >= self.http_retries:
                    break

                delay = min(
                    8.0,
                    0.75 * (2 ** (attempt - 1)),
                )

                logger.warning(
                    "Polymarket HTTP retry {}/{}: {} ; sleep {:.1f}s",
                    attempt,
                    self.http_retries,
                    exc,
                    delay,
                )

                time.sleep(delay)

        raise RuntimeError(
            f"Polymarket HTTP failed: {url}"
        ) from last_error

    # ============================================================
    # Gamma market discovery
    # ============================================================

    def discover_btc_updown(
        self,
        window="15m",
    ):
        """
        Final BTC 15m market discovery.

        15m窗口的真实起点来自：
            btc-updown-15m-<unix_timestamp>

        不使用 Gamma market.startDate 作为预测窗口起点。
        """

        if str(window).lower() != "15m":

            logger.warning(
                "Polymarket discovery optimized for 15m, requested={}",
                window,
            )

        now = time.time()

        with self._lock:

            cached = (
                self._market_cache.get(
                    "market"
                )
            )

            cached_ts = float(
                self._market_cache.get(
                    "ts",
                    0.0
                )
            )

        # ----------------------------------------------------
        # cache only while the cached 15m window is still live
        # ----------------------------------------------------

        if (
            cached
            and
            now
            - cached_ts
            <
            self.refresh_sec
        ):

            slug = str(
                cached.get(
                    "slug",
                    ""
                )
            ).lower()

            cached_match = re.search(
                r"btc-updown-15m-(\d{10})$",
                slug,
            )

            if cached_match:

                start_ts = float(
                    cached_match.group(1)
                )

                if (
                    start_ts
                    <= now
                    <
                    start_ts + 900.0
                ):

                    return cached

        # ----------------------------------------------------
        # 当前15分钟窗口
        # ----------------------------------------------------

        bucket = (
            int(now)
            // 900
        ) * 900

        def normalize(
            market,
            event=None,
            slug_hint="",
        ):

            if not isinstance(
                market,
                dict,
            ):

                return None

            event = (
                event
                if isinstance(
                    event,
                    dict,
                )
                else {}
            )

            slug = str(
                market.get(
                    "slug"
                )
                or
                event.get(
                    "slug"
                )
                or
                slug_hint
                or
                ""
            ).lower()

            match = re.search(
                r"btc-updown-15m-(\d{10})$",
                slug,
            )

            if not match:
                return None

            start_ts = float(
                match.group(1)
            )

            end_ts = (
                start_ts
                + 900.0
            )

            # 真正的15m预测窗口
            if not (
                start_ts
                <= now
                <
                end_ts
            ):

                return None

            if market.get(
                "closed"
            ) is True:

                return None

            if market.get(
                "archived"
            ) is True:

                return None

            token_raw = (
                market.get(
                    "clobTokenIds"
                )
                or
                market.get(
                    "clob_token_ids"
                )
            )

            try:

                token_raw = (
                    self._jsonish(
                        token_raw
                    )
                )

            except Exception:
                pass

            if not isinstance(
                token_raw,
                list,
            ):

                return None

            token_ids = [
                str(x)
                for x in token_raw
                if x
            ]

            if len(
                token_ids
            ) < 2:

                return None

            outcomes = (
                market.get(
                    "outcomes"
                )
            )

            try:

                outcomes = (
                    self._jsonish(
                        outcomes
                    )
                )

            except Exception:
                pass

            if not isinstance(
                outcomes,
                list,
            ):

                outcomes = [
                    "Up",
                    "Down",
                ]

            outcomes = [
                str(x)
                for x in outcomes
            ]

            # ------------------------------------------------
            # 保证 token 顺序为 Up / Down
            # ------------------------------------------------

            ordered = (
                token_ids[:2]
            )

            lowered = [
                x.lower()
                for x in outcomes
            ]

            up_index = next(
                (
                    i
                    for i, x
                    in enumerate(
                        lowered
                    )
                    if x
                    in {
                        "up",
                        "yes",
                    }
                ),
                None,
            )

            down_index = next(
                (
                    i
                    for i, x
                    in enumerate(
                        lowered
                    )
                    if x
                    in {
                        "down",
                        "no",
                    }
                ),
                None,
            )

            if (
                up_index is not None
                and
                down_index is not None
                and
                up_index
                < len(token_ids)
                and
                down_index
                < len(token_ids)
            ):

                ordered = [
                    token_ids[
                        up_index
                    ],
                    token_ids[
                        down_index
                    ],
                ]

            start_dt = (
                dt.datetime.fromtimestamp(
                    start_ts,
                    tz=dt.timezone.utc,
                )
            )

            end_dt = (
                dt.datetime.fromtimestamp(
                    end_ts,
                    tz=dt.timezone.utc,
                )
            )

            return {
                "condition_id":
                    (
                        market.get(
                            "conditionId"
                        )
                        or
                        market.get(
                            "condition_id"
                        )
                    ),

                "market_id":
                    market.get(
                        "id"
                    ),

                "event_id":
                    event.get(
                        "id"
                    ),

                "slug":
                    (
                        market.get(
                            "slug"
                        )
                        or
                        event.get(
                            "slug"
                        )
                        or
                        slug
                    ),

                "question":
                    (
                        market.get(
                            "question"
                        )
                        or
                        event.get(
                            "title"
                        )
                        or
                        "Bitcoin Up or Down"
                    ),

                "start_time":
                    start_dt.isoformat(),

                "end_time":
                    end_dt.isoformat(),

                "window_start_ts":
                    start_ts,

                "window_end_ts":
                    end_ts,

                "token_ids":
                    ordered,

                "outcomes":
                    outcomes[:2],

                "duration_sec":
                    900.0,

                "volume":
                    float(
                        market.get(
                            "volumeNum"
                        )
                        or
                        market.get(
                            "volume"
                        )
                        or
                        0.0
                    ),

                "raw":
                    market,
            }

        def accept(
            result,
            source_name,
        ):

            if not result:
                return None

            with self._lock:

                self._market_cache = {
                    "ts":
                        now,
                    "market":
                        result,
                }

            logger.success(
                "Polymarket LIVE BTC 15m discovered via {}: {} | start={} | end={} | tokens={}",
                source_name,
                result.get(
                    "slug"
                ),
                result.get(
                    "start_time"
                ),
                result.get(
                    "end_time"
                ),
                len(
                    result.get(
                        "token_ids",
                        []
                    )
                ),
            )

            return result

        # ====================================================
        # A. 直接当前窗口 event slug
        # ====================================================

        for start_ts in (
            bucket,
            bucket - 900,
            bucket + 900,
        ):

            slug = (
                f"btc-updown-15m-{start_ts}"
            )

            try:

                payload = (
                    self._get_json(
                        self.GAMMA_EVENT_SLUG_URL.format(
                            slug=slug
                        )
                    )
                )

                if not isinstance(
                    payload,
                    dict,
                ):

                    continue

                markets = (
                    payload.get(
                        "markets"
                    )
                    or
                    []
                )

                if not isinstance(
                    markets,
                    list,
                ):

                    markets = []

                if (
                    not markets
                    and
                    (
                        payload.get(
                            "clobTokenIds"
                        )
                        or
                        payload.get(
                            "clob_token_ids"
                        )
                    )
                ):

                    markets = [
                        payload
                    ]

                for market in markets:

                    result = normalize(
                        market,
                        payload,
                        slug,
                    )

                    if result:

                        return accept(
                            result,
                            "event-slug",
                        )

            except Exception as exc:

                logger.debug(
                    "Polymarket event-slug lookup {} failed: {}",
                    slug,
                    exc,
                )

        # ====================================================
        # B. public-search fallback
        # ====================================================

        search_url = (
            "https://gamma-api.polymarket.com/public-search"
        )

        for query in (
            "Bitcoin Up or Down",
            "BTC Up or Down",
        ):

            try:

                payload = (
                    self._get_json(
                        search_url,
                        {
                            "q":
                                query,
                            "limit_per_type":
                                100,
                            "page":
                                1,
                        },
                    )
                )

                stack = [
                    payload
                ]

                seen = set()

                while stack:

                    obj = stack.pop()

                    if isinstance(
                        obj,
                        dict,
                    ):

                        if (
                            "clobTokenIds"
                            in obj
                            or
                            "clob_token_ids"
                            in obj
                        ):

                            key = id(
                                obj
                            )

                            if key not in seen:

                                seen.add(
                                    key
                                )

                                result = (
                                    normalize(
                                        obj
                                    )
                                )

                                if result:

                                    return accept(
                                        result,
                                        "public-search",
                                    )

                        for value in obj.values():

                            if isinstance(
                                value,
                                (
                                    dict,
                                    list,
                                ),
                            ):

                                stack.append(
                                    value
                                )

                    elif isinstance(
                        obj,
                        list,
                    ):

                        stack.extend(
                            obj
                        )

            except Exception as exc:

                logger.debug(
                    "Polymarket public-search {} failed: {}",
                    query,
                    exc,
                )

        # ====================================================
        # C. /markets fallback
        # ====================================================

        try:

            payload = (
                self._get_json(
                    self.GAMMA_URL,
                    {
                        "closed":
                            "false",
                        "active":
                            "true",
                        "limit":
                            100,
                        "order":
                            "endDate",
                        "ascending":
                            "false",
                    },
                )
            )

            if isinstance(
                payload,
                list,
            ):

                for market in payload:

                    result = normalize(
                        market
                    )

                    if result:

                        return accept(
                            result,
                            "markets",
                        )

        except Exception as exc:

            logger.debug(
                "Polymarket /markets failed: {}",
                exc,
            )

        logger.warning(
            "Polymarket: API reachable but current BTC 15m market not found"
        )

        return None

    # ============================================================
    # Book
    # ============================================================

    @staticmethod
    def _levels(raw):
        result = []

        if not isinstance(
            raw,
            list,
        ):
            return result

        for level in raw:
            try:

                if isinstance(
                    level,
                    dict,
                ):
                    price = float(
                        level[
                            "price"
                        ]
                    )

                    size = float(
                        level[
                            "size"
                        ]
                    )

                else:
                    price = float(
                        level[0]
                    )

                    size = float(
                        level[1]
                    )

                if (
                    price > 0
                    and size > 0
                ):
                    result.append(
                        (
                            price,
                            size,
                        )
                    )

            except Exception:
                continue

        return result

    def _apply_book(
        self,
        token_id,
        payload,
        source="ws",
    ):
        bids = sorted(
            self._levels(
                payload.get(
                    "bids",
                    [],
                )
            ),
            key=lambda x: x[0],
            reverse=True,
        )

        asks = sorted(
            self._levels(
                payload.get(
                    "asks",
                    [],
                )
            ),
            key=lambda x: x[0],
        )

        try:
            minimum = (
                float(
                    payload[
                        "min_order_size"
                    ]
                )
                if payload.get(
                    "min_order_size"
                )
                is not None
                else None
            )

        except Exception:
            minimum = None

        try:
            tick = (
                float(
                    payload[
                        "tick_size"
                    ]
                )
                if payload.get(
                    "tick_size"
                )
                is not None
                else None
            )

        except Exception:
            tick = None

        book = Book(
            bids=bids,
            asks=asks,
            timestamp=time.time(),
            server_timestamp=self._epoch(
                payload.get(
                    "timestamp"
                )
            ),
            hash=(
                str(
                    payload[
                        "hash"
                    ]
                )
                if payload.get(
                    "hash"
                )
                else None
            ),
            min_order_size=minimum,
            tick_size=tick,
        )

        with self._lock:

            self.books[
                str(token_id)
            ] = book

            if source == "ws":
                self._last_ws_activity = (
                    time.time()
                )

                self._last_market_event = (
                    time.time()
                )

            else:
                self._last_clob_ok = (
                    time.time()
                )

        self._emit(
            {
                "type": "book",
                "token_id":
                    str(token_id),
                "book": book,
                "source":
                    source,
            }
        )

    def sync_book_rest(
        self,
        token_id,
    ):
        try:

            payload = self._get_json(
                self.BOOK_URL,
                {
                    "token_id":
                        str(token_id)
                },
            )

            if not isinstance(
                payload,
                dict,
            ):
                return False

            self._apply_book(
                str(token_id),
                payload,
                source="rest",
            )

            last_trade = (
                payload.get(
                    "last_trade_price"
                )
            )

            if last_trade is not None:

                with self._lock:

                    self.last_trades[
                        str(token_id)
                    ] = {
                        "event_type":
                            "last_trade_price",
                        "asset_id":
                            str(token_id),
                        "price":
                            str(last_trade),
                        "timestamp":
                            payload.get(
                                "timestamp"
                            ),
                        "source":
                            "clob_rest",
                    }

            logger.info(
                "Polymarket CLOB REST book synced: {} bid={} ask={} spread={}",
                token_id,
                self.books[
                    str(token_id)
                ].best_bid,
                self.books[
                    str(token_id)
                ].best_ask,
                self.books[
                    str(token_id)
                ].spread,
            )

            return True

        except Exception as exc:

            logger.warning(
                "Polymarket CLOB REST book sync failed {}: {}",
                token_id,
                exc,
            )

            return False

    def initial_sync(
        self,
        token_ids,
    ):
        success = 0

        for token_id in token_ids:

            if self.sync_book_rest(
                str(token_id)
            ):
                success += 1

        return success

    # ============================================================
    # WebSocket events
    # ============================================================

    def _apply_price_change(
        self,
        payload,
    ):
        token_id = str(
            payload.get(
                "asset_id"
            )
            or payload.get(
                "token_id"
            )
            or ""
        )

        if not token_id:
            return

        try:

            price = float(
                payload.get(
                    "price"
                )
            )

            size = float(
                payload.get(
                    "size"
                )
            )

        except Exception:
            return

        side = str(
            payload.get(
                "side",
                "",
            )
        ).upper()

        if side not in {
            "BUY",
            "SELL",
        }:
            return

        with self._lock:

            old = self.books.get(
                token_id,
                Book(),
            )

            bids = dict(
                old.bids
            )

            asks = dict(
                old.asks
            )

            target = (
                bids
                if side == "BUY"
                else asks
            )

            if size <= 0:
                target.pop(
                    price,
                    None,
                )

            else:
                target[
                    price
                ] = size

            book = Book(
                bids=sorted(
                    bids.items(),
                    reverse=True,
                ),
                asks=sorted(
                    asks.items()
                ),
                timestamp=time.time(),
                server_timestamp=self._epoch(
                    payload.get(
                        "timestamp"
                    )
                ),
                hash=old.hash,
                min_order_size=old.min_order_size,
                tick_size=old.tick_size,
            )

            self.books[
                token_id
            ] = book

            self._last_ws_activity = (
                time.time()
            )

            self._last_market_event = (
                time.time()
            )

        self._emit(
            {
                "type": "book",
                "token_id":
                    token_id,
                "book":
                    book,
                "source":
                    "ws",
                "event":
                    "price_change",
            }
        )

    def _handle_message(
        self,
        raw,
    ):
        with self._lock:

            self._last_ws_activity = (
                time.time()
            )

        if raw == "PONG":
            return

        try:

            payload = json.loads(
                raw
            )

        except Exception:

            return

        messages = (
            payload
            if isinstance(
                payload,
                list,
            )
            else [payload]
        )

        for item in messages:

            if not isinstance(
                item,
                dict,
            ):
                continue

            event_type = str(
                item.get(
                    "event_type"
                )
                or item.get(
                    "type"
                )
                or ""
            ).lower()

            token_id = str(
                item.get(
                    "asset_id"
                )
                or item.get(
                    "token_id"
                )
                or ""
            )

            if event_type in {
                "book",
                "snapshot",
                "book_snapshot",
                "initial_dump",
            } and token_id:

                self._apply_book(
                    token_id,
                    item,
                    source="ws",
                )

            elif event_type in {
                "price_change",
                "pricechange",
            }:

                changes = item.get(
                    "price_changes"
                )

                if isinstance(
                    changes,
                    list,
                ):

                    for change in changes:

                        if isinstance(
                            change,
                            dict,
                        ):
                            self._apply_price_change(
                                change
                            )

                else:

                    self._apply_price_change(
                        item
                    )

            elif event_type in {
                "last_trade_price",
                "trade",
            } and token_id:

                with self._lock:

                    self.last_trades[
                        token_id
                    ] = item

                    self._last_market_event = (
                        time.time()
                    )

                self._emit(
                    {
                        "type":
                            "trade",
                        "token_id":
                            token_id,
                        "trade":
                            item,
                        "source":
                            "ws",
                    }
                )

            elif event_type == (
                "best_bid_ask"
            ):

                self._emit(
                    {
                        "type":
                            "best_bid_ask",
                        "token_id":
                            token_id,
                        "payload":
                            item,
                        "source":
                            "ws",
                    }
                )

    def _emit(
        self,
        event,
    ):
        callback = (
            self.on_update
        )

        if not callback:
            return

        try:
            callback(
                event
            )

        except Exception as exc:

            logger.debug(
                "Polymarket callback failed: {}",
                exc,
            )

    # ============================================================
    # Proxy
    # ============================================================

    def _ws_proxy_kwargs(
        self
    ):
        if not self.proxy_url:
            return {}

        try:

            p = urlparse(
                self.proxy_url
            )

            result = {
                "http_proxy_host":
                    p.hostname,
                "http_proxy_port":
                    p.port,
                "proxy_type":
                    (
                        "socks5"
                        if p.scheme.lower().startswith(
                            "socks"
                        )
                        else "http"
                    ),
            }

            if p.username:

                result[
                    "http_proxy_auth"
                ] = (
                    p.username,
                    p.password
                    or "",
                )

            return result

        except Exception:

            return {}

    # ============================================================
    # Application heartbeat
    # ============================================================

    def _heartbeat(
        self,
        ws,
        stop_event,
    ):

        while (
            not stop_event.wait(
                10.0
            )
            and not self._stop.is_set()
        ):

            try:

                # Polymarket market channel uses
                # text PING/PONG heartbeats.
                ws.send(
                    "PING"
                )

            except Exception:

                return

    # ============================================================
    # WebSocket loop
    # ============================================================

    def _ws_loop(self):

        if websocket is None:

            logger.error(
                "websocket-client is not installed"
            )

            return

        backoff = 1.0

        while not self._stop.is_set():

            connection_stop = (
                threading.Event()
            )

            try:

                def on_open(ws):

                    self._connected = True

                    self._last_ws_activity = (
                        time.time()
                    )

                    subscribe = {
                        "assets_ids":
                            list(
                                self._subscribed_assets
                            ),
                        "type":
                            "market",
                        "custom_feature_enabled":
                            True,
                    }

                    ws.send(
                        json.dumps(
                            subscribe
                        )
                    )

                    logger.success(
                        "Polymarket CLOB WSS connected; subscribed {} assets",
                        len(
                            self._subscribed_assets
                        ),
                    )

                    threading.Thread(
                        target=self._heartbeat,
                        args=(
                            ws,
                            connection_stop,
                        ),
                        name="polymarket-ws-heartbeat",
                        daemon=True,
                    ).start()

                def on_message(
                    ws,
                    message,
                ):

                    self._handle_message(
                        message
                    )

                def on_error(
                    ws,
                    error,
                ):

                    self._last_ws_error = (
                        str(error)
                    )

                    logger.warning(
                        "Polymarket CLOB WSS error: {}",
                        error,
                    )

                def on_close(
                    ws,
                    code,
                    message,
                ):

                    connection_stop.set()

                    self._connected = False

                    self._last_ws_close = {
                        "code":
                            code,
                        "message":
                            message,
                        "time":
                            time.time(),
                    }

                    logger.warning(
                        "Polymarket CLOB WSS closed: code={} msg={}",
                        code,
                        message,
                    )

                app = websocket.WebSocketApp(
                    self.WS_URL,
                    on_open=on_open,
                    on_message=on_message,
                    on_error=on_error,
                    on_close=on_close,
                )

                with self._lock:
                    self._ws = app

                kwargs = {
                    "ping_interval":
                        0,
                    "ping_timeout":
                        None,
                }

                kwargs.update(
                    self._ws_proxy_kwargs()
                )

                # Do not pass close_timeout:
                # websocket-client 1.8.x does not accept it.
                app.run_forever(
                    **kwargs
                )

            except Exception as exc:

                self._connected = False
                self._last_ws_error = (
                    str(exc)
                )

                logger.warning(
                    "Polymarket CLOB reconnect error: {}",
                    exc,
                )

            finally:

                connection_stop.set()

                self._connected = False

                with self._lock:
                    self._ws = None

            if self._stop.is_set():
                break

            logger.warning(
                "Polymarket CLOB reconnect in {:.1f}s",
                backoff,
            )

            self._stop.wait(
                backoff
            )

            backoff = min(
                30.0,
                backoff * 2.0,
            )

    # ============================================================
    # Data API v2 status
    # ============================================================

    def check_status(
        self,
        force=False,
    ):

        now = time.time()

        with self._lock:

            if (
                not force
                and now
                - self._status_checked
                < self.status_interval_sec
            ):

                return dict(
                    self._status
                )

            self._status_checked = (
                now
            )

        try:

            payload = self._get_json(
                self.STATUS_URL
            )

            data = (
                payload.get(
                    "data",
                    {},
                )
                if isinstance(
                    payload,
                    dict,
                )
                else {}
            )

            serving = (
                data.get(
                    "serving",
                    {},
                )
                if isinstance(
                    data,
                    dict,
                )
                else {}
            )

            lag = (
                float(
                    serving[
                        "lag_seconds"
                    ]
                )
                if serving.get(
                    "lag_seconds"
                ) is not None
                else None
            )

            age = (
                float(
                    data[
                        "age_seconds"
                    ]
                )
                if data.get(
                    "age_seconds"
                ) is not None
                else None
            )

            result = {
                "ok":
                    (
                        lag is None
                        or lag
                        <= self.status_max_lag_sec
                    ),
                "age_seconds":
                    age,
                "lag_seconds":
                    lag,
                "worst":
                    serving.get(
                        "worst"
                    ),
                "checked_at":
                    now,
                "error":
                    None,
            }

        except Exception as exc:

            # Status failure never stops OKX or Shadow.
            result = {
                "ok":
                    False,
                "age_seconds":
                    None,
                "lag_seconds":
                    None,
                "worst":
                    None,
                "checked_at":
                    now,
                "error":
                    str(exc),
            }

        with self._lock:

            self._status = dict(
                result
            )

        return dict(
            result
        )

    # ============================================================
    # Stale watchdog
    # ============================================================

    def _watchdog(
        self
    ):

        while not self._stop.wait(
            5.0
        ):

            with self._lock:

                ws = self._ws

                connected = (
                    self._connected
                )

                last = (
                    self._last_ws_activity
                )

            if (
                connected
                and ws is not None
                and last > 0
                and time.time()
                - last
                > self.ws_stale_sec
            ):

                logger.warning(
                    "Polymarket CLOB WSS stale; forcing reconnect"
                )

                try:
                    ws.close()
                except Exception:
                    pass

    # ============================================================
    # Health
    # ============================================================

    def health_snapshot(
        self,
        max_book_age_sec=30.0,
    ):

        now = time.time()

        status = (
            self.check_status()
        )

        with self._lock:

            connected = (
                self._connected
            )

            ws_age = (
                max(
                    0.0,
                    now - self._last_ws_activity,
                )
                if self._last_ws_activity
                else None
            )

            market_age = (
                max(
                    0.0,
                    now - self._last_market_event,
                )
                if self._last_market_event
                else None
            )

            books = {
                token:
                    book.timestamp
                for token, book
                in self.books.items()
            }

            last_error = (
                self._last_ws_error
            )

        book_ages = {
            token:
                max(
                    0.0,
                    now - ts,
                )
            for token, ts
            in books.items()
        }

        books_fresh = (
            bool(book_ages)
            and all(
                age
                <= float(
                    max_book_age_sec
                )
                for age
                in book_ages.values()
            )
        )

        return {
            "proxy":
                self._masked_proxy(),
            "ws_connected":
                connected,
            "ws_activity_age_sec":
                ws_age,
            "last_market_event_age_sec":
                market_age,
            "book_ages_sec":
                book_ages,
            "books_fresh":
                books_fresh,
            "status":
                status,
            "subscribed_assets":
                list(
                    self._subscribed_assets
                ),
            "last_ws_error":
                last_error,
            "fresh":
                bool(
                    connected
                    and books_fresh
                    and (
                        ws_age is None
                        or ws_age
                        <= self.ws_stale_sec
                    )
                ),
        }

    # ============================================================
    # Lifecycle
    # ============================================================

    def start(
        self,
        token_ids,
    ):

        tokens = [
            str(x)
            for x in token_ids
            if x
        ]

        if not tokens:
            raise ValueError(
                "token_ids cannot be empty"
            )

        with self._lock:

            old_tokens = list(
                self._subscribed_assets
            )

            changed = (
                old_tokens
                != tokens
            )

            self._subscribed_assets = (
                tokens
            )

            self._stop.clear()

            ws = self._ws

            if changed:

                self.books = {
                    k: v
                    for k, v
                    in self.books.items()
                    if k in tokens
                }

                self.last_trades = {
                    k: v
                    for k, v
                    in self.last_trades.items()
                    if k in tokens
                }

        # New 15m market:
        # close old WSS so worker reconnects
        # with the new tokens.
        if (
            changed
            and old_tokens
            and ws is not None
        ):

            try:
                ws.close()
            except Exception:
                pass

        # REST snapshot before WSS.
        self.initial_sync(
            tokens
        )

        if not (
            self._ws_thread
            and self._ws_thread.is_alive()
        ):

            self._ws_thread = (
                threading.Thread(
                    target=self._ws_loop,
                    name="polymarket-clob-ws",
                    daemon=True,
                )
            )

            self._ws_thread.start()

        if not (
            self._watchdog_thread
            and self._watchdog_thread.is_alive()
        ):

            self._watchdog_thread = (
                threading.Thread(
                    target=self._watchdog,
                    name="polymarket-clob-watchdog",
                    daemon=True,
                )
            )

            self._watchdog_thread.start()

    def stop(self):

        self._stop.set()

        self._connected = False

        with self._lock:
            ws = self._ws

        if ws is not None:

            try:
                ws.close()
            except Exception:
                pass

        self._ws = None

    def snapshot(
        self,
        token_id,
    ):

        token_id = str(
            token_id
        )

        with self._lock:

            book = self.books.get(
                token_id
            )

            trade = (
                self.last_trades.get(
                    token_id
                )
            )

            connected = (
                self._connected
            )

        if not book:
            return None

        age = max(
            0.0,
            time.time()
            - book.timestamp,
        )

        return {
            "token_id":
                token_id,
            "best_bid":
                book.best_bid,
            "best_ask":
                book.best_ask,
            "midpoint":
                book.midpoint,
            "spread":
                book.spread,
            "bids":
                list(book.bids),
            "asks":
                list(book.asks),
            "last_trade":
                trade,
            "timestamp":
                book.timestamp,
            "server_timestamp":
                book.server_timestamp,
            "age_sec":
                age,
            "fresh":
                age
                <= self.ws_stale_sec,
            "ws_connected":
                connected,
            "min_order_size":
                book.min_order_size,
            "tick_size":
                book.tick_size,
        }
