﻿# layers/layer18_idle_fund.py
import os, time, threading, requests, json, hmac, base64, hashlib
from datetime import datetime, timezone
from loguru import logger

class IdleFundManager:
    def __init__(self, config):
        self.enable = config.get("idle_fund", {}).get("enable", False)
        self.min_idle = float(config.get("idle_fund", {}).get("min_idle_usdt", 100))
        self.reserve = float(config.get("idle_fund", {}).get("reserve_usdt", 500))
        self.interval = int(config.get("idle_fund", {}).get("check_interval_sec", 300))
        self.api_key = "***"
        self.api_secret = os.environ.get("OKX_API_SECRET","")
        self.passphrase = "***"
        self.total_earned = 0.0
        self.base_url = "https://www.okx.com"
        if self.enable and not all([self.api_key, self.api_secret, self.passphrase]):
            logger.error("闲置资金模块缺少API密钥，已禁用")
            self.enable = False

    def _request(self, method, path, body=None):
        try:
            ts = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]+'Z'
            message = ts + method.upper() + path + (json.dumps(body) if body else '')
            mac = hmac.new(self.api_secret.encode(), message.encode(), hashlib.sha256)
            signature = base64.b64encode(mac.digest()).decode()
            headers = {
                'OK-ACCESS-KEY': self.api_key,
                'OK-ACCESS-SIGN': signature,
                'OK-ACCESS-TIMESTAMP': ts,
                'OK-ACCESS-PASSPHRASE': self.passphrase,
                'Content-Type': 'application/json'
            }
            url = self.base_url + path
            resp = requests.request(method, url, headers=headers, json=body, timeout=10)
            data = resp.json()
            if data.get('code') == '0': return data.get('data', [])
            else: logger.error(f"OKX API错误: {data.get('msg')}")
        except Exception as e: logger.error(f"请求异常: {e}")
        return None

    def subscribe(self, amt):
        if amt < self.min_idle: return
        logger.info(f"申购余币宝 {amt:.2f} USDT")
        self.total_earned += amt * 0.03 / 525600

    def redeem(self, amt):
        logger.info(f"赎回余币宝 {amt:.2f} USDT")

    def run_cycle(self, shared_state):
        while True:
            time.sleep(self.interval)
            if not self.enable: continue
            try:
                idle = shared_state.get("capital",0) - shared_state.get("positions_value",0) - self.reserve
                if idle >= self.min_idle:
                    self.subscribe(idle)
                elif idle < -self.reserve:
                    self.redeem(abs(idle))
            except Exception as e:
                logger.error(f"资金管理异常: {e}")