# -*- coding: utf-8 -*-
"""Read-only Polymarket RTDS Chainlink BTC/USD collector.

This stream is used only as a settlement-aligned reference feed for shadow
research. It never places orders.
"""
from __future__ import annotations

import json
import threading
import time
from collections import deque
from typing import Any, Optional

from loguru import logger

try:
    import websocket
except ImportError:  # pragma: no cover
    websocket = None


class PolymarketRTDSChainlink:
    WS_URL = "wss://ws-live-data.polymarket.com"
    TOPIC = "crypto_prices_chainlink"
    SYMBOL = "btc/usd"

    def __init__(
        self,
        symbol: str = SYMBOL,
        history_size: int = 10000,
        proxy_url: Optional[str] = None,
    ):
        self.symbol = symbol.lower()

        self.proxy_url = (
            proxy_url
            if proxy_url is not None
            else "http://127.0.0.1:12450"
        ).strip()

        self.history: deque[dict[str, Any]] = deque(
            maxlen=int(
                history_size
            )
        )
        self.latest: Optional[dict[str, Any]] = None
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._ws = None

    @staticmethod
    def _ticks(payload: dict[str, Any]) -> list[dict[str, Any]]:
        raw = payload.get("payload") or {}
        items = raw.get("data") if isinstance(raw, dict) else None
        if isinstance(items, list):
            source = items
        elif isinstance(raw, dict):
            source = [raw]
        else:
            source = []
        result = []
        for item in source:
            if not isinstance(item, dict):
                continue
            symbol = str(item.get("symbol") or raw.get("symbol") or "").lower()
            if symbol != "btc/usd":
                continue
            try:
                price = float(item.get("value"))
                ts_ms = int(item.get("timestamp") or payload.get("timestamp") or 0)
            except (TypeError, ValueError):
                continue
            if price <= 0 or ts_ms <= 0:
                continue
            result.append({"symbol": symbol, "price": price, "timestamp_ms": ts_ms})
        return result

    def _record(self, tick: dict[str, Any]) -> None:
        with self._lock:
            if self.latest and tick["timestamp_ms"] < self.latest["timestamp_ms"]:
                return
            self.latest = tick
            self.history.append(tick)

    def _proxy_kwargs(self) -> dict[str, Any]:
        if not self.proxy_url:
            return {}

        from urllib.parse import urlparse

        try:
            parsed = urlparse(
                self.proxy_url
            )

            if not parsed.hostname:
                return {}

            result = {
                "http_proxy_host":
                    parsed.hostname,
                "http_proxy_port":
                    parsed.port,
                "proxy_type":
                    (
                        "socks5"
                        if parsed.scheme.lower().startswith(
                            "socks"
                        )
                        else "http"
                    ),
            }

            if parsed.username:
                result[
                    "http_proxy_auth"
                ] = (
                    parsed.username,
                    parsed.password
                    or "",
                )

            return result

        except Exception:
            return {}

    def _loop(self) -> None:
        if websocket is None:
            logger.error("websocket-client is not installed; RTDS disabled")
            return
        while not self._stop.is_set():
            try:
                def on_open(ws):
                    ws.send(json.dumps({
                        "action": "subscribe",
                        "subscriptions": [{
                            "topic": self.TOPIC,
                            "type": "*",
                            "filters": json.dumps({"symbol": self.symbol}, separators=(",", ":")),
                        }],
                    }))

                def on_message(_ws, message):
                    try:
                        if isinstance(message, str) and message.upper() in {"PING", "PONG"}:
                            return
                        payload = json.loads(message)
                    except Exception:
                        return
                    if isinstance(payload, dict):
                        for tick in self._ticks(payload):
                            self._record(tick)

                def on_error(_ws, error):
                    logger.warning("Polymarket RTDS error: {}", error)

                self._ws = websocket.WebSocketApp(
                    self.WS_URL,
                    on_open=on_open,
                    on_message=on_message,
                    on_error=on_error,
                )
                run_kwargs = {
                    "ping_interval":
                        20,
                    "ping_timeout":
                        10,
                }

                run_kwargs.update(
                    self._proxy_kwargs()
                )

                self._ws.run_forever(
                    **run_kwargs
                )
            except Exception as exc:
                logger.warning("Polymarket RTDS reconnect error: {}", exc)
            if not self._stop.is_set():
                self._stop.wait(2.0)

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="polymarket-rtds", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        try:
            if self._ws:
                self._ws.close()
        except Exception:
            pass
        self._ws = None

    def snapshot(self) -> Optional[dict[str, Any]]:
        with self._lock:
            return dict(self.latest) if self.latest else None

    def reference_at(self, start_ts: float, tolerance_sec: float = 3.0) -> Optional[dict[str, Any]]:
        """Return the nearest observed Chainlink tick around a market open.

        We deliberately refuse to invent a strike. If no RTDS tick was
        observed within the configured tolerance, the market stays unqualified
        for shadow Alpha evaluation.
        """
        target_ms = int(float(start_ts) * 1000)
        tol_ms = int(float(tolerance_sec) * 1000)
        with self._lock:
            candidates = [
                t for t in self.history
                if abs(int(t["timestamp_ms"]) - target_ms) <= tol_ms
            ]
        if not candidates:
            return None
        candidates.sort(key=lambda t: abs(int(t["timestamp_ms"]) - target_ms))
        return dict(candidates[0])
