﻿import requests
from loguru import logger

class ExternalSentiment:
    def __init__(self):
        self.base_url_funding = "https://www.okx.com/api/v5/public/funding-rate"
        self.base_url_fear_greed = "https://api.alternative.me/fng/"

    def get_funding_rate(self, instId="BTC-USD-SWAP"):
        """获取合约资金费率"""
        try:
            resp = requests.get(f"{self.base_url_funding}?instId={instId}", timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                rate = float(data['data'][0]['fundingRate'])
                signal = max(-1.0, min(1.0, -rate * 100))
                return signal, 0.7
        except Exception as e:
            logger.warning(f"获取资金费率失败: {e}")
        return 0.0, 0.0

    def get_fear_greed_index(self):
        """获取恐慌贪婪指数"""
        try:
            resp = requests.get(self.base_url_fear_greed, timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                value = int(data['data'][0]['value'])
                signal = (value - 50) / 50.0
                return signal, 0.8
        except Exception as e:
            logger.warning(f"获取恐慌贪婪指数失败: {e}")
        return 0.0, 0.0

    def get_combined_sentiment(self):
        """融合外部情绪"""
        funding_signal, funding_conf = self.get_funding_rate()
        fg_signal, fg_conf = self.get_fear_greed_index()
        total_signal = 0.6 * funding_signal + 0.4 * fg_signal
        total_conf = 0.6 * funding_conf + 0.4 * fg_conf
        logger.info(f"外部情绪融合: 资金费率({funding_signal:.2f}) 恐慌指数({fg_signal:.2f}) -> {total_signal:.2f}")
        return {"external_sentiment": total_signal, "external_confidence": total_conf}
