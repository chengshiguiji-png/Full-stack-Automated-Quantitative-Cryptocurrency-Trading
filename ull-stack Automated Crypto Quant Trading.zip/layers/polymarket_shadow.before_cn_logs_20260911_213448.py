# -*- coding: utf-8 -*-
"""Shadow-only Polymarket Alpha runner.

It records what the strategy *would* have done. It never calls an executor.
The recorder deliberately requires a Chainlink RTDS strike observation around
market open and refuses to substitute Binance/OKX as settlement truth.
"""
from __future__ import annotations

import datetime as dt
import json
import re
import time
from pathlib import Path
from typing import Any, Optional

from loguru import logger

from layers.fair_probability import FairProbabilityModel
from layers.polymarket_alpha_engine import PolymarketAlphaEngine
from layers.polymarket_clob import PolymarketCLOB
from layers.polymarket_rtds import PolymarketRTDSChainlink
from layers.market_data_bus import MarketDataBus


class PolymarketShadowRecorder:
    def __init__(self, config: Optional[dict[str, Any]] = None):
        cfg = config or {}
        self.enabled = bool(cfg.get("enable", False))
        self.window = str(cfg.get("window", "15m"))
        self.requested_size = float(cfg.get("requested_size", 10.0))
        self.reference_tolerance_sec = float(cfg.get("reference_tolerance_sec", 3.0))
        self.output = Path(cfg.get("output", "data/polymarket_shadow/signals.jsonl"))
        self.output.parent.mkdir(parents=True, exist_ok=True)
        self.clob = PolymarketCLOB(
            refresh_sec=float(cfg.get("market_refresh_sec", 30.0)),
            request_timeout=float(cfg.get("request_timeout_sec", 10.0)),
            proxy_url=cfg.get("proxy_url"),
            ws_stale_sec=float(cfg.get("websocket_stale_sec", 30.0)),
            status_interval_sec=float(cfg.get("status_interval_sec", 20.0)),
            status_max_lag_sec=float(cfg.get("status_max_lag_sec", 30.0)),
        )

        self.require_realtime = bool(
            cfg.get("require_realtime", True)
        )

        self.max_book_age_sec = float(
            cfg.get("max_book_age_sec", 30.0)
        )
        self.rtds = PolymarketRTDSChainlink(
            proxy_url=cfg.get(
                "proxy_url"
            )
        )
        self.fair = FairProbabilityModel(cfg.get("fair_probability", {}))
        self.alpha = PolymarketAlphaEngine(cfg.get("alpha", {}))
        self.market: Optional[dict[str, Any]] = None
        self._started = False
        self._last_log_key: Optional[str] = None
        self.bus = MarketDataBus("BTC-USDT", history_size=int(cfg.get("history_size", 2000)))
        self._last_feature_ts = 0.0

    @staticmethod
    def _start_ts(market: dict[str, Any]) -> Optional[float]:
        start_time = market.get("start_time")

        if start_time:
            try:
                value = dt.datetime.fromisoformat(
                    str(start_time).replace("Z", "+00:00")
                )

                if value.tzinfo is None:
                    value = value.replace(
                        tzinfo=dt.timezone.utc
                    )

                return value.timestamp()

            except Exception:
                pass

        slug = str(
            market.get("slug", "")
        )

        match = re.search(
            r"-(\d{10})$",
            slug,
        )

        if match:
            return float(
                match.group(1)
            )

        return None

    @staticmethod
    def _end_ts(
        market: dict[str, Any],
        start_ts: float,
    ) -> float:
        """
        优先使用Gamma返回的真实end_time。
        不再强制假设所有市场都精确900秒。
        """

        value = market.get(
            "end_time"
        )

        if value:
            try:
                parsed = (
                    dt.datetime.fromisoformat(
                        str(
                            value
                        ).replace(
                            "Z",
                            "+00:00",
                        )
                    )
                )

                if parsed.tzinfo is None:
                    parsed = parsed.replace(
                        tzinfo=dt.timezone.utc
                    )

                return parsed.timestamp()

            except Exception:
                pass

        raw = market.get(
            "raw"
        )

        if isinstance(
            raw,
            dict,
        ):

            value = (
                raw.get(
                    "endDate"
                )
                or
                raw.get(
                    "endDateIso"
                )
            )

            if value:

                try:

                    parsed = (
                        dt.datetime.fromisoformat(
                            str(
                                value
                            ).replace(
                                "Z",
                                "+00:00",
                            )
                        )
                    )

                    if parsed.tzinfo is None:
                        parsed = parsed.replace(
                            tzinfo=dt.timezone.utc
                        )

                    return parsed.timestamp()

                except Exception:
                    pass

        return (
            start_ts
            + 900.0
        )

    def start(self) -> None:
        if not self.enabled or self._started:
            return
        self.rtds.start()
        self.bus.start(
            enable_binance=bool(self.enabled),
            enable_okx=True,
        )
        self._started = True
        logger.info("Polymarket Shadow Mode enabled: read-only / no executor")

    def stop(self) -> None:
        self.rtds.stop()
        self.bus.stop()
        self.clob.stop()

    def _ensure_market(self) -> Optional[dict[str, Any]]:
        market = self.clob.discover_btc_updown(self.window)
        if not market:
            return None
        if market != self.market:
            self.market = market
            self.clob.start(market["token_ids"])
            self.bus.attach_polymarket(self.clob)
            logger.info("Shadow market: {}", market.get("slug"))
        return market

    def _record(self, payload: dict[str, Any]) -> None:
        with self.output.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False, default=str) + "\n")

    def evaluate_once(self, now: Optional[float] = None) -> Optional[dict[str, Any]]:
        if not self.enabled:
            return None
        now = time.time() if now is None else float(now)
        market = self._ensure_market()
        if not market:
            return None

        health = self.clob.health_snapshot(
            max_book_age_sec=self.max_book_age_sec
        )

        if self.require_realtime and not health.get("fresh"):
            health_key = (
                f"HEALTH:{market.get('slug')}:"
                f"{int(now // 30)}:"
                f"{health.get('ws_connected')}:"
                f"{health.get('books_fresh')}"
            )

            if health_key != self._last_log_key:

                self._last_log_key = health_key

                self._record({
                    "timestamp": now,
                    "market_slug": market.get("slug"),
                    "health": health,
                    "shadow_only": True,
                    "executed": False,
                    "status": "POLYMARKET_DATA_STALE",
                })

                logger.warning(
                    "Polymarket Shadow stale: "
                    "ws_connected={} books_fresh={} "
                    "status_ok={} status_lag={} "
                    "ws_age={} books={}",
                    health.get("ws_connected"),
                    health.get("books_fresh"),
                    health.get("status", {}).get("ok"),
                    health.get("status", {}).get("lag_seconds"),
                    health.get("ws_activity_age_sec"),
                    health.get("book_ages_sec"),
                )

            return None
        start_ts = self._start_ts(market)
        if start_ts is None:
            return None
        end_ts = self._end_ts(
            market,
            start_ts,
        )
        if now < start_ts or now >= end_ts:
            return None
        reference = self.rtds.reference_at(start_ts, self.reference_tolerance_sec)
        if not reference:
            return None
        tokens = market.get("token_ids") or []
        if len(tokens) < 2:
            return None
        yes = self.clob.snapshot(tokens[0])
        no = self.clob.snapshot(tokens[1])
        if not yes or not no:
            return None
        snapshot = self.rtds.snapshot()
        current = float(snapshot["price"]) if snapshot else 0.0
        if current <= 0:
            return None
        features = self.bus.feature_snapshot()
        # Prefer Binance as the fast reference when available; fall back to
        # Chainlink only until the CEX feed has enough observations.
        binance_state = self.bus.snapshot().get("binance", {})
        model_price = float(binance_state.get("price") or current)
        sigma = float(features.get("realized_vol_60s", 0.50))
        momentum = max(-1.0, min(1.0, features["binance_return_5s"] / 0.002))
        flow = float(features["okx_flow_imbalance"])
        cross = float(features["cross_exchange_return"])
        volatility_shock = max(0.0, min(1.0, sigma / 2.0 - 0.25))
        fair = self.fair.estimate(
            current_price=model_price,
            reference_price=float(reference["price"]),
            seconds_to_expiry=max(1.0, end_ts - now),
            sigma_annualized=sigma,
            momentum=momentum,
            flow_imbalance=flow,
            cross_exchange_return=cross,
            regime_bias=0.0,
            volatility_shock=volatility_shock,
        )
        result = self.alpha.evaluate(
            fair_probability=fair["fair_probability"],
            uncertainty=fair["uncertainty"],
            yes_book=yes,
            no_book=no,
            requested_size=self.requested_size,
            timestamp=now,
        )
        key = f"{market.get('slug')}:{int(now // 1)}:{result.get('direction')}"
        if key == self._last_log_key:
            return result
        self._last_log_key = key
        record = {
            "timestamp": now,
            "market_slug": market.get("slug"),
            "condition_id": market.get("condition_id"),
            "token_ids": tokens,
            "market_start_ts": start_ts,
            "market_end_ts": end_ts,
            "seconds_to_expiry": end_ts - now,
            "reference_price": reference["price"],
            "reference_timestamp_ms": reference["timestamp_ms"],
            "reference_source": "polymarket_rtds_chainlink",
            "current_chainlink_price": current,
            "model_price": model_price,
            "features": features,
            "fair": fair,
            "alpha": result,
            "shadow_only": True,
            "executed": False,
        }
        self._record(record)
        return result
