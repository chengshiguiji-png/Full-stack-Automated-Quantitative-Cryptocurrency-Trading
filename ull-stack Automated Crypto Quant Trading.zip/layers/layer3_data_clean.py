# -*- coding: utf-8 -*-
"""第3层：严格因果数据清洗。"""
from __future__ import annotations

import pandas as pd
from loguru import logger


class DataCleaner:
    def __init__(self, config=None):
        self.config = config or {}
        self.require_confirm = bool(self.config.get("require_confirmed", True))

    def clean_klines(self, raw_klines):
        if raw_klines is None or len(raw_klines) == 0:
            return pd.DataFrame()
        try:
            df = pd.DataFrame(raw_klines).copy()
            df.rename(columns={"ts": "timestamp", "vol": "volume"}, inplace=True)
            required = ["timestamp", "open", "high", "low", "close", "volume"]
            missing = [c for c in required if c not in df.columns]
            if missing:
                logger.error("K线缺少必要字段: %s", missing)
                return pd.DataFrame()

            numeric_cols = ["open", "high", "low", "close", "volume"]
            for col in numeric_cols:
                df[col] = pd.to_numeric(df[col], errors="coerce")
            df["timestamp"] = pd.to_numeric(df["timestamp"], errors="coerce")
            df.dropna(subset=required, inplace=True)
            df.sort_values("timestamp", inplace=True)
            df.drop_duplicates(subset="timestamp", keep="last", inplace=True)

            if self.require_confirm and "confirm" in df.columns:
                df["confirm"] = pd.to_numeric(df["confirm"], errors="coerce").fillna(0).astype(int)
                confirmed = df[df["confirm"] == 1]
                if not confirmed.empty:
                    df = confirmed

            # 不做均值替换：真实跳变可能就是市场事件。这里只删除不可能/不合法的 OHLC。
            valid = (
                (df["open"] > 0) & (df["high"] > 0) & (df["low"] > 0) & (df["close"] > 0) &
                (df["volume"] >= 0) &
                (df["high"] >= df[["open", "close", "low"]].max(axis=1)) &
                (df["low"] <= df[["open", "close", "high"]].min(axis=1))
            )
            df = df.loc[valid].copy()
            df["datetime"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
            df["return"] = df["close"].pct_change()
            df["spread"] = df["high"] - df["low"]
            df.reset_index(drop=True, inplace=True)
            return df
        except Exception as exc:
            logger.error("数据清洗失败: %s", exc)
            return pd.DataFrame()
