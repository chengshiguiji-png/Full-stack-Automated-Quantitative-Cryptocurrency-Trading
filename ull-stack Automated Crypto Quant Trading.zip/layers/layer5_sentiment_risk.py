# -*- coding: utf-8 -*-
"""第5层：可选情绪上下文。
默认不改变 ML 概率；外部数据失败时只返回中性。
"""
from __future__ import annotations

import os
import time
import requests
from loguru import logger
from layers.layer5_llm_sentiment import SentimentRiskAnalyzer as LLMAnalyzer


class SentimentRiskAnalyzer:
    def __init__(self, config=None):
        self.config = config or {}
        self.enabled = bool(self.config.get("enable", False))
        self.update_interval = float(self.config.get("update_interval_minutes", 5))
        self.cache = {}
        self.last_update = {}
        self.llm = LLMAnalyzer()

    def _get_fear_greed_index(self):
        try:
            r = requests.get("https://api.alternative.me/fng/", timeout=5)
            value = float(r.json()["data"][0]["value"])
            return (value - 50) / 50.0
        except Exception:
            return 0.0

    def _get_funding_rate(self, symbol="BTC-USDT-SWAP"):
        try:
            r = requests.get("https://www.okx.com/api/v5/public/funding-rate", params={"instId": symbol}, timeout=5)
            row = (r.json().get("data") or [{}])[0]
            return float(row.get("fundingRate", 0.0))
        except Exception:
            return 0.0

    def get_aggregated_sentiment(self, symbol):
        if not self.enabled:
            return 0.0
        now = time.time()
        if now - self.last_update.get(symbol, 0) < self.update_interval * 60:
            return self.cache.get(symbol, 0.0)
        fg = self._get_fear_greed_index()
        funding = max(-1.0, min(1.0, -self._get_funding_rate() * 100))
        score = max(-0.5, min(0.5, 0.5 * fg + 0.5 * funding))
        self.cache[symbol] = score
        self.last_update[symbol] = now
        return score

    def run_once(self, symbol, df_feat=None):
        result = self.llm.run_once(symbol, df_feat) if self.config.get("llm_confirmation", False) else {
            "sentiment_adj": 0.0, "llm_confidence": 0.0, "ai_action": "HOLD", "ai_reason": "LLM关闭"
        }
        base = self.get_aggregated_sentiment(symbol)
        return {
            "sentiment_adj": float(max(-0.5, min(0.5, base + result.get("sentiment_adj", 0.0)))),
            "event": "Neutral",
            "score": base,
            "llm_confidence": float(result.get("llm_confidence", 0.0)),
        }
