# -*- coding: utf-8 -*-
"""第9层：信号生成。

最终版原则：
- p_up 是“未来交易窗口内先触发目标盈利”的概率估计。
- 微结构/情绪只做确认信息，不修改模型概率。
- 阈值与 EV edge 不重复叠加成两道相同的硬门。
"""
from __future__ import annotations

import time
from datetime import datetime, timezone


class SignalGenerator:
    def __init__(self, config=None):
        self.config = config or {}
        self.threshold_up = float(self.config.get("threshold_up", 0.58))
        self.threshold_down = float(self.config.get("threshold_down", 0.42))
        self.strong_threshold_up = float(self.config.get("strong_threshold_up", 0.65))
        self.strong_threshold_down = float(self.config.get("strong_threshold_down", 0.35))
        self.min_ev_edge = float(self.config.get("min_ev_edge", 0.08))
        self.signal_ttl_sec = float(self.config.get("signal_ttl_min", 5)) * 60
        self.cooldown_sec = float(self.config.get("cooldown_min", 0)) * 60
        # 是否把最终交易方向对调（模型说涨就做空，反之亦然）。
        # 只应该在拿到独立样本外证据支持的情况下打开，见 layers/symbol_config.py 顶部说明。
        self.invert_direction = bool(self.config.get("invert_direction", False))
        self.last_signal_time = 0.0
        self.last_bar_by_symbol = {}

    def generate_signal(self, base_p_up: float, micro_adj: float = 0.0,
                        sentiment_adj: float = 0.0, symbol: str = "BTC-USDT", bar_ts=None) -> dict:
        p_up = float(max(0.0, min(1.0, base_p_up)))
        edge_up = p_up - 0.5
        edge_down = 0.5 - p_up
        confirmation = max(0.0, min(1.0, 0.5 + 0.25 * float(micro_adj) + 0.25 * float(sentiment_adj)))
        if p_up >= self.threshold_up and edge_up >= self.min_ev_edge:
            direction, edge = "BUY", edge_up
        elif p_up <= self.threshold_down and edge_down >= self.min_ev_edge:
            direction, edge = "SELL", edge_down
        else:
            direction, edge = "HOLD", max(edge_up, edge_down, 0.0)
        now = time.time()
        reason = "model_edge"
        if direction != "HOLD" and self.cooldown_sec > 0 and now - self.last_signal_time < self.cooldown_sec:
            direction, reason = "HOLD", "cooldown"
        elif direction != "HOLD" and bar_ts is not None and self.last_bar_by_symbol.get(symbol) == bar_ts:
            direction, reason = "HOLD", "duplicate_bar"
        if direction != "HOLD":
            self.last_signal_time = now
            if bar_ts is not None:
                self.last_bar_by_symbol[symbol] = bar_ts
        signal_type = "STRONG" if (p_up >= self.strong_threshold_up or p_up <= self.strong_threshold_down) else ("NORMAL" if direction != "HOLD" else "WEAK")
        inverted = False
        if self.invert_direction and direction in ("BUY", "SELL"):
            direction = "SELL" if direction == "BUY" else "BUY"
            reason = f"{reason}|inverted"
            inverted = True
        return {
            "symbol": symbol, "timestamp": datetime.now(timezone.utc).isoformat(), "bar_ts": bar_ts,
            "base_p_up": p_up, "p_up": p_up,
            "micro_adj": float(micro_adj), "sentiment_adj": float(sentiment_adj),
            "confirmation": confirmation,
            "direction": direction, "confidence": abs(p_up - 0.5) * 2,
            "ev_edge": edge, "signal_type": signal_type, "ttl": self.signal_ttl_sec,
            "valid": direction != "HOLD", "reason": reason, "inverted": inverted,
        }
