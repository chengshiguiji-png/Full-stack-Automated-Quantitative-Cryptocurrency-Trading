# -*- coding: utf-8 -*-
"""第12层：订单执行与成交确认。

execute() 的 size 默认表示 base-asset 数量；buy_notional() 用于 USDT 名义金额。
真实/模拟成交只有在 fill 确认后才返回 executed=True。
"""
from __future__ import annotations

import os
import time
import uuid

from loguru import logger


class OrderExecutor:
    def __init__(self, config=None, okx_trader=None):
        self.config = config or {}
        self.okx_trader = okx_trader
        self.max_order_value = float(self.config.get("max_order_value", 50000))
        self.min_order_value = float(self.config.get("min_order_value", 10))
        env_dry = os.getenv("OKX_DRY_RUN")
        self.dry_run = (str(env_dry).lower() == "true") if env_dry is not None else bool(self.config.get("dry_run", True))
        self.max_fill_wait_sec = float(self.config.get("max_fill_wait_sec", 12))
        self.processed_ids = set()

    def buy_notional(self, symbol, notional_usdt, market_price):
        if market_price <= 0 or notional_usdt < self.min_order_value or notional_usdt > self.max_order_value:
            return {"executed": False, "reason": "invalid_notional"}
        qty = notional_usdt / market_price
        return self.execute({"symbol": symbol, "side": "BUY", "quantity": qty, "notional_usdt": notional_usdt}, market_price)

    def execute(self, order, market_price):
        symbol = order["symbol"]
        side = str(order["side"]).upper()
        qty = float(order.get("quantity", 0))
        notional = float(order.get("notional_usdt", qty * market_price))
        if qty <= 0 or market_price <= 0:
            return {"executed": False, "reason": "invalid_quantity"}
        if notional > self.max_order_value:
            return {"executed": False, "reason": "max_order_value"}
        client_key = order.get("client_order_id") or f"qa{uuid.uuid4().hex[:24]}"
        if client_key in self.processed_ids:
            return {"executed": False, "reason": "duplicate"}

        if self.dry_run or self.okx_trader is None:
            # 用配置的滑点做保守模拟，但明确标记为 synthetic fill。
            slip = float(self.config.get("simulated_slippage_rate", 0.0005))
            fill_price = market_price * (1 + slip if side == "BUY" else 1 - slip)
            self.processed_ids.add(client_key)
            return {
                "executed": True,
                "real": False,
                "order_id": client_key,
                "fill_price": fill_price,
                "fill_quantity": qty,
                "fee_usdt": notional * float(self.config.get("fee_rate", 0.001)),
            }

        try:
            if side == "BUY" and order.get("notional_usdt") is not None:
                request_size = float(order["notional_usdt"])
                tgt_ccy = "quote_ccy"
            else:
                request_size = qty
                tgt_ccy = "base_ccy"
            result = self.okx_trader.place_order(symbol, side, request_size, order_type="market", tgt_ccy=tgt_ccy)
            order_id = result["ordId"]
            filled = self.okx_trader.wait_for_fill(symbol, order_id, self.max_fill_wait_sec)
            if not filled:
                return {"executed": False, "reason": "fill_timeout", "order_id": order_id}
            state = str(filled.get("state", "")).lower()
            if state != "filled":
                return {"executed": False, "reason": f"order_state_{state}", "order_id": order_id}
            fill_qty = float(filled.get("accFillSz") or qty)
            fill_price = float(filled.get("avgPx") or filled.get("px") or market_price)
            fee_raw = abs(float(filled.get("fee", 0) or 0))
            quote_ccy = symbol.split("-")[-1].upper()
            fee_ccy = str(filled.get("feeCcy", "")).upper()
            fee = fee_raw if fee_ccy in {quote_ccy, ""} else fee_raw * fill_price
            self.processed_ids.add(client_key)
            return {
                "executed": True,
                "real": True,
                "order_id": order_id,
                "fill_price": fill_price,
                "fill_quantity": fill_qty,
                "fee_usdt": fee,
            }
        except Exception as exc:
            logger.error("执行订单失败 {} {}: {}", symbol, side, exc)
            return {"executed": False, "reason": str(exc)}
