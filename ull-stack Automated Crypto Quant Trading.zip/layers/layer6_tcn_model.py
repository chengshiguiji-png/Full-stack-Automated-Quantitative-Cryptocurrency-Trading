﻿import torch
import torch.nn as nn
import numpy as np

class TCNPredictor:
    def __init__(self, model_path):
        checkpoint = torch.load(model_path, map_location=torch.device('cpu'), weights_only=False)
        self.scaler_mean = checkpoint['scaler_mean']
        self.scaler_scale = checkpoint['scaler_scale']
        self.seq_len = checkpoint['seq_len']
        self.model = TCN(input_dim=2, num_channels=[32, 32, 16], kernel_size=3, dropout=0.2)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.model.eval()

    def predict(self, df):
        # 计算特征（收益率 + 成交量比率）
        df = df.copy()
        df['returns'] = df['close'].pct_change()
        df['vol_ratio'] = df['volume'] / df['volume'].rolling(20).mean()
        df = df.dropna().tail(self.seq_len)
        if len(df) < self.seq_len:
            return 0.5
        X = df[['returns', 'vol_ratio']].values
        # 标准化
        X = (X - self.scaler_mean) / (self.scaler_scale + 1e-9)
        X_tensor = torch.tensor(X, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            prob = self.model(X_tensor).item()
        return prob

class TCN(nn.Module):
    def __init__(self, input_dim=2, num_channels=[32, 32, 16], kernel_size=3, dropout=0.2):
        super(TCN, self).__init__()
        layers = []
        in_dim = input_dim
        for out_dim in num_channels:
            layers += [
                nn.Conv1d(in_dim, out_dim, kernel_size, padding=kernel_size-1),
                nn.ReLU(),
                nn.Dropout(dropout),
            ]
            in_dim = out_dim
        self.conv = nn.Sequential(*layers)
        self.fc = nn.Linear(in_dim, 1)

    def forward(self, x):
        x = x.permute(0, 2, 1)
        x = self.conv(x)
        x = x.mean(dim=-1)
        return torch.sigmoid(self.fc(x)).squeeze()
