# -*- coding: utf-8 -*-
"""第8层：盘口/成交流微结构。
没有真实 orderbook/trade 数据时必须返回中性值，禁止随机制造信号。
"""
from __future__ import annotations

import numpy as np
from loguru import logger


class MicrostructureAnalyzer:
    def __init__(self, config=None):
        self.config = config or {}

    def analyze(self, orderbook=None, trades=None, window_seconds=60):
        if orderbook is None and trades is None:
            return 0.0
        try:
            scores = []
            if isinstance(orderbook, dict):
                bids = orderbook.get("bids") or []
                asks = orderbook.get("asks") or []
                bid_vol = sum(float(x[1]) for x in bids[:10] if len(x) >= 2)
                ask_vol = sum(float(x[1]) for x in asks[:10] if len(x) >= 2)
                if bid_vol + ask_vol > 0:
                    scores.append(np.clip((bid_vol - ask_vol) / (bid_vol + ask_vol), -1, 1))
            if trades:
                buy = sell = 0.0
                for t in trades[-500:]:
                    side = str(t.get("side", "")).lower() if isinstance(t, dict) else ""
                    qty = float(t.get("qty", t.get("size", 0))) if isinstance(t, dict) else 0.0
                    if side == "buy": buy += qty
                    elif side == "sell": sell += qty
                if buy + sell > 0:
                    scores.append(np.clip((buy - sell) / (buy + sell), -1, 1))
            return float(np.mean(scores)) if scores else 0.0
        except Exception as exc:
            logger.warning("微结构计算失败，返回中性: %s", exc)
            return 0.0
