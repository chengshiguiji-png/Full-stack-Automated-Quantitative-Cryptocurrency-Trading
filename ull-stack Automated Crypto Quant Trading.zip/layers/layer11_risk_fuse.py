# -*- coding: utf-8 -*-
"""第11层：最终风险熔断。
所有仓位统一按 USDT 名义价值衡量。
"""
from __future__ import annotations

from datetime import date
from loguru import logger


class RiskFuse:
    def __init__(self, config=None):
        self.config = config or {}
        self.max_daily_loss_rate = float(self.config.get("max_daily_loss_rate", 0.02))
        self.max_total_exposure_rate = float(self.config.get("max_total_exposure_rate", 0.60))
        self.single_symbol_max_rate = float(self.config.get("single_symbol_max_rate", 0.20))
        self.leverage_max = float(self.config.get("leverage_max", 1))
        self.last_reset_date = date.today()
        self.daily_loss = 0.0

    def check(self, order, portfolio, market_data=None):
        if date.today() != self.last_reset_date:
            self.daily_loss = 0.0
            self.last_reset_date = date.today()
        portfolio = portfolio or {}
        market_data = market_data or {}
        total_value = float(portfolio.get("total_value", 0))
        if total_value <= 0:
            return {"allowed": False, "reasons": ["组合权益无效"]}
        today_pnl = float(portfolio.get("today_pnl", 0))
        if today_pnl < -self.max_daily_loss_rate * total_value:
            return {"allowed": False, "reasons": ["当日亏损超过熔断阈值"]}

        leverage = float(order.get("leverage", 1))
        if leverage > self.leverage_max:
            return {"allowed": False, "reasons": ["杠杆超过上限"]}

        symbol = str(order.get("symbol", "")).upper()
        if symbol.endswith("-USDT"):
            base = symbol.split("-")[0]
        else:
            base = symbol
        side = str(order.get("side", "")).upper()
        current_price = float(market_data.get("current_price", 0))
        prices = market_data.get("prices", {}) or {}
        price = float(prices.get(symbol, prices.get(base, current_price)) or current_price)
        if price <= 0:
            return {"allowed": False, "reasons": ["缺少有效价格"]}

        positions = portfolio.get("positions", {}) or {}
        current_qty = float(positions.get(symbol, positions.get(base, 0)) or 0)
        order_value = float(order.get("notional_usdt", 0))
        if order_value <= 0 and order.get("quantity") is not None:
            order_value = float(order["quantity"]) * price
        if order_value <= 0:
            return {"allowed": False, "reasons": ["订单名义价值无效"]}

        current_exposure = 0.0
        for sym, qty in positions.items():
            p = float(prices.get(sym, prices.get(str(sym).split("-")[0], price)) or price)
            current_exposure += max(0.0, float(qty)) * p
        current_symbol_exposure = max(0.0, current_qty * price)
        if side == "BUY":
            new_symbol_exposure = current_symbol_exposure + order_value
            new_total_exposure = current_exposure + order_value
            if new_symbol_exposure > total_value * self.single_symbol_max_rate:
                return {"allowed": False, "reasons": ["单品种仓位超限"]}
            if new_total_exposure > total_value * self.max_total_exposure_rate:
                return {"allowed": False, "reasons": ["总敞口超限"]}

        volatility = float(market_data.get("volatility", 0) or 0)
        if volatility > float(self.config.get("max_entry_volatility", 0.025)):
            return {"allowed": False, "reasons": ["波动率过高"]}
        if bool(market_data.get("panic", False)) and side == "BUY":
            return {"allowed": False, "reasons": ["恐慌模式禁止开多"]}
        return {"allowed": True, "reasons": []}
