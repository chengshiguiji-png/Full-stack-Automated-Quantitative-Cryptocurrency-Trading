﻿# layers/layer1_ws_collector.py - 稳健WebSocket采集（指数退避重连）
import json, threading, time
import websocket
from loguru import logger

class WSDataCollector:
    def __init__(self, symbols=["BTC-USDT", "ETH-USDT", "SOL-USDT"]):
        self.symbols = symbols
        self.caches = {s: [] for s in symbols}
        self._lock = threading.Lock()
        self.ws = None
        self.running = False
        self.thread = None
        self.retry_count = 0
        self.max_retry = 10

    def start(self):
        self.running = True
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close()

    def get_klines(self, symbol, limit=200):
        with self._lock:
            if symbol in self.caches and len(self.caches[symbol]) >= limit:
                return self.caches[symbol][-limit:]
            return None

    def _run(self):
        while self.running:
            try:
                self.ws = websocket.WebSocketApp(
                    "wss://ws.okx.com:8443/ws/v5/public",
                    on_open=self._on_open,
                    on_message=self._on_message,
                    on_error=self._on_error,
                    on_close=self._on_close
                )
                self.ws.run_forever()
            except Exception as e:
                logger.error(f"WebSocket 连接异常: {e}")
            # 指数退避等待
            if self.retry_count < self.max_retry:
                wait = min(60, 2 ** self.retry_count)
                self.retry_count += 1
                logger.debug(f"WebSocket 将在 {wait} 秒后重连 (第 {self.retry_count}/{self.max_retry} 次)")
                time.sleep(wait)
            else:
                logger.error("WebSocket 重连次数耗尽，暂停 5 分钟")
                time.sleep(300)
                self.retry_count = 0

    def _on_open(self, ws):
        self.retry_count = 0
        for sym in self.symbols:
            subscribe_msg = json.dumps({
                "op": "subscribe",
                "args": [{"channel": "candle1m", "instId": sym}]
            })
            ws.send(subscribe_msg)
        logger.info("WebSocket 已连接并订阅行情")

    def _on_message(self, ws, message):
        try:
            data = json.loads(message)
            if "data" in data:
                for item in data["data"]:
                    candle = [
                        int(item[0]), float(item[1]), float(item[2]),
                        float(item[3]), float(item[4]), float(item[5]),
                        float(item[6]), float(item[7]), int(item[8])
                    ]
                    inst_id = item[-1]
                    with self._lock:
                        cache = self.caches.get(inst_id)
                        if cache is None: continue
                        if cache and cache[-1][0] == candle[0]:
                            cache[-1] = candle
                        else:
                            cache.append(candle)
                            if len(cache) > 300:
                                cache.pop(0)
        except Exception as e:
            logger.debug(f"WebSocket 消息解析失败: {e}")

    def _on_error(self, ws, error):
        logger.debug(f"WebSocket 错误: {error}")

    def _on_close(self, ws, close_status_code, close_msg):
        logger.debug("WebSocket 连接关闭，将自动重连")
