# -*- coding: utf-8 -*-
"""第13层：风险预算仓位管理。"""
from __future__ import annotations

import numpy as np
from loguru import logger


class PositionManager:
    def __init__(self, config=None):
        self.config = config or {}
        self.risk_budget = float(self.config.get("risk_budget", 0.005))
        self.max_position_pct = float(self.config.get("max_position_pct", 0.20))
        self.trailing_stop_pct = float(self.config.get("trailing_stop_pct", 0.015))
        self.take_profit_pct = float(self.config.get("take_profit_pct", 0.0368))
        self.consecutive_losses = 0
        self.consecutive_wins = 0
        self.highest_price = 0.0
        self.lowest_price = 0.0

    def calculate_position_size(self, capital: float, volatility: float, signal_confidence: float,
                               atr: float = 0.0, recent_returns=None) -> float:
        if capital <= 0:
            return 0.0
        volatility = max(float(volatility), 1e-5)
        confidence = max(0.0, min(1.0, float(signal_confidence)))
        risk_amount = capital * self.risk_budget
        stop_pct = max(self.config.get("min_stop_pct", 0.004), float(self.config.get("atr_multiplier", 1.2)) * float(atr) / max(1.0, capital)) if atr else max(0.004, volatility * 2.0)
        # 以百分比风险近似计算名义仓位，再受最大组合比例限制。
        position_value = risk_amount / max(stop_pct, 1e-4)
        vol_adj = float(np.clip(0.012 / volatility, 0.35, 1.0))
        conf_adj = 0.5 + 0.5 * confidence
        loss_adj = 0.5 ** min(self.consecutive_losses, 3)
        # 不因连胜加杠杆：只允许持平或降仓。
        position_value *= vol_adj * conf_adj * loss_adj
        position_value = min(position_value, capital * self.max_position_pct)
        return max(0.0, float(position_value))

    def update_trade_result(self, is_win: bool):
        if is_win:
            self.consecutive_wins += 1
            self.consecutive_losses = 0
        else:
            self.consecutive_losses += 1
            self.consecutive_wins = 0

    def manage_position(self, current_price: float, entry_price: float, side: str = "BUY") -> dict:
        if entry_price <= 0 or current_price <= 0:
            return {"action": "HOLD", "reason": "no_position"}
        side = side.upper()
        if side != "BUY":
            return {"action": "HOLD", "reason": "short_not_enabled"}
        self.highest_price = max(self.highest_price, current_price, entry_price)
        pnl_pct = current_price / entry_price - 1
        if pnl_pct <= -float(self.config.get("stop_loss_pct", 0.0078)):
            return {"action": "STOP_LOSS", "reason": "硬止损"}
        if pnl_pct >= self.take_profit_pct:
            return {"action": "TAKE_PROFIT", "reason": "止盈"}
        trail = self.highest_price * (1 - self.trailing_stop_pct)
        if self.highest_price > entry_price and current_price <= trail:
            return {"action": "TRAILING_STOP", "reason": "移动止损"}
        return {"action": "HOLD", "reason": "正常"}
