# -*- coding: utf-8 -*-
"""第14层：基于真实已平仓结果的自适应统计。
不再使用随机分数、随机 A/B 结果或连胜加仓。
"""
from __future__ import annotations

from datetime import date
from collections import deque


class AdaptiveLearner:
    def __init__(self, config=None):
        cfg = (config or {}).get("adaptive", {})
        self.alpha = float(cfg.get("ema_alpha", 0.1))
        self.ema_win = 0.5
        self.results = deque(maxlen=200)
        self.last_retrain_date = None
        self.min_samples = int(cfg.get("min_samples_retrain", 100))
        self.retrain_cooldown_hours = float(cfg.get("retrain_cooldown_hours", 24))

    def update_strategy_score(self, strategy_name, pnl, is_win):
        self.results.append(bool(is_win))
        self.ema_win = self.alpha * int(bool(is_win)) + (1 - self.alpha) * self.ema_win

    def daily_update(self, performance_metrics):
        today = date.today()
        if self.last_retrain_date == today:
            return {"retrained": False, "reason": "already_today"}
        self.last_retrain_date = today
        return {
            "retrained": False,
            "reason": "statistics_only",
            "ema_win": self.ema_win,
            "samples": len(self.results),
        }
