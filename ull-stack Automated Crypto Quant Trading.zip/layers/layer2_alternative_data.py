﻿"""
第2层：另类大数据采集层（模拟版）
"""
import random
import time
from datetime import datetime
from loguru import logger

class AlternativeDataCollector:
    def __init__(self, config=None):
        self.config = config or {}

    def get_sentiment_score(self, symbol="BTC"):
        score = random.uniform(-1, 1)
        sentiment = "positive" if score > 0.3 else "negative" if score < -0.3 else "neutral"
        return {
            "symbol": symbol,
            "sentiment_score": score,
            "sentiment_label": sentiment,
            "timestamp": datetime.now().isoformat()
        }

    def get_onchain_score(self, symbol="BTC"):
        whale_activity = random.choice(["accumulate", "distribute", "neutral"])
        onchain_score = random.uniform(-0.5, 0.5)
        return {
            "symbol": symbol,
            "onchain_score": onchain_score,
            "whale_activity": whale_activity,
            "timestamp": datetime.now().isoformat()
        }

    def get_event_risk(self):
        events = ["CPI", "Nonfarm Payrolls", "Fed Rate Decision"]
        event = random.choice(events)
        risk_level = random.choice(["low", "medium", "high"])
        return {
            "event": event,
            "risk_level": risk_level,
            "risk_score": 0.1 if risk_level == "low" else 0.5 if risk_level == "medium" else 0.9
        }

    def run_once(self):
        sentiment = self.get_sentiment_score()
        onchain = self.get_onchain_score()
        event = self.get_event_risk()
        combined = {**sentiment, **onchain, "event_risk": event}
        logger.info(f"第2层: sentiment={sentiment['sentiment_score']:.2f}, onchain={onchain['onchain_score']:.2f}")
        return combined

if __name__ == "__main__":
    print("=== 测试第2层（模拟数据）===")
    collector = AlternativeDataCollector()
    for i in range(3):
        data = collector.run_once()
        print(f"样本{i+1}: 情感分={data['sentiment_score']:.2f}, 链上分={data['onchain_score']:.2f}, 事件={data['event_risk']['event']}({data['event_risk']['risk_level']})")
        time.sleep(1)
    print("测试结束")
