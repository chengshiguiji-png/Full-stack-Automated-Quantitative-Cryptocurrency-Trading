# -*- coding: utf-8 -*-
"""第10层：入场过滤。
只负责二次安全检查，不重复实施第9层的概率门槛。"""
from __future__ import annotations

import time
from loguru import logger


class EntryFilter:
    def __init__(self, config=None):
        self.config = config or {}
        self.min_ev_edge = float(self.config.get("min_ev_edge", 0.08))
        self.cooldown_min = float(self.config.get("cooldown_min", 0))
        # 2026-09 修复：layer9算出来的confirmation（融合了sentiment_adj/micro_adj）
        # 以前只是被塞进signal字典就再也没人读过——不管情绪/LLM信号说什么，
        # 从来没有真正影响过任何一笔交易是否成交。现在真正接一个门槛：
        # 明显跟方向相反的confirmation会挡掉这笔信号。默认0.35/0.65（对称，比较宽松），
        # 只挡掉"情绪明显唱反调"的情况，不会因为情绪平平就否掉本来合格的信号。
        self.min_confirmation_for_buy = float(self.config.get("min_confirmation_for_buy", 0.35))
        self.max_confirmation_for_sell = float(self.config.get("max_confirmation_for_sell", 0.65))
        self.last_entry_time = 0.0
        self.last_entry_symbol = None

    def check(self, signal: dict, market_regime: str, available_capital: float, position_size: float) -> dict:
        reasons = []
        direction = str(signal.get("direction", "HOLD")).upper()
        symbol = signal.get("symbol", "")
        ev_edge = float(signal.get("ev_edge", 0.0))
        passed = True

        if direction not in {"BUY", "SELL"}:
            return self._result(False, ["信号方向不是 BUY/SELL"], signal)

        if market_regime == "transition":
            # 对应"过渡区"：ADX/ER都判不出方向，规则法也判不出方向。
            # 不区分BUY/SELL，新开仓一律不放行；已有持仓的止损/止盈/移动止损
            # 在第17层照常独立管理，不受这条限制影响。
            return self._result(False, ["过渡区(regime=transition)，暂不开新仓"], signal)

        if ev_edge < self.min_ev_edge:
            passed = False
            reasons.append(f"EV优势不足: {ev_edge:.3f} < {self.min_ev_edge:.3f}")

        confirmation = signal.get("confirmation")
        if confirmation is not None:
            confirmation = float(confirmation)
            if direction == "BUY" and confirmation < self.min_confirmation_for_buy:
                passed = False
                reasons.append(f"情绪/微观结构confirmation偏空({confirmation:.3f} < {self.min_confirmation_for_buy})，暂缓BUY")
            elif direction == "SELL" and confirmation > self.max_confirmation_for_sell:
                passed = False
                reasons.append(f"情绪/微观结构confirmation偏多({confirmation:.3f} > {self.max_confirmation_for_sell})，暂缓SELL")

        if (
            direction == "BUY"
            and
            market_regime == "extreme_liquidation"
        ):
            passed = False
            reasons.append(
                "极端清算状态下禁止新增 BUY"
            )

        if (
            direction == "BUY"
            and
            market_regime in ("strong_down", "strong_down_confirmed")
        ):
            # strong_down不再100%封杀BUY。
            #
            # 只允许非常有限的逆势反转：
            # 1. 主模型达到强信号
            # 2. RSI明显超卖
            # 3. 价格处于布林带低位
            # 4. edge至少达到0.05
            #
            # 这样不会把普通逆势BUY放进去，
            # 但不会再造成strong_down期间开仓机会永久归零。

            p_up = float(
                signal.get(
                    "p_up",
                    0.0,
                )
                or 0.0
            )

            rsi = signal.get(
                "rsi_14"
            )

            bb_pos = signal.get(
                "bb_pos"
            )

            strong_threshold = max(
                0.65,
                float(
                    signal.get(
                        "strong_threshold_up",
                        0.68,
                    )
                ),
            )

            countertrend_ok = (
                p_up
                >= strong_threshold
                and
                rsi is not None
                and
                float(rsi)
                <= 38.0
                and
                bb_pos is not None
                and
                float(bb_pos)
                <= 0.25
                and
                ev_edge
                >= max(
                    0.05,
                    self.min_ev_edge,
                )
            )

            if not countertrend_ok:

                passed = False

                reasons.append(
                    "strong_down逆势BUY条件不足"
                    f"(p_up={p_up:.3f}, "
                    f"rsi={rsi}, "
                    f"bb_pos={bb_pos})"
                )
        if direction == "SELL" and market_regime == "extreme_liquidation":
            passed = False
            reasons.append("极端清算状态下禁止新增方向交易")

        if (
            direction == "SELL"
            and
            market_regime in ("strong_up", "strong_up_confirmed")
        ):
            # 和 strong_down 对 BUY 的限制完全对称：strong_up 期间不是100%封杀SELL，
            # 而是只放行"确实有理由认为要反转"的逆势SELL——
            # 主模型强烈看空 + RSI明显超买 + 价格处于布林带高位 + edge足够。
            # 目的：单边上涨行情里，不能让"看到涨了一段就想做空摸顶"的信号轻易通过，
            # 这正是用户反馈"在单边上涨里还是按窄幅震荡执行下单"的对症之处——
            # 以前 strong_up 和 narrow_range 在这一层的处理是完全一样的，没有任何区别。
            p_up = float(signal.get("p_up", 0.0) or 0.0)
            rsi = signal.get("rsi_14")
            bb_pos = signal.get("bb_pos")
            strong_threshold_down = min(
                0.35,
                float(signal.get("strong_threshold_down", 0.32)),
            )
            countertrend_ok = (
                p_up <= strong_threshold_down
                and rsi is not None and float(rsi) >= 62.0
                and bb_pos is not None and float(bb_pos) >= 0.75
                and ev_edge >= max(0.05, self.min_ev_edge)
            )
            if not countertrend_ok:
                passed = False
                reasons.append(
                    "strong_up逆势SELL条件不足"
                    f"(p_up={p_up:.3f}, rsi={rsi}, bb_pos={bb_pos})"
                )

        now = time.time()
        if self.last_entry_symbol == symbol and self.cooldown_min > 0 and now - self.last_entry_time < self.cooldown_min * 60:
            passed = False
            reasons.append("同品种冷却中")
        if available_capital <= 0 or position_size <= 0:
            passed = False
            reasons.append("资金或仓位无效")
        if available_capital < position_size:
            passed = False
            reasons.append("可用资金不足")
        if passed:
            self.last_entry_time = now
            self.last_entry_symbol = symbol
            logger.info("过滤通过: {} {} edge={:.3f}", direction, symbol, ev_edge)
        else:
            logger.info("过滤拒绝: {} {} 原因={}", direction, symbol, "; ".join(reasons))
        return self._result(passed, reasons, signal)

    def _result(self, passed, reasons, signal):
        return {"passed": passed, "reasons": reasons, "adjusted_signal": signal if passed else None}
