﻿# layers/layer20_adaptive_learning.py
import time, threading, numpy as np, joblib, os, shutil
from collections import deque
from loguru import logger
from layers.layer6_ml_model import MLModelEnsemble

class AdaptiveLearner:
    def __init__(self, config):
        adp = config.get("adaptive", {})
        self.alpha = adp.get("ema_alpha", 0.1)
        self.min_samples = adp.get("min_samples_retrain", 50)
        self.thresh = adp.get("win_rate_threshold", 0.45)
        self.ema_win = 0.5
        self.preds = deque(maxlen=500)
        self.model_path = "ml_lib/trained_models/ensemble_model.pkl"
        self.backup_path = self.model_path + ".bak"
        self.scaler_path = "ml_lib/transformers/scaler.pkl"
        self.selector_path = "ml_lib/transformers/selector.pkl"
        self.lock = threading.Lock()
        self.training = False
        self.last_train = 0
        self.cooldown = adp.get("retrain_cooldown_hours", 24) * 3600
        self.retrain_count = 0
        self.max_retrains = adp.get("max_retrains", 3)
        self.disabled = False

    def update_ema_win_rate(self, correct):
        self.preds.append(correct)
        self.ema_win = self.alpha * int(correct) + (1 - self.alpha) * self.ema_win

    def should_retrain(self):
        if self.disabled:
            return False
        if len(self.preds) < self.min_samples:
            return False
        if self.ema_win >= self.thresh:
            return False
        if time.time() - self.last_train < self.cooldown:
            return False
        if self.training:
            return False
        if self.retrain_count >= self.max_retrains:
            logger.warning("重训练次数已达上限，自适应学习已禁用")
            self.disabled = True
            return False
        return True

    def trigger_retrain(self, X_raw, y_train):
        if self.training or self.disabled:
            return
        self.training = True
        logger.warning(f"开始异步重训练（第{self.retrain_count+1}次），EMA胜率:{self.ema_win:.3f}")
        threading.Thread(target=self._retrain, args=(X_raw, y_train), daemon=True).start()

    def _retrain(self, X_raw, y_train):
        try:
            with self.lock:
                # 安全保护：如果只有一个类别，跳过本次重训练
                if len(set(y_train)) < 2:
                    logger.warning("训练数据只有一个类别，跳过重训练")
                    self.last_train = time.time()
                    return
                scaler = joblib.load(self.scaler_path)
                selector = joblib.load(self.selector_path)
                X_scaled = scaler.transform(X_raw)
                X_sel = selector.transform(X_scaled)
                model = MLModelEnsemble()
                model.train(X_sel, y_train)
                # 先删除旧备份，再备份当前模型
                if os.path.exists(self.backup_path):
                    os.remove(self.backup_path)
                if os.path.exists(self.model_path):
                    shutil.move(self.model_path, self.backup_path)
                joblib.dump(model, self.model_path)
                self.last_train = time.time()
                self.retrain_count += 1
                logger.success(f"重训练完成（第{self.retrain_count}次），新模型已保存")
        except Exception as e:
            logger.error(f"重训练失败: {e}")
        finally:
            self.training = False

    def opponent_modeling(self, trades: list):
        pass

    def genetic_strategy_factory(self):
        pass
