# -*- coding: utf-8 -*-
"""第5层：可选新闻情绪，默认中性。"""
from __future__ import annotations

import os
import time


class DeepNewsSentiment:
    def __init__(self, v4_api_key=None):
        self.enabled = os.getenv("DEEP_NEWS_ENABLED", "false").lower() == "true"
        self.cache = {"time": 0.0, "score": 0.0, "summary": "disabled"}
        self.cache_ttl = 300

    def get_sentiment(self):
        if not self.enabled:
            return 0.0, "disabled"
        if time.time() - self.cache["time"] < self.cache_ttl:
            return self.cache["score"], self.cache["summary"]
        # 新闻模块保留接口，避免其网络抖动影响主策略。
        self.cache = {"time": time.time(), "score": 0.0, "summary": "no_news_provider"}
        return 0.0, "no_news_provider"
