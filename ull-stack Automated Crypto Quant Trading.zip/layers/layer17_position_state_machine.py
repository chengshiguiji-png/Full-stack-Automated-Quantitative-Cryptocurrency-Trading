# -*- coding: utf-8 -*-
"""第17层：现货多头持仓状态机。"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import time

from loguru import logger


class PositionState(Enum):
    EMPTY = "empty"
    HOLDING = "holding"
    PARTIAL_CLOSE = "partial_close"
    STOPPED = "stopped"
    COOLDOWN = "cooldown"


@dataclass
class PositionInfo:
    symbol: str
    state: PositionState = PositionState.EMPTY
    quantity: float = 0.0
    entry_price: float = 0.0
    highest_price: float = 0.0
    lowest_price: float = 0.0
    current_sl: float = 0.0
    current_tp: float = 0.0
    cooldown_until: float = 0.0
    cooldown_duration: float = 1800.0
    trailing_activated: bool = False
    partial_close_ratio: float = 0.33
    partial_close_trigger: float = 0.004
    sl_multiplier: float = 1.0
    tp_multiplier: float = 2.0
    trailing_multiplier: float = 1.0
    partial_closed: bool = False
    entry_time: float = 0.0
    oscillation: bool = False


class PositionStateMachine:
    def __init__(self, config=None):
        cfg = config or {}
        sm = cfg.get("state_machine", cfg)
        self.partial_close_ratio = float(sm.get("partial_close_ratio", 0.33))
        self.partial_close_trigger = float(sm.get("partial_profit_pct", 0.004))
        self.sl_multiplier = float(sm.get("atr_stop_multiplier", 1.0))
        self.tp_multiplier = float(sm.get("profit_lock_atr_mult", 2.0))
        self.trailing_multiplier = float(sm.get("aggressive_trail_atr_mult", 1.0))
        self.cooldown_duration = float(sm.get("cool_down_minutes", 30)) * 60
        self.use_sar = bool(sm.get("use_sar", False))

    def initialize_position(self, symbol: str) -> PositionInfo:
        return PositionInfo(
            symbol=symbol,
            cooldown_duration=self.cooldown_duration,
            partial_close_ratio=self.partial_close_ratio,
            partial_close_trigger=self.partial_close_trigger,
            sl_multiplier=self.sl_multiplier,
            tp_multiplier=self.tp_multiplier,
            trailing_multiplier=self.trailing_multiplier,
        )

    def allow_new_entry(self, pi: PositionInfo) -> bool:
        if pi.state in (PositionState.HOLDING, PositionState.PARTIAL_CLOSE, PositionState.STOPPED):
            return False
        if pi.state == PositionState.COOLDOWN:
            if time.time() < pi.cooldown_until:
                return False
            pi.state = PositionState.EMPTY
            pi.cooldown_until = 0.0
            pi.partial_closed = False
        return True

    def update_on_price(self, pi: PositionInfo, current_price: float, df_feat, atr: float, market_regime: str = None):
        if pi.state not in (PositionState.HOLDING, PositionState.PARTIAL_CLOSE):
            return
        if pi.entry_price <= 0 or current_price <= 0:
            return
        pi.highest_price = max(pi.highest_price, current_price)
        pi.lowest_price = current_price if pi.lowest_price <= 0 else min(pi.lowest_price, current_price)
        atr = max(float(atr), pi.entry_price * 0.001)

        if pi.current_sl > 0 and current_price <= pi.current_sl:
            pi.state = PositionState.STOPPED
            return
        # 分级放行止盈上限：
        # - strong_up_confirmed（规则法+ADX/ER都确认了强趋势）：彻底取消固定止盈，
        #   只靠移动止损和到时间强制平仓来退出，让利润真正奔跑，
        #   这是针对"止盈后价格继续涨"这个具体投诉的直接修复。
        # - strong_up/trend（只有规则法确认，ADX/ER没有双确认，更不确定）：
        #   保留固定止盈上限，只放宽移动止损距离——更保守，避免仅凭一个信号来源
        #   就大幅改变退出纪律。
        # - 其它状态：行为不变。
        tp_disabled = market_regime == "strong_up_confirmed"
        if not tp_disabled and pi.current_tp > 0 and current_price >= pi.current_tp:
            pi.state = PositionState.STOPPED
            return
        profit_pct = current_price / pi.entry_price - 1
        if not pi.partial_closed and profit_pct >= self.partial_close_trigger:
            pi.state = PositionState.PARTIAL_CLOSE
            return

        # 市场状态感知的移动止损宽度：以前这里跟市场状态完全无关，导致哪怕已经确认
        # 是单边上涨(strong_up/trend)，移动止损还是按窄幅震荡一样的紧距离收，
        # 经常在正常的趋势内回调里就被震出局，吃不到后面的主升浪。
        # strong_up_confirmed 放得最宽（2.2倍，配合上面取消固定止盈）；
        # strong_up/trend（仅规则法确认）放宽到1.6倍；
        # narrow_range/wide_range/noise 保持原样收紧（这类状态下本来就该早点落袋）。
        effective_trailing_mult = pi.trailing_multiplier
        if market_regime == "strong_up_confirmed":
            effective_trailing_mult = pi.trailing_multiplier * 2.2
        elif market_regime in ("strong_up", "trend"):
            effective_trailing_mult = pi.trailing_multiplier * 1.6
        elif market_regime in ("narrow_range", "wide_range", "noise"):
            effective_trailing_mult = pi.trailing_multiplier

        if current_price >= pi.entry_price + effective_trailing_mult * atr:
            new_sl = pi.highest_price - effective_trailing_mult * atr
            if new_sl > pi.current_sl:
                pi.current_sl = new_sl
                pi.trailing_activated = True

    def on_order_filled(self, pi: PositionInfo, side: str, quantity: float, price: float, atr: float):
        side = side.upper()
        quantity = float(quantity)
        price = float(price)
        atr = max(float(atr), price * 0.001)
        if side == "BUY":
            old_qty = pi.quantity
            old_entry = pi.entry_price
            new_qty = old_qty + quantity
            pi.entry_price = ((old_qty * old_entry) + quantity * price) / new_qty if new_qty > 0 else price
            pi.quantity = new_qty
            pi.highest_price = max(pi.highest_price, price)
            pi.lowest_price = price if pi.lowest_price <= 0 else min(pi.lowest_price, price)
            pi.current_sl = pi.entry_price - self.sl_multiplier * atr
            pi.current_tp = pi.entry_price + self.tp_multiplier * atr
            pi.trailing_activated = False
            pi.partial_closed = False
            pi.entry_time = pi.entry_time or time.time()
            pi.state = PositionState.HOLDING
        elif side == "SELL":
            pi.quantity = max(0.0, pi.quantity - quantity)
            if pi.quantity <= 1e-12:
                pi.quantity = 0.0
                pi.state = PositionState.COOLDOWN
                pi.cooldown_until = time.time() + pi.cooldown_duration
                pi.current_sl = 0.0
                pi.current_tp = 0.0
                pi.partial_closed = False
                pi.trailing_activated = False
                pi.entry_price = 0.0
                pi.entry_time = 0.0
            else:
                pi.state = PositionState.HOLDING
                pi.partial_closed = True
