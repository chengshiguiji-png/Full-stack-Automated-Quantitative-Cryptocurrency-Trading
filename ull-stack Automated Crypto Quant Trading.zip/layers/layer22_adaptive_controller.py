﻿from loguru import logger

class AdaptiveController:
    def __init__(self):
        self.recent_trades = []
        self.mode = "normal"

    def update(self, pnl):
        self.recent_trades.append(pnl)
        if len(self.recent_trades) > 10:
            self.recent_trades.pop(0)

    def should_be_conservative(self):
        if len(self.recent_trades) >= 5:
            win_rate = sum(1 for p in self.recent_trades if p > 0) / len(self.recent_trades)
            consec_loss = sum(1 for p in self.recent_trades[-4:] if p <= 0)
            if win_rate < 0.30 or consec_loss >= 4:
                self.mode = "conservative"
                logger.warning(f"触发保守模式：胜率 {win_rate:.1%}，连续亏损 {consec_loss} 笔")
                return True
        if self.mode == "conservative" and len(self.recent_trades) >= 5:
            win_rate = sum(1 for p in self.recent_trades if p > 0) / len(self.recent_trades)
            consec_win = sum(1 for p in self.recent_trades[-2:] if p > 0)
            if win_rate > 0.5 and consec_win >= 2:
                self.mode = "normal"
                logger.info(f"恢复正常模式：胜率 {win_rate:.1%}")
                return False
        return self.mode == "conservative"

    def get_adjusted_params(self, base_vote=2, base_cool=10, base_size=500, market_regime="narrow_range"):
        if self.mode == "conservative":
            return {"vote_threshold": 3, "cool_down_min": 15, "position_size": 300}
        if market_regime == "trend":
            return {"vote_threshold": max(1, base_vote - 1), "cool_down_min": max(3, base_cool // 2), "position_size": min(600, base_size + 100)}
        elif market_regime == "volatile":
            return {"vote_threshold": 3, "cool_down_min": 20, "position_size": 300}
        else:
            return {"vote_threshold": base_vote, "cool_down_min": base_cool, "position_size": base_size}