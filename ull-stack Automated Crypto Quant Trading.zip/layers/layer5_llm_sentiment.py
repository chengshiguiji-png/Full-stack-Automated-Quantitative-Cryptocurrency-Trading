# -*- coding: utf-8 -*-
"""第5层：可选 LLM 市场解读。
LLM 永远不能直接拥有下单权，也不能修改 ML 概率。
默认关闭，缺少 API 时返回中性结果。
"""
from __future__ import annotations

import json
import os
import re
from typing import Optional

from loguru import logger


class SentimentRiskAnalyzer:
    def __init__(self, api_key: Optional[str] = None, model: str = "claude-3-5-sonnet-20241022",
                 v4_api_key: Optional[str] = None, v4_model: str = "deepseek-chat",
                 enabled: Optional[bool] = None):
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        self.model = model
        self.v4_api_key = v4_api_key or os.getenv("DEEPSEEK_API_KEY")
        self.v4_model = v4_model
        # 2026-09 修复：以前这里只认环境变量 LLM_SENTIMENT_ENABLED，跟 config.yaml 里的
        # sentiment.enable 完全是两回事——改config.yaml那个开关实际上什么都不会发生，
        # 因为 main_strategy.py 构造这个类时根本没把 config 传进来。
        # 现在优先用调用方显式传入的 enabled（应该来自 config.yaml），
        # 没传时才退回环境变量，保持向后兼容。
        if enabled is not None:
            self.enabled = bool(enabled)
        else:
            self.enabled = os.getenv("LLM_SENTIMENT_ENABLED", "false").lower() == "true"

    def run_once(self, asset, df_feat):
        if not self.enabled:
            return {
                "sentiment_adj": 0.0,
                "llm_confidence": 0.0,
                "ai_action": "HOLD",
                "ai_reason": "LLM未启用；仅使用量化模型",
                "v4_raw_score": 0.0,
                "v4_raw_reason": "disabled",
            }
        rsi = float(df_feat["rsi_14"].iloc[-1]) if "rsi_14" in df_feat else 50.0
        ret3 = float(df_feat["ret_3"].iloc[-1]) if "ret_3" in df_feat else 0.0
        prompt = (
            f"资产={asset}; RSI={rsi:.2f}; ret3={ret3:.4%}. "
            "请只做市场风险/情绪描述，不直接授权交易。"
            ' 输出JSON: {"sentiment": -1到1, "confidence": 0到1, "reason": ""}'
        )
        # 先试 Claude，失败或没配置 key 再试 DeepSeek——
        # 以前 v4_api_key/v4_model 这两个字段定义了但从没在任何地方被真正用过，
        # 相当于"DeepSeek"这半只是摆设。现在两条路径都是真的会被调用的。
        result = self._call_claude(asset, prompt)
        if result is not None:
            return result
        result = self._call_deepseek(asset, prompt)
        if result is not None:
            return result
        return {
            "sentiment_adj": 0.0, "llm_confidence": 0.0, "ai_action": "HOLD",
            "ai_reason": "Claude 和 DeepSeek 均不可用（未安装依赖/未配置key/调用失败）",
            "v4_raw_score": 0.0, "v4_raw_reason": "all_providers_unavailable",
        }

    def _parse_llm_json(self, text: str) -> dict:
        match = re.search(r"\{.*\}", text, re.S)
        data = json.loads(match.group()) if match else {}
        score = max(-1.0, min(1.0, float(data.get("sentiment", 0.0))))
        conf = max(0.0, min(1.0, float(data.get("confidence", 0.0))))
        return {
            "sentiment_adj": score * conf * 0.1,
            "llm_confidence": conf,
            "ai_action": "HOLD",
            "ai_reason": str(data.get("reason", "")),
            "v4_raw_score": score,
            "v4_raw_reason": str(data.get("reason", "")),
        }

    def _call_claude(self, asset, prompt) -> Optional[dict]:
        # 为避免把第三方 LLM SDK 强绑进主程序，这里只在用户显式开启时动态导入。
        try:
            from anthropic import Anthropic
        except ImportError:
            logger.debug("anthropic 未安装，跳过 Claude，尝试 DeepSeek")
            return None
        if not self.api_key:
            logger.debug("未配置 ANTHROPIC_API_KEY，跳过 Claude，尝试 DeepSeek")
            return None
        try:
            client = Anthropic(api_key=self.api_key)
            resp = client.messages.create(model=self.model, max_tokens=180, temperature=0,
                                          messages=[{"role": "user", "content": prompt}])
            text = resp.content[0].text if resp.content else ""
            return self._parse_llm_json(text)
        except Exception as exc:
            logger.warning("Claude 情绪分析失败: {}，尝试 DeepSeek", exc)
            return None

    def _call_deepseek(self, asset, prompt) -> Optional[dict]:
        # DeepSeek 的 API 是 OpenAI 兼容格式，用 openai SDK 指向 DeepSeek 的 base_url 即可，
        # 不需要单独的 DeepSeek SDK。
        try:
            from openai import OpenAI
        except ImportError:
            logger.debug("openai 库未安装（DeepSeek调用需要它），跳过")
            return None
        if not self.v4_api_key:
            logger.debug("未配置 DEEPSEEK_API_KEY，跳过")
            return None
        try:
            client = OpenAI(api_key=self.v4_api_key, base_url="https://api.deepseek.com")
            resp = client.chat.completions.create(
                model=self.v4_model, max_tokens=180, temperature=0,
                messages=[{"role": "user", "content": prompt}],
            )
            text = resp.choices[0].message.content if resp.choices else ""
            return self._parse_llm_json(text)
        except Exception as exc:
            logger.warning("DeepSeek 情绪分析失败: {}", exc)
            return None
