# -*- coding: utf-8 -*-
"""按币种合并全局配置与 symbol_overrides，供 main_strategy / backtest_engine / train_model 共用。

设计原则：
- 全局 signal / risk 段落作为默认值，symbol_overrides.<SYMBOL> 中出现的键覆盖对应默认值。
- enabled=false 的币种：调用方（目前是 main_strategy.py 的实盘循环）应在生成信号之前就直接跳过，
  而不是依赖信号层自己把阈值调到永远触发不了——那样一旦以后有人为了调参改动阈值，
  一个本应被暂停的币种可能在无人察觉的情况下"复活"。
- direction_mode: normal | inverted。inverted 表示把模型给出的方向对调（例如"模型说涨，实际做空"）。
  这是一个高风险配置项：只有在独立于产生该假设的样本之外，重新做过一次样本外验证、
  且置信区间下界仍然清晰站在盈亏平衡点之上时，才应该把某个币种设为 inverted。
  仅仅因为回测里某个方向的历史精确率低于50%，不构成把它设为 inverted 的理由
  ——那是在用产生假设的同一批数据去"验证"假设，是过拟合的典型陷阱。
"""
from __future__ import annotations

import copy


def _deep_merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base or {})
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def get_symbol_override(config: dict, symbol: str) -> dict:
    overrides = config.get("symbol_overrides", {}) or {}
    return overrides.get(symbol, {}) or {}


def is_symbol_enabled(config: dict, symbol: str) -> bool:
    """是否允许该币种参与实盘/纸面交易下单。默认 True（未配置 = 不限制）。"""
    ov = get_symbol_override(config, symbol)
    return bool(ov.get("enabled", True))


def get_symbol_signal_config(config: dict, symbol: str) -> dict:
    """合并全局 signal 配置与该币种的 signal 覆盖项，并把 direction_mode 转成
    SignalGenerator 能直接使用的 invert_direction 布尔开关。"""
    base = config.get("signal", {}) or {}
    ov = get_symbol_override(config, symbol).get("signal", {}) or {}
    merged = _deep_merge(base, ov)
    mode = str(merged.get("direction_mode", "normal")).lower()
    merged["direction_mode"] = mode if mode in ("normal", "inverted") else "normal"
    merged["invert_direction"] = merged["direction_mode"] == "inverted"
    return merged


def get_symbol_risk_config(config: dict, symbol: str) -> dict:
    base = config.get("risk", {}) or {}
    ov = get_symbol_override(config, symbol).get("risk", {}) or {}
    return _deep_merge(base, ov)


def check_horizon_consistency(config: dict, logger=None) -> bool:
    """检查 label.horizon_bars 与 strategy.max_hold_bars 是否一致。

    不一致只告警、不阻断运行——因为训练脚本和回测脚本也会调用这个检查，
    阻断会导致连"看一眼当前差多少"都做不到。真正阻断实盘下单的是 is_symbol_enabled。
    """
    h = int((config.get("label", {}) or {}).get("horizon_bars", 12))
    m = int((config.get("strategy", {}) or {}).get("max_hold_bars", 16))
    ok = h == m
    if not ok and logger is not None:
        logger.warning(
            "[HORIZON MISMATCH] label.horizon_bars={} != strategy.max_hold_bars={}; "
            "模型训练视界与持仓上限不一致，信号质量可能受影响。建议让两者相等。",
            h, m,
        )
    return ok
