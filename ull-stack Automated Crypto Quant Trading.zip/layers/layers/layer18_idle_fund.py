# layers/layer18_idle_fund.py
"""
层18：闲置资金管理（纯现货专用）
- 自动将闲置USDT申购OKX余币宝（简单赚币）
- 交易前自动赎回所需金额
- 低风险，只利用交易所内部功能，不涉及链上合约
"""
import os
import time
import threading
import requests
import json
import hmac
import base64
import hashlib
from datetime import datetime, timezone
from loguru import logger


class IdleFundManager:
    def __init__(self, config):
        self.config = config
        fund_cfg = config.get("idle_fund", {})
        self.enable = fund_cfg.get("enable", False)
        self.min_idle_usdt = float(fund_cfg.get("min_idle_usdt", 100))
        self.reserve_usdt = float(fund_cfg.get("reserve_usdt", 500))
        self.check_interval = int(fund_cfg.get("check_interval_sec", 300))
        self.total_earned_est = 0.0

        # 从环境变量读取 OKX API 密钥（安全）
        self.api_key = "***"
        self.api_secret = os.environ.get("OKX_API_SECRET", "")
        self.passphrase = "***"
        self.base_url = "https://www.okx.com"

        if self.enable and (not self.api_key or not self.api_secret or not self.passphrase):
            logger.error("闲置资金管理层启用，但缺少 OKX API 环境变量，请设置 OKX_API_KEY, OKX_API_SECRET, OKX_PASSPHRASE")
            self.enable = False

    def _get_timestamp(self):
        return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'

    def _sign(self, timestamp, method, request_path, body=''):
        """OKX API V5 签名"""
        message = timestamp + method.upper() + request_path + body
        mac = hmac.new(
            self.api_secret.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        )
        return base64.b64encode(mac.digest()).decode('utf-8')

    def _request(self, method, path, body_dict=None):
        """发送 OKX 签名请求"""
        try:
            body = json.dumps(body_dict) if body_dict else ''
            timestamp = self._get_timestamp()
            signature = self._sign(timestamp, method, path, body)
            headers = {
                'OK-ACCESS-KEY': self.api_key,
                'OK-ACCESS-SIGN': signature,
                'OK-ACCESS-TIMESTAMP': timestamp,
                'OK-ACCESS-PASSPHRASE': self.passphrase,
                'Content-Type': 'application/json'
            }
            url = self.base_url + path
            if method.upper() == 'GET':
                resp = requests.get(url, headers=headers, timeout=10)
            else:
                resp = requests.post(url, headers=headers, data=body, timeout=10)
            data = resp.json()
            if data.get('code') == '0':
                return data.get('data', [])
            else:
                logger.error(f"OKX API 错误: {data.get('msg')}")
                return None
        except Exception as e:
            logger.error(f"OKX API 请求异常: {e}")
            return None

    def get_saving_balance(self):
        """查询余币宝余额"""
        if not self.enable:
            return 0.0
        data = self._request('GET', '/api/v5/finance/savings/balance?ccy=USDT')
        if data and len(data) > 0:
            amt = float(data[0].get('amt', 0))
            return amt
        return 0.0

    def get_available_balance(self):
        """查询现货账户可用余额"""
        if not self.enable:
            return 0.0
        data = self._request('GET', '/api/v5/account/balance?ccy=USDT')
        if data and len(data) > 0:
            details = data[0].get('details', [])
            for d in details:
                if d.get('ccy') == 'USDT':
                    return float(d.get('availBal', 0))
        return 0.0

    def subscribe(self, amount: float):
        """申购余币宝"""
        if amount < self.min_idle_usdt or not self.enable:
            return False
        logger.info(f"[资金层] 申购 {amount:.2f} USDT → 余币宝")
        # 实际调用
        data = self._request('POST', '/api/v5/finance/savings/purchase-redempt',
                             {"ccy": "USDT", "amt": str(round(amount, 2)), "side": "purchase"})
        if data is not None:
            # 简单估算收益（年化3%，按分钟计）
            self.total_earned_est += amount * 0.03 / 525600  # 一年分钟数
            return True
        return False

    def redeem(self, amount: float):
        """赎回余币宝"""
        if amount <= 0 or not self.enable:
            return False
        logger.info(f"[资金层] 赎回 {amount:.2f} USDT ← 余币宝")
        data = self._request('POST', '/api/v5/finance/savings/purchase-redempt',
                             {"ccy": "USDT", "amt": str(round(amount, 2)), "side": "redempt"})
        return data is not None

    def run_cycle(self, shared_state: dict):
        """
        后台线程：定期检查闲置资金并处理
        shared_state 字典应由主线程更新，包含：
            - 'capital': float  总资金（USDT）
            - 'positions_value': float  当前持仓估值（USDT）
        """
        while True:
            try:
                if not self.enable:
                    time.sleep(60)
                    continue

                total_capital = shared_state.get("capital", 0)
                positions_value = shared_state.get("positions_value", 0)

                # 可用闲置 = 总资金 - 持仓价值 - 永远保留的交易储备金
                idle = total_capital - positions_value - self.reserve_usdt

                if idle >= self.min_idle_usdt:
                    # 申购
                    self.subscribe(round(idle, 2))
                elif idle < -self.reserve_usdt:
                    # 需要补充资金，赎回
                    need = abs(idle)
                    saving_bal = self.get_saving_balance()
                    if saving_bal >= need:
                        self.redeem(round(need, 2))
                    else:
                        logger.warning(f"余币宝余额不足，无法赎回所需 {need:.2f}")

                time.sleep(self.check_interval)
            except Exception as e:
                logger.error(f"资金管理层异常: {e}")
                time.sleep(60)

    def get_summary(self):
        return {
            "enable": self.enable,
            "total_earned_est": round(self.total_earned_est, 6),
            "reserve_usdt": self.reserve_usdt
        }