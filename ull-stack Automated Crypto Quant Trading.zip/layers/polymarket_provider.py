import requests
import time
import json
import datetime
from loguru import logger

class PolymarketBTC15mProvider:
    def __init__(self, refresh_sec=60):
        self.refresh_sec = refresh_sec
        self.cache = {
            "time": 0,
            "prob_up": 0.5,
            "volume": 0.0,
            "spread": None,
            "end_time": None,
            "market_type": None,
            "active": False
        }
        self.base_url = "https://gamma-api.polymarket.com"

    def _fetch_markets(self):
        try:
            url = f"{self.base_url}/markets"
            params = {
                "closed": "false",
                "limit": 200,
                "order": "endDate",
                "ascending": "true"
            }
            resp = requests.get(url, params=params, timeout=10)
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            logger.error(f"Failed to fetch markets: {e}")
            return []

    def _find_active_btc_market(self):
        markets = self._fetch_markets()
        now = datetime.datetime.now(datetime.timezone.utc)
        for m in markets:
            slug = m.get("slug", "").lower()
            if "btc" not in slug or "updown" not in slug:
                continue
            if "5m" in slug:
                mtype = "5m"
            elif "15m" in slug:
                mtype = "15m"
            else:
                continue
            end_str = m.get("endDate")
            if not end_str:
                continue
            try:
                end_dt = datetime.datetime.fromisoformat(end_str.replace("Z", "+00:00"))
            except:
                continue
            if end_dt <= now:
                continue
            raw_prices = m.get("outcomePrices", [])
            prices = self._parse_outcome_prices(raw_prices)
            if prices and len(prices) >= 2 and prices[0] > 0 and prices[1] > 0:
                return m, mtype
        return None, None

    def _parse_outcome_prices(self, raw_prices):
        if raw_prices is None:
            return None
        if isinstance(raw_prices, list):
            try:
                return [float(x) for x in raw_prices]
            except:
                return None
        elif isinstance(raw_prices, str):
            try:
                cleaned = raw_prices.strip()
                if cleaned.startswith('['):
                    data = json.loads(cleaned)
                    return [float(x) for x in data]
                parts = cleaned.replace('[', '').replace(']', '').replace('"', '').split(',')
                vals = [float(p) for p in parts if p.strip()]
                return vals if vals else None
            except:
                logger.warning(f"Failed to parse outcomePrices string: {raw_prices}")
                return None
        else:
            return None

    def get_market_data(self):
        if time.time() - self.cache["time"] < self.refresh_sec:
            return self.cache

        market, mtype = self._find_active_btc_market()
        if not market:
            self.cache["active"] = False
            self.cache["time"] = time.time()
            logger.warning("No active BTC Up/Down market found, Polymarket signal disabled")
            return self.cache

        try:
            prices = self._parse_outcome_prices(market.get("outcomePrices", []))
            if prices and len(prices) >= 2:
                prob_up = prices[0]
                volume = float(market.get("volumeNum", 0))
                self.cache.update({
                    "time": time.time(),
                    "prob_up": prob_up,
                    "volume": volume,
                    "spread": None,
                    "end_time": market.get("endDate"),
                    "market_type": mtype,
                    "active": True
                })
                logger.info(f"Polymarket BTC {mtype}: UP prob={prob_up:.3f}, volume={volume:.0f}")
            else:
                logger.warning("Could not parse outcomePrices, market may be inactive")
                self.cache["active"] = False
                self.cache["time"] = time.time()
        except Exception as e:
            logger.error(f"Error parsing market data: {e}")
            self.cache["active"] = False
            self.cache["time"] = time.time()

        return self.cache
