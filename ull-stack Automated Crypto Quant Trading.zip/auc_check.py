﻿# -*- coding: utf-8 -*-
from pathlib import Path
import yaml, numpy as np, joblib
from sklearn.metrics import roc_auc_score, precision_score
from layers.layer1_data_collector import DataCollector
from layers.layer3_data_clean import DataCleaner
from layers.layer4_feature_engineer import FeatureEngineer

cfg = yaml.safe_load(Path("config.yaml").read_text(encoding="utf-8"))
raw = DataCollector(cfg.get("market_data", {})).fetch_klines_rest("BTC-USDT", "15m", 1000)
df = DataCleaner().clean_klines(raw)
feat = FeatureEngineer(cfg.get("features", {})).calculate_features(df)

key = "BTC_USDT"
model = joblib.load(f"ml_lib/trained_models/{key}_ensemble_model.pkl")
scaler = joblib.load(f"ml_lib/transformers/{key}_scaler.pkl")
selector = joblib.load(f"ml_lib/transformers/{key}_selector.pkl")
cols = [x.strip() for x in Path(f"ml_lib/transformers/{key}_feature_columns.txt").read_text(encoding="utf-8").splitlines() if x.strip()]

feat = feat.sort_values("timestamp").reset_index(drop=True)
close = feat["close"]
# 与训练一致：未来3根上涨为1
y = (close.shift(-3) > close).astype(int)
sub = feat[cols].copy()
sub["__y"] = y
sub = sub.dropna()
X = sub[cols].values
y = sub["__y"].values

Xs = scaler.transform(X)
Xs = selector.transform(Xs)
p = np.asarray(model.predict_proba(Xs))

auc = roc_auc_score(y, p)
print(f"样本数     : {len(y)}")
print(f"正样本占比 : {y.mean():.3f}")
print(f"AUC-ROC    : {auc:.4f}")
print()
print("阈值      精确率  触发数")
print("-" * 30)
for th in [0.50, 0.52, 0.55, 0.58, 0.60, 0.65]:
    mask = p >= th
    n = mask.sum()
    prec = y[mask].mean() if n > 0 else 0
    print(f"{th:.2f}      {prec:.3f}   {n}")
