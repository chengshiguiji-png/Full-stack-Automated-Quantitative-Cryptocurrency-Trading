# 本次修改说明（基于你上传的 `quant_ai_final_okx_demo_FIXED_20260913_233817.zip`）

先说好消息：你之前几轮自己迭代（`apply_final_*.py`）已经把不少东西修对了——
`rolling_backtest_trades_{symbol}.csv` 已经是按币种独立文件名（我们上一轮怀疑的"BTC文件
其实是ETH价格"那个 bug，在这个版本里已经不存在了）；`main_strategy.py` 也已经有
horizon一致性检查的日志告警。这次是在这些基础上，做剩下没做完的部分。

## 1. 【新发现，影响比预想的更大】回测引擎的仓位大小和实盘完全是两套逻辑

这是这次审查中最重要的一条，之前几轮分析都还没看到这个问题：

`backtest_engine.py` 里每笔 BUY 是**硬编码固定 10 USDT**（`size = 0.001 if SELL else 10`），
跟 `main_strategy.py` 实盘用的、基于 ATR 动态计算+5%/500U上限的 `risk_manager.calculate_position_size()`
完全是两套公式。也就是说，**你之前跑出来的"BTC: -0.01%, 59笔交易"这个回测结果，测的是一个每次只用
10/100000=0.01%总资金下注的极小仓位策略，根本不是实盘真正会用的仓位大小**——这比我上一轮猜测的
"500U上限导致收益被稀释"还要严重10倍不止。

**已修复**：`backtest_engine.py` 现在和 `main_strategy.py` 调用同一个 `RiskManager.calculate_position_size()`，
仓位大小、`max_single_entry_pct` 上限、`min_order_value` 下限全部对齐。以后回测出来的收益率，才是你实盘会
真正遇到的仓位规模下的收益率。

同时顺手修了一个小的连带问题：`entry_filter.check()` 之前传的 `position_size=1000` 是写死的占位值，跟当时
实际要下的单子大小无关；现在传的是真实计算出来的下单金额。

## 2. horizon_bars 和 max_hold_bars 不一致——已同步

`config.yaml` 里 `label.horizon_bars=12`、`strategy.max_hold_bars=16` 这个我们上一轮讨论过的问题，
现在改成两者都是 12。因为训练用的模型本来就是 `horizon_bars=12`，所以**这次改动不需要重新跑
`train_model.py`**——只是让实盘持仓上限和模型训练时的判断视界对齐，不会让模型突然失效。

`check_horizon_consistency()` 这个检查现在被抽成 `layers/symbol_config.py` 里的公共函数，
`train_model.py`、`backtest_engine.py`、`main_strategy.py` 三处都会在启动时调用，不再各写各的。

## 3. 新增按币种差异化配置：`config.yaml` 的 `symbol_overrides` 段落

对应你上一轮的诉求（三个币种都要保留，但要能做差异化处理）。新增：

```yaml
symbol_overrides:
  BTC-USDT:
    enabled: false
    signal:
      direction_mode: normal
  ETH-USDT:
    enabled: true
    signal:
      direction_mode: normal
  SOL-USDT:
    enabled: true
    signal:
      direction_mode: normal
```

- `enabled: false` → `main_strategy.py` 实盘循环会在最前面直接跳过该币种（连行情探测都不请求），
  但 `backtest_engine.py` 和 `train_model.py` **不受影响**，照常跑——这样才能持续积累"要不要重新启用"的证据。
- `direction_mode: normal | inverted` → 由 `layers/layer9_signal_generator.py` 里新增的 `invert_direction`
  开关实现，`inverted` 会把模型给出的 BUY/SELL 最终动作对调，但 `p_up`、`ev_edge`、`confidence` 这些字段
  仍然如实反映模型本身的判断，方便你事后复盘"模型说的和实际做的是不是反的"。

**按照上一轮的统计结果，这次三个币种全部设成 `normal`，BTC 设成 `enabled: false`：**
- BTC：OOS accuracy=0.5009（样本量大，置信区间紧贴50%），三个阈值(0.55/0.62/0.68)全部触发0笔信号——
  没有可交易的信号，不是"该调低阈值"的问题，所以直接停用，而不是硬调阈值制造噪声交易。
- ETH：二项检验 p=0.0195 单独看是显著的，但你训练日志里对3个币种×3个阈值一共做了9次检验，
  没有做多重比较校正，保守起见先保持 `enabled: true` 但不建议加大仓位权重，等下一段全新样本外数据复现。
- SOL："35%精确率反过来看是65%"这个假设，是在产生这个数字的同一批20个样本上得出的，二项检验
  p=0.263 完全不显著——**没有给它设成 `inverted`**，这需要一次全新的、独立于本次分析的样本外验证
  才能考虑，直接反向做空目前没有统计支持。

如果你之后拿到新数据验证出 SOL 反向确实成立，只需要把 `symbol_overrides.SOL-USDT.signal.direction_mode`
改成 `inverted`，不需要碰任何 `.py` 代码——这也是当时选"配置驱动"而不是"代码里加 if 分支"的原因。

## 4. `train_model.py` 的一个小 bug：阈值列表重复打印

`for th in (0.55, threshold_up, 0.62, strong_up)` 在 `threshold_up` 恰好等于 0.55 时（当前config就是这样），
会把同一个阈值的检验结果打印两遍，容易让人误以为跑了两次或者数据翻倍了。改成 `sorted(set(...))` 去重。
这解释了你之前贴的训练日志里每个阈值的"N=... precision=..."都出现两次的现象——不是回测跑了两次，
只是日志去重没做。

## 5. `backtest_engine.py` 里一段死代码

`run()` 循环最开始会用 `close_train.shift(-3)` 现算一个简单标签、对齐特征、丢NaN……但这批变量在后面
从来没被用到过（真正预测用的是从 `ml_lib/trained_models/` 加载的生产模型）。这是早期"每窗口自训"改成
"加载生产模型"时遗留下来的死代码，删掉后逻辑不变，但少了一部分没用的计算量，也少了一处容易看错口径的干扰项。

## 6. `run_backtest.py` 里报告打印两次

`engine.run()` 内部结尾已经调用了一次 `self._report_performance()`，`run_backtest.py` 外面又手动调用了一次，
导致绩效报告打印两遍、CSV 被多写一次（内容一样，只是浪费一次IO）。已删掉外面多余的那次调用。

## 未改动、但建议你知道的事情

- `RiskManager`、`RiskFuse` 目前仍然是全局单例（一份参数用于所有币种），`symbol_overrides` 目前只覆盖了
  `signal` 段落（阈值、方向）。如果之后你想给 ETH/SOL/BTC 用不同的止损止盈比例，需要把
  `get_symbol_risk_config()` 也接到 `RiskManager` 的实例化那一行——现在这行还是读全局 `risk` 段落，
  我没有动它，因为目前的差异化需求（enabled + direction_mode）还不需要动到这里，没必要在没有明确要求时
  多改一处有实盘资金风险的代码。
- ETH 的显著性结论没有变："promising，但没有经过多重比较校正、也没有独立样本外复现"，这次的代码修改
  不能让这个结论自动变得更可信——该做的复现验证还是要做。
