﻿from pathlib import Path
import ast
import py_compile
import shutil
from datetime import datetime

P = Path("layers/polymarket_clob.py")

if not P.exists():
    raise RuntimeError(f"找不到文件: {P}")

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = P.with_name(
    f"polymarket_clob.before_final_health_{stamp}.py"
)

shutil.copy2(P, backup)

source = P.read_text(
    encoding="utf-8-sig"
)

tree = ast.parse(source)

clob = None
health_node = None

for node in tree.body:

    if (
        isinstance(node, ast.ClassDef)
        and node.name == "PolymarketCLOB"
    ):

        clob = node

        for child in node.body:

            if (
                isinstance(child, ast.FunctionDef)
                and child.name == "health_snapshot"
            ):

                health_node = child
                break

        break

if clob is None:
    raise RuntimeError(
        "找不到 class PolymarketCLOB"
    )

if health_node is None:
    raise RuntimeError(
        "找不到 health_snapshot"
    )


# ============================================================
# 最终 health_snapshot
# ============================================================

new_health = r'''
    def health_snapshot(
        self,
        max_book_age_sec=30.0,
    ):
        """
        最终健康状态：

        ws_connected:
            Socket是否连接。

        ws_activity_age_sec:
            最近任意WSS消息的年龄。

        last_market_event_age_sec:
            最近真正市场事件(book/price_change等)的年龄。

        fresh:
            必须满足：
                1. Data API status正常
                2. 所有订阅盘口新鲜
                3. WSS已连接
                4. 最近真正市场事件没有超过ws_stale_sec

        注意：
            age永远不会出现负数。
        """

        now = time.time()

        try:
            status = self.check_status()
        except Exception as exc:
            status = {
                "ok": False,
                "age_seconds": None,
                "lag_seconds": None,
                "worst": None,
                "checked_at": now,
                "error": str(exc),
            }

        with self._lock:

            connected = bool(
                self._connected
            )

            last_ws_activity = float(
                self._last_ws_activity
                or
                0.0
            )

            last_market_event = float(
                self._last_market_event
                or
                0.0
            )

            books = {
                token:
                    book.timestamp
                for token, book
                in self.books.items()
            }

            last_error = (
                self._last_ws_error
            )

            subscribed = list(
                self._subscribed_assets
            )

        # ----------------------------------------------------
        # 统一防止负数 age
        # ----------------------------------------------------

        if last_ws_activity > 0:

            ws_age = max(
                0.0,
                now - last_ws_activity,
            )

        else:

            ws_age = None

        if last_market_event > 0:

            market_age = max(
                0.0,
                now - last_market_event,
            )

        else:

            market_age = None

        book_ages = {}

        for token, timestamp in books.items():

            book_ages[
                token
            ] = max(
                0.0,
                now - timestamp,
            )

        books_fresh = bool(
            book_ages
            and
            all(
                age
                <= float(
                    max_book_age_sec
                )
                for age
                in book_ages.values()
            )
        )

        status_ok = bool(
            status.get(
                "ok",
                False,
            )
        )

        # ----------------------------------------------------
        # 真正的WSS实时市场数据健康状态
        #
        # 不再使用：
        #     on_open时间
        #
        # 而是使用：
        #     最近真正市场事件
        # ----------------------------------------------------

        stale_limit = float(
            getattr(
                self,
                "ws_stale_sec",
                30.0,
            )
        )

        wss_stream_fresh = bool(
            connected
            and
            market_age is not None
            and
            market_age <= stale_limit
        )

        # ----------------------------------------------------
        # 最终可用状态
        # ----------------------------------------------------

        fresh = bool(
            status_ok
            and
            books_fresh
            and
            connected
            and
            market_age is not None
            and
            market_age <= stale_limit
        )

        if fresh:

            transport = "WSS"

        else:

            transport = "STALE"

        return {
            "proxy":
                self._masked_proxy(),

            "ws_connected":
                connected,

            "ws_activity_age_sec":
                ws_age,

            "last_market_event_age_sec":
                market_age,

            "book_ages_sec":
                book_ages,

            "books_fresh":
                books_fresh,

            "status":
                status,

            "subscribed_assets":
                subscribed,

            "last_ws_error":
                last_error,

            "wss_stream_fresh":
                wss_stream_fresh,

            "transport":
                transport,

            "fresh":
                fresh,
        }
'''


lines = source.splitlines(
    keepends=True
)

lines[
    health_node.lineno - 1:
    health_node.end_lineno
] = [
    new_health.strip("\n")
    + "\n"
]

P.write_text(
    "".join(lines),
    encoding="utf-8"
)


# ============================================================
# 编译
# ============================================================

py_compile.compile(
    str(P),
    doraise=True
)


# ============================================================
# AST最终结构验证
# ============================================================

verify = P.read_text(
    encoding="utf-8-sig"
)

tree = ast.parse(
    verify
)

verified = None

for node in tree.body:

    if (
        isinstance(node, ast.ClassDef)
        and node.name == "PolymarketCLOB"
    ):

        verified = node
        break

if verified is None:
    raise RuntimeError(
        "最终验证失败：PolymarketCLOB不存在"
    )

health_ok = any(
    isinstance(
        child,
        ast.FunctionDef
    )
    and child.name == "health_snapshot"
    for child in verified.body
)

if not health_ok:
    raise RuntimeError(
        "最终验证失败：health_snapshot不存在"
    )


print()
print("=" * 72)
print("POLYMARKET FINAL HEALTH FIX SUCCESS")
print("=" * 72)
print("health_snapshot       : CLASS METHOD")
print("negative age guard    : ENABLED")
print("market event based    : ENABLED")
print("fresh requires WSS    : ENABLED")
print("book freshness        : ENABLED")
print("Data API status       : ENABLED")
print("syntax                : PASS")
print("backup                :", backup)
print("=" * 72)
