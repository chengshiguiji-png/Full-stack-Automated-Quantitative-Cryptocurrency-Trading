# -*- coding: utf-8 -*-
"""训练与保存最终版交易模型。

目标不是预测“未来收盘涨幅”，而是预测：
在 horizon 根 15m K 线内，价格是否先触发 TP(ATR 倍数) 再触发 SL(ATR 倍数)。
这与 Layer 17 的初始退出结构保持一致。
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import yaml
from dotenv import load_dotenv
from loguru import logger
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, log_loss, precision_score
from sklearn.preprocessing import StandardScaler

from layers.layer1_data_collector import DataCollector
from layers.layer3_data_clean import DataCleaner
from layers.layer4_feature_engineer import FeatureEngineer
from layers.layer6_ml_model import MLModelEnsemble
from layers.symbol_config import check_horizon_consistency, is_symbol_enabled



def _wilson_ci(hits, n, z=1.96):
    """Wilson 95% 置信区间。"""
    if n == 0:
        return 0.0, 0.0
    p = hits / n
    denom = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denom
    half = z * ((p * (1 - p) / n + z * z / (4 * n * n)) ** 0.5) / denom
    return max(0.0, center - half), min(1.0, center + half)



class IdentityCalibrator:
    def predict(self, p):
        return np.asarray(p, dtype=float)


def _symbol_key(symbol: str) -> str:
    return symbol.upper().replace("-", "_")


def _load_config():
    load_dotenv(override=False)
    with open("config.yaml", "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _build_trade_labels(df_feat: pd.DataFrame, horizon: int, sl_atr: float, tp_atr: float):
    close = pd.to_numeric(df_feat["close"], errors="coerce").to_numpy()
    high = pd.to_numeric(df_feat["high"], errors="coerce").to_numpy()
    low = pd.to_numeric(df_feat["low"], errors="coerce").to_numpy()
    atr = pd.to_numeric(df_feat["atr_14"], errors="coerce").to_numpy()
    n = len(df_feat)

    labels = np.full(n, np.nan, dtype=float)
    reason = np.full(n, "", dtype=object)
    last_valid = n - horizon
    for i in range(max(0, last_valid)):
        entry = close[i]
        a = atr[i]
        if not np.isfinite(entry) or entry <= 0 or not np.isfinite(a) or a <= 0:
            continue
        tp = entry + tp_atr * a
        sl = entry - sl_atr * a
        hi = high[i + 1 : i + 1 + horizon]
        lo = low[i + 1 : i + 1 + horizon]
        tp_hit = np.flatnonzero(hi >= tp)
        sl_hit = np.flatnonzero(lo <= sl)
        if len(tp_hit) == 0 and len(sl_hit) == 0:
            # 在持有窗口内没有达到目标，按“未完成交易”记为 0，避免把 p_up 人为抬高。
            labels[i] = 0.0
            reason[i] = "no_hit"
        elif len(tp_hit) == 0:
            labels[i] = 0.0
            reason[i] = "sl_first"
        elif len(sl_hit) == 0:
            labels[i] = 1.0
            reason[i] = "tp_first"
        elif tp_hit[0] < sl_hit[0]:
            labels[i] = 1.0
            reason[i] = "tp_first"
        elif sl_hit[0] < tp_hit[0]:
            labels[i] = 0.0
            reason[i] = "sl_first"
        else:
            # 同一根K线同时触发 TP/SL，无法从 OHLC 确定先后，直接排除。
            reason[i] = "ambiguous"

    # 最后 horizon 根无法形成完整未来窗口，保持 NaN，不参与训练。
    return pd.Series(labels, index=df_feat.index, name="trade_label"), pd.Series(reason, index=df_feat.index, name="label_reason")


def _fit_calibrator(p_raw, y):
    p = np.clip(np.asarray(p_raw, dtype=float), 1e-5, 1 - 1e-5)
    y = np.asarray(y, dtype=int)
    if len(p) < 300 or len(np.unique(y)) < 2 or np.std(p) < 1e-6:
        return IdentityCalibrator()
    logit = np.log(p / (1 - p)).reshape(-1, 1)
    cal = LogisticRegression(C=1.0, solver="lbfgs", max_iter=1000)
    cal.fit(logit, y)
    return cal


def _apply_calibrator(cal, p):
    p = np.clip(np.asarray(p, dtype=float), 1e-5, 1 - 1e-5)
    if isinstance(cal, IdentityCalibrator):
        return p
    logit = np.log(p / (1 - p)).reshape(-1, 1)
    return np.clip(cal.predict_proba(logit)[:, 1], 1e-5, 1 - 1e-5)


def train_one(df: pd.DataFrame, symbol: str, config: dict, k_features: int = 20):
    features_cfg = config.get("features", {})
    signal_cfg = config.get("signal", {})
    label_cfg = config.get("label", {})
    horizon = int(label_cfg.get("horizon_bars", config.get("strategy", {}).get("max_hold_bars", 16)))
    sl_atr = float(label_cfg.get("sl_atr", config.get("state_machine", {}).get("atr_stop_multiplier", 1.0)))
    tp_atr = float(label_cfg.get("tp_atr", config.get("state_machine", {}).get("profit_lock_atr_mult", 1.5)))

    cleaner = DataCleaner({"require_confirmed": True})
    if not isinstance(df, pd.DataFrame):
        df = cleaner.clean_klines(df)
    if df.empty:
        raise ValueError(f"{symbol}: 清洗后无数据")

    feat_engineer = FeatureEngineer(features_cfg)
    funding_df = None
    if bool(config.get("regime", {}).get("use_funding_rate_feature", False)):
        # 默认关闭：这是一个待验证的实验性特征，不应该在没验证过之前就悄悄改变
        # 已有的64列特征基线和SelectKBest选择结果。config.regime.use_funding_rate_feature
        # 设成true才会启用；用try/except包起来是因为这只是可选的免费另类数据，
        # 拉取失败绝不应该让主流程的ML训练也跟着失败。
        try:
            end_ts = int(df["timestamp"].iloc[-1].value // 1_000_000) if hasattr(df["timestamp"].iloc[-1], "value") else None
            rows = DataCollector(config.get("market_data", {})).fetch_funding_rate_history(
                symbol, limit=min(2000, len(df) // 4 + 50), end_ts=end_ts
            )
            if rows:
                funding_df = pd.DataFrame(rows)
                funding_df["timestamp"] = pd.to_datetime(funding_df["timestamp"], unit="ms")
        except Exception as exc:
            logger.warning("{}: 资金费率特征获取失败，继续使用不含资金费率的基线特征集: {}", symbol, exc)
    feat = feat_engineer.calculate_features(df, funding_df=funding_df)
    label, label_reason = _build_trade_labels(feat, horizon, sl_atr, tp_atr)
    exclude = {"timestamp", "datetime", "label", "forward_return", "forward_volatility", "trade_label", "label_reason", "confirm", "symbol"}
    cols = [c for c in feat.columns if c not in exclude and pd.api.types.is_numeric_dtype(feat[c])]
    X_all = feat[cols]
    valid = X_all.notna().all(axis=1) & label.notna()
    # 去掉无法确定先后顺序的同K线双触发样本。
    valid &= label_reason != "ambiguous"
    X = X_all.loc[valid].copy()
    y = label.loc[valid].astype(int)
    if len(X) < 1000 or y.nunique() < 2:
        raise ValueError(f"{symbol}: 有效训练样本不足，N={len(X)}")

    split = int(len(X) * 0.80)
    split = max(500, min(split, len(X) - 300))
    X_train, X_val = X.iloc[:split], X.iloc[split:]
    y_train, y_val = y.iloc[:split], y.iloc[split:]

    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_val_s = scaler.transform(X_val)
    selector = SelectKBest(f_classif, k=min(k_features, X_train_s.shape[1]))
    X_train_sel = selector.fit_transform(X_train_s, y_train)
    X_val_sel = selector.transform(X_val_s)

    model_cfg = {"model_weight": config.get("model_weight", {})}
    model = MLModelEnsemble(model_cfg)
    model.train(X_train_sel, y_train)
    p_raw = np.asarray(model.predict_proba(X_val_sel), dtype=float)
    calibrator = _fit_calibrator(p_raw, y_val)
    p_cal = _apply_calibrator(calibrator, p_raw)

    threshold_up = float(signal_cfg.get("threshold_up", 0.58))
    strong_up = float(signal_cfg.get("strong_threshold_up", 0.65))
    logger.info(
        "{} OOS raw accuracy={:.4f} logloss={:.4f} calibrated accuracy={:.4f} logloss={:.4f}",
        symbol,
        accuracy_score(y_val, p_raw >= 0.5),
        log_loss(y_val, p_raw),
        accuracy_score(y_val, p_cal >= 0.5),
        log_loss(y_val, p_cal),
    )
    # 用 set 去重：如果 config 里 threshold_up 恰好等于 0.55（或 strong_up 恰好等于 0.62），
    # 原来的写法会把同一个阈值打印两遍，容易被误读成"跑了两次"。
    for th in sorted(set((0.55, threshold_up, 0.62, strong_up))):
        mask = p_cal >= th
        hits = int(mask.sum())
        correct = int((y_val[mask] == 1).sum()) if hits else 0
        prec = correct / hits if hits else 0.0
        lo, hi = _wilson_ci(correct, hits)
        warn = ""
        if hits < 30:
            warn = " [样本不足]"
        elif lo < 0.50:
            warn = " [Wilson下界<50%，未通过显著性]"
        logger.info(
            "{} OOS BUY threshold {:.2f}: N={} precision={:.4f} "
            "Wilson95=[{:.3f},{:.3f}]{}",
            symbol, th, hits, prec, lo, hi, warn,
        )

    # 最终模型：在全部有效历史上训练，但预处理器只根据历史本身拟合，不读取未来。
    X_all_s = scaler.fit_transform(X)
    X_all_sel = selector.fit_transform(X_all_s, y)
    final_model = MLModelEnsemble(model_cfg)
    final_model.train(X_all_sel, y)

    out = Path("ml_lib/trained_models")
    trans = Path("ml_lib/transformers")
    out.mkdir(parents=True, exist_ok=True)
    trans.mkdir(parents=True, exist_ok=True)
    key = _symbol_key(symbol)
    joblib.dump(final_model, out / f"{key}_ensemble_model.pkl")
    joblib.dump(scaler, trans / f"{key}_scaler.pkl")
    joblib.dump(selector, trans / f"{key}_selector.pkl")
    joblib.dump(calibrator, trans / f"{key}_calibrator.pkl")
    (trans / f"{key}_feature_columns.txt").write_text("\n".join(cols), encoding="utf-8")

    meta = {
        "symbol": symbol,
        "feature_count": len(cols),
        "selected_features": int(selector.k),
        "effective_samples": int(len(X)),
        "positive_rate": float(y.mean()),
        "oos_samples": int(len(y_val)),
        "label": {"horizon_bars": horizon, "sl_atr": sl_atr, "tp_atr": tp_atr},
        "signal": {"threshold_up": threshold_up, "strong_threshold_up": strong_up},
    }
    (trans / f"{key}_metadata.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    logger.success("{} 模型已保存：N={} positive={:.3f}", symbol, len(X), y.mean())
    return meta


def _read_local_csv(path: str):
    df = pd.read_csv(path)
    if "timestamp" in df.columns:
        ts = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
        df["timestamp"] = (ts.astype("int64") // 10**6).astype("int64")
    return df


def train_symbol(symbol: str, config: dict, lookback: int, csv_path: str | None = None):
    if csv_path:
        df = _read_local_csv(csv_path)
        if lookback > 0 and len(df) > lookback:
            df = df.tail(lookback).reset_index(drop=True)
    else:
        raw = DataCollector(config.get("market_data", {})).fetch_klines_rest(symbol, interval=config.get("market", {}).get("timeframe", "15m"), limit=lookback)
        if not raw:
            raise RuntimeError(f"{symbol}: OKX 历史K线获取失败")
        df = DataCleaner({"require_confirmed": True}).clean_klines(raw)
    return train_one(df, symbol, config)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbol", default="BTC-USDT")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--lookback", type=int, default=None)
    ap.add_argument("--csv", default=None, help="本地CSV，用于离线复核")
    args = ap.parse_args()
    config = _load_config()
    check_horizon_consistency(config, logger)
    lookback = int(args.lookback or config.get("market", {}).get("training_lookback", 6000))
    symbols = config.get("assets", [args.symbol]) if args.all else [args.symbol]
    for symbol in symbols:
        if not is_symbol_enabled(config, symbol):
            logger.warning(
                "{} 在 symbol_overrides 中被标记为 enabled=false（暂停实盘），"
                "但仍然会正常训练/评估——训练不受实盘开关影响，这样才能持续积累证据判断是否可以重新启用。",
                symbol,
            )
        try:
            train_symbol(symbol, config, lookback, args.csv if len(symbols) == 1 else None)
        except Exception as exc:
            logger.error("训练 %s 失败: %s", symbol, exc)
            raise


if __name__ == "__main__":
    main()
