# -*- coding: utf-8 -*-
"""25层 AI 量化交易系统：原架构深度重构版。

核心原则：
1. AI 负责预测，不把情绪/随机数/规则直接加到概率上。
2. 策略决定是否存在可交易 edge，RiskFuse 拥有最终否决权。
3. 只有已确认 K 线产生新信号；持仓管理可以用实时 ticker。
4. 订单必须先得到实际 fill，再更新本地资金/持仓。
5. 模型缺失、数据异常、对账失败时 fail-closed。
6. 训练/重训练为离线任务，主策略不在实盘循环里自我改模型。
"""
from __future__ import annotations

import csv
import json
import os
import time
import uuid
import traceback
from datetime import datetime, timezone
from pathlib import Path

import joblib
import pandas as pd
import yaml
from dotenv import load_dotenv
from loguru import logger

from layers.layer1_data_collector import DataCollector
from layers.layer3_data_clean import DataCleaner
from layers.layer4_feature_engineer import FeatureEngineer
from layers.layer6_ml_model import MLModelEnsemble
from layers.layer7_market_regime import MarketRegimeDetector
from layers.layer8_microstructure import MicrostructureAnalyzer
from layers.layer9_signal_generator import SignalGenerator
from layers.layer10_filter import EntryFilter
from layers.layer11_risk_fuse import RiskFuse
from layers.symbol_config import (
    check_horizon_consistency,
    get_symbol_risk_config,
    get_symbol_signal_config,
    is_symbol_enabled,
)
from layers.layer12_executor import OrderExecutor
from layers.layer17_position_state_machine import PositionStateMachine, PositionState
from layers.layer5_external_sentiment import ExternalSentiment
from layers.layer5_llm_sentiment import SentimentRiskAnalyzer
from core.event_store import EventStore
from core.kline_db import init_db, save_klines
from core.okx_trader import OKXTrader
from core.trade_logger import log_trade
from monitoring.monitor import StrategyMonitor
from reporting.performance_reporter import PerformanceReporter
from risk_manager import RiskManager
from security.vault_client import apply_env_overrides
from layers.polymarket_shadow import PolymarketShadowRecorder


def safe_json_dump(data, filepath):
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        os.replace(tmp, path)
    except Exception as exc:
        logger.error("状态写入失败 {}: {}", filepath, exc)


def load_config():
    load_dotenv(override=False)
    config_path = Path(__file__).resolve().parent / "config.yaml"
    with config_path.open("r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}
    config = apply_env_overrides(config)

    # FINAL OKX ENV OVERRIDE
    okx = config.setdefault("exchange", {}).setdefault("okx", {})

    for key, env_name in (
        ("api_key", "OKX_API_KEY"),
        ("api_secret", "OKX_API_SECRET"),
        ("passphrase", "OKX_API_PASSPHRASE"),
        ("flag", "OKX_FLAG"),
        ("instrument_type", "OKX_INSTRUMENT_TYPE"),
    ):
        value = os.getenv(env_name)
        if value is not None and str(value).strip() != "":
            okx[key] = str(value).strip()

    demo = os.getenv("OKX_DEMO_TRADING")
    if demo is not None:
        if demo.strip().lower() in {"1", "true", "yes", "on"}:
            config["mode"] = "demo"

    dry = os.getenv("OKX_DRY_RUN")
    if dry is not None:
        config.setdefault("execution", {})["dry_run"] = (
            dry.strip().lower()
            in {"1", "true", "yes", "on"}
        )

    live = os.getenv(
        "LIVE_TRADING_ENABLED",
        "false"
    ).strip().lower()

    if live not in {"1", "true", "yes", "on"}:
        config["mode"] = "demo"
        okx["flag"] = "1"

    return config


def find_okx_cli():
    """兼容旧控制台脚本；主策略不依赖 CLI。"""
    candidates = [
        os.environ.get("OKX_CLI_PATH"),
        os.path.expandvars(r"%APPDATA%\\npm\\okx.cmd"),
        r"C:\\Program Files\\nodejs\\okx.cmd",
    ]
    for candidate in candidates:
        if candidate and os.path.exists(candidate):
            return candidate
    return None


def place_order_via_cli(symbol, side, size, profile="demo", max_retries=0):
    """旧 Web Panel 兼容接口。

    新主策略使用 OrderExecutor；该函数仅保留旧外部调用兼容性，并默认不绕过 Demo/安全门。
    """
    try:
        cfg = {
            "dry_run": str(os.getenv("OKX_DRY_RUN", "true")).lower() == "true",
            "min_order_value": 10,
            "max_order_value": float(os.getenv("OKX_MAX_ORDER_VALUE", "500")),
        }
        trader = None
        if not cfg["dry_run"]:
            trader = OKXTrader({"flag": "1"})
        executor = OrderExecutor(cfg, trader)
        side = str(side).upper()
        price = DataCollector().fetch_ticker(symbol) or 0.0
        if price <= 0:
            return {"executed": False, "reason": "market_price_unavailable"}
        if side == "BUY":
            return executor.buy_notional(symbol, float(size), price)
        return executor.execute({"symbol": symbol, "side": side, "quantity": float(size)}, price)
    except Exception as exc:
        logger.error("兼容下单接口失败: {}", exc)
        return {"executed": False, "reason": str(exc)}


class MultiAssetTrader:
    def __init__(self, config, initial_capital=100000.0, fee_rate=0.001):
        self.config = config
        self.assets = list(config.get("assets", ["BTC-USDT", "ETH-USDT", "SOL-USDT"]))
        self.capital = float(initial_capital)
        self.initial_capital = float(initial_capital)
        self.fee_rate = float(fee_rate)
        self.positions = {a: 0.0 for a in self.assets}
        self.entry_prices = {a: None for a in self.assets}
        self.highest_prices = {a: None for a in self.assets}

    def update_position(self, symbol, side, quantity, price):
        side = side.upper()
        quantity, price = float(quantity), float(price)
        if quantity <= 0 or price <= 0:
            raise ValueError("quantity/price must be positive")
        if side == "BUY":
            old_qty = self.positions.get(symbol, 0.0)
            old_entry = self.entry_prices.get(symbol) or 0.0
            new_qty = old_qty + quantity
            self.entry_prices[symbol] = ((old_qty * old_entry) + quantity * price) / new_qty
            self.positions[symbol] = new_qty
            self.highest_prices[symbol] = max(price, self.highest_prices.get(symbol) or price)
        elif side == "SELL":
            old_qty = self.positions.get(symbol, 0.0)
            sell_qty = min(quantity, old_qty)
            self.positions[symbol] = max(0.0, old_qty - sell_qty)
            if self.positions[symbol] <= 1e-12:
                self.positions[symbol] = 0.0
                self.entry_prices[symbol] = None
                self.highest_prices[symbol] = None
        else:
            raise ValueError(f"unsupported side: {side}")

    def apply_fill(self, symbol, side, quantity, fill_price, fee_usdt=0.0):
        """只有成交确认后才调用。返回实现的已实现 PnL。"""
        side = side.upper()
        quantity, fill_price, fee_usdt = float(quantity), float(fill_price), abs(float(fee_usdt))
        realized = 0.0
        if side == "SELL":
            entry = self.entry_prices.get(symbol)
            if entry:
                realized = quantity * (fill_price - entry) - fee_usdt
        gross = quantity * fill_price
        if side == "BUY":
            self.capital -= gross + fee_usdt
            self.update_position(symbol, side, quantity, fill_price)
        elif side == "SELL":
            self.capital += gross - fee_usdt
            self.update_position(symbol, side, quantity, fill_price)
        else:
            raise ValueError(side)
        return realized

    def equity(self, prices):
        value = self.capital
        for asset, qty in self.positions.items():
            p = prices.get(asset) or self.entry_prices.get(asset) or 0.0
            value += qty * p
        return value

    def record_trade(self, asset, side, price, coin_amount, usdt_amount, order_id, pnl_usdt=None):
        path = Path("live_trades.csv")
        is_new = not path.exists()
        with path.open("a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            if is_new:
                writer.writerow(["timestamp", "asset", "side", "price", "usdt_amount", "coin_amount", "order_id", "pnl_usdt"])
            writer.writerow([
                datetime.now(timezone.utc).isoformat(), asset, side.upper(), f"{price:.10f}",
                f"{usdt_amount:.8f}", f"{coin_amount:.12f}", order_id,
                "" if pnl_usdt is None else f"{pnl_usdt:.8f}",
            ])


def adjust_risk_params(base_sl_mult, base_tp_mult, base_trail_mult, regime, volatility_pct, asset=None):
    """只调整止损结构，不修改 AI 概率。"""
    if regime in {"volatile", "extreme_liquidation"}:
        return base_sl_mult * 0.9, base_tp_mult, base_trail_mult * 0.9
    if regime == "narrow_range":
        return base_sl_mult * 0.85, base_tp_mult * 0.9, base_trail_mult * 0.9
    if volatility_pct < 0.001:
        return base_sl_mult * 0.9, base_tp_mult, base_trail_mult
    return base_sl_mult, base_tp_mult, base_trail_mult


def _symbol_key(symbol: str) -> str:
    return symbol.upper().replace("-", "_")


def _load_model_bundle(symbol, allow_missing=False):
    key = _symbol_key(symbol)
    model_path = Path(f"ml_lib/trained_models/{key}_ensemble_model.pkl")
    scaler_path = Path(f"ml_lib/transformers/{key}_scaler.pkl")
    selector_path = Path(f"ml_lib/transformers/{key}_selector.pkl")
    calibrator_path = Path(f"ml_lib/transformers/{key}_calibrator.pkl")
    feature_path = Path(f"ml_lib/transformers/{key}_feature_columns.txt")
    feature_cols = [x.strip() for x in feature_path.read_text(encoding="utf-8").splitlines() if x.strip()] if feature_path.exists() else []
    required = [model_path, scaler_path, selector_path]
    if not all(p.exists() for p in required):
        if allow_missing:
            logger.warning("{} 未发现完整训练模型包：安全观察模式，不产生交易信号。请先执行 train_model.py --symbol {}", symbol, symbol)
            return None, None, None, None, feature_cols
        raise FileNotFoundError(f"缺少 {symbol} 已训练模型/Scaler/Selector；禁止自动生成模型")
    model = joblib.load(model_path)
    scaler = joblib.load(scaler_path)
    selector = joblib.load(selector_path)
    calibrator = joblib.load(calibrator_path) if calibrator_path.exists() else None
    return model, scaler, selector, calibrator, feature_cols


def _calibrate_probability(calibrator, p_up):
    if calibrator is None:
        return float(max(0.0, min(1.0, p_up)))
    try:
        import numpy as np
        p = float(max(1e-5, min(1 - 1e-5, p_up)))
        if hasattr(calibrator, "predict") and not hasattr(calibrator, "predict_proba"):
            out = calibrator.predict(np.asarray([p]))
            return float(max(0.0, min(1.0, out[0])))
        if hasattr(calibrator, "predict_proba"):
            z = np.log(p / (1 - p)).reshape(-1, 1)
            return float(max(0.0, min(1.0, calibrator.predict_proba(z)[0, 1])))
    except Exception as exc:
        logger.warning("概率校准失败，回退原始概率: {}", exc)
    return float(max(0.0, min(1.0, p_up)))


def _prepare_model_input(df_feat, scaler, selector, feature_cols):
    if feature_cols:
        missing = [c for c in feature_cols if c not in df_feat.columns]
        if missing:
            raise ValueError(f"模型依赖特征缺失: {missing}")
        cols = feature_cols
    else:
        cols = [c for c in df_feat.columns if c not in {"timestamp", "datetime"} and pd.api.types.is_numeric_dtype(df_feat[c])]
    row = df_feat[cols].tail(1)
    if row.empty or row.isna().any(axis=1).iloc[0]:
        raise ValueError("最新模型输入包含 NaN")
    scaled = scaler.transform(row)
    selected = selector.transform(scaled)
    return selected


def _load_optional_ai(config):
    """TCN/Transformer 仅作独立确认，不修改主概率。"""
    result = {"tcn": None, "transformer": None}
    if not config.get("ai_confirmation", {}).get("enable", False):
        return result
    try:
        from layers.layer6_tcn_model import TCNPredictor
        path = "ml_lib/trained_models/tcn_model.pth"
        if os.path.exists(path):
            result["tcn"] = TCNPredictor(path)
    except Exception as exc:
        logger.warning("TCN 未加载: {}", exc)
    try:
        from layers.transformer_model import TransformerPredictor
        path = "ml_lib/trained_models/transformer_model.pth"
        if os.path.exists(path):
            result["transformer"] = TransformerPredictor(path)
    except Exception as exc:
        logger.warning("Transformer 未加载: {}", exc)
    return result


def main():
    Path("logs").mkdir(exist_ok=True)
    logger.add("logs/strategy_{time}.log", rotation="1 day", retention=14, encoding="utf-8")
    config = load_config()
    assets = config.get("assets", ["BTC-USDT", "ETH-USDT", "SOL-USDT"])
    timeframe = config.get("market", {}).get("timeframe", "15m")
    interval = max(10, int(config.get("check_interval_seconds", 30)))
    execution_cfg = config.get("execution", {})
    dry_run = bool(execution_cfg.get("dry_run", True))

    check_horizon_consistency(config, logger)

    # 哪些币种被 symbol_overrides 标记为暂停实盘（例如 BTC：OOS accuracy≈0.501，
    # 阈值0.55/0.62/0.68下都触发0笔信号，没有可用信号前不应该继续消耗API配额和撮合风险）。
    enabled_assets = [a for a in assets if is_symbol_enabled(config, a)]
    disabled_assets = [a for a in assets if a not in enabled_assets]
    if disabled_assets:
        logger.warning(
            "以下币种在 symbol_overrides 中被标记为 enabled=false，本次运行将跳过实盘信号生成："
            " {}（训练/回测不受影响，仍会正常跑，用来持续积累是否可以重新启用的证据）",
            disabled_assets,
        )

    logger.info("=== 原架构深度重构版启动：AI → Strategy → Risk → Fill ===")
    logger.info("资产={} | 周期={} | dry_run={}", assets, timeframe, dry_run)

    model_bundles = {a: _load_model_bundle(a, allow_missing=dry_run) for a in assets}
    collector = DataCollector(config.get("market_data", {}))
    cleaner = DataCleaner({"require_confirmed": True})
    engineer = FeatureEngineer(config.get("features", {}))
    regime_detector = MarketRegimeDetector(config.get("model_weight", {}))
    micro_analyzer = MicrostructureAnalyzer()
    # 每个币种一份独立的 SignalGenerator / EntryFilter 实例，配置项 = 全局 signal 段落
    # 与 symbol_overrides.<SYMBOL>.signal 合并后的结果（阈值、direction_mode 均可按币种覆盖）。
    # risk_fuse 保持全局单例，因为它要看的是跨币种的总敞口，不能按币种拆开。
    signal_gen = {a: SignalGenerator(get_symbol_signal_config(config, a)) for a in assets}
    entry_filter = {a: EntryFilter(get_symbol_signal_config(config, a)) for a in assets}
    risk_fuse = RiskFuse(config.get("risk", {}))
    for a in assets:
        _sc = get_symbol_signal_config(config, a)
        if _sc.get("invert_direction"):
            logger.warning("{}: symbol_overrides 配置了 direction_mode=inverted，实盘将对调 BUY/SELL 方向", a)
    sm = {a: PositionStateMachine(config) for a in assets}
    positions = {a: sm[a].initialize_position(a) for a in assets}

    starting_cash = float(config.get("capital", {}).get("initial_usdt", 100000))
    fee_rate = float(config.get("execution", {}).get("fee_rate", 0.001))
    trader = MultiAssetTrader(config, initial_capital=starting_cash, fee_rate=fee_rate)
    risk_manager = RiskManager(
        initial_capital=starting_cash,
        risk_per_trade=float(config.get("risk", {}).get("risk_per_trade", 0.005)),
        atr_multiplier=float(config.get("risk", {}).get("atr_multiplier", 1.2)),
        stop_loss_pct=float(config.get("risk", {}).get("stop_loss_pct", 0.0078)),
        take_profit_pct=float(config.get("risk", {}).get("take_profit_pct", 0.0368)),
        trailing_stop_pct=float(config.get("risk", {}).get("trailing_stop_pct", 0.015)),
    )

    okx_trader = None
    if not dry_run:
        okx_trader = OKXTrader(config.get("exchange", {}).get("okx", {}))
    executor = OrderExecutor(execution_cfg, okx_trader=okx_trader)

    event_store = EventStore()
    monitor = StrategyMonitor(config)
    reporter = PerformanceReporter()
    external = ExternalSentiment()
    llm = SentimentRiskAnalyzer(enabled=bool(config.get("sentiment", {}).get("enable", False)))
    from collections import deque
    equity_history = deque(maxlen=10000)
    if config.get("web_panel", {}).get("enable", False):
        try:
            from interaction.web_panel import run_web_panel, app as web_app
            web_app.trader = trader
            web_app.position_states = positions
            import threading
            threading.Thread(
                target=run_web_panel,
                args=(config.get("web_panel", {}).get("host", "127.0.0.1"), config.get("web_panel", {}).get("port", 5000)),
                daemon=True,
            ).start()
        except ImportError as exc:
            logger.warning("Web panel 未启用：缺少依赖 {}", exc)

    init_db()
    hold_bars_max = int(config.get("strategy", {}).get("max_hold_bars", 16))
    hold_counter = {a: 0 for a in assets}
    last_bar = {a: None for a in assets}

    # 每个币种只在新的“已确认15m K线”出现时重新计算：
    # 特征工程 / ATR / volatility / regime / ML。
    # ticker 与持仓管理仍然每30秒实时执行。
    feature_cache = {
        a: None
        for a in assets
    }

    daily_pnl = 0.0
    daily_trades = 0
    last_trade_day = datetime.now(timezone.utc).date()
    price_cache = {a: None for a in assets}
    decision_stats = {"bars": 0, "candidate_ge_50": 0, "candidate_ge_55": 0, "candidate_ge_threshold": 0, "candidate_ge_strong": 0, "buy_signals": 0, "entry_reject": 0, "risk_reject": 0, "fills": 0, "reasons": {}}
    ai_aux = _load_optional_ai(config)

    # Shadow-only Polymarket research path. It is deliberately independent
    # from OrderExecutor and cannot place an order.
    polymarket_shadow = PolymarketShadowRecorder(config.get("polymarket_shadow", {}))
    polymarket_shadow.start()

    while True:
        cycle_start = time.time()
        try:
            today = datetime.now(timezone.utc).date()
            if today != last_trade_day:
                daily_pnl = 0.0
                daily_trades = 0
                last_trade_day = today

            try:
                polymarket_shadow.evaluate_once()
            except Exception as exc:
                logger.debug("Polymarket Shadow cycle unavailable: {}", exc)

            for asset in assets:
                if asset not in enabled_assets:
                    continue
                try:
                    # ------------------------------------------------
                    # 轻量探测：只判断最新“已确认15m K线”有没有变化。
                    # 不再每30秒重新计算299x64特征。
                    # ------------------------------------------------
                    probe_raw = collector.fetch_klines_rest(
                        asset,
                        interval=timeframe,
                        limit=3,
                    )

                    if not probe_raw:
                        continue

                    probe_df = cleaner.clean_klines(
                        probe_raw
                    )

                    if probe_df.empty:
                        continue

                    bar_ts = int(
                        probe_df["timestamp"].iloc[-1]
                    )

                    cached = feature_cache.get(
                        asset
                    )

                    is_new_confirmed_bar = (
                        cached is None
                        or int(
                            cached["bar_ts"]
                        ) != bar_ts
                    )

                    # ticker 每一轮都获取，保证持仓管理继续实时。
                    ticker = collector.fetch_ticker(
                        asset
                    )

                    fallback_price = float(
                        probe_df["close"].iloc[-1]
                    )

                    current_price = float(
                        ticker or fallback_price
                    )

                    price_cache[asset] = (
                        current_price
                    )

                    if is_new_confirmed_bar:

                        # 只有新的确认K线出现时才重新拉300根。
                        raw = collector.fetch_klines_rest(
                            asset,
                            interval=timeframe,
                            limit=int(
                                config.get(
                                    "market",
                                    {}
                                ).get(
                                    "lookback",
                                    300,
                                )
                            ),
                        )

                        if not raw:
                            continue

                        df = cleaner.clean_klines(
                            raw
                        )

                        if len(df) < 80:
                            continue

                        df_feat = (
                            engineer.calculate_features(
                                df
                            )
                        )

                        if df_feat.empty:
                            continue

                        save_klines(
                            asset,
                            raw[-200:],
                        )

                        full_bar_ts = int(
                            df["timestamp"].iloc[-1]
                        )

                        bar_ts = full_bar_ts

                        atr = (
                            float(
                                df_feat[
                                    "atr_14"
                                ].iloc[-1]
                            )
                            if pd.notna(
                                df_feat[
                                    "atr_14"
                                ].iloc[-1]
                            )
                            else current_price * 0.005
                        )

                        vol = (
                            float(
                                df_feat[
                                    "volatility_20"
                                ].iloc[-1]
                            )
                            if pd.notna(
                                df_feat[
                                    "volatility_20"
                                ].iloc[-1]
                            )
                            else 0.0
                        )

                        regime_info = (
                            regime_detector.detect_regime(
                                df
                            )
                        )

                        regime = regime_info[
                            "market_regime"
                        ]

                        feature_cache[
                            asset
                        ] = {
                            "bar_ts":
                                bar_ts,
                            "df":
                                df,
                            "df_feat":
                                df_feat,
                            "atr":
                                atr,
                            "vol":
                                vol,
                            "regime":
                                regime,
                        }

                        # 只有新的确认K线才计入真实signal sample。
                        decision_stats[
                            "bars"
                        ] += 1

                    else:

                        # 同一根15m K线复用缓存。
                        df = cached["df"]
                        df_feat = cached["df_feat"]
                        atr = float(
                            cached["atr"]
                        )
                        vol = float(
                            cached["vol"]
                        )
                        regime = str(
                            cached["regime"]
                        )

                    pos = positions[
                        asset
                    ]

                    # --- 持仓管理：每个循环都检查，但只有实际 fill 才改变账本 ---
                    if pos.state in (PositionState.HOLDING, PositionState.PARTIAL_CLOSE):
                        if bar_ts != last_bar[asset]:
                            hold_counter[asset] += 1
                        action = sm[asset].update_on_price(pos, current_price, df_feat, atr, market_regime=regime)
                        exit_due_to_time = hold_counter[asset] >= hold_bars_max
                        if pos.state in (PositionState.STOPPED, PositionState.PARTIAL_CLOSE) or exit_due_to_time:
                            sell_qty = pos.quantity
                            if pos.state == PositionState.PARTIAL_CLOSE:
                                sell_qty = pos.quantity * sm[asset].partial_close_ratio
                            if sell_qty > 0:
                                result = executor.execute(
                                    {"symbol": asset, "side": "SELL", "quantity": sell_qty}, current_price
                                )
                                if result.get("executed"):
                                    fill_price = float(result["fill_price"])
                                    fill_qty = float(result.get("fill_quantity", sell_qty))
                                    pnl = trader.apply_fill(asset, "SELL", fill_qty, fill_price, result.get("fee_usdt", 0.0))
                                    sm[asset].on_order_filled(pos, "SELL", fill_qty, fill_price, atr)
                                    trader.record_trade(asset, "SELL", fill_price, fill_qty, fill_qty * fill_price,
                                                        result.get("order_id", "unknown"), pnl)
                                    event_store.append_event("ORDER_FILLED", {
                                        "symbol": asset, "side": "SELL", "quantity": fill_qty,
                                        "price": fill_price, "order_id": result.get("order_id"), "pnl": pnl,
                                    })
                                    monitor.record_trade(asset, "SELL", pnl)
                                    daily_pnl += pnl
                                    daily_trades += 1
                                    hold_counter[asset] = 0
                                    risk_manager.update_trade_result(pnl > 0)
                                    log_trade(asset, "SELL", fill_price, fill_qty, fill_qty * fill_price,
                                              result.get("order_id", "unknown"), pnl_usdt=pnl)
                                    logger.success("{} 平仓成交 {:.8f} @ {:.4f} PnL={:+.4f}", asset, fill_qty, fill_price, pnl)
                                else:
                                    event_store.add_to_dlq({"symbol": asset, "side": "SELL", "quantity": sell_qty})
                        if bar_ts != last_bar[asset]:
                            last_bar[asset] = bar_ts
                        # 有持仓时本轮不再开新仓
                        continue

                    if pos.state == PositionState.COOLDOWN:
                        sm[asset].allow_new_entry(pos)
                    if pos.state != PositionState.EMPTY:
                        last_bar[asset] = bar_ts
                        continue
                    if bar_ts == last_bar[asset]:
                        continue

                    # --- AI 主预测：每个币种独立模型；缺模型安全观察 ---
                    model, scaler, selector, calibrator, feature_cols = model_bundles[asset]
                    if model is None:
                        event_store.append_event("SIGNAL", {
                            "symbol": asset, "bar_ts": bar_ts, "p_up": 0.5,
                            "direction": "HOLD", "regime": regime, "reason": "model_missing_safe_mode",
                        })
                        last_bar[asset] = bar_ts
                        continue
                    X_selected = _prepare_model_input(df_feat, scaler, selector, feature_cols)
                    raw_p_up = float(model.predict_proba(X_selected)[0])
                    use_calibration = bool(config.get("signal", {}).get("use_probability_calibration", False))
                    p_up = _calibrate_probability(calibrator, raw_p_up) if use_calibration else max(0.0, min(1.0, raw_p_up))
                    decision_stats["candidate_ge_50"] += int(p_up >= 0.50)
                    decision_stats["candidate_ge_55"] += int(p_up >= 0.55)
                    decision_stats["candidate_ge_threshold"] += int(p_up >= float(config.get("signal", {}).get("threshold_up", 0.58)))
                    decision_stats["candidate_ge_strong"] += int(p_up >= float(config.get("signal", {}).get("strong_threshold_up", 0.65)))

                    # 独立 AI 辅助只做验证/记录，不修改 p_up。
                    aux_conflict = False
                    if ai_aux["tcn"] is not None:
                        try:
                            tcn_p = float(ai_aux["tcn"].predict(df_feat))
                            aux_conflict |= (tcn_p < 0.40 and p_up >= 0.65)
                        except Exception:
                            tcn_p = None
                    else:
                        tcn_p = None
                    if ai_aux["transformer"] is not None:
                        try:
                            tf_p = float(ai_aux["transformer"].predict(df_feat))
                            aux_conflict |= (tf_p < 0.40 and p_up >= 0.65)
                        except Exception:
                            tf_p = None
                    else:
                        tf_p = None

                    sentiment_adj = 0.0
                    sentiment_conf = 0.0
                    if config.get("sentiment", {}).get("enable", False):
                        try:
                            ext = external.get_combined_sentiment()
                            sentiment_adj = float(ext.get("external_sentiment", 0.0))
                            sentiment_conf = float(ext.get("external_confidence", 0.0))
                        except Exception as exc:
                            logger.debug("外部情绪不可用: {}", exc)
                    if config.get("sentiment", {}).get("llm_confirmation", False):
                        try:
                            llm_result = llm.run_once(asset, df_feat)
                            sentiment_adj = max(-1.0, min(1.0, sentiment_adj + float(llm_result.get("sentiment_adj", 0.0))))
                        except Exception as exc:
                            logger.debug("LLM确认不可用: {}", exc)

                    micro_adj = micro_analyzer.analyze()
                    signal = signal_gen[asset].generate_signal(
                        p_up, micro_adj=micro_adj, sentiment_adj=sentiment_adj,
                        symbol=asset, bar_ts=bar_ts,
                    )
                    # 心跳日志：以前AI/信号这条链路只在真正下单/拒单时才打印一行，
                    # 平时（大多数bar都是HOLD）完全沉默——在日志里全是Polymarket每30秒
                    # 一条的重连/发现市场消息的背景下，很容易让人误以为"AI/OKX那套压根没在跑"。
                    # 现在每次评估都打一行 INFO，能直接在日志里看到AI确实在每根K线上运行。
                    logger.info(
                        "心跳 | {} regime={} p_up={:.4f} direction={} sentiment_adj={:.4f}",
                        asset, regime, p_up, signal["direction"], sentiment_adj,
                    )
                    if aux_conflict:
                        signal["aux_conflict"] = True
                        signal["aux_conflict_reason"] = "独立AI确认冲突，仅记录，不直接否决主模型"

                    # 窄幅反转仅作为第二策略，但必须同时满足 ML 门槛和成本后的 edge。
                    if signal["direction"] == "HOLD" and regime == "narrow_range":
                        rsi = float(df_feat["rsi_14"].iloc[-1])
                        rsi_prev = float(df_feat["rsi_14"].iloc[-2])
                        bb_pos = float(df_feat["bb_pos"].iloc[-1]) if pd.notna(df_feat["bb_pos"].iloc[-1]) else 0.5
                        if p_up >= float(config.get("signal", {}).get("mean_reversion_min_prob", config.get("signal", {}).get("threshold_up", 0.60))) \
                                and rsi <= 42 and rsi > rsi_prev and bb_pos < 0.35:
                            signal["direction"] = "BUY"
                            signal["valid"] = True
                            signal["reason"] = "mean_reversion_confirmed"

                    # 仅把真实模型上下文传给Layer10。
                    # 不修改p_up本身。
                    signal["p_up"] = float(p_up)
                    signal["raw_p_up"] = float(raw_p_up)

                    signal["rsi_14"] = (
                        float(
                            df_feat[
                                "rsi_14"
                            ].iloc[-1]
                        )
                        if (
                            "rsi_14"
                            in df_feat.columns
                            and
                            pd.notna(
                                df_feat[
                                    "rsi_14"
                                ].iloc[-1]
                            )
                        )
                        else None
                    )

                    signal["bb_pos"] = (
                        float(
                            df_feat[
                                "bb_pos"
                            ].iloc[-1]
                        )
                        if (
                            "bb_pos"
                            in df_feat.columns
                            and
                            pd.notna(
                                df_feat[
                                    "bb_pos"
                                ].iloc[-1]
                            )
                        )
                        else None
                    )

                    signal[
                        "strong_threshold_up"
                    ] = max(
                        0.65,
                        float(
                            config.get(
                                "signal",
                                {}
                            ).get(
                                "strong_threshold_up",
                                0.68,
                            )
                        )
                    )

                    event_store.append_event("SIGNAL", {
                        "symbol": asset, "bar_ts": bar_ts, "raw_p_up": raw_p_up, "p_up": p_up,
                        "direction": signal["direction"], "regime": regime,
                        "tcn_p": tcn_p, "transformer_p": tf_p,
                        "aux_conflict": aux_conflict,
                    })
                    last_bar[asset] = bar_ts
                    if signal["direction"] != "BUY":
                        continue
                    decision_stats["buy_signals"] += 1
                    if daily_trades >= int(config.get("risk", {}).get("max_daily_trades", 30)):
                        continue
                    if daily_pnl <= -starting_cash * float(config.get("risk", {}).get("max_daily_loss_rate", 0.02)):
                        logger.warning("日亏损熔断，停止开仓")
                        continue

                    # 先计算风险预算，再运行 EntryFilter/RiskFuse。
                    # 确认的强趋势(strong_up_confirmed)下小幅放宽仓位上限——
                    # 光靠退出管理(移动止损/取消止盈)补不齐和满仓买入持有的差距，
                    # 仓位上限也要跟着市场状态走，见 risk_manager.py 里的说明。
                    _regime_boost = float(config.get("regime", {}).get("position_size_boost", 1.5)) if regime == "strong_up_confirmed" else 1.0
                    position_notional = risk_manager.calculate_position_size(
                        asset, "BUY", current_price, atr, trader.capital, regime_boost=_regime_boost
                    )
                    # 额外保守上限：单币/总组合由 RiskFuse 再次检查。
                    max_entry = trader.capital * float(config.get("risk", {}).get("max_single_entry_pct", 0.10))
                    position_notional = min(float(position_notional or 0), max_entry)
                    if position_notional < float(execution_cfg.get("min_order_value", 10)):
                        continue

                    portfolio = {
                        "total_value": trader.equity(price_cache),
                        "positions": trader.positions.copy(),
                        "today_pnl": daily_pnl,
                    }
                    filter_result = entry_filter[asset].check(signal, regime, trader.capital, position_notional)
                    if not filter_result["passed"]:
                        decision_stats["entry_reject"] += 1
                        for reason in filter_result.get("reasons", []):
                            decision_stats["reasons"][f"entry:{reason}"] = decision_stats["reasons"].get(f"entry:{reason}", 0) + 1
                        continue
                    order_qty = position_notional / current_price
                    order = {
                        "symbol": asset, "side": "BUY", "quantity": order_qty,
                        "notional_usdt": position_notional, "leverage": 1,
                        "order_type": "market", "client_order_id": f"qa_{asset}_{bar_ts}_{uuid.uuid4().hex[:8]}",
                    }
                    market_data = {
                        "current_price": current_price,
                        "prices": price_cache,
                        "volatility": vol,
                        "liquidity_score": 1.0,
                        "panic": regime == "extreme_liquidation",
                    }
                    risk_result = risk_fuse.check(order, portfolio, market_data)
                    if not risk_result["allowed"]:
                        decision_stats["risk_reject"] += 1
                        for reason in risk_result.get("reasons", []):
                            decision_stats["reasons"][f"risk:{reason}"] = decision_stats["reasons"].get(f"risk:{reason}", 0) + 1
                        continue

                    result = executor.execute(order, current_price)
                    if not result.get("executed"):
                        event_store.add_to_dlq({"symbol": asset, "side": "BUY", "quantity": order_qty})
                        continue

                    fill_price = float(result["fill_price"])
                    fill_qty = float(result.get("fill_quantity", order_qty))
                    trader.apply_fill(asset, "BUY", fill_qty, fill_price, result.get("fee_usdt", position_notional * fee_rate))
                    sm[asset].on_order_filled(positions[asset], "BUY", fill_qty, fill_price, atr)
                    hold_counter[asset] = 0
                    trader.record_trade(asset, "BUY", fill_price, fill_qty, fill_qty * fill_price,
                                        result.get("order_id", "unknown"))
                    event_store.append_event("ORDER_FILLED", {
                        "symbol": asset, "side": "BUY", "quantity": fill_qty,
                        "price": fill_price, "order_id": result.get("order_id"),
                    })
                    monitor.notify_trade(asset, "BUY", fill_price, fill_qty)
                    log_trade(asset, "BUY", fill_price, fill_qty, fill_qty * fill_price,
                              result.get("order_id", "unknown"))
                    daily_trades += 1
                    decision_stats["fills"] += 1
                    logger.success("{} 开仓成交 {:.8f} @ {:.4f} notional={:.2f}", asset, fill_qty, fill_price, fill_qty * fill_price)

                except Exception as exc:
                    logger.error("处理 {} 异常: {}\n{}", asset, exc, traceback.format_exc())

            # 持久化本地状态；它不是成交真相源，成交仍以 executor fill 为准。
            safe_json_dump({
                "capital": trader.capital,
                "positions": trader.positions,
                "entry_prices": trader.entry_prices,
                "highest_prices": trader.highest_prices,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }, "positions.json")
            safe_json_dump({
                a: {
                    "state": positions[a].state.value,
                    "quantity": positions[a].quantity,
                    "entry_price": positions[a].entry_price,
                    "highest_price": positions[a].highest_price,
                    "current_sl": positions[a].current_sl,
                    "current_tp": positions[a].current_tp,
                    "cooldown_until": positions[a].cooldown_until,
                    "trailing_activated": positions[a].trailing_activated,
                    "entry_time": positions[a].entry_time,
                } for a in assets
            }, "position_states.json")

            equity = trader.equity(price_cache)
            equity_history.append(equity)
            if decision_stats["bars"] and decision_stats["bars"] % 10 == 0:
                logger.info("信号漏斗 bars={} p>=.50={} p>=.55={} p>=th={} p>=strong={} buys={} entry_reject={} risk_reject={} fills={} reasons={}", decision_stats["bars"], decision_stats["candidate_ge_50"], decision_stats["candidate_ge_55"], decision_stats["candidate_ge_threshold"], decision_stats["candidate_ge_strong"], decision_stats["buy_signals"], decision_stats["entry_reject"], decision_stats["risk_reject"], decision_stats["fills"], decision_stats["reasons"])
            metrics_path = Path("metrics.prom")
            metrics_path.write_text(monitor.export_metrics_prometheus(trader.capital, trader.positions, daily_pnl), encoding="utf-8")
            if int(time.time()) % 300 < interval:
                reporter.print_summary()
            elapsed = time.time() - cycle_start
            time.sleep(max(0.5, interval - elapsed))
        except KeyboardInterrupt:
            logger.info("用户终止策略")
            try:
                polymarket_shadow.stop()
            except Exception:
                pass
            break
        except Exception as exc:
            logger.error("主循环异常: {}\n{}", exc, traceback.format_exc())
            time.sleep(min(60, interval * 2))


if __name__ == "__main__":
    main()
