# -*- coding: utf-8 -*-
"""OKX V5 SPOT trader.
凭证只从环境变量读取；Demo 模式默认开启。
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import time
import uuid
from datetime import datetime, timezone
from typing import Optional

import requests
from loguru import logger


class OKXTrader:
    def __init__(self, config=None):
        config = config or {}
        self.api_key = os.getenv("OKX_API_KEY") or config.get("api_key")
        self.secret_key = os.getenv("OKX_API_SECRET") or config.get("api_secret")
        self.passphrase = os.getenv("OKX_API_PASSPHRASE") or config.get("passphrase")
        self.flag = str(os.getenv("OKX_FLAG", config.get("flag", "1")))
        self.demo = str(os.getenv("OKX_DEMO_TRADING", "true")).lower() == "true" or self.flag == "1"
        self.live_enabled = str(os.getenv("LIVE_TRADING_ENABLED", "false")).lower() == "true"
        if not self.demo and not self.live_enabled:
            raise RuntimeError("Live trading is disabled. Set LIVE_TRADING_ENABLED=true only for an intentional real-account deployment.")
        self.base_url = "https://www.okx.com"
        self.timeout = (5, 15)
        self.session = requests.Session()
        self._seen_order_ids = set()

    def _timestamp(self):
        return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")

    def _sign(self, timestamp, method, request_path, body=""):
        message = f"{timestamp}{method.upper()}{request_path}{body}"
        digest = hmac.new(self.secret_key.encode(), message.encode(), hashlib.sha256).digest()
        return base64.b64encode(digest).decode()

    def _headers(self, timestamp, sign):
        if not (self.api_key and self.secret_key and self.passphrase):
            raise RuntimeError("OKX Demo API 凭证未配置到环境变量")
        headers = {
            "OK-ACCESS-KEY": self.api_key,
            "OK-ACCESS-SIGN": sign,
            "OK-ACCESS-TIMESTAMP": timestamp,
            "OK-ACCESS-PASSPHRASE": self.passphrase,
            "Content-Type": "application/json",
        }
        if self.demo:
            headers["x-simulated-trading"] = "1"
        return headers

    def _request(self, method, path, body=None, query=""):
        body_text = json.dumps(body, separators=(",", ":"), ensure_ascii=False) if body else ""
        request_path = path + (f"?{query}" if query else "")
        ts = self._timestamp()
        sign = self._sign(ts, method, request_path, body_text)
        resp = self.session.request(
            method, self.base_url + request_path,
            headers=self._headers(ts, sign),
            data=body_text if body else None,
            timeout=self.timeout,
        )
        payload = resp.json()
        if resp.status_code >= 400 or payload.get("code") != "0":
            raise RuntimeError(f"OKX API错误 {resp.status_code}: {payload}")
        return payload

    def place_order(self, symbol, side, size, price=None, order_type="market", leverage=1, tgt_ccy=None):
        inst_id = symbol if "-" in symbol else f"{symbol}-USDT"
        side = side.lower()
        params = {
            "instId": inst_id,
            "tdMode": "cash",
            "side": side,
            "ordType": order_type,
            "sz": str(size),
            "clOrdId": f"qa{uuid.uuid4().hex[:24]}",
        }
        if order_type == "market":
            params["tgtCcy"] = tgt_ccy or ("quote_ccy" if side == "buy" else "base_ccy")
        if order_type == "limit" and price is not None:
            params["px"] = str(price)
        return self._request("POST", "/api/v5/trade/order", body=params)["data"][0]

    def get_order(self, symbol, order_id):
        inst_id = symbol if "-" in symbol else f"{symbol}-USDT"
        query = f"instId={requests.utils.quote(inst_id)}&ordId={requests.utils.quote(str(order_id))}"
        return self._request("GET", "/api/v5/trade/order", query=query)["data"][0]

    def wait_for_fill(self, symbol, order_id, timeout_sec=12, poll_sec=1):
        deadline = time.time() + timeout_sec
        last = None
        while time.time() < deadline:
            last = self.get_order(symbol, order_id)
            state = str(last.get("state", "")).lower()
            if state == "filled":
                return last
            if state in {"canceled", "cancelled", "mmp_canceled", "rejected"}:
                return last
            time.sleep(poll_sec)
        return last

    def get_spot_balance(self, ccy):
        query = f"ccy={requests.utils.quote(ccy)}"
        data = self._request("GET", "/api/v5/account/balance", query=query)["data"]
        details = data[0].get("details", []) if data else []
        for row in details:
            if row.get("ccy") == ccy:
                return float(row.get("availBal") or row.get("cashBal") or 0)
        return 0.0
