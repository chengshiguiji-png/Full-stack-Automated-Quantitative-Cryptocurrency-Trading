﻿import csv, os
from datetime import datetime

ARCHIVE_FILE = "trade_archive.csv"

def init_archive():
    if not os.path.exists(ARCHIVE_FILE):
        with open(ARCHIVE_FILE, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["timestamp", "asset", "side", "price", "quantity", "usdt_amount", "order_id", "pnl_usdt", "reason"])

def log_trade(asset, side, price, quantity, usdt_amount, order_id, pnl_usdt=None, reason=""):
    init_archive()
    with open(ARCHIVE_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([datetime.now().strftime("%Y-%m-%d %H:%M:%S"), asset, side, f"{price:.2f}", f"{quantity:.8f}", f"{usdt_amount:.2f}", order_id, f"{pnl_usdt:.4f}" if pnl_usdt else "", reason])
