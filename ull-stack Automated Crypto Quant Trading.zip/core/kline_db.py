﻿import sqlite3, os
from loguru import logger

DB_PATH = "kline_data.db"

def init_db():
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS klines (
                        symbol TEXT, timestamp INTEGER, open REAL, high REAL,
                        low REAL, close REAL, volume REAL,
                        PRIMARY KEY (symbol, timestamp))''')
        conn.commit(); conn.close()
    except Exception as e: logger.warning(f"数据库初始化失败: {e}")

def save_klines(symbol, klines):
    if not klines: return
    try:
        conn = sqlite3.connect(DB_PATH); c = conn.cursor()
        count = 0
        for k in klines:
            try:
                c.execute("INSERT OR IGNORE INTO klines VALUES (?,?,?,?,?,?,?)",
                          (symbol, int(k[0]), float(k[1]), float(k[2]), float(k[3]), float(k[4]), float(k[5])))
                count += 1
            except: pass
        conn.commit(); conn.close()
        if count > 0: logger.debug(f"已保存 {symbol} 的 {count} 条K线")
    except Exception as e: logger.warning(f"数据库写入失败: {e}")

def load_klines(symbol, start_ts=None, end_ts=None, limit=5000):
    try:
        conn = sqlite3.connect(DB_PATH); c = conn.cursor()
        q = "SELECT timestamp,open,high,low,close,volume FROM klines WHERE symbol=? "
        p = [symbol]
        if start_ts: q += "AND timestamp>=? "; p.append(start_ts)
        if end_ts: q += "AND timestamp<=? "; p.append(end_ts)
        q += "ORDER BY timestamp ASC LIMIT ?"; p.append(limit)
        c.execute(q, p); rows = c.fetchall(); conn.close()
        return [list(r) for r in rows]
    except: return []
