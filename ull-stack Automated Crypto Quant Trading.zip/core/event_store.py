﻿# core/event_store.py
import os, json, time
from loguru import logger

class EventStore:
    def __init__(self, log_path="event_log.jsonl", dlq_path="dead_letter_queue.jsonl"):
        self.log_path = log_path
        self.dlq_path = dlq_path
        self.dlq = []

    def append_event(self, etype, payload):
        try:
            with open(self.log_path, "a") as f:
                f.write(json.dumps({"t":time.time(),"type":etype,"data":payload})+"\n")
        except Exception as e:
            logger.error(f"事件写入失败: {e}")

    def add_to_dlq(self, order):
        self.dlq.append(order)
        try:
            with open(self.dlq_path, "a") as f:
                f.write(json.dumps(order)+"\n")
        except: pass

    def replay_events(self, expected_assets):
        positions = {}
        orders = {}
        if not os.path.exists(self.log_path): return {"positions":positions,"orders":orders}
        with open(self.log_path) as f:
            for line in f:
                try:
                    ev = json.loads(line)
                    d = ev["data"]
                    sym = d["symbol"]
                    if ev["type"]=="ORDER_FILLED":
                        side = d["side"]
                        qty = d["quantity"]
                        price = d["price"]
                        if side=="BUY":
                            positions[sym] = positions.get(sym,0)+qty
                            old_qty, old_cost = orders.get(sym, (0,0))
                            new_qty = old_qty+qty
                            new_cost = (old_qty*old_cost + qty*price)/new_qty if new_qty>0 else price
                            orders[sym] = (new_qty, new_cost)
                        else:
                            cur = positions.get(sym,0)
                            sold = min(qty, cur)
                            positions[sym] = cur - sold
                            if positions[sym]<=0:
                                positions.pop(sym,None); orders.pop(sym,None)
                except: pass
        return {"positions":{a:positions.get(a,0) for a in expected_assets},
                "orders":{a:{"quantity":orders[a][0],"entry_price":orders[a][1]} if a in orders else {} for a in expected_assets}}
