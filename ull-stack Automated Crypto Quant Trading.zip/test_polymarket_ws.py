﻿from __future__ import annotations

import json
import os
import time
from urllib.parse import urlparse

import websocket


WS_URL = "wss://ws-subscriptions-clob.polymarket.com/ws/market"

proxy = os.getenv(
    "POLYMARKET_PROXY",
    "http://127.0.0.1:12450"
).strip()

proxy_host = None
proxy_port = None
proxy_type = "http"

if proxy:
    parsed = urlparse(proxy)

    proxy_host = parsed.hostname
    proxy_port = parsed.port

    if parsed.scheme.lower().startswith("socks"):
        proxy_type = "socks5"


print("=" * 72)
print("POLYMARKET CLOB WEBSOCKET TEST")
print("=" * 72)

print("WS_URL :", WS_URL)
print("PROXY  :", proxy or "DIRECT")
print()


stats = {
    "connect": 0,
    "message": 0,
    "error": 0,
    "close": 0,
}

start_time = time.time()
last_message_time = None


def on_open(ws):
    stats["connect"] += 1

    print(
        f"[OPEN] connection #{stats['connect']}"
    )

    # 这里只验证WebSocket连接。
    # 不发送无效token订阅，避免把“订阅格式错误”
    # 误判成网络错误。
    print(
        "[INFO] WebSocket已建立，等待服务端数据/心跳..."
    )


def on_message(ws, message):
    global last_message_time

    stats["message"] += 1
    last_message_time = time.time()

    text = str(message)

    print(
        f"[MESSAGE #{stats['message']}] "
        f"{text[:500]}"
    )


def on_error(ws, error):
    stats["error"] += 1

    print(
        "[ERROR]",
        repr(error)
    )


def on_close(ws, code, msg):
    stats["close"] += 1

    print(
        "[CLOSE]",
        "code=",
        code,
        "msg=",
        msg
    )


def build_ws():
    return websocket.WebSocketApp(
        WS_URL,
        on_open=on_open,
        on_message=on_message,
        on_error=on_error,
        on_close=on_close,
    )


deadline = time.time() + 120
retry = 0

while time.time() < deadline:

    retry += 1

    print()
    print(
        f"[CONNECT] attempt={retry}"
    )

    ws = build_ws()

    run_kwargs = {
        "ping_interval": 20,
        "ping_timeout": 10,
        "close_timeout": 5,
    }

    if proxy_host and proxy_port:
        run_kwargs.update(
            {
                "http_proxy_host": proxy_host,
                "http_proxy_port": proxy_port,
                "proxy_type": proxy_type,
            }
        )

    try:

        ws.run_forever(
            **run_kwargs
        )

    except KeyboardInterrupt:

        print(
            "[STOP] 用户终止测试"
        )

        break

    except Exception as exc:

        print(
            "[EXCEPTION]",
            repr(exc)
        )

        stats["error"] += 1

    if time.time() >= deadline:
        break

    print(
        "[RECONNECT] 5秒后重新连接..."
    )

    time.sleep(5)


elapsed = time.time() - start_time

print()
print("=" * 72)
print("RESULT")
print("=" * 72)

print(
    "connect  =",
    stats["connect"]
)

print(
    "message  =",
    stats["message"]
)

print(
    "error    =",
    stats["error"]
)

print(
    "close    =",
    stats["close"]
)

print(
    "elapsed  =",
    round(elapsed, 2),
    "seconds"
)

if last_message_time:
    print(
        "last_message_age =",
        round(
            time.time() - last_message_time,
            2
        ),
        "seconds"
    )
else:
    print(
        "last_message_age = N/A"
    )

print("=" * 72)
