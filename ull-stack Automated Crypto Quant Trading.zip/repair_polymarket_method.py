﻿from __future__ import annotations

import ast
import shutil
import py_compile
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path


ROOT = Path.cwd()
PATH = ROOT / "layers" / "polymarket_clob.py"
BACKUP_DIR = ROOT / "_FINAL_BACKUP"

if not PATH.exists():
    raise RuntimeError(
        f"找不到: {PATH}"
    )

BACKUP_DIR.mkdir(
    exist_ok=True
)

stamp = datetime.now().strftime(
    "%Y%m%d_%H%M%S"
)

# ------------------------------------------------------------
# 1. 先备份当前文件
# ------------------------------------------------------------

current_backup = (
    BACKUP_DIR
    / f"polymarket_clob.py_before_repair_{stamp}"
)

shutil.copy2(
    PATH,
    current_backup
)

print(
    "[BACKUP]",
    current_backup
)


def class_has_discover(
    text: str
) -> bool:

    try:

        tree = ast.parse(
            text
        )

    except Exception:

        return False

    for node in tree.body:

        if (
            isinstance(
                node,
                ast.ClassDef
            )
            and node.name
            == "PolymarketCLOB"
        ):

            for child in node.body:

                if (
                    isinstance(
                        child,
                        ast.FunctionDef
                    )
                    and child.name
                    == "discover_btc_updown"
                ):

                    return True

    return False


# ------------------------------------------------------------
# 2. 如果当前文件已经没有方法，自动找最近一个正常备份恢复
# ------------------------------------------------------------

source = PATH.read_text(
    encoding="utf-8-sig"
)

if not class_has_discover(
    source
):

    candidates = []

    patterns = [
        ROOT.glob(
            "layers/polymarket_clob.py.bak_*"
        ),
        BACKUP_DIR.glob(
            "polymarket_clob.py*"
        ),
    ]

    for group in patterns:

        for candidate in group:

            try:

                candidate_source = (
                    candidate.read_text(
                        encoding="utf-8-sig"
                    )
                )

                if class_has_discover(
                    candidate_source
                ):

                    candidates.append(
                        (
                            candidate.stat().st_mtime,
                            candidate,
                        )
                    )

            except Exception:
                continue

    if not candidates:

        raise RuntimeError(
            "没有找到包含 "
            "PolymarketCLOB.discover_btc_updown "
            "的有效备份"
        )

    candidates.sort(
        reverse=True
    )

    restore_from = (
        candidates[0][1]
    )

    shutil.copy2(
        restore_from,
        PATH
    )

    source = PATH.read_text(
        encoding="utf-8-sig"
    )

    print(
        "[RESTORE]",
        restore_from
    )


# ------------------------------------------------------------
# 3. 增加官方 event-by-slug 地址
# ------------------------------------------------------------

if (
    "GAMMA_EVENT_SLUG_URL"
    not in source
):

    marker = (
        '    GAMMA_URL = '
        '"https://gamma-api.polymarket.com/markets"\n'
    )

    if marker not in source:

        raise RuntimeError(
            "找不到 GAMMA_URL"
        )

    source = source.replace(
        marker,
        marker
        + (
            '    GAMMA_EVENT_SLUG_URL = '
            '"https://gamma-api.polymarket.com/events/slug/{slug}"\n'
        ),
        1
    )


# ------------------------------------------------------------
# 4. AST定位 discover_btc_updown
# ------------------------------------------------------------

tree = ast.parse(
    source
)

clazz = None

for node in tree.body:

    if (
        isinstance(
            node,
            ast.ClassDef
        )
        and node.name
        == "PolymarketCLOB"
    ):

        clazz = node
        break

if clazz is None:

    raise RuntimeError(
        "找不到 class PolymarketCLOB"
    )

method = None

for child in clazz.body:

    if (
        isinstance(
            child,
            ast.FunctionDef
        )
        and child.name
        == "discover_btc_updown"
    ):

        method = child
        break

if method is None:

    raise RuntimeError(
        "恢复后仍然找不到 discover_btc_updown"
    )


# ------------------------------------------------------------
# 5. 最终市场发现函数
# ------------------------------------------------------------

new_method = r'''
def discover_btc_updown(
    self,
    window="15m",
):
    """
    最终BTC 15m市场发现。

    第一优先级：
        根据当前UTC时间计算 btc-updown-15m-<unix>

    第二优先级：
        上一个/下一个15m窗口

    第三优先级：
        public-search

    第四优先级：
        /markets

    永远要求：
        start <= now < end
        + active
        + 未closed
        + 至少两个clob token
    """

    now = time.time()

    now_dt = datetime.now(
        timezone.utc
    )

    with self._lock:

        cached = (
            self._market_cache.get(
                "market"
            )
        )

        cached_ts = float(
            self._market_cache.get(
                "ts",
                0.0,
            )
        )

    def parse_time(
        value
    ):

        if not value:
            return None

        try:

            parsed = (
                self._parse_dt(
                    value
                )
            )

            return parsed

        except Exception:

            return None

    def get_start(
        market,
        fallback_slug="",
    ):

        start = parse_time(
            market.get(
                "startDate"
            )
            or market.get(
                "startDateIso"
            )
            or market.get(
                "startTime"
            )
        )

        if start:
            return start

        import re

        hit = re.search(
            r"btc-updown-15m-(\d{10})$",
            str(
                market.get(
                    "slug",
                    fallback_slug,
                )
            ).lower()
        )

        if hit:

            return (
                datetime.fromtimestamp(
                    float(
                        hit.group(1)
                    ),
                    tz=timezone.utc,
                )
            )

        return None

    def get_end(
        market,
        start=None,
    ):

        end = parse_time(
            market.get(
                "endDate"
            )
            or market.get(
                "endDateIso"
            )
        )

        if end:
            return end

        if start:

            return (
                start
                + timedelta(
                    minutes=15
                )
            )

        return None

    def normalize(
        market,
        event=None,
        slug_hint="",
    ):

        if not isinstance(
            market,
            dict,
        ):
            return None

        event = (
            event
            if isinstance(
                event,
                dict,
            )
            else {}
        )

        slug = str(
            market.get(
                "slug"
            )
            or event.get(
                "slug"
            )
            or slug_hint
            or ""
        )

        question = str(
            market.get(
                "question"
            )
            or event.get(
                "title"
            )
            or "Bitcoin Up or Down"
        )

        text = (
            slug
            + " "
            + question
        ).lower()

        if (
            "btc" not in text
            and
            "bitcoin" not in text
        ):
            return None

        if (
            "updown" not in text
            and not (
                "up" in text
                and
                "down" in text
            )
        ):
            return None

        if market.get(
            "closed"
        ) is True:
            return None

        if market.get(
            "archived"
        ) is True:
            return None

        if market.get(
            "active"
        ) is False:
            return None

        start = get_start(
            market,
            slug,
        )

        end = get_end(
            market,
            start,
        )

        if (
            start is None
            or
            end is None
        ):
            return None

        if not (
            start
            <= now_dt
            <
            end
        ):
            return None

        raw_tokens = (
            market.get(
                "clobTokenIds"
            )
            or
            market.get(
                "clob_token_ids"
            )
        )

        raw_tokens = (
            self._jsonish(
                raw_tokens
            )
        )

        if not isinstance(
            raw_tokens,
            list,
        ):
            return None

        token_ids = [
            str(x)
            for x in raw_tokens
            if x
        ]

        if len(
            token_ids
        ) < 2:

            return None

        outcomes = (
            self._jsonish(
                market.get(
                    "outcomes"
                )
            )
        )

        if not isinstance(
            outcomes,
            list,
        ):

            outcomes = [
                "Up",
                "Down",
            ]

        outcomes = [
            str(x)
            for x in outcomes
        ]

        ordered = (
            token_ids[:2]
        )

        lowered = [
            x.lower()
            for x in outcomes
        ]

        up_index = next(
            (
                i
                for i, x
                in enumerate(
                    lowered
                )
                if x
                in {
                    "up",
                    "yes",
                }
            ),
            None,
        )

        down_index = next(
            (
                i
                for i, x
                in enumerate(
                    lowered
                )
                if x
                in {
                    "down",
                    "no",
                }
            ),
            None,
        )

        if (
            up_index is not None
            and
            down_index is not None
            and
            up_index
            < len(
                token_ids
            )
            and
            down_index
            < len(
                token_ids
            )
        ):

            ordered = [
                token_ids[
                    up_index
                ],
                token_ids[
                    down_index
                ],
            ]

        return {
            "condition_id":
                (
                    market.get(
                        "conditionId"
                    )
                    or
                    market.get(
                        "condition_id"
                    )
                ),
            "market_id":
                market.get(
                    "id"
                ),
            "event_id":
                event.get(
                    "id"
                ),
            "slug":
                (
                    market.get(
                        "slug"
                    )
                    or
                    event.get(
                        "slug"
                    )
                    or
                    slug
                ),
            "question":
                question,
            "start_time":
                start.isoformat(),
            "end_time":
                end.isoformat(),
            "token_ids":
                ordered,
            "outcomes":
                outcomes[:2],
            "duration_sec":
                (
                    end
                    - start
                ).total_seconds(),
            "volume":
                float(
                    market.get(
                        "volumeNum"
                    )
                    or
                    market.get(
                        "volume"
                    )
                    or
                    0.0
                ),
            "raw":
                market,
        }

    def accept(
        result,
        source,
    ):

        if not result:
            return None

        with self._lock:

            self._market_cache = {
                "ts":
                    now,
                "market":
                    result,
            }

        logger.success(
            "Polymarket LIVE 15m market discovered via {}: {} | start={} | end={} | tokens={}",
            source,
            result.get(
                "slug"
            ),
            result.get(
                "start_time"
            ),
            result.get(
                "end_time"
            ),
            len(
                result.get(
                    "token_ids",
                    [],
                )
            ),
        )

        return result

    # ========================================================
    # 0. Cached live market
    # ========================================================

    if (
        cached
        and
        now - cached_ts
        < float(
            self.refresh_sec
        )
    ):

        raw = cached.get(
            "raw",
            {}
        )

        cached_start = (
            get_start(
                raw,
                cached.get(
                    "slug",
                    "",
                ),
            )
        )

        cached_end = (
            get_end(
                raw,
                cached_start,
            )
        )

        if (
            cached_start
            and
            cached_end
            and
            cached_start
            <= now_dt
            <
            cached_end
        ):

            return cached

    # ========================================================
    # 1. 当前15m窗口的确定slug
    # ========================================================

    bucket = (
        int(now)
        // 900
    ) * 900

    for start_ts in (
        bucket,
        bucket - 900,
        bucket + 900,
    ):

        slug = (
            f"btc-updown-15m-{start_ts}"
        )

        try:

            payload = (
                self._get_json(
                    self.GAMMA_EVENT_SLUG_URL.format(
                        slug=slug
                    )
                )
            )

            if not isinstance(
                payload,
                dict,
            ):
                continue

            markets = (
                payload.get(
                    "markets"
                )
                or []
            )

            if not isinstance(
                markets,
                list,
            ):

                markets = []

            if (
                not markets
                and
                (
                    payload.get(
                        "clobTokenIds"
                    )
                    or
                    payload.get(
                        "clob_token_ids"
                    )
                )
            ):

                markets = [
                    payload
                ]

            for market in markets:

                result = normalize(
                    market,
                    payload,
                    slug,
                )

                if result:

                    return accept(
                        result,
                        "event-slug",
                    )

        except Exception as exc:

            logger.debug(
                "Polymarket event-slug {} failed: {}",
                slug,
                exc,
            )

    # ========================================================
    # 2. public-search
    # ========================================================

    for query in (
        "Bitcoin Up or Down",
        "BTC Up or Down",
    ):

        try:

            payload = (
                self._get_json(
                    "https://gamma-api.polymarket.com/public-search",
                    {
                        "q":
                            query,
                        "limit_per_type":
                            100,
                        "page":
                            1,
                    },
                )
            )

            stack = [
                payload
            ]

            seen = set()

            while stack:

                obj = stack.pop()

                if isinstance(
                    obj,
                    dict,
                ):

                    if (
                        "clobTokenIds"
                        in obj
                        or
                        "clob_token_ids"
                        in obj
                    ):

                        key = str(
                            obj.get(
                                "id"
                            )
                            or
                            obj.get(
                                "slug"
                            )
                            or
                            id(obj)
                        )

                        if key not in seen:

                            seen.add(
                                key
                            )

                            result = (
                                normalize(
                                    obj
                                )
                            )

                            if result:

                                return accept(
                                    result,
                                    "public-search",
                                )

                    for value in obj.values():

                        if isinstance(
                            value,
                            (
                                dict,
                                list,
                            ),
                        ):

                            stack.append(
                                value
                            )

                elif isinstance(
                    obj,
                    list,
                ):

                    stack.extend(
                        obj
                    )

        except Exception as exc:

            logger.debug(
                "Polymarket public-search failed {}: {}",
                query,
                exc,
            )

    # ========================================================
    # 3. /markets fallback
    # ========================================================

    try:

        payload = (
            self._get_json(
                self.GAMMA_URL,
                {
                    "closed":
                        "false",
                    "active":
                        "true",
                    "limit":
                        100,
                    "order":
                        "endDate",
                    "ascending":
                        "true",
                },
            )
        )

        if isinstance(
            payload,
            list,
        ):

            for market in payload:

                result = normalize(
                    market
                )

                if result:

                    return accept(
                        result,
                        "markets",
                    )

    except Exception as exc:

        logger.debug(
            "Polymarket /markets failed: {}",
            exc,
        )

    logger.warning(
        "Polymarket: API reachable but no LIVE BTC 15m market found"
    )

    return None
'''


# ------------------------------------------------------------
# 6. 按AST的真实行号替换函数
# ------------------------------------------------------------

lines = source.splitlines(
    keepends=True
)

replacement = (
    new_method.strip(
        "\n"
    )
    + "\n"
)

lines[
    method.lineno - 1:
    method.end_lineno
] = [
    replacement
]

PATH.write_text(
    "".join(lines),
    encoding="utf-8"
)


# ------------------------------------------------------------
# 7. 最终语法 + 接口测试
# ------------------------------------------------------------

py_compile.compile(
    str(PATH),
    doraise=True
)

verify = PATH.read_text(
    encoding="utf-8"
)

tree = ast.parse(
    verify
)

clazz = next(
    n
    for n in tree.body
    if (
        isinstance(
            n,
            ast.ClassDef
        )
        and
        n.name
        == "PolymarketCLOB"
    )
)

method_ok = any(
    isinstance(
        n,
        ast.FunctionDef
    )
    and
    n.name
    == "discover_btc_updown"
    for n in clazz.body
)

if not method_ok:
    raise RuntimeError(
        "最终检查失败：discover_btc_updown 仍不存在"
    )

print()
print(
    "=" * 72
)
print(
    "POLYMARKET CLOB METHOD REPAIRED"
)
print(
    "=" * 72
)
print(
    "discover_btc_updown : PRESENT"
)
print(
    "syntax              : PASS"
)
print(
    "backup              :",
    current_backup,
)
print(
    "=" * 72
)
