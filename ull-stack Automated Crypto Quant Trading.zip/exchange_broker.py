# exchange_broker.py
import os, subprocess, shutil, time, hmac, hashlib, json, requests
from abc import ABC, abstractmethod
from loguru import logger

class ExchangeBroker(ABC):
    @abstractmethod
    def place_order(self, symbol: str, side: str, quantity: float, price: float = None) -> dict:
        pass

class OKXBroker(ExchangeBroker):
    def __init__(self, profile="demo"):
        self.profile = profile
        self.cli_path = self._find_cli()

    def _find_cli(self):
        okx = shutil.which("okx")
        if okx: return okx
        for p in [r"C:\Users\mi\AppData\Roaming\npm\okx.cmd",
                  r"C:\Program Files\nodejs\okx.cmd",
                  "/usr/local/bin/okx"]:
            if os.path.exists(p): return p
        return None

    def place_order(self, symbol, side, quantity, price=None):
        if not self.cli_path:
            return {"executed": False, "reason": "okx CLI not found"}
        cmd = [self.cli_path, "spot", "place",
               "--instId", symbol, "--side", side.lower(),
               "--ordType", "market", "--sz", str(quantity),
               "--profile", self.profile]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            if result.returncode == 0 and "Order placed:" in result.stdout:
                order_id = result.stdout.split()[2]
                logger.success(f"OKX下单成功，订单ID: {order_id}")
                return {"executed": True, "order_id": order_id, "fill_price": None}
            else:
                return {"executed": False, "reason": result.stderr.strip()}
        except Exception as e:
            return {"executed": False, "reason": str(e)}

class BinanceBroker(ExchangeBroker):
    def __init__(self, api_key, api_secret, testnet=True):
        self.api_key = "***"
        self.api_secret = api_secret
        if testnet:
            self.base_url = "https://testnet.binance.vision"
        else:
            self.base_url = "https://api.binance.com"

    def _sign(self, params: dict) -> dict:
        query_string = "&".join([f"{k}={v}" for k, v in params.items()])
        signature = hmac.new(
            self.api_secret.encode('utf-8'),
            query_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        params['signature'] = signature
        return params

    def _request(self, method, path, params=None, signed=False):
        url = self.base_url + path
        headers = {"X-MBX-APIKEY": self.api_key}
        if signed:
            if not params: params = {}
            params['timestamp'] = int(time.time() * 1000)
            params = self._sign(params)
        try:
            if method == "GET":
                resp = requests.get(url, headers=headers, params=params, timeout=15)
            elif method == "POST":
                resp = requests.post(url, headers=headers, data=params, timeout=15)
            data = resp.json()
            if "code" in data and data["code"] < 0:
                logger.error(f"币安API错误: {data}")
                return None
            return data
        except Exception as e:
            logger.error(f"请求异常: {e}")
            return None

    def place_order(self, symbol: str, side: str, quantity: float, price: float = None):
        sym = symbol.replace("-", "")
        params = {
            "symbol": sym,
            "side": side.upper(),
            "type": "MARKET",
            "quantity": round(quantity, 6)
        }
        result = self._request("POST", "/api/v3/order", params, signed=True)
        if result and result.get("status") == "FILLED":
            order_id = str(result["orderId"])
            fill_price = float(result["fills"][0]["price"]) if result.get("fills") else 0.0
            logger.success(f"币安下单成功，订单ID: {order_id}")
            return {"executed": True, "order_id": order_id, "fill_price": fill_price}
        else:
            reason = result.get("msg", "未知错误") if result else "无响应"
            return {"executed": False, "reason": reason}

def create_broker(config):
    active = config.get("exchange", {}).get("active", "okx")
    if active == "binance":
        api_key = "***"
        api_secret = os.environ.get("BINANCE_API_SECRET") or config["exchange"]["binance"]["api_secret"]
        testnet = config["exchange"]["binance"].get("testnet", True)
        return BinanceBroker(api_key, api_secret, testnet=testnet)
    else:
        profile = config["exchange"]["okx"].get("profile", "demo")
        return OKXBroker(profile=profile)