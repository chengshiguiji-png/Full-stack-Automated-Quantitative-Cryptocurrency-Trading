# backtest_engine.py
# -*- coding: utf-8 -*-
"""
精细滚动回测引擎（无未来数据泄露，已修复 NaN 问题）
"""
import pandas as pd
import numpy as np
from loguru import logger
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_classif

from layers.layer1_data_collector import DataCollector
from layers.layer3_data_clean import DataCleaner
from layers.layer4_feature_engineer import FeatureEngineer
from layers.layer5_sentiment_risk import SentimentRiskAnalyzer
from layers.layer6_ml_model import MLModelEnsemble
from layers.layer7_market_regime import MarketRegimeDetector
from layers.layer8_microstructure import MicrostructureAnalyzer
from layers.layer9_signal_generator import SignalGenerator
from layers.layer10_filter import EntryFilter
from layers.layer11_risk_fuse import RiskFuse
from layers.layer17_position_state_machine import PositionStateMachine, PositionState
from risk_manager import RiskManager
from layers.symbol_config import (
    check_horizon_consistency,
    get_symbol_risk_config,
    get_symbol_signal_config,
)


class RollingBacktest:
    def __init__(self, config, symbol="BTC-USDT", initial_capital=100000, fee_rate=0.001):
        self.config = config
        self.symbol = symbol
        self.initial_capital = initial_capital
        self.capital = initial_capital
        self.fee_rate = fee_rate
        self.positions = {}
        self.trades = []
        self.equity_curve = []

        # 注意：回测引擎不看 symbol_overrides.enabled——即使某个币种在实盘里被暂停，
        # 研究/回测也应该继续跑，这样才能持续产生"是否可以重新启用"的证据。
        # 只有 main_strategy.py 的实盘循环才会尊重 enabled 开关。
        check_horizon_consistency(config, logger)
        signal_cfg = get_symbol_signal_config(config, symbol)
        risk_cfg = get_symbol_risk_config(config, symbol)
        if signal_cfg.get("invert_direction"):
            logger.warning("{}: symbol_overrides 配置了 direction_mode=inverted，回测将对调 BUY/SELL 方向", symbol)

        self.regime_detector = MarketRegimeDetector()
        self.micro_analyzer = MicrostructureAnalyzer()
        self.signal_gen = SignalGenerator(signal_cfg)
        self.entry_filter = EntryFilter(signal_cfg)
        self.risk_fuse = RiskFuse(risk_cfg)
        self.sentiment_analyzer = SentimentRiskAnalyzer()
        # 关键修复：以前这里没有用到 RiskManager，导致回测里每笔 BUY 都是硬编码
        # 固定 10 USDT，跟实盘 main_strategy.py 里真正用的、基于 ATR 动态计算
        # （并且有 5%/500U 上限）的仓位公式完全是两套逻辑——回测测的不是实盘会跑的仓位大小。
        # 现在统一改成调用同一个 RiskManager.calculate_position_size。
        self.risk_manager = RiskManager(
            initial_capital=initial_capital,
            risk_per_trade=float(risk_cfg.get("risk_per_trade", 0.005)),
            atr_multiplier=float(risk_cfg.get("atr_multiplier", 1.2)),
            stop_loss_pct=float(risk_cfg.get("stop_loss_pct", 0.0078)),
            take_profit_pct=float(risk_cfg.get("take_profit_pct", 0.018)),
            trailing_stop_pct=float(risk_cfg.get("trailing_stop_pct", 0.015)),
        )
        self.max_single_entry_pct = float(risk_cfg.get("max_single_entry_pct", 0.10))
        self.min_order_value = float(config.get("execution", {}).get("min_order_value", 10))
        # 关键修复2：以前这里完全没有独立于模型信号的止损/止盈/移动止损检查——
        # 只有模型自己发出SELL信号才会平仓，导致亏损仓位可以一直扛着直到模型"想通"。
        # 实盘 main_strategy.py 用的是 PositionStateMachine（ATR止损+移动止损+分批止盈），
        # 现在回测引擎接入同一个状态机，这样两边测的才是同一套真实的风控行为。
        self.sm = PositionStateMachine(config)
        self.pos_info = self.sm.initialize_position(symbol)
        self.hold_bars_max = int(config.get("strategy", {}).get("max_hold_bars", 12))
        self.hold_counter = 0

    def get_historical_data(self, limit=1000, end_ts=None):
        collector = DataCollector()
        # 关键修复：以前这里没有传 interval，不管 config.yaml 的 market.timeframe
        # 设成什么，永远拉15m数据——这次要honest测一下4h是否有救，这个参数必须接上，
        # 否则不管改config改成4h，实际测的还是15m，会得出"4h没用"的假结论。
        timeframe = str((self.config.get("market") or {}).get("timeframe", "15m"))
        klines = collector.fetch_klines_rest(symbol=self.symbol, interval=timeframe, limit=limit, end_ts=end_ts)
        if not klines:
            raise Exception("数据获取失败")
        cleaner = DataCleaner()
        df = cleaner.clean_klines(klines)
        return df.sort_values('timestamp').reset_index(drop=True)

    def run(self, train_window=200, step=1, start_index=300, end_ts=None, total_bars=None):
        # 2026-09 修复：以前这里 total_bars 固定是 start_index+train_window+100，
        # 15m下也就600根≈6.25天——但你实际跑出来的CSV时间跨度有32天，说明你本地
        # 大概率已经自己改过这个值了（比如直接改了start_index/train_window，或者
        # 在别处覆盖了total_bars），我这边保留的版本和你本地实际在跑的版本已经有差异。
        # 现在把 total_bars 变成显式参数：不传时保持旧默认公式（向后兼容），
        # 传了就按你给的来——tools/multi_window_backtest.py 会显式传入按timeframe
        # 换算出来的天数对应的根数，不再依赖那个只够6天的默认值。
        if total_bars is None:
            total_bars = start_index + train_window + 100
        df_full = self.get_historical_data(limit=total_bars, end_ts=end_ts)
        if len(df_full) < start_index + train_window:
            logger.error(f"数据不足，需要 {start_index + train_window}，实际 {len(df_full)}")
            return

        engineer = FeatureEngineer()
        funding_df = None
        if bool(self.config.get("regime", {}).get("use_funding_rate_feature", False)):
            try:
                funding_end_ts = end_ts if end_ts else int(df_full["timestamp"].iloc[-1].value // 1_000_000)
                rows = DataCollector(self.config.get("market_data", {})).fetch_funding_rate_history(
                    self.symbol, limit=min(2000, len(df_full) // 4 + 50), end_ts=funding_end_ts
                )
                if rows:
                    funding_df = pd.DataFrame(rows)
                    funding_df["timestamp"] = pd.to_datetime(funding_df["timestamp"], unit="ms")
            except Exception as exc:
                logger.warning("{}: 资金费率特征获取失败，回测继续使用不含资金费率的基线特征集: {}", self.symbol, exc)
        df_features = engineer.calculate_features(df_full, funding_df=funding_df)
        exclude_cols = ['timestamp', 'datetime']
        feature_cols = [c for c in df_features.columns if c not in exclude_cols and pd.api.types.is_numeric_dtype(df_features[c])]
        df_features = df_features.sort_values('timestamp').reset_index(drop=True)
        full_X = df_features[feature_cols]
        full_close = df_features['close']
        full_ts = df_features['timestamp']

        self.capital = self.initial_capital
        self.positions = {}
        self.trades = []
        self.equity_curve = []

        for i in range(start_index, len(df_features) - 3, step):
            train_end_idx = i - 1
            if train_end_idx < train_window:
                continue

            # === 使用 ml_lib 生产模型（train_model.py 用 ATR 三段式标签训练），
            # 不再在每个滚动窗口里用 shift(-3) 简单标签现场自训一个模型。
            # （历史上这里曾经两条路径都在，导致混淆："标签口径" 和"评估口径"不一致——
            #  现在只保留生产模型这一条路径，特征对齐/NaN过滤都在下面统一处理。）
            import joblib
            from pathlib import Path as _P
            _key = self.symbol.replace("-", "_")
            _mp = _P(f"ml_lib/trained_models/{_key}_ensemble_model.pkl")
            _sp = _P(f"ml_lib/transformers/{_key}_scaler.pkl")
            _lp = _P(f"ml_lib/transformers/{_key}_selector.pkl")
            _fp = _P(f"ml_lib/transformers/{_key}_feature_columns.txt")
            if not (_mp.exists() and _sp.exists() and _lp.exists() and _fp.exists()):
                logger.warning(f"缺少 {_key} 生产模型，跳过")
                continue
            model = joblib.load(_mp)
            scaler = joblib.load(_sp)
            selector = joblib.load(_lp)
            prod_cols = [x.strip() for x in _fp.read_text(encoding="utf-8").splitlines() if x.strip()]

            current_X = full_X.iloc[i:i+1]
            if current_X.isnull().any().any():
                continue
            current_X = current_X[prod_cols].dropna(axis=1, how='any')
            if current_X.shape[1] != len(prod_cols):
                continue
            current_scaled = scaler.transform(current_X)
            current_selected = selector.transform(current_scaled)
            p_up = model.predict_proba(current_selected)[0]
            current_price = full_close.iloc[i]
            current_ts = full_ts.iloc[i]

            df_current = df_features.iloc[:i+1].copy()
            regime_result = self.regime_detector.detect_regime(df_current)
            market_regime = regime_result["market_regime"]
            atr_val = float(df_current["atr_14"].iloc[-1]) if "atr_14" in df_current.columns else 0.0

            # --- 独立于模型信号的持仓管理：每根K线都检查，不等模型自己发SELL ---
            if self.pos_info.state in (PositionState.HOLDING, PositionState.PARTIAL_CLOSE):
                self.hold_counter += 1
                self.sm.update_on_price(self.pos_info, current_price, df_current, atr_val, market_regime=market_regime)
                exit_due_to_time = self.hold_counter >= self.hold_bars_max
                if self.pos_info.state in (PositionState.STOPPED, PositionState.PARTIAL_CLOSE) or exit_due_to_time:
                    sell_qty = self.pos_info.quantity
                    if self.pos_info.state == PositionState.PARTIAL_CLOSE:
                        sell_qty = self.pos_info.quantity * self.sm.partial_close_ratio
                    if sell_qty > 0:
                        exit_reason = (
                            "time_exit" if exit_due_to_time and self.pos_info.state != PositionState.STOPPED
                            else ("partial_take_profit" if self.pos_info.state == PositionState.PARTIAL_CLOSE else "stop_or_trailing")
                        )
                        exit_order = {
                            "symbol": self.symbol, "side": "SELL", "size": sell_qty,
                            "quantity": sell_qty, "notional_usdt": sell_qty * current_price,
                            "leverage": 1, "order_type": "market", "exit_reason": exit_reason,
                        }
                        self._execute_simulation(exit_order, current_price, current_ts)
                        self.sm.on_order_filled(self.pos_info, "SELL", sell_qty, current_price, atr_val)
                        total_equity = self.capital + sum(qty * current_price for qty in self.positions.values())
                        self.equity_curve.append((current_ts, total_equity))
                    if self.pos_info.quantity <= 1e-12:
                        self.hold_counter = 0
                    continue

            micro_adj = self.micro_analyzer.analyze()
            sentiment_data = self.sentiment_analyzer.run_once(self.symbol)
            sentiment_adj = sentiment_data.get("sentiment_adj", 0.0)

            if not self.sm.allow_new_entry(self.pos_info):
                continue

            signal = self.signal_gen.generate_signal(p_up, micro_adj, sentiment_adj, self.symbol)
            if signal["direction"] == "HOLD":
                continue
            # 关键修复：entry_filter 里 strong_down/strong_up 的逆势门槛需要读 rsi_14/bb_pos，
            # 之前这里从没往 signal 字典里塞过这两个字段——导致回测里这两条逆势限制
            # 无论如何都会因为"rsi is not None"判断失败而直接拒绝，跟实盘 main_strategy.py
            # 的行为不一致（实盘那边有补这两个字段）。现在补齐，保持两边口径一致。
            if "rsi_14" in df_current.columns:
                signal["rsi_14"] = float(df_current["rsi_14"].iloc[-1])
            if "bb_pos" in df_current.columns:
                bb_val = df_current["bb_pos"].iloc[-1]
                signal["bb_pos"] = float(bb_val) if pd.notna(bb_val) else 0.5

            portfolio = {
                "total_value": self.capital + sum(qty * current_price for qty in self.positions.values()),
                "positions": {self.symbol.split('-')[0]: self.positions.get(self.symbol, 0)},
                "today_pnl": 0,
                "equity_curve": [1.0]
            }
            direction = signal["direction"]
            if direction == "BUY":
                # 和 main_strategy.py 完全同一套公式：先算 ATR 风险预算仓位，
                # 再叠加 max_single_entry_pct 的保守上限，最后过滤掉低于最小下单额的信号。
                _regime_boost = float(self.config.get("regime", {}).get("position_size_boost", 1.5)) if market_regime == "strong_up_confirmed" else 1.0
                notional_usdt = self.risk_manager.calculate_position_size(
                    self.symbol, "BUY", current_price, atr_val, portfolio["total_value"], regime_boost=_regime_boost
                )
                max_entry = portfolio["total_value"] * self.max_single_entry_pct
                notional_usdt = min(float(notional_usdt or 0), max_entry)
                if notional_usdt < self.min_order_value:
                    continue
                quantity = notional_usdt / current_price if current_price > 0 else 0.0
            else:
                # RiskManager 目前只对 BUY 侧给出仓位建议（SPOT 现货、无法开空），
                # SELL 信号在这套架构里代表"平多"，数量不应该凭空定一个和当前持仓无关的常数。
                held = self.positions.get(self.symbol, 0.0)
                if held <= 0:
                    continue
                quantity = held
                notional_usdt = quantity * current_price

            # position_size 现在传的是这笔单子真实的名义金额，而不是之前写死的占位值 1000。
            filter_result = self.entry_filter.check(signal, market_regime, portfolio["total_value"], position_size=notional_usdt)
            if not filter_result["passed"]:
                continue

            market_data = {
                "current_price": current_price,
                "prices": {self.symbol: current_price},
                "volatility": df_current['close'].pct_change().std(),
                "liquidity_score": 0.8,
                "panic": False,
                "returns_20d": df_current['close'].pct_change().dropna().iloc[-20:].tolist()
            }
            order = {
                "symbol": self.symbol,
                "side": direction,
                "size": notional_usdt if direction == "BUY" else quantity,
                "quantity": quantity,
                "notional_usdt": notional_usdt,
                "leverage": 1,
                "order_type": "market",
            }
            risk_result = self.risk_fuse.check(order, portfolio, market_data)
            if not risk_result["allowed"]:
                continue

            self._execute_simulation(order, current_price, current_ts)
            # 保持 pos_info（状态机用来判断止损/止盈/移动止损）跟 self.positions（用于算权益）同步，
            # 否则模型自己发的BUY/SELL不会被状态机感知，止损距离/移动止损会用错的入场价计算。
            self.sm.on_order_filled(self.pos_info, direction, quantity, current_price, atr_val)
            if direction == "BUY":
                self.hold_counter = 0
            total_equity = self.capital + sum(qty * current_price for qty in self.positions.values())
            self.equity_curve.append((current_ts, total_equity))

        self._report_performance()

    def _execute_simulation(self, order, price, timestamp):
        side = order["side"]
        size = order["size"]
        if side == "BUY":
            cost = size
            fee = cost * self.fee_rate
            if self.capital >= cost + fee:
                self.capital -= (cost + fee)
                base_amount = cost / price
                self.positions[self.symbol] = self.positions.get(self.symbol, 0) + base_amount
                self.trades.append({
                    "timestamp": timestamp, "side": "BUY", "price": price,
                    "usdt_amount": cost, "base_amount": base_amount, "fee": fee,
                    "capital": self.capital
                })
                logger.info(f"[回测] 买入 {base_amount:.6f} {self.symbol} @ {price:.2f}")
        elif side == "SELL":
            if self.symbol in self.positions and self.positions[self.symbol] > 0:
                base_amount = min(size, self.positions[self.symbol])
                income = base_amount * price
                fee = income * self.fee_rate
                self.capital += (income - fee)
                self.positions[self.symbol] -= base_amount
                if self.positions[self.symbol] == 0:
                    del self.positions[self.symbol]
                self.trades.append({
                    "timestamp": timestamp, "side": "SELL", "price": price,
                    "base_amount": base_amount, "income": income, "fee": fee,
                    "capital": self.capital, "exit_reason": order.get("exit_reason", "model_signal"),
                })
                logger.info(f"[回测] 卖出 {base_amount:.6f} {self.symbol} @ {price:.2f}")

    def _report_performance(self):
        if not self.equity_curve:
            logger.warning("回测无交易记录")
            return
        df_equity = pd.DataFrame(self.equity_curve, columns=["timestamp", "equity"])
        df_equity['date'] = pd.to_datetime(df_equity['timestamp'], unit='ms')
        daily_equity = df_equity.groupby(df_equity['date'].dt.date)['equity'].last()
        returns = daily_equity.pct_change().dropna()
        total_return = (df_equity['equity'].iloc[-1] - self.initial_capital) / self.initial_capital
        sharpe = returns.mean() / returns.std() * np.sqrt(252) if returns.std() > 0 else 0
        max_drawdown = (df_equity['equity'] / df_equity['equity'].cummax() - 1).min()

        logger.info("========== 滚动回测绩效报告 ==========")
        logger.info(f"初始资金: {self.initial_capital:.2f}")
        logger.info(f"最终权益: {df_equity['equity'].iloc[-1]:.2f}")
        logger.info(f"总收益率: {total_return:.2%}")
        logger.info(f"年化夏普比率: {sharpe:.2f}")
        logger.info(f"最大回撤: {max_drawdown:.2%}")
        logger.info(f"总交易次数: {len(self.trades)}")

        key = self.symbol.replace("-", "_")
        trades_file = f"rolling_backtest_trades_{key}.csv"
        equity_file = f"rolling_backtest_equity_{key}.csv"
        trades_df = pd.DataFrame(self.trades)
        if not trades_df.empty and "symbol" not in trades_df.columns:
            trades_df.insert(0, "symbol", self.symbol)
        trades_df.to_csv(trades_file, index=False)
        df_equity.to_csv(equity_file, index=False)
        logger.info(f"交易明细已保存至 {trades_file} 和 {equity_file}")