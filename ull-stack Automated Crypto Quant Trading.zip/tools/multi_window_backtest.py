# -*- coding: utf-8 -*-
"""按月分窗口跑回测，对应报告里的问题9/12：
"应该先跑5月/6月/7月/8月/9月五个窗口看基线表现"。

用法：
    python tools/multi_window_backtest.py

关键说明——这个工具存在的原因：
以前 backtest_engine.py 的 get_historical_data() 只会拉"运行这一刻往前数的最近N根"，
没有办法指定"我要测2026年5月"这种历史区间。哪怕你以为自己在分月测试，实际上每次
跑出来的都是同一份"现在往回数"的数据。这次给 fetch_klines_rest/get_historical_data/
run() 都加了 end_ts 参数，这个工具就是用来验证这个参数确实生效、并且把5个月的结果
汇总成一张表，而不是每个月单独手动跑一次、自己拼表格。

重要限制：OKX 的 history-candles 接口对更早的历史数据是否还留着15m级别的完整数据，
需要实际跑一次才知道——如果某个月拉不到数据，这里会跳过并打印原因，不会假装成功。

方法论提醒（对应问题10：如何避免"看哪个月效果好就挑哪个月"）：
- 这个脚本只负责把5个月的表现如实列出来，不做任何"哪个月最能证明策略有效"的判断。
- 建议流程：先冻结 config.yaml 里的参数（尤其是这次新加的 regime.adx_trend 等阈值），
  再一次性跑完5个月，全部如实记录，不要跑完某个月觉得不理想就回去改参数再重跑那个月——
  那样等于用"已知结果"去调参数，是我们之前反复强调的过拟合陷阱。
"""
from __future__ import annotations

import sys
import os
import datetime as dt

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import yaml
from backtest_engine import RollingBacktest

CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.yaml")

# 2026-09 新增：按 config.yaml 的 market.timeframe 动态换算窗口长度。
# 原因：train_window=200 + start_index=300（预热用）在15m下只占约5天，1个月窗口
# 绰绰有余；但如果直接把同样的"1个月"套到4h，500根预热K线就要83天，
# 一个月的窗口连预热都不够，更别提留出K线给实际的测试交易——那样测出来的
# "4h没有效果"根本不能说明什么，只是窗口长度设错了。
# 下面按目标"预热300+200根 + 至少再留500根用于产生测试交易"反推需要多少天，
# 15m下算出来远小于31天，所以保留原有的1个月惯例；4h下会自动算出大约5-6个月，
# 数值会在运行时打印出来，不是拍脑袋决定的。
BARS_PER_DAY = {"1m": 1440, "5m": 288, "15m": 96, "30m": 48, "1h": 24, "4h": 6, "1d": 1}
MIN_WINDOW_DAYS = 31


def _compute_window_days(timeframe: str, train_window: int, start_index: int, desired_test_bars: int = 500) -> int:
    bars_per_day = BARS_PER_DAY.get(timeframe, 96)
    total_bars_needed = start_index + train_window + desired_test_bars
    days_needed = total_bars_needed / bars_per_day
    return max(MIN_WINDOW_DAYS, int(days_needed) + 1)


# 五个"月末"锚点日期——窗口的结束时间不变，起始时间按上面算出的天数往回推，
# 15m下这五个窗口基本还是原来的自然月；4h下会自动变长（窗口之间会有更多重叠，
# 这是时间跨度换取样本量的必然代价，运行时会打印每个窗口实际覆盖的起止日期）。
WINDOW_ENDS = [
    ("2026-05", dt.datetime(2026, 5, 31, 23, 59, 59)),
    ("2026-06", dt.datetime(2026, 6, 30, 23, 59, 59)),
    ("2026-07", dt.datetime(2026, 7, 31, 23, 59, 59)),
    ("2026-08", dt.datetime(2026, 8, 31, 23, 59, 59)),
    ("2026-09", dt.datetime(2026, 9, 15, 23, 59, 59)),
]
SYMBOLS = ["BTC-USDT", "ETH-USDT", "SOL-USDT"]
TRAIN_WINDOW = 200
START_INDEX = 300


def run_all():
    with open(CONFIG_PATH, encoding="utf-8") as f:
        config = yaml.safe_load(f)
    timeframe = str((config.get("market") or {}).get("timeframe", "15m"))
    window_days = _compute_window_days(timeframe, TRAIN_WINDOW, START_INDEX)
    bars_needed = window_days * BARS_PER_DAY.get(timeframe, 96) + START_INDEX + TRAIN_WINDOW
    print(f"当前 timeframe={timeframe}，每个窗口按 {window_days} 天计算（自动换算，不是写死的）")

    results = []
    for label, end_dt in WINDOW_ENDS:
        end_ts = int(end_dt.timestamp() * 1000)
        start_dt = end_dt - dt.timedelta(days=window_days)
        print(f"\n窗口 {label}: {start_dt.date()} ~ {end_dt.date()}（{window_days}天, timeframe={timeframe}）")
        for symbol in SYMBOLS:
            print(f"  --- {symbol} ---")
            try:
                engine = RollingBacktest(config, symbol=symbol)
                engine.run(train_window=TRAIN_WINDOW, step=1, start_index=START_INDEX,
                          end_ts=end_ts, total_bars=bars_needed)
                final_capital = engine.capital
                ret_pct = (final_capital / 100000.0 - 1) * 100
                results.append({
                    "window": label, "symbol": symbol,
                    "final_capital": round(final_capital, 2),
                    "return_pct": round(ret_pct, 3),
                    "trades": len(engine.trades),
                    "status": "ok",
                })
            except Exception as e:
                print(f"  跳过（{e}）")
                results.append({
                    "window": label, "symbol": symbol,
                    "final_capital": None, "return_pct": None,
                    "trades": None, "status": f"failed: {e}",
                })

    print("\n\n================ 汇总表 ================")
    print(f"{'窗口':<10}{'币种':<12}{'收益率':>10}{'交易数':>8}  状态")
    for r in results:
        ret_str = f"{r['return_pct']:+.2f}%" if r["return_pct"] is not None else "N/A"
        trades_str = str(r["trades"]) if r["trades"] is not None else "N/A"
        print(f"{r['window']:<10}{r['symbol']:<12}{ret_str:>10}{trades_str:>8}  {r['status']}")

    import json
    out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "multi_window_results.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"\n完整结果已保存到 {out_path}")


if __name__ == "__main__":
    run_all()
