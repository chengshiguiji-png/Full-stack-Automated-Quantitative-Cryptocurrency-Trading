#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Offline report for Polymarket shadow JSONL observations.

No network access, no credentials, no order placement. It scores observations
only when a resolved outcome is present in the record (or can be supplied via
--outcome-file). This intentionally does not fabricate labels.
"""
from __future__ import annotations
import argparse, json, math
from collections import defaultdict
from pathlib import Path


def load_jsonl(path):
    rows=[]
    for line in Path(path).read_text(encoding='utf-8').splitlines():
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except json.JSONDecodeError: continue
    return rows


def prob_from_row(r):
    fair = r.get('fair', {}).get('conservative_fair_probability')
    if fair is None: fair = r.get('fair', {}).get('fair_probability')
    try: return float(fair)
    except (TypeError, ValueError): return None


def score(rows):
    labeled=[]
    for r in rows:
        outcome=r.get('resolved_outcome')
        if outcome not in ('YES','NO',True,False,1,0): continue
        p=prob_from_row(r)
        if p is None: continue
        y=1.0 if outcome in ('YES',True,1) else 0.0
        labeled.append((r,p,y))
    if not labeled: return None
    brier=sum((p-y)**2 for _,p,y in labeled)/len(labeled)
    eps=1e-9
    logloss=-sum(y*math.log(max(eps,min(1-eps,p)))+(1-y)*math.log(max(eps,min(1-eps,1-p))) for _,p,y in labeled)/len(labeled)
    hit=sum((p>=.5)==bool(y) for _,p,y in labeled)/len(labeled)
    return {'n':len(labeled),'brier':brier,'log_loss':logloss,'accuracy':hit}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('path', nargs='?', default='data/polymarket_shadow/signals.jsonl')
    ap.add_argument('--outcome-file', help='JSONL mapping market_slug -> YES/NO; labels are never inferred')
    args=ap.parse_args()
    rows=load_jsonl(args.path)
    if args.outcome_file:
        labels={}
        for r in load_jsonl(args.outcome_file):
            if r.get('market_slug') and r.get('resolved_outcome') in ('YES','NO'):
                labels[r['market_slug']]=r['resolved_outcome']
        for r in rows:
            if r.get('market_slug') in labels: r['resolved_outcome']=labels[r['market_slug']]
    print(json.dumps({'observations':len(rows),'labeled_score':score(rows)}, ensure_ascii=False, indent=2))
    buckets=defaultdict(lambda:[0,0,0.0])
    for r in rows:
        a=r.get('alpha',{})
        try: edge=float(a.get('net_edge')); trade=bool(a.get('tradeable'))
        except (TypeError,ValueError): continue
        key=f'{math.floor(edge*1000)/10:.1f}%'
        buckets[key][0]+=1; buckets[key][1]+=int(trade); buckets[key][2]+=edge
    if buckets:
        print('\nNet-edge buckets:')
        for k,v in sorted(buckets.items(), key=lambda x: float(x[0][:-1])):
            print(f'{k:>8}  observations={v[0]:>6} tradeable={v[1]:>6} mean_edge={v[2]/v[0]:.4%}')

if __name__ == '__main__': main()
