# -*- coding: utf-8 -*-
"""Block Bootstrap 显著性检验，对应报告问题11。

为什么不能用普通的（逐笔独立重抽样的）bootstrap 或者简单 t 检验：
你的交易是"滚动窗口回测"产生的，相邻交易之间用的训练窗口高度重叠、
市场状态也是连续的（一段趋势里可能连续出好几笔同方向交易）——这些交易
不是互相独立的。如果假装它们独立、用普通 bootstrap 逐笔重抽样，
会系统性地低估真实的不确定性，把"运气好"误判成"显著有效"。

Block Bootstrap 的做法：不逐笔重抽样，而是把交易序列切成连续的"块"
（比如每块10笔，按时间顺序不打乱块内部顺序），重抽样的单位是"块"而不是"笔"，
这样能部分保留交易之间的时间相关性。

用法：
    python tools/block_bootstrap.py path/to/trades.csv --pnl-col pnl_pct --block-size 10

CSV 至少需要一列可以代表"这笔交易的收益率"（比如 pnl_pct，单位：小数，0.0073表示0.73%）。
如果你的CSV里没有现成的pnl列，只有entry/exit价格，本脚本也支持从
price/side/base_amount 之类的字段自己算，具体看 --help。
"""
from __future__ import annotations

import argparse
import numpy as np
import pandas as pd


def block_bootstrap_mean_ci(returns: np.ndarray, block_size: int = 10, n_boot: int = 5000, seed: int = 42):
    """对收益率序列做 block bootstrap，返回均值的置信区间和"均值>0"的经验p值。"""
    rng = np.random.default_rng(seed)
    n = len(returns)
    if n < block_size * 3:
        raise ValueError(f"样本太少(n={n})，block_size={block_size}下至少需要{block_size*3}笔才有意义，建议调小block_size或多攒点交易")

    n_blocks_needed = int(np.ceil(n / block_size))
    starts_pool = np.arange(0, n - block_size + 1)

    boot_means = np.empty(n_boot)
    for b in range(n_boot):
        starts = rng.choice(starts_pool, size=n_blocks_needed, replace=True)
        sample = np.concatenate([returns[s:s + block_size] for s in starts])[:n]
        boot_means[b] = sample.mean()

    obs_mean = returns.mean()
    ci_lo, ci_hi = np.percentile(boot_means, [2.5, 97.5])
    # 经验单侧p值：如果真实均值本来就是0，bootstrap分布里有多少比例落在<=0
    # （用bootstrap分布本身而不是零假设重采样，是一种保守但直观的近似）
    p_le_zero = float((boot_means <= 0).mean())
    return {
        "n_trades": n,
        "block_size": block_size,
        "observed_mean_pct": round(obs_mean * 100, 4),
        "bootstrap_ci_95_pct": [round(ci_lo * 100, 4), round(ci_hi * 100, 4)],
        "p_mean_le_zero": round(p_le_zero, 4),
        "significant_at_5pct": bool(ci_lo > 0),
    }


def load_returns_from_csv(path: str, pnl_col: str = None) -> np.ndarray:
    df = pd.read_csv(path)
    if pnl_col and pnl_col in df.columns:
        return df[pnl_col].dropna().to_numpy(dtype=float)

    # 没有现成pnl列：尝试从 side/price/base_amount 配对 BUY->SELL 算收益率
    # （只是一个尽量通用的兜底，字段名对不上时会报错并提示你手动指定 --pnl-col）
    candidates = [c for c in df.columns if "pnl" in c.lower() or "return" in c.lower() or "income" in c.lower()]
    if candidates:
        print(f"未指定 --pnl-col，自动使用检测到的列: {candidates[0]}")
        return df[candidates[0]].dropna().to_numpy(dtype=float)

    raise ValueError(
        "CSV里找不到明显的收益率列，请用 --pnl-col 指定列名，"
        f"当前列有: {list(df.columns)}"
    )


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("csv_path", help="交易记录CSV路径")
    ap.add_argument("--pnl-col", default=None, help="收益率列名（小数形式，如0.0073代表0.73%）；不指定则自动检测")
    ap.add_argument("--block-size", type=int, default=10, help="每个块包含的交易笔数，默认10")
    ap.add_argument("--n-boot", type=int, default=5000, help="重抽样次数，默认5000")
    args = ap.parse_args()

    returns = load_returns_from_csv(args.csv_path, args.pnl_col)
    result = block_bootstrap_mean_ci(returns, block_size=args.block_size, n_boot=args.n_boot)

    print("\n=== Block Bootstrap 结果 ===")
    for k, v in result.items():
        print(f"  {k}: {v}")

    print()
    if result["significant_at_5pct"]:
        print("结论：95%置信区间下界 > 0，在block bootstrap的意义下是显著正收益。")
        print("但仍然只是这一段回测窗口的结果——按报告里问题10的建议，")
        print("还是需要在一段全新的、独立的样本外数据上复现一次才能真正确认。")
    else:
        print("结论：95%置信区间包含0（或下界<=0），不能确认是显著正收益，")
        print("很可能是噪声或者block_size选得不够大掩盖了自相关——")
        print("可以试试把 --block-size 调大（比如20或30）再看结果是否稳定。")


if __name__ == "__main__":
    main()
