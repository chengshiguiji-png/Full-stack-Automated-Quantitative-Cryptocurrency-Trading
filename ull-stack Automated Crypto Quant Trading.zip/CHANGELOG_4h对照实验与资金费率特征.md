# 本次修改说明：不是继续调15m的参数，而是搭好"一次诚实的4h对照实验"

## 先说清楚这次没做什么

上一轮我们的结论是：15m纯技术指标方向预测在你的三个独立窗口测试里没有跑赢beta的真实
alpha，胜率在下跌市塌到接近随机——这个结论我认，也建议你认。**所以这次没有再去调
threshold_up/take_profit_pct这些15m的参数**，那条路已经被你自己的三窗口测试证伪过了，
继续调参数不会有新答案。这次做的是你自己列的"下一步"里唯一还没做过的两件事：
(1) 换周期到4h是否真的能改善手续费/波动比这个结构性问题，(2) 免费的资金费率数据
有没有增量信息——都是"再做一次诚实测试"，不是"再调一次参数"。

## 发现的一个新bug：4h测试差点从一开始就是假的

检查 `backtest_engine.py` 发现两个问题，如果不修，你即使把 `config.yaml` 的
`market.timeframe` 改成 `4h` 重新跑，实际测的可能还是别的东西：

1. **`get_historical_data()` 以前完全没有把 timeframe 传给K线接口**，不管config怎么改，
   永远请求15m数据。已修复：现在会读 `market.timeframe` 并传给
   `fetch_klines_rest(interval=timeframe, ...)`。

2. **`run()` 内部的 `total_bars` 公式是写死的 `start_index+train_window+100`**（15m下
   约600根，只有6.25天）——但我核对你上传的CSV，交易时间戳实际跨度是32天。这说明你
   本地大概率已经自己改过这处逻辑，我这边保留的版本和你实际在跑的版本有差异。
   已经把 `total_bars` 改成显式参数（不传时保留旧公式，向后兼容），
   `run_backtest.py` 和 `tools/multi_window_backtest.py` 都会按timeframe算出合理的
   根数再传进去，不再依赖那个只够6天的默认值。

## regime检测器：4h和15m现在说的是"同一件事"

`layer7_market_regime.py` 里 `trend48`/`trend192`/`long_trend_bars` 以前是硬编码的
"48根/192根/480根K线"，在15m下正好是12小时/48小时/5天。如果直接照搬到4h，48根K线会变成
8天、192根变成32天——`strong_up`在两个周期下代表完全不是一回事的市场状态，4h的对照实验
就不成立了。

**已修复**：这三个窗口现在按 `market.timeframe` 换算成"以小时为单位的真实时间跨度"，
15m和4h下`strong_up`/`narrow_range`说的都是同一个真实世界的12小时/48小时/5天，
只是采样粒度不同。已经用单元测试验证：15m下算出48/192/480根（跟以前完全一致，不影响
你已有的15m测试结果），4h下正确算出3/12/30根。

**没修、且诚实说明的部分**：`vol20`（20根K线滚动波动率）这类"量级"阈值（0.006/0.012等）
没有做同样的换算——因为这些阈值当初是拿15m真实数据的分布校准出来的，4h下同样20根K线
覆盖的是80小时而不是5小时，同一个数字不再代表同样的"剧烈程度"，但我没有4h的真实历史
数据去重新校准。**如果你要认真测4h，建议先用一段4h真实数据把这几个 `config.regime.vol_*`
阈值重新校准一遍**（跟之前ADX/ER校准是同一个思路），不要直接假设15m的阈值在4h下依然成立。

## 免费的资金费率特征——加了，默认关闭，等你测完再决定要不要留

你问"OKX免费的funding-rate接口够不够用，要不要花钱买Glassnode/CryptoQuant"——
这次直接把OKX免费的资金费率历史接入了特征工程，这样你能实际测出"这个免费数据有没有
增量信息"，而不是靠我猜。

- `layers/layer1_data_collector.py` 新增 `fetch_funding_rate_history()`，免费、不需要key，
  用永续合约（`BTC-USDT-SWAP`）的历史资金费率，用 `merge_asof(direction="backward")`
  按时间对齐到K线上——保证每根K线只用"当时已经公布"的费率，不会有前视偏差。
- `layers/layer4_feature_engineer.py` 新增 `funding_rate` / `funding_rate_zscore` 两个
  可选特征列——**默认完全不加**（`funding_df=None`时跟以前一模一样，64列不变），
  只有 `config.yaml` 的 `regime.use_funding_rate_feature` 设成 `true` 才会启用。
- `train_model.py` 和 `backtest_engine.py` 都接好了，`main_strategy.py`（实盘）**故意没接**——
  等离线训练/回测证明这个特征真的有用了再接实盘，不要没验证就上线。

**怎么判断有没有用**：把 `use_funding_rate_feature` 改成 `true`，重新跑
`train_model.py --all`，对比开启前后的 OOS accuracy——如果只是从50.x%变到50.y%，
那就是没有增量信息，不需要再花钱买更贵的另类数据了；如果有肉眼可见的提升（比如到53%+），
才值得考虑要不要进一步买Glassnode/CryptoQuant那种更贵的数据。**先用免费的测一遍，
比直接花钱订阅更划算**，这也是我上次给你的建议的具体落地。

## `tools/multi_window_backtest.py`：现在会按周期自动算窗口该多长

以前这个工具固定用"一个自然月"做窗口——这对15m是对的（有足够余量），但对4h完全不够
（500根预热K线在4h下要83天，一个月连预热都不够）。现在会按
`start_index+train_window+期望的测试根数` 反推需要多少天：15m下算出来还是31天封顶
（不影响你已经做过的三窗口验证），4h下会自动算出约167天（约5.5个月）并在运行时打印
出来，不是拍脑袋决定、也不会背着你偷偷跑一个太短、测不出东西的假窗口。

## 建议的验证顺序

1. `config.yaml` 的 `market.timeframe` 改成 `4h`，跑一遍 `train_model.py --all`，
   看OOS accuracy是不是真的比15m的50.x%好——这是判断"4h是否有救"最直接的第一道关卡，
   比直接跑回测更快出结果。
2. 如果4h的OOS accuracy也就是50%左右，那基本可以确认：不是周期的问题，是"纯价格技术
   指标预测方向"这条路本身在你这两个品种/这段行情上就是没有信息量，可以彻底放下，
   不用再花时间跑4h的完整回测了。
3. 如果4h的OOS accuracy有实质提升（不是51%这种噪声级别的提升，是53%+这种），
   再跑 `tools/multi_window_backtest.py`（记得先把 `market.timeframe` 保持为4h），
   用同样的多窗口协议验证是否真的能转化成收益。
4. 资金费率特征：改 `use_funding_rate_feature: true`，同样先看OOS accuracy有没有提升，
   再决定要不要往下走、要不要接实盘。

## 追加修复（同一天）：confirmation 字段以前算了从来没人用

排查"DeepSeek/Claude的API是不是没起作用"这个问题时发现：`layer9_signal_generator.py`
算出来的 `confirmation`（融合了 `sentiment_adj`/`micro_adj`）以前只是被塞进signal字典，
`layer10_filter.py`/`layer11_risk_fuse.py`/`main_strategy.py` 全部链路都没有人读过这个字段
——也就是说，就算你打开 `sentiment.enable`/`sentiment.llm_confirmation`，算出来的情绪值
对任何一笔交易都没有产生过任何实际影响，纯粹是算了白算。

**已修复**：`layers/layer10_filter.py` 现在真正读取 `confirmation`，情绪明显跟方向唱反调时
会挡掉这笔交易（阈值 `signal.min_confirmation_for_buy=0.35` / `max_confirmation_for_sell=0.65`，
默认对称、比较宽松）。**情绪关闭时的默认行为完全不受影响**——因为
`sentiment_adj=0` 时 `confirmation` 恒等于0.5，落在[0.35,0.65]区间内，不会挡掉任何本来
合格的信号，已经用单元测试验证过这一点。

这不代表打开情绪/LLM信号就一定能提升收益——只是让这个信号终于有机会真正影响到交易，
之前是完全没有意义的死代码。要不要真的打开、能不能带来提升，还是要走同一套三窗口验证
流程，不能因为"终于接上了"就默认它有用。

这四步都是"看数据说话"，不是"我觉得应该行"——如果4h和资金费率两个都测出来没有实质提升，
那"15m纯技术指标无alpha"这个结论就更加确定了，下一步该认真考虑的是你自己提的
期权/波动率交易这条路，而不是继续在这个方向上找参数。
