﻿from pathlib import Path
import re
import shutil
from datetime import datetime
import py_compile

ROOT = Path.cwd()

MAIN = ROOT / "main_strategy.py"
ML = ROOT / "layers" / "layer6_ml_model.py"
L10 = ROOT / "layers" / "layer10_filter.py"

STAMP = datetime.now().strftime("%Y%m%d_%H%M%S")

for p in (MAIN, ML, L10):
    if not p.exists():
        raise FileNotFoundError(f"文件不存在: {p}")

    backup = p.with_suffix(
        p.suffix + f".bak_{STAMP}"
    )

    shutil.copy2(p, backup)

    print(f"[BACKUP] {backup}")


# ============================================================
# 1. main_strategy.py
# ============================================================

s = MAIN.read_text(encoding="utf-8")


# ------------------------------------------------------------
# 1.1 修复模型输入：
#     Selector之后继续保留DataFrame和feature names
# ------------------------------------------------------------

pattern_prepare = re.compile(
    r'def _prepare_model_input\(df_feat, scaler, selector, feature_cols\):.*?'
    r'\n\n\ndef _load_optional_ai',
    re.S
)

replacement_prepare = r'''def _prepare_model_input(df_feat, scaler, selector, feature_cols):
    """准备模型输入，并尽可能保留选中特征名称。"""

    if feature_cols:
        missing = [
            c for c in feature_cols
            if c not in df_feat.columns
        ]

        if missing:
            raise ValueError(
                f"模型依赖特征缺失: {missing}"
            )

        cols = list(feature_cols)

    else:
        cols = [
            c
            for c in df_feat.columns
            if c not in {"timestamp", "datetime"}
            and pd.api.types.is_numeric_dtype(df_feat[c])
        ]

    row = df_feat[cols].tail(1).copy()

    if row.empty:
        raise ValueError(
            "最新模型输入为空"
        )

    if row.isna().any(axis=1).iloc[0]:
        bad = [
            c
            for c in row.columns
            if pd.isna(row.iloc[0][c])
        ]

        raise ValueError(
            f"最新模型输入包含 NaN: {bad}"
        )

    scaled = scaler.transform(row)

    try:
        support = selector.get_support(
            indices=True
        )

        selected_cols = [
            cols[int(i)]
            for i in support
        ]

    except Exception:
        selected_cols = [
            f"selected_{i}"
            for i in range(scaled.shape[1])
        ]

    selected = selector.transform(
        scaled
    )

    return pd.DataFrame(
        selected,
        columns=selected_cols,
        index=row.index,
    )


def _load_optional_ai'''

s, n = pattern_prepare.subn(
    replacement_prepare,
    s,
    count=1
)

if n != 1:
    raise RuntimeError(
        "无法定位 _prepare_model_input，已停止修改。"
    )


# ------------------------------------------------------------
# 1.2 增加实时缓存
# ------------------------------------------------------------

old_cache = '''    last_bar = {a: None for a in assets}
    daily_pnl = 0.0
    daily_trades = 0
    last_trade_day = datetime.now(timezone.utc).date()
    price_cache = {a: None for a in assets}
'''

new_cache = '''    last_bar = {a: None for a in assets}

    # 同一根15m K线缓存：
    # 不再每30秒重复执行完整64列特征工程
    feature_cache = {
        a: None for a in assets
    }

    atr_cache = {
        a: None for a in assets
    }

    vol_cache = {
        a: 0.0 for a in assets
    }

    regime_cache = {
        a: "unknown" for a in assets
    }

    daily_pnl = 0.0
    daily_trades = 0
    last_trade_day = datetime.now(timezone.utc).date()
    price_cache = {a: None for a in assets}
'''

if old_cache not in s:
    raise RuntimeError(
        "无法定位 last_bar 初始化区域，已停止修改。"
    )

s = s.replace(
    old_cache,
    new_cache,
    1
)


# ------------------------------------------------------------
# 1.3 替换实际的行情→特征准备区
#
# 原逻辑：
# 每30秒：
#   拉300根
#   清洗
#   calculate_features()
#
# 新逻辑：
#   新15m K线 → calculate_features()
#   同一根K线 → 直接使用缓存
# ------------------------------------------------------------

pattern_data = re.compile(
    r'''            for asset in assets:
                try:
                    raw = collector\.fetch_klines_rest\(asset, interval=timeframe, limit=int\(config\.get\("market", \{\}\)\.get\("lookback", 300\)\)\)
                    if not raw:
                        continue
                    df = cleaner\.clean_klines\(raw\)
                    if len\(df\) < 80:
                        continue
                    df_feat = engineer\.calculate_features\(df\)
                    if df_feat\.empty:
                        continue
                    save_klines\(asset, raw\[-200:\]\)

                    ticker = collector\.fetch_ticker\(asset\)
                    current_price = float\(ticker or df\["close"\]\.iloc\[-1\]\)
                    price_cache\[asset\] = current_price
                    bar_ts = int\(df\["timestamp"\]\.iloc\[-1\]\)
                    atr = float\(df_feat\["atr_14"\]\.iloc\[-1\]\) if pd\.notna\(df_feat\["atr_14"\]\.iloc\[-1\]\) else current_price \* 0\.005
                    vol = float\(df_feat\["volatility_20"\]\.iloc\[-1\]\) if pd\.notna\(df_feat\["volatility_20"\]\.iloc\[-1\]\) else 0\.0
                    regime_info = regime_detector\.detect_regime\(df\)
                    regime = regime_info\["market_regime"\]
                    pos = positions\[asset\]
''',
    re.S
)

replacement_data = '''            for asset in assets:
                try:
                    raw = collector.fetch_klines_rest(
                        asset,
                        interval=timeframe,
                        limit=int(
                            config.get(
                                "market",
                                {}
                            ).get(
                                "lookback",
                                300
                            )
                        )
                    )

                    if not raw:
                        continue

                    df = cleaner.clean_klines(raw)

                    if len(df) < 80:
                        continue

                    bar_ts = int(
                        df["timestamp"].iloc[-1]
                    )

                    is_new_bar = (
                        bar_ts != last_bar[asset]
                    )

                    # 实时ticker继续每30秒更新
                    ticker = collector.fetch_ticker(
                        asset
                    )

                    current_price = float(
                        ticker
                        or df["close"].iloc[-1]
                    )

                    price_cache[asset] = current_price


                    # ========================================================
                    # 新15m K线：
                    # 完整计算一次特征
                    # ========================================================

                    if (
                        is_new_bar
                        or feature_cache[asset] is None
                    ):

                        df_feat = (
                            engineer.calculate_features(
                                df
                            )
                        )

                        if df_feat.empty:
                            continue

                        feature_cache[
                            asset
                        ] = df_feat

                        save_klines(
                            asset,
                            raw[-200:]
                        )

                        if (
                            "atr_14"
                            in df_feat.columns
                            and pd.notna(
                                df_feat[
                                    "atr_14"
                                ].iloc[-1]
                            )
                        ):
                            atr = float(
                                df_feat[
                                    "atr_14"
                                ].iloc[-1]
                            )
                        else:
                            atr = (
                                current_price
                                * 0.005
                            )

                        if (
                            "volatility_20"
                            in df_feat.columns
                            and pd.notna(
                                df_feat[
                                    "volatility_20"
                                ].iloc[-1]
                            )
                        ):
                            vol = float(
                                df_feat[
                                    "volatility_20"
                                ].iloc[-1]
                            )
                        else:
                            vol = 0.0

                        try:
                            regime = (
                                regime_detector
                                .detect_regime(df)
                                ["market_regime"]
                            )
                        except Exception:
                            regime = "unknown"

                        atr_cache[
                            asset
                        ] = atr

                        vol_cache[
                            asset
                        ] = vol

                        regime_cache[
                            asset
                        ] = regime


                    # ========================================================
                    # 同一根15m K线：
                    # 不再重复计算特征
                    # ========================================================

                    else:

                        df_feat = (
                            feature_cache[
                                asset
                            ]
                        )

                        atr = float(
                            atr_cache[
                                asset
                            ]
                            or (
                                current_price
                                * 0.005
                            )
                        )

                        vol = float(
                            vol_cache[
                                asset
                            ]
                        )

                        regime = (
                            regime_cache[
                                asset
                            ]
                        )


                    pos = positions[asset]
'''

s, n = pattern_data.subn(
    replacement_data,
    s,
    count=1
)

if n != 1:
    raise RuntimeError(
        "无法定位行情/特征准备区域。"
        "你当前 main_strategy.py 版本与目标版本差异较大，已停止。"
    )


# ------------------------------------------------------------
# 1.4 在 signal 生成之后，把 RSI / BB / strong threshold
#     传递给 Layer10
# ------------------------------------------------------------

needle = '''                    signal = signal_gen.generate_signal(
                        p_up, micro_adj=micro_adj, sentiment_adj=sentiment_adj,
                        symbol=asset, bar_ts=bar_ts,
                    )
'''

replacement_signal = '''                    signal = signal_gen.generate_signal(
                        p_up,
                        micro_adj=micro_adj,
                        sentiment_adj=sentiment_adj,
                        symbol=asset,
                        bar_ts=bar_ts,
                    )

                    # 将市场状态辅助信息传给Layer10，
                    # 用于strong_down中的有限反转例外。
                    signal["p_up"] = p_up

                    signal["rsi_14"] = (
                        float(
                            df_feat[
                                "rsi_14"
                            ].iloc[-1]
                        )
                        if (
                            "rsi_14"
                            in df_feat.columns
                            and pd.notna(
                                df_feat[
                                    "rsi_14"
                                ].iloc[-1]
                            )
                        )
                        else 50.0
                    )

                    signal["bb_pos"] = (
                        float(
                            df_feat[
                                "bb_pos"
                            ].iloc[-1]
                        )
                        if (
                            "bb_pos"
                            in df_feat.columns
                            and pd.notna(
                                df_feat[
                                    "bb_pos"
                                ].iloc[-1]
                            )
                        )
                        else 0.5
                    )

                    signal["strong_threshold_up"] = float(
                        config.get(
                            "signal",
                            {}
                        ).get(
                            "strong_threshold_up",
                            0.68
                        )
                    )
'''

if needle not in s:
    raise RuntimeError(
        "无法定位 signal.generate_signal 区域。"
    )

s = s.replace(
    needle,
    replacement_signal,
    1
)


MAIN.write_text(
    s,
    encoding="utf-8"
)


# ============================================================
# 2. Layer6：
#    消除 LightGBM feature-name warning
# ============================================================

m = ML.read_text(
    encoding="utf-8"
)

if "import pandas as pd" not in m:
    m = m.replace(
        "import numpy as np\n",
        "import numpy as np\nimport pandas as pd\n",
        1
    )

pattern_predict = re.compile(
    r'''    def predict_proba\(self, X\):
.*?
    def predict_components''',
    re.S
)

replacement_predict = '''    @staticmethod
    def _predict_one(model, X):
        # DataFrame优先，保留训练时的feature names。
        if isinstance(X, pd.DataFrame):

            expected = getattr(
                model,
                "feature_names_in_",
                None
            )

            if expected is not None:
                expected = [
                    str(x)
                    for x in expected
                ]

                current = [
                    str(x)
                    for x in X.columns
                ]

                if current != expected:

                    if set(expected).issubset(
                        set(current)
                    ):
                        X2 = X[expected]

                    else:
                        # 极老模型没有可匹配列名，
                        # 最终退回numpy兼容模式。
                        X2 = X.to_numpy()

                else:
                    X2 = X

            else:
                X2 = X

        else:
            X2 = np.asarray(X)

        return model.predict_proba(
            X2
        )[:, 1]


    def predict_proba(self, X):

        available = [
            (name, model)
            for name, model
            in self.models.items()
            if model is not None
        ]

        if not available:
            raise RuntimeError(
                "没有已加载模型；请先训练或加载已验证模型"
            )

        probs = []
        names = []

        for name, model in available:

            try:

                p = self._predict_one(
                    model,
                    X
                )

                probs.append(
                    np.asarray(
                        p,
                        dtype=float
                    )
                )

                names.append(
                    name
                )

            except Exception as exc:

                logger.warning(
                    "模型 %s 预测失败: %s",
                    name,
                    exc
                )

        if not probs:
            raise RuntimeError(
                "所有模型预测均失败"
            )

        weights = self._normalize_weights(
            self.model_weights,
            names
        )

        return np.sum(
            [
                weights[n] * p
                for n, p
                in zip(
                    names,
                    probs
                )
            ],
            axis=0
        )


    def predict_components'''

m, n = pattern_predict.subn(
    replacement_predict,
    m,
    count=1
)

if n != 1:
    raise RuntimeError(
        "无法定位 layer6 predict_proba。"
    )


pattern_components = re.compile(
    r'''    def predict_components\(self, X\):
.*?
        return result
''',
    re.S
)

replacement_components = '''    def predict_components(self, X):
        result = {}

        for name, model in self.models.items():

            if model is None:
                continue

            try:
                result[name] = float(
                    self._predict_one(
                        model,
                        X
                    )[0]
                )

            except Exception:
                continue

        return result
'''

m, n = pattern_components.subn(
    replacement_components,
    m,
    count=1
)

if n != 1:
    raise RuntimeError(
        "无法定位 predict_components。"
    )

ML.write_text(
    m,
    encoding="utf-8"
)


# ============================================================
# 3. Layer10：
#    strong_down 不再100%封杀BUY
# ============================================================

l = L10.read_text(
    encoding="utf-8"
)

old_regime = '''        if direction == "BUY" and market_regime in {"strong_down", "extreme_liquidation"}:
            passed = False
            reasons.append(f"市场状态 {market_regime} 禁止追多")
'''

new_regime = '''        # strong_down不再一刀切。
        #
        # 普通BUY：
        #   继续拒绝
        #
        # 逆势反转：
        #   只有高模型概率 + 明显超卖才允许
        #
        # extreme_liquidation：
        #   始终禁止新增多头
        #
        if direction == "BUY" and market_regime == "strong_down":

            strong_threshold = float(
                signal.get(
                    "strong_threshold_up",
                    0.68
                )
            )

            rsi_14 = float(
                signal.get(
                    "rsi_14",
                    50.0
                )
            )

            bb_pos = float(
                signal.get(
                    "bb_pos",
                    0.5
                )
            )

            # 强逆势反转条件
            countertrend_ok = (
                p_up >= strong_threshold
                and rsi_14 <= 38.0
                and bb_pos <= 0.25
            )

            if not countertrend_ok:

                passed = False

                reasons.append(
                    "strong_down禁止普通追多: "
                    f"p_up={p_up:.3f}, "
                    f"rsi={rsi_14:.1f}, "
                    f"bb={bb_pos:.3f}"
                )

        if direction == "BUY" and market_regime == "extreme_liquidation":

            passed = False

            reasons.append(
                "极端清算状态下禁止新增多头"
            )
'''

if old_regime not in l:
    raise RuntimeError(
        "无法定位 Layer10 strong_down 规则。"
    )

l = l.replace(
    old_regime,
    new_regime,
    1
)

L10.write_text(
    l,
    encoding="utf-8"
)


# ============================================================
# 4. 最终语法检查
# ============================================================

for p in (
    MAIN,
    ML,
    L10,
):

    py_compile.compile(
        str(p),
        doraise=True
    )

    print(
        f"[OK] syntax: {p}"
    )


print()
print("=" * 72)
print("FINAL REALTIME FIX SUCCESS")
print("=" * 72)
print()
print("已经完成：")
print()
print("1. 同一根15m K线不再重复计算64列特征")
print("2. 同一根15m K线不再重复运行完整ML")
print("3. 持仓期间依然每30秒监控ticker")
print("4. Feature/ATR/Volatility/Regime加入缓存")
print("5. LightGBM保持DataFrame feature names")
print("6. 修复feature-name warning路径")
print("7. strong_down不再无条件封杀BUY")
print("8. strong_down仅允许高概率+超卖反转")
print("9. extreme_liquidation继续禁止新增多头")
print()
print("旧文件已经自动备份。")
print()
