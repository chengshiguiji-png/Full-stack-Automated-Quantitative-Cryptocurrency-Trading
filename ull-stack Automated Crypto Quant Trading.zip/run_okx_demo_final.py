﻿from pathlib import Path
import ast
import py_compile
import shutil
from datetime import datetime

P = Path("main_strategy.py")

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = P.with_name(
    f"main_strategy.py.before_okx_runtime_{stamp}.bak"
)
shutil.copy2(P, backup)

source = P.read_text(encoding="utf-8-sig")

marker = "# FINAL OKX ENV OVERRIDE"

if marker not in source:

    tree = ast.parse(source)

    target = None

    for node in tree.body:
        if (
            isinstance(node, ast.FunctionDef)
            and node.name == "load_config"
        ):
            target = node
            break

    if target is None:
        raise RuntimeError("找不到 load_config()")

    lines = source.splitlines(keepends=True)

    body = "".join(
        lines[target.lineno - 1:target.end_lineno]
    )

    needle = "return apply_env_overrides(config)"

    if needle not in body:
        raise RuntimeError(
            "无法定位 load_config() 中的配置返回位置"
        )

    replacement = """config = apply_env_overrides(config)

    # FINAL OKX ENV OVERRIDE
    okx = config.setdefault("exchange", {}).setdefault("okx", {})

    for key, env_name in (
        ("api_key", "OKX_API_KEY"),
        ("api_secret", "OKX_API_SECRET"),
        ("passphrase", "OKX_API_PASSPHRASE"),
        ("flag", "OKX_FLAG"),
        ("instrument_type", "OKX_INSTRUMENT_TYPE"),
    ):
        value = os.getenv(env_name)
        if value is not None and str(value).strip() != "":
            okx[key] = str(value).strip()

    demo = os.getenv("OKX_DEMO_TRADING")
    if demo is not None:
        if demo.strip().lower() in {"1", "true", "yes", "on"}:
            config["mode"] = "demo"

    dry = os.getenv("OKX_DRY_RUN")
    if dry is not None:
        config.setdefault("execution", {})["dry_run"] = (
            dry.strip().lower()
            in {"1", "true", "yes", "on"}
        )

    live = os.getenv(
        "LIVE_TRADING_ENABLED",
        "false"
    ).strip().lower()

    if live not in {"1", "true", "yes", "on"}:
        config["mode"] = "demo"
        okx["flag"] = "1"

    return config"""

    body = body.replace(
        needle,
        replacement,
        1
    )

    lines[
        target.lineno - 1:
        target.end_lineno
    ] = [body]

    P.write_text(
        "".join(lines),
        encoding="utf-8"
    )

py_compile.compile(
    str(P),
    doraise=True
)

from main_strategy import load_config

cfg = load_config()
okx = cfg.get("exchange", {}).get("okx", {})
execution = cfg.get("execution", {})

checks = {
    "api_key": bool(okx.get("api_key")),
    "api_secret": bool(okx.get("api_secret")),
    "passphrase": bool(okx.get("passphrase")),
}

print()
print("=" * 72)
print("OKX FINAL RUNTIME CHECK")
print("=" * 72)
print("API_KEY       =", checks["api_key"])
print("API_SECRET    =", checks["api_secret"])
print("PASSPHRASE    =", checks["passphrase"])
print("FLAG          =", okx.get("flag"))
print("INSTRUMENT    =", okx.get("instrument_type"))
print("DRY_RUN       =", execution.get("dry_run"))
print("MODE          =", cfg.get("mode"))
print("=" * 72)

if not all(checks.values()):
    raise RuntimeError(
        "OKX有效配置仍不完整，停止启动主程序"
    )

if str(okx.get("flag")) != "1":
    raise RuntimeError(
        "OKX_FLAG不是1，停止启动"
    )

if execution.get("dry_run") is not False:
    raise RuntimeError(
        "execution.dry_run不是False，停止启动"
    )

print("OKX FINAL CONFIG = PASS")
print("BACKUP =", backup)
print()
