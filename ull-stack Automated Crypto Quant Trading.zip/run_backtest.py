﻿# -*- coding: utf-8 -*-
from pathlib import Path
import yaml
from backtest_engine import RollingBacktest

cfg = yaml.safe_load(Path("config.yaml").read_text(encoding="utf-8"))

for symbol in ["BTC-USDT", "ETH-USDT", "SOL-USDT"]:
    print()
    print("=" * 78)
    print(f"回测 {symbol}")
    print("=" * 78)
    try:
        engine = RollingBacktest(cfg, symbol=symbol)
        # run() 内部末尾已经会调用一次 _report_performance()（打印报告 + 写 CSV），
        # 这里以前又手动调用了一次，导致报告打印两遍、CSV 被多写一次——已去掉这行多余调用。
        # 2026-09 修复：以前不传 total_bars 时，run() 内部默认公式只会拉600根K线
        # （15m下约6.25天）——如果你想测一整个月，光靠默认值是不够的，之前能测出
        # 32天的结果，说明这行调用本地已经被改过。这里显式给一个按1个月估算的
        # total_bars，跟 tools/multi_window_backtest.py 用的是同一套换算逻辑，
        # 想测更长/更短，直接改这个数字。
        timeframe = str(cfg.get("market", {}).get("timeframe", "15m"))
        bars_per_day = {"1m": 1440, "5m": 288, "15m": 96, "30m": 48, "1h": 24, "4h": 6, "1d": 1}.get(timeframe, 96)
        one_month_bars = 300 + 200 + 31 * bars_per_day
        engine.run(train_window=200, step=1, start_index=300, total_bars=one_month_bars)
    except Exception as exc:
        import traceback
        print(f"[FAIL] {symbol}: {exc}")
        traceback.print_exc()
