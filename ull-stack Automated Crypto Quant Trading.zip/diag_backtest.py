﻿# -*- coding: utf-8 -*-
"""诊断 BacktestEngine 为什么零交易"""
from pathlib import Path
import yaml
from layers.layer1_data_collector import DataCollector
from layers.layer3_data_clean import DataCleaner
from layers.layer4_feature_engineer import FeatureEngineer
from layers.layer6_ml_model import MLModelEnsemble
from layers.layer7_market_regime import MarketRegimeDetector
from layers.layer8_microstructure import MicrostructureAnalyzer
from layers.layer9_signal_generator import SignalGenerator
from layers.layer10_filter import EntryFilter
from layers.layer11_risk_fuse import RiskFuse
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_classif
import pandas as pd, numpy as np

cfg = yaml.safe_load(Path("config.yaml").read_text(encoding="utf-8"))

# 拉数据
raw = DataCollector(cfg.get("market_data", {})).fetch_klines_rest(
    symbol="BTC-USDT", interval="15m", limit=600
)
df = DataCleaner({"require_confirmed": True}).clean_klines(raw)
feat = FeatureEngineer(cfg.get("features", {})).calculate_features(df)
feature_cols = [c for c in feat.columns if c not in ("timestamp","datetime") and pd.api.types.is_numeric_dtype(feat[c])]
feat = feat.sort_values("timestamp").reset_index(drop=True)

print(f"K线 {len(df)} 行，特征 {len(feature_cols)} 列")

sg = SignalGenerator(cfg.get("signal", {}))
ef = EntryFilter(cfg.get("signal", {}))
rf = RiskFuse(cfg.get("risk", {}))
reg = MarketRegimeDetector(cfg.get("model_weight", {}))
micro = MicrostructureAnalyzer()

# 滑窗模拟
stats = {"bars": 0, "p_up_list": [], "direction_count": {}, "filter_reject": {}, "risk_reject": {}, "would_buy": 0}

for i in range(300, len(feat) - 3, 20):   # 每20根一步，加速
    train_end = i - 1
    if train_end < 200: continue

    X_train = feat[feature_cols].iloc[:train_end].dropna()
    y_train = (feat["close"].iloc[:train_end].shift(-3) > feat["close"].iloc[:train_end]).astype(int).dropna()
    common = X_train.index.intersection(y_train.index)
    X_train = X_train.loc[common]; y_train = y_train.loc[common]
    if len(X_train) < 50 or y_train.nunique() < 2: continue

    sc = StandardScaler().fit(X_train)
    Xs = sc.transform(X_train)
    sel = SelectKBest(f_classif, k=min(20, Xs.shape[1])).fit(Xs, y_train)
    Xsel = sel.transform(Xs)
    mdl = MLModelEnsemble()
    mdl.train(Xsel, y_train.values)

    cur = feat[feature_cols].iloc[i:i+1]
    if cur.isnull().any().any(): continue
    p_up = float(mdl.predict_proba(sel.transform(sc.transform(cur)))[0])
    stats["p_up_list"].append(p_up)

    cur_price = float(feat["close"].iloc[i])
    regime = reg.detect_regime(feat.iloc[:i+1].copy())["market_regime"]
    signal = sg.generate_signal(p_up, 0.0, 0.0, "BTC-USDT")
    d = signal["direction"]
    stats["direction_count"][d] = stats["direction_count"].get(d, 0) + 1

    if d == "HOLD":
        continue

    portfolio = {"total_value": 100000, "positions": {}, "today_pnl": 0}
    fr = ef.check(signal, regime, 100000, 1000)
    if not fr["passed"]:
        for r in fr.get("reasons", []):
            stats["filter_reject"][r] = stats["filter_reject"].get(r, 0) + 1
        continue

    order = {"symbol": "BTC-USDT", "side": d, "size": 10, "leverage": 1, "order_type": "market"}
    rr = rf.check(order, portfolio, {"volatility": 0.01, "current_price": cur_price, "prices": {"BTC-USDT": cur_price}})
    if not rr["allowed"]:
        for r in rr.get("reasons", []):
            stats["risk_reject"][r] = stats["risk_reject"].get(r, 0) + 1
        continue

    stats["would_buy"] += 1

print("=" * 78)
print(f"总滑窗次数            : {len(stats['p_up_list'])}")
if stats["p_up_list"]:
    arr = np.array(stats["p_up_list"])
    print(f"p_up 范围             : {arr.min():.4f} ~ {arr.max():.4f}")
    print(f"p_up 均值             : {arr.mean():.4f}")
    print(f"p_up >= 0.50 比例     : {(arr>=0.50).mean()*100:.1f}%")
    print(f"p_up >= 0.55 比例     : {(arr>=0.55).mean()*100:.1f}%")
    print(f"p_up >= 0.60 比例     : {(arr>=0.60).mean()*100:.1f}%")
print(f"方向分布              : {stats['direction_count']}")
print(f"EntryFilter 拒绝原因  : {stats['filter_reject']}")
print(f"RiskFuse 拒绝原因     : {stats['risk_reject']}")
print(f"通过全部过滤的次数    : {stats['would_buy']}")
print("=" * 78)
