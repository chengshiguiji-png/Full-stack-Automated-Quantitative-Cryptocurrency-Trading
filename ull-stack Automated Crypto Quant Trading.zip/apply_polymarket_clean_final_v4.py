﻿from pathlib import Path
import ast
import shutil
import py_compile
from datetime import datetime

ROOT = Path.cwd()
P = ROOT / "layers" / "polymarket_clob.py"

if not P.exists():
    raise RuntimeError(f"找不到 {P}")

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup_dir = ROOT / "_FINAL_BACKUP"
backup_dir.mkdir(exist_ok=True)

backup = (
    backup_dir
    / f"polymarket_clob_BEFORE_CLEAN_FINAL_{stamp}.py"
)

shutil.copy2(P, backup)

print("[BACKUP]", backup)

source = P.read_text(
    encoding="utf-8-sig"
)

# ============================================================
# 1. 清掉所有之前追加到文件末尾的 V1/V2/V3 / dynamic patch
# ============================================================

markers = [
    "# FINAL_PM_REST_FALLBACK_V1",
    "# FINAL_PM_STABILITY_V2",
    "# FINAL_PM_STABILITY_V3",
    "_final_discover_btc_updown",
    "PolymarketCLOB.discover_btc_updown =",
    "PolymarketCLOB.start =",
    "PolymarketCLOB.stop =",
    "PolymarketCLOB.health_snapshot =",
    "# FINAL POLYMARKET BTC 15M DISCOVERY",
]

cut_positions = []

for marker in markers:

    pos = source.find(marker)

    if pos >= 0:
        cut_positions.append(pos)

if cut_positions:

    cut = min(cut_positions)

    # 从第一个旧补丁开始全部删除
    source = source[:cut].rstrip() + "\n"

    print(
        "[CLEAN] removed old appended Polymarket patches"
    )

# ============================================================
# 2. 确保 imports
# ============================================================

if "import re\n" not in source:

    source = source.replace(
        "import os\n",
        "import os\nimport re\n",
        1,
    )

# ============================================================
# 3. 确保 event slug URL
# ============================================================

if "GAMMA_EVENT_SLUG_URL" not in source:

    marker = (
        '    GAMMA_URL = "https://gamma-api.polymarket.com/markets"\n'
    )

    if marker not in source:

        raise RuntimeError(
            "找不到 GAMMA_URL"
        )

    source = source.replace(
        marker,
        marker
        + (
            '    GAMMA_EVENT_SLUG_URL = '
            '"https://gamma-api.polymarket.com/events/slug/{slug}"\n'
        ),
        1,
    )

# ============================================================
# 4. AST helper
# ============================================================

def find_class(tree):
    for node in tree.body:

        if (
            isinstance(node, ast.ClassDef)
            and node.name == "PolymarketCLOB"
        ):
            return node

    raise RuntimeError(
        "找不到 class PolymarketCLOB"
    )


def find_method(cls, name):

    for node in cls.body:

        if (
            isinstance(
                node,
                (
                    ast.FunctionDef,
                    ast.AsyncFunctionDef,
                ),
            )
            and
            node.name == name
        ):

            return node

    raise RuntimeError(
        f"PolymarketCLOB中找不到方法: {name}"
    )


# ============================================================
# 5. 新 discover_btc_updown
# ============================================================

discover = r'''
def discover_btc_updown(
    self,
    window="15m",
):
    """
    最终BTC 15m市场发现。

    规则：
    1. 当前15m窗口来自 slug:
       btc-updown-15m-<unix_timestamp>
    2. 不使用 market.startDate 判断预测窗口。
    3. 当前窗口优先直接 event-by-slug。
    4. public-search / markets 仅作fallback。
    """

    now = time.time()

    # --------------------------------------------------------
    # cache
    # --------------------------------------------------------

    with self._lock:

        cached = (
            self._market_cache.get(
                "market"
            )
        )

        cached_ts = float(
            self._market_cache.get(
                "ts",
                0.0,
            )
        )

    if (
        cached
        and
        now
        -
        cached_ts
        <
        self.refresh_sec
    ):

        slug = str(
            cached.get(
                "slug",
                "",
            )
        )

        if re.search(
            r"btc-updown-15m-\d{10}$",
            slug.lower(),
        ):

            match = re.search(
                r"btc-updown-15m-(\d{10})$",
                slug.lower(),
            )

            start_ts = float(
                match.group(1)
            )

            if (
                start_ts
                <= now
                <
                start_ts + 900.0
            ):

                return cached

    bucket = (
        int(now)
        // 900
    ) * 900

    def normalize_market(
        market,
        event=None,
        slug_hint="",
    ):

        if not isinstance(
            market,
            dict,
        ):
            return None

        event = (
            event
            if isinstance(
                event,
                dict,
            )
            else {}
        )

        slug = str(
            market.get(
                "slug"
            )
            or event.get(
                "slug"
            )
            or slug_hint
            or ""
        ).lower()

        match = re.search(
            r"btc-updown-15m-(\d{10})$",
            slug,
        )

        if not match:

            return None

        start_ts = float(
            match.group(1)
        )

        end_ts = (
            start_ts
            + 900.0
        )

        if not (
            start_ts
            <= now
            <
            end_ts
        ):

            return None

        if market.get(
            "closed"
        ) is True:

            return None

        if market.get(
            "archived"
        ) is True:

            return None

        token_raw = (
            market.get(
                "clobTokenIds"
            )
            or
            market.get(
                "clob_token_ids"
            )
        )

        try:

            token_raw = (
                self._jsonish(
                    token_raw
                )
            )

        except Exception:
            pass

        if not isinstance(
            token_raw,
            list,
        ):

            return None

        token_ids = [
            str(x)
            for x in token_raw
            if x
        ]

        if len(
            token_ids
        ) < 2:

            return None

        outcomes = (
            market.get(
                "outcomes"
            )
        )

        try:

            outcomes = (
                self._jsonish(
                    outcomes
                )
            )

        except Exception:
            pass

        if not isinstance(
            outcomes,
            list,
        ):

            outcomes = [
                "Up",
                "Down",
            ]

        outcomes = [
            str(x)
            for x in outcomes
        ]

        ordered_tokens = (
            token_ids[:2]
        )

        lowered = [
            x.lower()
            for x in outcomes
        ]

        up_index = next(
            (
                i
                for i, x
                in enumerate(
                    lowered
                )
                if x
                in {
                    "up",
                    "yes",
                }
            ),
            None,
        )

        down_index = next(
            (
                i
                for i, x
                in enumerate(
                    lowered
                )
                if x
                in {
                    "down",
                    "no",
                }
            ),
            None,
        )

        if (
            up_index is not None
            and
            down_index is not None
            and
            up_index
            < len(token_ids)
            and
            down_index
            < len(token_ids)
        ):

            ordered_tokens = [
                token_ids[
                    up_index
                ],
                token_ids[
                    down_index
                ],
            ]

        start_dt = (
            dt.datetime.fromtimestamp(
                start_ts,
                tz=dt.timezone.utc,
            )
        )

        end_dt = (
            dt.datetime.fromtimestamp(
                end_ts,
                tz=dt.timezone.utc,
            )
        )

        return {
            "condition_id":
                (
                    market.get(
                        "conditionId"
                    )
                    or
                    market.get(
                        "condition_id"
                    )
                ),

            "market_id":
                market.get(
                    "id"
                ),

            "event_id":
                event.get(
                    "id"
                ),

            "slug":
                market.get(
                    "slug"
                )
                or
                event.get(
                    "slug"
                )
                or
                slug,

            "question":
                market.get(
                    "question"
                )
                or
                event.get(
                    "title"
                )
                or
                "Bitcoin Up or Down",

            "start_time":
                start_dt.isoformat(),

            "end_time":
                end_dt.isoformat(),

            "window_start_ts":
                start_ts,

            "window_end_ts":
                end_ts,

            "token_ids":
                ordered_tokens,

            "outcomes":
                outcomes[:2],

            "duration_sec":
                900.0,

            "volume":
                float(
                    market.get(
                        "volumeNum"
                    )
                    or
                    market.get(
                        "volume"
                    )
                    or
                    0.0
                ),

            "raw":
                market,
        }

    def accept(
        result,
        via,
    ):

        if not result:

            return None

        with self._lock:

            self._market_cache = {
                "ts":
                    now,
                "market":
                    result,
            }

        logger.success(
            "Polymarket LIVE BTC 15m discovered via {}: {} | start={} | end={} | tokens={}",
            via,
            result.get(
                "slug"
            ),
            result.get(
                "start_time"
            ),
            result.get(
                "end_time"
            ),
            len(
                result.get(
                    "token_ids",
                    [],
                )
            ),
        )

        return result

    # ========================================================
    # A. 当前15m event slug
    # ========================================================

    for start_ts in (
        bucket,
        bucket - 900,
        bucket + 900,
    ):

        slug = (
            f"btc-updown-15m-{start_ts}"
        )

        try:

            payload = (
                self._get_json(
                    self.GAMMA_EVENT_SLUG_URL.format(
                        slug=slug
                    )
                )
            )

            if not isinstance(
                payload,
                dict,
            ):

                continue

            markets = (
                payload.get(
                    "markets"
                )
                or
                []
            )

            if not isinstance(
                markets,
                list,
            ):

                markets = []

            if (
                not markets
                and
                (
                    payload.get(
                        "clobTokenIds"
                    )
                    or
                    payload.get(
                        "clob_token_ids"
                    )
                )
            ):

                markets = [
                    payload
                ]

            for market in markets:

                result = normalize_market(
                    market,
                    payload,
                    slug,
                )

                if result:

                    return accept(
                        result,
                        "event-slug",
                    )

        except Exception as exc:

            logger.debug(
                "Polymarket event-slug {} failed: {}",
                slug,
                exc,
            )

    # ========================================================
    # B. public-search
    # ========================================================

    search_url = (
        "https://gamma-api.polymarket.com/public-search"
    )

    for query in (
        "Bitcoin Up or Down",
        "BTC Up or Down",
    ):

        try:

            payload = (
                self._get_json(
                    search_url,
                    {
                        "q":
                            query,
                        "limit_per_type":
                            100,
                        "page":
                            1,
                    },
                )
            )

            stack = [
                payload
            ]

            seen = set()

            while stack:

                obj = stack.pop()

                if isinstance(
                    obj,
                    dict,
                ):

                    token_present = (
                        "clobTokenIds"
                        in obj
                        or
                        "clob_token_ids"
                        in obj
                    )

                    if token_present:

                        key = id(
                            obj
                        )

                        if key not in seen:

                            seen.add(
                                key
                            )

                            result = (
                                normalize_market(
                                    obj
                                )
                            )

                            if result:

                                return accept(
                                    result,
                                    "public-search",
                                )

                    for value in obj.values():

                        if isinstance(
                            value,
                            (
                                dict,
                                list,
                            ),
                        ):

                            stack.append(
                                value
                            )

                elif isinstance(
                    obj,
                    list,
                ):

                    stack.extend(
                        obj
                    )

        except Exception as exc:

            logger.debug(
                "Polymarket public-search failed {}: {}",
                query,
                exc,
            )

    # ========================================================
    # C. /markets fallback
    # ========================================================

    try:

        payload = (
            self._get_json(
                self.GAMMA_URL,
                {
                    "closed":
                        "false",
                    "active":
                        "true",
                    "limit":
                        100,
                    "order":
                        "endDate",
                    "ascending":
                        "false",
                },
            )
        )

        if isinstance(
            payload,
            list,
        ):

            for market in payload:

                result = normalize_market(
                    market
                )

                if result:

                    return accept(
                        result,
                        "markets",
                    )

    except Exception as exc:

        logger.debug(
            "Polymarket /markets fallback failed: {}",
            exc,
        )

    logger.warning(
        "Polymarket: API reachable but current BTC 15m market not found"
    )

    return None
'''


# ============================================================
# 6. REST fallback class method
# ============================================================

rest_loop = r'''
def _rest_fallback_loop(
    self
):
    """
    WSS异常时每5秒REST /book兜底。
    启动前8秒不给fallback制造噪声。
    """

    startup = time.time()

    while not self._stop.wait(
        1.0
    ):

        now = time.time()

        if (
            now - startup
            < 8.0
        ):

            continue

        with self._lock:

            tokens = list(
                self._subscribed_assets
            )

            connected = bool(
                self._connected
            )

            last_event = float(
                self._last_market_event
                or
                0.0
            )

        if not tokens:
            continue

        event_age = (
            now - last_event
            if last_event > 0
            else float("inf")
        )

        wss_healthy = (
            connected
            and
            event_age <= 15.0
        )

        if wss_healthy:

            continue

        logger.warning(
            "Polymarket WSS stale/disconnected "
            "(connected={}, event_age={:.1f}s); "
            "REST /book fallback active",
            connected,
            event_age,
        )

        try:

            ok = self.initial_sync(
                tokens
            )

            logger.info(
                "Polymarket REST fallback sync: {}/{} books",
                ok,
                len(tokens),
            )

        except Exception as exc:

            logger.warning(
                "Polymarket REST fallback failed: {}",
                exc,
            )
'''


# ============================================================
# 7. Watchdog
# ============================================================

watchdog = r'''
def _watchdog(
    self
):

    while not self._stop.wait(
        5.0
    ):

        with self._lock:

            ws = self._ws

            connected = (
                self._connected
            )

            last_event = float(
                self._last_market_event
                or
                0.0
            )

        if not (
            connected
            and
            ws is not None
        ):

            continue

        if last_event <= 0:

            continue

        event_age = (
            time.time()
            -
            last_event
        )

        if event_age > 30.0:

            logger.warning(
                "Polymarket CLOB WSS market-event stale "
                "({:.1f}s); forcing reconnect",
                event_age,
            )

            try:

                ws.close()

            except Exception:

                pass
'''


# ============================================================
# 8. Health
# ============================================================

health = r'''
def health_snapshot(
    self,
    max_book_age_sec=30.0,
):

    now = time.time()

    status = (
        self.check_status()
    )

    with self._lock:

        connected = bool(
            self._connected
        )

        last_ws = float(
            self._last_ws_activity
            or
            0.0
        )

        last_event = float(
            self._last_market_event
            or
            0.0
        )

        last_clob = float(
            self._last_clob_ok
            or
            0.0
        )

        books = {
            token:
                book.timestamp
            for token, book
            in self.books.items()
        }

    # 不允许产生负 age
    ws_age = (
        max(
            0.0,
            now - last_ws,
        )
        if last_ws > 0
        else None
    )

    event_age = (
        max(
            0.0,
            now - last_event,
        )
        if last_event > 0
        else None
    )

    rest_age = (
        max(
            0.0,
            now - last_clob,
        )
        if last_clob > 0
        else None
    )

    book_ages = {
        token:
            max(
                0.0,
                now - ts,
            )
        for token, ts
        in books.items()
    }

    books_fresh = (
        bool(book_ages)
        and
        all(
            age
            <= float(
                max_book_age_sec
            )
            for age
            in book_ages.values()
        )
    )

    status_ok = bool(
        status.get(
            "ok",
            False,
        )
    )

    wss_stream_fresh = bool(
        connected
        and
        event_age is not None
        and
        event_age <= 15.0
    )

    rest_fallback_fresh = bool(
        rest_age is not None
        and
        rest_age <= 10.0
    )

    if wss_stream_fresh:

        transport = "WSS"

    elif (
        rest_fallback_fresh
        and
        books_fresh
    ):

        transport = "REST_FALLBACK"

    else:

        transport = "STALE"

    fresh = bool(
        status_ok
        and
        books_fresh
        and
        (
            wss_stream_fresh
            or
            rest_fallback_fresh
        )
    )

    return {
        "proxy":
            self._masked_proxy(),

        "ws_connected":
            connected,

        "ws_activity_age_sec":
            ws_age,

        "last_market_event_age_sec":
            event_age,

        "rest_last_ok_age_sec":
            rest_age,

        "book_ages_sec":
            book_ages,

        "books_fresh":
            books_fresh,

        "status":
            status,

        "subscribed_assets":
            list(
                self._subscribed_assets
            ),

        "last_ws_error":
            self._last_ws_error,

        "wss_stream_fresh":
            wss_stream_fresh,

        "rest_fallback_fresh":
            rest_fallback_fresh,

        "transport":
            transport,

        "fresh":
            fresh,
    }
'''


# ============================================================
# 9. Start
# ============================================================

start = r'''
def start(
    self,
    token_ids,
):

    tokens = [
        str(x)
        for x in token_ids
        if x
    ]

    if not tokens:

        raise ValueError(
            "token_ids cannot be empty"
        )

    with self._lock:

        old_tokens = list(
            self._subscribed_assets
        )

        changed = (
            old_tokens != tokens
        )

        self._subscribed_assets = (
            tokens
        )

        self._stop.clear()

        ws = self._ws

        if changed:

            self.books = {
                k: v
                for k, v
                in self.books.items()
                if k in tokens
            }

            self.last_trades = {
                k: v
                for k, v
                in self.last_trades.items()
                if k in tokens
            }

    if (
        changed
        and
        old_tokens
        and
        ws is not None
    ):

        try:

            ws.close()

        except Exception:
            pass

    # REST first
    self.initial_sync(
        tokens
    )

    # WSS
    if not (
        self._ws_thread
        and
        self._ws_thread.is_alive()
    ):

        self._ws_thread = (
            threading.Thread(
                target=self._ws_loop,
                name="polymarket-clob-ws",
                daemon=True,
            )
        )

        self._ws_thread.start()

    # watchdog
    if not (
        self._watchdog_thread
        and
        self._watchdog_thread.is_alive()
    ):

        self._watchdog_thread = (
            threading.Thread(
                target=self._watchdog,
                name="polymarket-clob-watchdog",
                daemon=True,
            )
        )

        self._watchdog_thread.start()

    # REST fallback
    thread = getattr(
        self,
        "_rest_fallback_thread",
        None,
    )

    if not (
        thread
        and
        thread.is_alive()
    ):

        self._rest_fallback_thread = (
            threading.Thread(
                target=self._rest_fallback_loop,
                name="polymarket-rest-fallback",
                daemon=True,
            )
        )

        self._rest_fallback_thread.start()
'''


# ============================================================
# 10. Stop
# ============================================================

stop = r'''
def stop(
    self
):

    self._stop.set()

    with self._lock:

        ws = self._ws

    if ws is not None:

        try:

            ws.close()

        except Exception:
            pass

    self._connected = False
    self._ws = None
'''


# ============================================================
# 11. 替换 class 方法
# ============================================================

tree = ast.parse(
    source
)

cls = find_class(
    tree
)

methods = {
    "discover_btc_updown":
        discover,

    "_watchdog":
        watchdog,

    "health_snapshot":
        health,

    "start":
        start,

    "stop":
        stop,
}

# fallback不存在，所以稍后插入
existing = {
    node.name:
        node
    for node in cls.body
    if isinstance(
        node,
        (
            ast.FunctionDef,
            ast.AsyncFunctionDef,
        ),
    )
}

lines = source.splitlines(
    keepends=True
)

# 从后往前替换，避免行号变化
targets = []

for name, code in methods.items():

    node = (
        existing.get(name)
        or
        find_method(
            cls,
            name,
        )
    )

    targets.append(
        (
            node.lineno,
            node.end_lineno,
            code,
        )
    )

targets.sort(
    reverse=True
)

for start_line, end_line, code in targets:

    lines[
        start_line - 1:
        end_line
    ] = [
        code.strip()
        + "\n"
    ]

source = "".join(
    lines
)

# ============================================================
# 12. 重新解析并插入 fallback method
# ============================================================

tree = ast.parse(
    source
)

cls = find_class(
    tree
)

if not any(
    isinstance(
        node,
        (
            ast.FunctionDef,
            ast.AsyncFunctionDef,
        ),
    )
    and
    node.name
    == "_rest_fallback_loop"
    for node in cls.body
):

    lines = source.splitlines(
        keepends=True
    )

    cls = find_class(
        ast.parse(
            source
        )
    )

    insert_index = (
        cls.end_lineno - 1
    )

    lines.insert(
        insert_index,
        rest_loop.strip()
        + "\n",
    )

    source = "".join(
        lines
    )

# ============================================================
# 13. 写入并编译
# ============================================================

P.write_text(
    source,
    encoding="utf-8"
)

py_compile.compile(
    str(P),
    doraise=True
)

# ============================================================
# 14. 最终AST结构验证
# ============================================================

verify = P.read_text(
    encoding="utf-8-sig"
)

tree = ast.parse(
    verify
)

cls = find_class(
    tree
)

required = {
    "discover_btc_updown",
    "_rest_fallback_loop",
    "_watchdog",
    "health_snapshot",
    "start",
    "stop",
}

present = {
    node.name
    for node in cls.body
    if isinstance(
        node,
        (
            ast.FunctionDef,
            ast.AsyncFunctionDef,
        ),
    )
}

missing = (
    required - present
)

if missing:

    raise RuntimeError(
        "缺少最终方法: "
        + ", ".join(
            sorted(
                missing
            )
        )
    )

print()
print("=" * 72)
print("POLYMARKET CLEAN FINAL V4 SUCCESS")
print("=" * 72)
print("Old stacked patches : REMOVED")
print("discover             : CLASS METHOD")
print("WSS                   : PRIMARY")
print("REST fallback         : 5s")
print("Startup grace         : 8s")
print("WSS stale trigger     : 15s")
print("Watchdog              : 30s")
print("Health transport      : WSS / REST_FALLBACK / STALE")
print("Negative age guard    : ENABLED")
print("Syntax                : PASS")
print("Backup                :", backup)
print("=" * 72)
