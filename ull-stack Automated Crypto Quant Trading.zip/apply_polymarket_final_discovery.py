﻿from pathlib import Path
import re
import shutil
import py_compile
from datetime import datetime

ROOT = Path.cwd()

CLOB = ROOT / "layers" / "polymarket_clob.py"
RTDS = ROOT / "layers" / "polymarket_rtds.py"
SHADOW = ROOT / "layers" / "polymarket_shadow.py"

STAMP = datetime.now().strftime("%Y%m%d_%H%M%S")

for p in (CLOB, RTDS, SHADOW):
    if not p.exists():
        raise RuntimeError(f"缺少文件: {p}")

    shutil.copy2(
        p,
        p.with_suffix(
            p.suffix + f".bak_final_pm_{STAMP}"
        )
    )


def replace_function(
    text: str,
    function_name: str,
    replacement: str,
) -> str:

    pattern = (
        rf"(?ms)^    def {re.escape(function_name)}\(.*?"
        rf"(?=^    (?:def |async def |# ))"
    )

    match = re.search(
        pattern,
        text,
    )

    if not match:
        raise RuntimeError(
            f"找不到函数: {function_name}"
        )

    return (
        text[:match.start()]
        + replacement.rstrip()
        + "\n\n"
        + text[match.end():]
    )


# ============================================================
# 1. polymarket_clob.py
# ============================================================

s = CLOB.read_text(
    encoding="utf-8-sig"
)

if "GAMMA_EVENTS_URL" not in s:

    s = s.replace(
        '    GAMMA_URL = "https://gamma-api.polymarket.com/markets"\n',
        '    GAMMA_URL = "https://gamma-api.polymarket.com/markets"\n'
        '    GAMMA_EVENTS_URL = "https://gamma-api.polymarket.com/events"\n'
        '    GAMMA_EVENT_SLUG_URL = "https://gamma-api.polymarket.com/events/slug/{slug}"\n',
        1,
    )

new_discovery = r'''
def discover_btc_updown(self, window="15m"):
    """
    Final BTC 15m discovery.

    Primary:
        deterministic current slug -> /events/slug/{slug}

    Secondary:
        time-bounded /events

    Last:
        /markets newest-first

    Never trust active=true/closed=false alone.
    """

    if str(window).lower() != "15m":
        logger.warning(
            "Polymarket discovery currently optimized for 15m; requested={}",
            window,
        )

    now = time.time()

    with self._lock:
        cached = self._market_cache.get("market")
        cached_ts = float(
            self._market_cache.get(
                "ts",
                0.0,
            )
        )

    if cached and now - cached_ts < self.refresh_sec:

        try:
            end_dt = self._parse_dt(
                cached.get(
                    "end_time"
                )
            )

            if (
                end_dt
                and
                end_dt.timestamp() > now
            ):
                return cached

        except Exception:
            pass

    now_dt = dt.datetime.now(
        dt.timezone.utc
    )

    # ========================================================
    # Helper: normalize actual Polymarket market
    # ========================================================

    def normalize(
        market,
        event=None,
        slug_hint=None,
    ):

        if not isinstance(
            market,
            dict,
        ):
            return None

        event = (
            event
            if isinstance(
                event,
                dict,
            )
            else {}
        )

        slug = str(
            market.get(
                "slug"
            )
            or
            event.get(
                "slug"
            )
            or
            slug_hint
            or
            ""
        ).lower()

        question = str(
            market.get(
                "question"
            )
            or
            event.get(
                "title"
            )
            or
            "Bitcoin Up or Down"
        )

        if not (
            re.match(
                r"^btc-updown-15m-\d{10}$",
                slug,
            )
            or
            (
                "bitcoin up or down"
                in question.lower()
                and
                "15m"
                in (
                    slug
                    + " "
                    + question
                ).lower()
            )
        ):
            return None

        token_raw = (
            market.get(
                "clobTokenIds"
            )
            or
            market.get(
                "clob_token_ids"
            )
        )

        token_raw = (
            self._jsonish(
                token_raw
            )
        )

        if not isinstance(
            token_raw,
            list,
        ):
            return None

        token_ids = [
            str(x)
            for x in token_raw
            if x
        ]

        if len(token_ids) < 2:
            return None

        outcomes = (
            self._jsonish(
                market.get(
                    "outcomes"
                )
            )
        )

        if not isinstance(
            outcomes,
            list,
        ):
            outcomes = [
                "Up",
                "Down",
            ]

        outcomes = [
            str(x)
            for x in outcomes
        ]

        # ----------------------------------------------------
        # 15m slug timestamp is the actual window start.
        # ----------------------------------------------------

        m = re.search(
            r"btc-updown-15m-(\d{10})",
            slug,
        )

        if m:

            start_ts = float(
                m.group(1)
            )

            start_dt = (
                dt.datetime.fromtimestamp(
                    start_ts,
                    tz=dt.timezone.utc,
                )
            )

        else:

            start_dt = (
                self._parse_dt(
                    market.get(
                        "startDate"
                    )
                    or
                    market.get(
                        "startDateIso"
                    )
                    or
                    event.get(
                        "startDate"
                    )
                    or
                    event.get(
                        "startTime"
                    )
                )
            )

            if start_dt is None:
                return None

        end_dt = (
            self._parse_dt(
                market.get(
                    "endDate"
                )
                or
                market.get(
                    "endDateIso"
                )
                or
                event.get(
                    "endDate"
                )
            )
        )

        if end_dt is None:

            end_dt = (
                start_dt
                +
                dt.timedelta(
                    minutes=15
                )
            )

        # Actual live-window check.
        if not (
            start_dt
            <= now_dt
            <
            end_dt
        ):
            return None

        # ----------------------------------------------------
        # Up / Down token ordering
        # ----------------------------------------------------

        ordered_tokens = (
            token_ids[:2]
        )

        lowered = [
            x.lower()
            for x in outcomes
        ]

        up_index = next(
            (
                i
                for i, x
                in enumerate(
                    lowered
                )
                if x
                in {
                    "up",
                    "yes",
                }
            ),
            None,
        )

        down_index = next(
            (
                i
                for i, x
                in enumerate(
                    lowered
                )
                if x
                in {
                    "down",
                    "no",
                }
            ),
            None,
        )

        if (
            up_index is not None
            and
            down_index is not None
            and
            up_index
            < len(token_ids)
            and
            down_index
            < len(token_ids)
        ):

            ordered_tokens = [
                token_ids[
                    up_index
                ],
                token_ids[
                    down_index
                ],
            ]

        return {
            "condition_id":
                (
                    market.get(
                        "conditionId"
                    )
                    or
                    market.get(
                        "condition_id"
                    )
                ),
            "market_id":
                market.get(
                    "id"
                ),
            "event_id":
                event.get(
                    "id"
                ),
            "slug":
                (
                    market.get(
                        "slug"
                    )
                    or
                    event.get(
                        "slug"
                    )
                    or
                    slug
                ),
            "question":
                question,
            "start_time":
                start_dt.isoformat(),
            "end_time":
                end_dt.isoformat(),
            "token_ids":
                ordered_tokens,
            "outcomes":
                outcomes[:2],
            "duration_sec":
                (
                    end_dt
                    -
                    start_dt
                ).total_seconds(),
            "volume":
                float(
                    market.get(
                        "volumeNum"
                    )
                    or
                    market.get(
                        "volume"
                    )
                    or
                    0.0
                ),
            "raw":
                market,
        }

    def accept(
        result,
        source,
    ):

        if not result:
            return None

        with self._lock:

            self._market_cache = {
                "ts":
                    now,
                "market":
                    result,
            }

        logger.success(
            "Polymarket LIVE 15m market discovered via {}: {} | start={} | end={} | tokens={}",
            source,
            result.get(
                "slug"
            ),
            result.get(
                "start_time"
            ),
            result.get(
                "end_time"
            ),
            len(
                result.get(
                    "token_ids",
                    []
                )
            ),
        )

        return result

    # ========================================================
    # 1. DIRECT CURRENT SLUG
    # ========================================================

    boundary = (
        int(
            now
        )
        //
        900
        *
        900
    )

    for start_ts in (
        boundary,
        boundary - 900,
        boundary + 900,
    ):

        slug = (
            f"btc-updown-15m-{start_ts}"
        )

        try:

            payload = (
                self._get_json(
                    self.GAMMA_EVENT_SLUG_URL.format(
                        slug=slug
                    )
                )
            )

            if not isinstance(
                payload,
                dict,
            ):
                continue

            markets = (
                payload.get(
                    "markets"
                )
                or
                []
            )

            if not isinstance(
                markets,
                list,
            ):
                markets = []

            if not markets and (
                payload.get(
                    "clobTokenIds"
                )
                or
                payload.get(
                    "clob_token_ids"
                )
            ):
                markets = [
                    payload
                ]

            for market in markets:

                result = normalize(
                    market,
                    payload,
                    slug,
                )

                if result:

                    return accept(
                        result,
                        "event-slug",
                    )

        except Exception as exc:

            logger.debug(
                "Polymarket direct slug lookup failed {}: {}",
                slug,
                exc,
            )

    # ========================================================
    # 2. TIME-BOUNDED EVENTS
    # ========================================================

    try:

        lower = (
            now_dt
            -
            dt.timedelta(
                minutes=2
            )
        )

        upper = (
            now_dt
            +
            dt.timedelta(
                minutes=20
            )
        )

        payload = (
            self._get_json(
                self.GAMMA_EVENTS_URL,
                {
                    "closed":
                        "false",
                    "active":
                        "true",
                    "archived":
                        "false",
                    "limit":
                        100,
                    "order":
                        "endDate",
                    "ascending":
                        "true",
                    "start_date_min":
                        lower.isoformat().replace(
                            "+00:00",
                            "Z",
                        ),
                    "end_date_min":
                        now_dt.isoformat().replace(
                            "+00:00",
                            "Z",
                        ),
                    "end_date_max":
                        upper.isoformat().replace(
                            "+00:00",
                            "Z",
                        ),
                },
            )
        )

        events = (
            payload
            if isinstance(
                payload,
                list,
            )
            else []
        )

        for event in events:

            if not isinstance(
                event,
                dict,
            ):
                continue

            event_slug = str(
                event.get(
                    "slug"
                )
                or
                ""
            ).lower()

            event_title = str(
                event.get(
                    "title"
                )
                or
                ""
            ).lower()

            if not (
                "btc-updown-15m-"
                in event_slug
                or
                (
                    "bitcoin up or down"
                    in event_title
                    and
                    "15m"
                    in event_title
                )
            ):
                continue

            for market in (
                event.get(
                    "markets"
                )
                or
                []
            ):

                result = normalize(
                    market,
                    event,
                    event_slug,
                )

                if result:

                    return accept(
                        result,
                        "events-time-bounded",
                    )

    except Exception as exc:

        logger.debug(
            "Polymarket /events discovery failed: {}",
            exc,
        )

    # ========================================================
    # 3. FINAL /markets FALLBACK
    # ========================================================

    try:

        payload = (
            self._get_json(
                self.GAMMA_URL,
                {
                    "closed":
                        "false",
                    "active":
                        "true",
                    "limit":
                        100,
                    "order":
                        "endDate",
                    "ascending":
                        "false",
                },
            )
        )

        for market in (
            payload
            if isinstance(
                payload,
                list,
            )
            else []
        ):

            result = normalize(
                market
            )

            if result:

                return accept(
                    result,
                    "markets-newest-first",
                )

    except Exception as exc:

        logger.debug(
            "Polymarket /markets fallback failed: {}",
            exc,
        )

    logger.warning(
        "Polymarket: API reachable but no LIVE BTC 15m market found"
    )

    return None
'''

s = replace_function(
    s,
    "discover_btc_updown",
    new_discovery,
)

CLOB.write_text(
    s,
    encoding="utf-8",
)

print(
    "[PATCH] polymarket_clob.py"
)


# ============================================================
# 2. RTDS proxy
# ============================================================

s = RTDS.read_text(
    encoding="utf-8-sig"
)

if "proxy_url" not in s:

    s = s.replace(
        "    def __init__(self, symbol: str = SYMBOL, history_size: int = 10000):\n"
        "        self.symbol = symbol.lower()\n",
        "    def __init__(self, symbol: str = SYMBOL, history_size: int = 10000, proxy_url: Optional[str] = None):\n"
        "        self.symbol = symbol.lower()\n"
        "        self.proxy_url = (proxy_url if proxy_url is not None else \"http://127.0.0.1:12450\").strip()\n",
        1,
    )

if "def _proxy_kwargs" not in s:

    s = s.replace(
        "    def _loop(self) -> None:\n",
        '''    def _proxy_kwargs(self) -> dict[str, Any]:
        if not self.proxy_url:
            return {}

        from urllib.parse import urlparse

        try:
            p = urlparse(
                self.proxy_url
            )

            if not p.hostname:
                return {}

            result = {
                "http_proxy_host":
                    p.hostname,
                "http_proxy_port":
                    p.port,
                "proxy_type":
                    (
                        "socks5"
                        if p.scheme.lower().startswith(
                            "socks"
                        )
                        else "http"
                    ),
            }

            if p.username:
                result[
                    "http_proxy_auth"
                ] = (
                    p.username,
                    p.password or "",
                )

            return result

        except Exception:
            return {}

    def _loop(self) -> None:
''',
        1,
    )

s = s.replace(
    "self._ws.run_forever(ping_interval=5, ping_timeout=3)",
    '''kwargs = {
                    "ping_interval":
                        20,
                    "ping_timeout":
                        10,
                }

                kwargs.update(
                    self._proxy_kwargs()
                )

                self._ws.run_forever(
                    **kwargs
                )''',
    1,
)

RTDS.write_text(
    s,
    encoding="utf-8",
)

print(
    "[PATCH] polymarket_rtds.py"
)


# ============================================================
# 3. Shadow passes proxy
# ============================================================

s = SHADOW.read_text(
    encoding="utf-8-sig"
)

s = s.replace(
    "        self.rtds = PolymarketRTDSChainlink()\n",
    '''        self.rtds = PolymarketRTDSChainlink(
            proxy_url=cfg.get(
                "proxy_url"
            )
        )
''',
    1,
)

SHADOW.write_text(
    s,
    encoding="utf-8",
)

print(
    "[PATCH] polymarket_shadow.py"
)


# ============================================================
# 4. Compile
# ============================================================

for p in (
    CLOB,
    RTDS,
    SHADOW,
):

    py_compile.compile(
        str(p),
        doraise=True,
    )

    print(
        "[PASS]",
        p.name,
    )

print()
print(
    "=" * 72
)
print(
    "POLYMARKET FINAL DISCOVERY FIX SUCCESS"
)
print(
    "=" * 72
)
print(
    "Primary  : current btc-updown-15m-<unix> event slug"
)
print(
    "Fallback : time-bounded /events"
)
print(
    "Fallback : /markets newest-first"
)
print(
    "Live     : start <= now < end"
)
print(
    "RTDS     : 127.0.0.1:12450"
)
print(
    "Syntax   : PASS"
)
print(
    "Backup   : _FINAL_BACKUP already preserved"
)
print(
    "=" * 72
)
