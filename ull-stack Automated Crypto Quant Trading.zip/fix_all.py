﻿# -*- coding: utf-8 -*-
from pathlib import Path
import py_compile

ROOT = Path.cwd()
print("=" * 70)
print("修复 4 项（低风险）")
print("=" * 70)

# ---- 修复 1+2: backtest_engine.py CSV 命名 + 列名 ----
bt = ROOT / "backtest_engine.py"
s = bt.read_text(encoding="utf-8")

old = '''        pd.DataFrame(self.trades).to_csv("rolling_backtest_trades.csv", index=False)
        df_equity.to_csv("rolling_backtest_equity.csv", index=False)
        logger.info("交易明细已保存至 rolling_backtest_trades.csv 和 rolling_backtest_equity.csv")'''
new = '''        key = self.symbol.replace("-", "_")
        trades_file = f"rolling_backtest_trades_{key}.csv"
        equity_file = f"rolling_backtest_equity_{key}.csv"
        trades_df = pd.DataFrame(self.trades)
        if not trades_df.empty and "symbol" not in trades_df.columns:
            trades_df.insert(0, "symbol", self.symbol)
        trades_df.to_csv(trades_file, index=False)
        df_equity.to_csv(equity_file, index=False)
        logger.info(f"交易明细已保存至 {trades_file} 和 {equity_file}")'''

if old in s:
    s = s.replace(old, new, 1)
    print("[1/4] CSV 按币种命名: OK")
else:
    print("[1/4] CSV 按币种命名: 跳过（块不匹配）")

# 列名和局部变量 btc_amount -> base_amount
n_before = s.count("btc_amount")
s = s.replace("btc_amount", "base_amount")
s = s.replace("买入 {base_amount:.6f} BTC ", "买入 {base_amount:.6f} {self.symbol} ")
s = s.replace("卖出 {base_amount:.6f} BTC ", "卖出 {base_amount:.6f} {self.symbol} ")
n_after = s.count("btc_amount")
print(f"[2/4] 列名替换: btc_amount 出现 {n_before} -> {n_after}")
bt.write_text(s, encoding="utf-8")
py_compile.compile(str(bt), doraise=True)
print("      backtest_engine.py 语法通过")

# ---- 修复 3: main_strategy.py 启动时校验 horizon ----
ms = ROOT / "main_strategy.py"
s = ms.read_text(encoding="utf-8")
marker = "# === HORIZON CONSISTENCY CHECK ==="
if marker not in s:
    old = '    logger.info("=== 原架构深度重构版启动：AI → Strategy → Risk → Fill ===")'
    new = '''    # === HORIZON CONSISTENCY CHECK ===
    _h = int(config.get("label", {}).get("horizon_bars", 12))
    _m = int(config.get("strategy", {}).get("max_hold_bars", 16))
    if _h != _m:
        logger.warning(
            "[HORIZON MISMATCH] label.horizon_bars={} != strategy.max_hold_bars={}; "
            "模型训练视界与持仓上限不一致，信号质量可能受影响。",
            _h, _m,
        )

    logger.info("=== 原架构深度重构版启动：AI → Strategy → Risk → Fill ===")'''
    if old in s:
        s = s.replace(old, new, 1)
        ms.write_text(s, encoding="utf-8")
        py_compile.compile(str(ms), doraise=True)
        print("[3/4] main_strategy.py horizon 校验: OK")
    else:
        print("[3/4] main_strategy.py: 未找到目标行，跳过")
else:
    print("[3/4] main_strategy.py horizon 校验: 已存在")

# ---- 修复 4: train_model.py 加 Wilson CI ----
tm = ROOT / "train_model.py"
s = tm.read_text(encoding="utf-8")

if "_wilson_ci" not in s:
    helper = '''

def _wilson_ci(hits, n, z=1.96):
    """Wilson 95% 置信区间。"""
    if n == 0:
        return 0.0, 0.0
    p = hits / n
    denom = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denom
    half = z * ((p * (1 - p) / n + z * z / (4 * n * n)) ** 0.5) / denom
    return max(0.0, center - half), min(1.0, center + half)


'''
    idx = s.find("\nclass ")
    if idx < 0:
        idx = s.find("\ndef ")
    if idx > 0:
        s = s[:idx] + helper + s[idx:]
        print("[4/4] Wilson CI 函数: 已插入")
    else:
        print("[4/4] Wilson CI 函数: 未找到插入点")

old_log = '''    for th in (0.55, threshold_up, 0.62, strong_up):
        mask = p_cal >= th
        hits = int(mask.sum())
        prec = float(y_val[mask].mean()) if hits else 0.0
        logger.info("{} OOS BUY threshold {:.2f}: N={} precision={:.4f}", symbol, th, hits, prec)'''

new_log = '''    for th in (0.55, threshold_up, 0.62, strong_up):
        mask = p_cal >= th
        hits = int(mask.sum())
        correct = int((y_val[mask] == 1).sum()) if hits else 0
        prec = correct / hits if hits else 0.0
        lo, hi = _wilson_ci(correct, hits)
        warn = ""
        if hits < 30:
            warn = " [样本不足]"
        elif lo < 0.50:
            warn = " [Wilson下界<50%，未通过显著性]"
        logger.info(
            "{} OOS BUY threshold {:.2f}: N={} precision={:.4f} "
            "Wilson95=[{:.3f},{:.3f}]{}",
            symbol, th, hits, prec, lo, hi, warn,
        )'''

if old_log in s:
    s = s.replace(old_log, new_log, 1)
    print("[4/4] 阈值日志: 已加 Wilson CI")
else:
    print("[4/4] 阈值日志: 块不匹配（可能已改过），跳过")

tm.write_text(s, encoding="utf-8")
py_compile.compile(str(tm), doraise=True)
print("      train_model.py 语法通过")

# ---- 清理旧 CSV ----
for f in ROOT.glob("rolling_backtest_*.csv"):
    f.unlink()
    print(f"[清理] 删除 {f.name}")

print("=" * 70)
print("修复完成")
print("=" * 70)
