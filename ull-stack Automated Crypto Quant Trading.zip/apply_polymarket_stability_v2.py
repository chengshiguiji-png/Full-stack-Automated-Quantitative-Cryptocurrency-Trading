﻿from pathlib import Path
import py_compile
import shutil
from datetime import datetime

ROOT = Path.cwd()

P = ROOT / "layers" / "polymarket_clob.py"

if not P.exists():
    raise RuntimeError(
        f"找不到 {P}"
    )

STAMP = datetime.now().strftime(
    "%Y%m%d_%H%M%S"
)

BACKUP_DIR = ROOT / "_FINAL_BACKUP"

BACKUP_DIR.mkdir(
    exist_ok=True
)

BACKUP = (
    BACKUP_DIR
    / f"polymarket_clob_before_stability_{STAMP}.py"
)

shutil.copy2(
    P,
    BACKUP
)

print(
    "[BACKUP]",
    BACKUP
)

source = P.read_text(
    encoding="utf-8-sig"
)

MARKER = "# FINAL_PM_STABILITY_V2"

if MARKER in source:

    print(
        "[INFO] FINAL_PM_STABILITY_V2 already installed"
    )

else:

    patch = r'''
# FINAL_PM_STABILITY_V2

# ============================================================
# 最终WSS/REST混合数据稳定层
# ============================================================

_PM_BASE_START_V2 = PolymarketCLOB.start
_PM_BASE_STOP_V2 = PolymarketCLOB.stop
_PM_BASE_HEALTH_V2 = PolymarketCLOB.health_snapshot


def _pm_rest_fallback_v2_loop(self):

    # --------------------------------------------------------
    # 参数
    # --------------------------------------------------------

    interval = 5.0
    startup_grace = 8.0
    stale_seconds = float(
        getattr(
            self,
            "ws_stale_sec",
            30.0,
        )
    )

    stale_for_fallback = min(
        15.0,
        stale_seconds,
    )

    started_at = time.time()

    stop_event = getattr(
        self,
        "_pm_v2_rest_stop",
        None,
    )

    if stop_event is None:
        return

    fallback_active = False

    while not (
        self._stop.is_set()
        or
        stop_event.is_set()
    ):

        if stop_event.wait(
            1.0
        ):
            break

        now = time.time()

        # ----------------------------------------------------
        # 启动宽限期
        # ----------------------------------------------------

        if (
            now
            - started_at
            < startup_grace
        ):
            continue

        with self._lock:

            tokens = list(
                getattr(
                    self,
                    "_subscribed_assets",
                    [],
                )
            )

            connected = bool(
                getattr(
                    self,
                    "_connected",
                    False,
                )
            )

            last_ws = float(
                getattr(
                    self,
                    "_last_ws_activity",
                    0.0,
                )
                or
                0.0
            )

            last_event = float(
                getattr(
                    self,
                    "_last_market_event",
                    0.0,
                )
                or
                0.0
            )

        if not tokens:
            continue

        # ----------------------------------------------------
        # 判断真正的数据流状态
        # ----------------------------------------------------

        ws_activity_age = (
            now
            - last_ws
            if last_ws > 0
            else 999999.0
        )

        market_event_age = (
            now
            - last_event
            if last_event > 0
            else 999999.0
        )

        ws_stream_dead = (
            not connected
            or
            ws_activity_age
            > stale_for_fallback
            or
            market_event_age
            > stale_for_fallback
        )

        # ----------------------------------------------------
        # WSS健康
        # ----------------------------------------------------

        if not ws_stream_dead:

            if fallback_active:

                logger.info(
                    "Polymarket REST fallback stopped; WSS stream healthy"
                )

                fallback_active = False

            continue

        # ----------------------------------------------------
        # WSS异常，进入REST fallback
        # ----------------------------------------------------

        if not fallback_active:

            fallback_active = True

            logger.warning(
                "Polymarket WSS data stale/disconnected "
                "(ws_age={:.1f}s,event_age={:.1f}s); "
                "activating REST /book fallback every 5s",
                ws_activity_age,
                market_event_age,
            )

        try:

            success = self.initial_sync(
                tokens
            )

            logger.debug(
                "Polymarket REST fallback sync: {}/{} books",
                success,
                len(tokens),
            )

        except Exception as exc:

            logger.warning(
                "Polymarket REST fallback exception: {}",
                exc,
            )


def _pm_v2_start(
    self,
    token_ids,
):

    # 先执行现有start逻辑：
    # REST初始同步 + WSS线程 + watchdog
    _PM_BASE_START_V2(
        self,
        token_ids,
    )

    # --------------------------------------------------------
    # 启动专用REST fallback
    # --------------------------------------------------------

    with self._lock:

        stop_event = getattr(
            self,
            "_pm_v2_rest_stop",
            None,
        )

        if stop_event is None:

            stop_event = (
                threading.Event()
            )

            self._pm_v2_rest_stop = (
                stop_event
            )

        stop_event.clear()

        thread = getattr(
            self,
            "_pm_v2_rest_thread",
            None,
        )

    if not (
        thread
        and
        thread.is_alive()
    ):

        thread = threading.Thread(
            target=_pm_rest_fallback_v2_loop,
            args=(self,),
            name="polymarket-rest-fallback-v2",
            daemon=True,
        )

        with self._lock:

            self._pm_v2_rest_thread = (
                thread
            )

        thread.start()


def _pm_v2_stop(
    self,
):

    with self._lock:

        stop_event = getattr(
            self,
            "_pm_v2_rest_stop",
            None,
        )

    if stop_event is not None:

        stop_event.set()

    thread = getattr(
        self,
        "_pm_v2_rest_thread",
        None,
    )

    try:

        _PM_BASE_STOP_V2(
            self
        )

    finally:

        if (
            thread
            and
            thread.is_alive()
        ):

            thread.join(
                timeout=1.0
            )


def _pm_v2_health(
    self,
    max_book_age_sec=30.0,
):

    base = _PM_BASE_HEALTH_V2(
        self,
        max_book_age_sec,
    )

    now = time.time()

    with self._lock:

        connected = bool(
            getattr(
                self,
                "_connected",
                False,
            )
        )

        last_ws = float(
            getattr(
                self,
                "_last_ws_activity",
                0.0,
            )
            or
            0.0
        )

        last_event = float(
            getattr(
                self,
                "_last_market_event",
                0.0,
            )
            or
            0.0
        )

        last_clob = float(
            getattr(
                self,
                "_last_clob_ok",
                0.0,
            )
            or
            0.0
        )

    ws_age = (
        now
        - last_ws
        if last_ws > 0
        else None
    )

    event_age = (
        now
        - last_event
        if last_event > 0
        else None
    )

    rest_age = (
        now
        - last_clob
        if last_clob > 0
        else None
    )

    wss_fresh = bool(
        connected
        and
        ws_age is not None
        and
        ws_age <= 15.0
        and
        event_age is not None
        and
        event_age <= 15.0
    )

    rest_fresh = bool(
        rest_age is not None
        and
        rest_age <= 10.0
    )

    status_ok = bool(
        base.get(
            "status",
            {}
        ).get(
            "ok",
            False,
        )
    )

    books_fresh = bool(
        base.get(
            "books_fresh",
            False,
        )
    )

    if wss_fresh:

        transport = "WSS"

    elif rest_fresh and books_fresh:

        transport = "REST_FALLBACK"

    else:

        transport = "STALE"

    # --------------------------------------------------------
    # 最终Shadow可用标准
    # --------------------------------------------------------

    base[
        "wss_stream_fresh"
    ] = wss_fresh

    base[
        "rest_fallback_fresh"
    ] = rest_fresh

    base[
        "rest_fallback_age_sec"
    ] = rest_age

    base[
        "last_market_event_age_sec"
    ] = event_age

    base[
        "transport"
    ] = transport

    base[
        "fresh"
    ] = bool(
        status_ok
        and
        books_fresh
        and
        (
            wss_fresh
            or
            rest_fresh
        )
    )

    return base


PolymarketCLOB.start = (
    _pm_v2_start
)

PolymarketCLOB.stop = (
    _pm_v2_stop
)

PolymarketCLOB.health_snapshot = (
    _pm_v2_health
)

'''

    P.write_text(
        source.rstrip()
        + "\n\n"
        + patch,
        encoding="utf-8",
    )

    print(
        "[PATCH] FINAL_PM_STABILITY_V2"
    )


# ============================================================
# 编译
# ============================================================

py_compile.compile(
    str(P),
    doraise=True,
)

print(
    "[PASS] polymarket_clob.py syntax"
)


# ============================================================
# import verification
# ============================================================

import importlib

import layers.polymarket_clob as mod

mod = importlib.reload(
    mod
)

cls = mod.PolymarketCLOB

print()
print(
    "=" * 72
)

print(
    "FINAL POLYMARKET STABILITY CHECK"
)

print(
    "=" * 72
)

print(
    "DISCOVER =",
    hasattr(
        cls,
        "discover_btc_updown",
    )
)

print(
    "START =",
    hasattr(
        cls,
        "start",
    )
)

print(
    "STOP =",
    hasattr(
        cls,
        "stop",
    )
)

print(
    "HEALTH =",
    hasattr(
        cls,
        "health_snapshot",
    )
)

print(
    "STABILITY =",
    "_FINAL_PM_STABILITY_V2"
    in source
)

if not all(
    [
        hasattr(
            cls,
            "discover_btc_updown",
        ),
        hasattr(
            cls,
            "start",
        ),
        hasattr(
            cls,
            "stop",
        ),
        hasattr(
            cls,
            "health_snapshot",
        ),
    ]
):

    raise RuntimeError(
        "Polymarket最终稳定层验证失败"
    )

print(
    "=" * 72
)

print(
    "FINAL POLYMARKET STABILITY PATCH SUCCESS"
)

print(
    "=" * 72
)

print(
    "WSS startup grace : 8s"
)

print(
    "WSS stale trigger : 15s"
)

print(
    "REST fallback     : every 5s"
)

print(
    "REST fallback     : only when WSS data stale"
)

print(
    "Shadow fresh      : WSS OR REST_FALLBACK"
)

print(
    "=" * 72
)
