﻿# reporting/performance_reporter.py
import pandas as pd, os
from collections import deque
from loguru import logger

class PerformanceReporter:
    def __init__(self, csv="live_trades.csv"):
        self.csv = csv

    def analyze(self):
        if not os.path.exists(self.csv):
            return {}
        df = pd.read_csv(self.csv)
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        closed = []
        for asset in df['asset'].unique():
            asset_df = df[df['asset'] == asset].sort_values('timestamp')
            buys = deque()
            for _, row in asset_df.iterrows():
                if row['side'] == 'BUY':
                    buys.append((row['timestamp'], row['price'], row['coin_amount']))
                elif row['side'] == 'SELL' and buys:
                    sell_qty = row['coin_amount']
                    sell_time = row['timestamp']
                    sell_price = row['price']
                    while sell_qty > 0 and buys:
                        b_time, b_price, b_qty = buys[0]
                        matched = min(sell_qty, b_qty)
                        pnl = matched * (sell_price - b_price)
                        closed.append({
                            'asset': asset,
                            'entry_time': b_time,
                            'exit_time': sell_time,
                            'entry_price': b_price,
                            'exit_price': sell_price,
                            'quantity': matched,
                            'pnl': pnl,
                            'hold_hours': (sell_time - b_time).total_seconds() / 3600
                        })
                        sell_qty -= matched
                        b_qty -= matched
                        if b_qty <= 0:
                            buys.popleft()
                        else:
                            buys[0] = (b_time, b_price, b_qty)
        if not closed:
            return {}
        dfc = pd.DataFrame(closed)
        return {
            "trades": len(dfc),
            "win_rate": len(dfc[dfc.pnl > 0]) / len(dfc),
            "total_pnl": dfc.pnl.sum(),
            "avg_hold": dfc.hold_hours.mean()
        }

    def print_summary(self):
        s = self.analyze()
        if s:
            logger.info(f"绩效: 交易{s['trades']} | 胜率{s['win_rate']:.2%} | 盈亏{s['total_pnl']:+.2f} | 持时{s['avg_hold']:.1f}h")
