﻿from pathlib import Path
import ast
import py_compile
import shutil
from datetime import datetime

P = Path("layers/polymarket_clob.py")

if not P.exists():
    raise RuntimeError(f"找不到 {P}")

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = P.with_name(
    f"polymarket_clob.before_age_fix_{stamp}.py"
)

shutil.copy2(P, backup)

source = P.read_text(
    encoding="utf-8-sig"
)

tree = ast.parse(source)

cls = None
health = None

for node in tree.body:
    if (
        isinstance(node, ast.ClassDef)
        and node.name == "PolymarketCLOB"
    ):
        cls = node
        break

if cls is None:
    raise RuntimeError(
        "找不到 PolymarketCLOB"
    )

for node in cls.body:
    if (
        isinstance(node, ast.FunctionDef)
        and node.name == "health_snapshot"
    ):
        health = node
        break

if health is None:
    raise RuntimeError(
        "找不到 health_snapshot"
    )

lines = source.splitlines(
    keepends=True
)

old = "".join(
    lines[
        health.lineno - 1:
        health.end_lineno
    ]
)

# ------------------------------------------------------------
# 只修健康统计，不碰其他逻辑
# ------------------------------------------------------------

old_ws = '''            ws_age = (
                now
                - self._last_ws_activity
                if self._last_ws_activity
                else None
            )
'''

new_ws = '''            ws_age = (
                max(
                    0.0,
                    now - self._last_ws_activity,
                )
                if self._last_ws_activity
                else None
            )
'''

old_market = '''            market_age = (
                now
                - self._last_market_event
                if self._last_market_event
                else None
            )
'''

new_market = '''            market_age = (
                max(
                    0.0,
                    now - self._last_market_event,
                )
                if self._last_market_event
                else None
            )
'''

old = old.replace(
    old_ws,
    new_ws,
    1,
)

old = old.replace(
    old_market,
    new_market,
    1,
)

lines[
    health.lineno - 1:
    health.end_lineno
] = [
    old
]

P.write_text(
    "".join(lines),
    encoding="utf-8"
)

py_compile.compile(
    str(P),
    doraise=True
)

print()
print("=" * 72)
print("POLYMARKET AGE FIX SUCCESS")
print("=" * 72)
print("ws_activity_age_sec   : never negative")
print("market_event_age_sec  : never negative")
print("discovery             : unchanged")
print("CLOB                  : unchanged")
print("WSS                   : unchanged")
print("syntax                : PASS")
print("backup                :", backup)
print("=" * 72)
