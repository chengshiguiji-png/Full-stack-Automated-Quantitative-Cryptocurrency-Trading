﻿from pathlib import Path
p = Path("backtest_engine.py")
s = p.read_text(encoding="utf-8")

old = '''            market_data = {
                "volatility": df_current['close'].pct_change().std(),
                "liquidity_score": 0.8,
                "panic": False,
                "returns_20d": df_current['close'].pct_change().dropna().iloc[-20:].tolist()
            }
'''

new = '''            market_data = {
                "current_price": current_price,
                "prices": {self.symbol: current_price},
                "volatility": df_current['close'].pct_change().std(),
                "liquidity_score": 0.8,
                "panic": False,
                "returns_20d": df_current['close'].pct_change().dropna().iloc[-20:].tolist()
            }
'''

if old not in s:
    print("[FAIL] 未找到 market_data 块，请检查第 125-130 行")
else:
    s = s.replace(old, new, 1)
    p.write_text(s, encoding="utf-8")
    print("[OK] market_data 已补齐 current_price 和 prices")
