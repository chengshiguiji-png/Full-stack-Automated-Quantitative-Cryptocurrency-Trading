﻿from pathlib import Path
import re
import shutil
from datetime import datetime
import py_compile

ROOT = Path(__file__).resolve().parent
MAIN = ROOT / "main_strategy.py"
LAYER10 = ROOT / "layers" / "layer10_filter.py"

STAMP = datetime.now().strftime("%Y%m%d_%H%M%S")

if not MAIN.exists():
    raise FileNotFoundError(MAIN)

if not LAYER10.exists():
    raise FileNotFoundError(LAYER10)

# ============================================================
# 备份
# ============================================================

for p in (MAIN, LAYER10):
    backup = p.with_suffix(
        p.suffix + f".bak_{STAMP}"
    )
    shutil.copy2(p, backup)
    print(f"[BACKUP] {backup}")


# ============================================================
# 1. 修复 main_strategy.py
# ============================================================

s = MAIN.read_text(encoding="utf-8")


# ------------------------------------------------------------
# 1.1 修复 LightGBM feature-name warning
# ------------------------------------------------------------

old_prepare = '''def _prepare_model_input(df_feat, scaler, selector, feature_cols):
    if feature_cols:
        missing = [c for c in feature_cols if c not in df_feat.columns]
        if missing:
            raise ValueError(f"模型依赖特征缺失: {missing}")
        cols = feature_cols
    else:
        cols = [c for c in df_feat.columns if c not in {"timestamp", "datetime"} and pd.api.types.is_numeric_dtype(df_feat[c])]
    row = df_feat[cols].tail(1)
    if row.empty or row.isna().any(axis=1).iloc[0]:
        raise ValueError("最新模型输入包含 NaN")
    scaled = scaler.transform(row)
    selected = selector.transform(scaled)
    return selected
'''

new_prepare = '''def _prepare_model_input(df_feat, scaler, selector, feature_cols):
    """准备模型输入，并尽可能保留特征名。"""
    if feature_cols:
        missing = [
            c for c in feature_cols
            if c not in df_feat.columns
        ]
        if missing:
            raise ValueError(
                f"模型依赖特征缺失: {missing}"
            )
        cols = list(feature_cols)
    else:
        cols = [
            c
            for c in df_feat.columns
            if c not in {"timestamp", "datetime"}
            and pd.api.types.is_numeric_dtype(df_feat[c])
        ]

    row = df_feat[cols].tail(1).copy()

    if row.empty:
        raise ValueError("最新模型输入为空")

    if row.isna().any(axis=1).iloc[0]:
        bad = [
            c for c in row.columns
            if pd.isna(row.iloc[0][c])
        ]
        raise ValueError(
            f"最新模型输入包含 NaN: {bad}"
        )

    scaled = scaler.transform(row)

    try:
        support = selector.get_support(
            indices=True
        )
        selected_cols = [
            cols[int(i)]
            for i in support
        ]
    except Exception:
        selected_cols = [
            f"selected_{i}"
            for i in range(scaled.shape[1])
        ]

    selected = selector.transform(scaled)

    return pd.DataFrame(
        selected,
        columns=selected_cols,
        index=row.index,
    )
'''

if old_prepare not in s:
    raise RuntimeError(
        "找不到 _prepare_model_input，文件版本可能和预期不同；已停止修改。"
    )

s = s.replace(
    old_prepare,
    new_prepare,
    1
)


# ------------------------------------------------------------
# 1.2 增加实时缓存
# ------------------------------------------------------------

old_cache = '''    last_bar = {a: None for a in assets}
    daily_pnl = 0.0
    daily_trades = 0
'''

new_cache = '''    last_bar = {a: None for a in assets}

    # 实时缓存：
    # 同一根15m K线不重复计算完整特征和ML
    feature_cache = {a: None for a in assets}
    atr_cache = {a: None for a in assets}
    vol_cache = {a: 0.0 for a in assets}
    regime_cache = {a: "unknown" for a in assets}

    daily_pnl = 0.0
    daily_trades = 0
'''

if old_cache not in s:
    raise RuntimeError(
        "找不到 last_bar 初始化区域。"
    )

s = s.replace(
    old_cache,
    new_cache,
    1
)


# ------------------------------------------------------------
# 1.3 改统计口径
# ------------------------------------------------------------

old_stats = '''    decision_stats = {"bars": 0, "candidate_ge_50": 0, "candidate_ge_55": 0, "candidate_ge_threshold": 0, "candidate_ge_strong": 0, "buy_signals": 0, "entry_reject": 0, "risk_reject": 0, "fills": 0, "reasons": {}}
'''

new_stats = '''    decision_stats = {
        "confirmed_bars": 0,
        "signal_evaluations": 0,
        "candidate_ge_50": 0,
        "candidate_ge_55": 0,
        "candidate_ge_threshold": 0,
        "candidate_ge_strong": 0,
        "buy_signals": 0,
        "entry_reject": 0,
        "risk_reject": 0,
        "execution_reject": 0,
        "fills": 0,
        "errors": 0,
        "reasons": {},
    }
'''

if old_stats not in s:
    raise RuntimeError(
        "找不到 decision_stats。"
    )

s = s.replace(
    old_stats,
    new_stats,
    1
)


# ------------------------------------------------------------
# 1.4 找到主资产循环
# ------------------------------------------------------------

loop_start = s.find(
    "            for asset in assets:\n",
    s.find("    while True:")
)

loop_end = s.find(
    "            # 持久化本地状态；它不是成交真相源，成交仍以 executor fill 为准。",
    loop_start
)

if loop_start < 0 or loop_end < 0:
    raise RuntimeError(
        "找不到主资产循环区域。"
    )


# ------------------------------------------------------------
# 1.5 全新的实时资产循环
# ------------------------------------------------------------

new_loop = r'''            for asset in assets:
                try:
                    # ========================================================
                    # A. 只做轻量K线探测
                    # 每30秒最多取3根已确认K线
                    # ========================================================
                    probe_raw = collector.fetch_klines_rest(
                        asset,
                        interval=timeframe,
                        limit=3,
                    )

                    if not probe_raw:
                        decision_stats["reasons"]["data:probe_empty"] = (
                            decision_stats["reasons"].get(
                                "data:probe_empty",
                                0,
                            ) + 1
                        )
                        continue

                    probe_df = cleaner.clean_klines(
                        probe_raw
                    )

                    if probe_df.empty:
                        decision_stats["reasons"]["data:no_confirmed_bar"] = (
                            decision_stats["reasons"].get(
                                "data:no_confirmed_bar",
                                0,
                            ) + 1
                        )
                        continue

                    bar_ts = int(
                        probe_df["timestamp"].iloc[-1]
                    )

                    is_new_bar = (
                        last_bar[asset] != bar_ts
                    )

                    pos = positions[asset]

                    # ========================================================
                    # B. 持仓管理
                    # ========================================================
                    if pos.state in (
                        PositionState.HOLDING,
                        PositionState.PARTIAL_CLOSE,
                    ):
                        ticker = collector.fetch_ticker(
                            asset
                        )

                        current_price = float(
                            ticker
                            or probe_df["close"].iloc[-1]
                        )

                        price_cache[asset] = (
                            current_price
                        )

                        # 只有新15m K线才重新计算完整特征
                        if is_new_bar:
                            raw = collector.fetch_klines_rest(
                                asset,
                                interval=timeframe,
                                limit=int(
                                    config.get(
                                        "market",
                                        {},
                                    ).get(
                                        "lookback",
                                        300,
                                    )
                                ),
                            )

                            if raw:
                                df = cleaner.clean_klines(
                                    raw
                                )

                                if len(df) >= 80:
                                    df_feat = (
                                        engineer.calculate_features(
                                            df
                                        )
                                    )

                                    if not df_feat.empty:
                                        feature_cache[
                                            asset
                                        ] = df_feat

                                        if (
                                            "atr_14"
                                            in df_feat.columns
                                            and pd.notna(
                                                df_feat[
                                                    "atr_14"
                                                ].iloc[-1]
                                            )
                                        ):
                                            atr_cache[
                                                asset
                                            ] = float(
                                                df_feat[
                                                    "atr_14"
                                                ].iloc[-1]
                                            )
                                        else:
                                            atr_cache[
                                                asset
                                            ] = (
                                                current_price
                                                * 0.005
                                            )

                                        if (
                                            "volatility_20"
                                            in df_feat.columns
                                            and pd.notna(
                                                df_feat[
                                                    "volatility_20"
                                                ].iloc[-1]
                                            )
                                        ):
                                            vol_cache[
                                                asset
                                            ] = float(
                                                df_feat[
                                                    "volatility_20"
                                                ].iloc[-1]
                                            )

                                        try:
                                            regime_cache[
                                                asset
                                            ] = (
                                                regime_detector
                                                .detect_regime(
                                                    df
                                                )[
                                                    "market_regime"
                                                ]
                                            )
                                        except Exception:
                                            regime_cache[
                                                asset
                                            ] = "unknown"

                            hold_counter[asset] += 1

                            last_bar[asset] = (
                                bar_ts
                            )

                            decision_stats[
                                "confirmed_bars"
                            ] += 1

                        df_feat = (
                            feature_cache.get(
                                asset
                            )
                        )

                        atr = float(
                            atr_cache.get(
                                asset
                            )
                            or current_price * 0.005
                        )

                        # 实时价格风险检查
                        if (
                            df_feat is not None
                            and not df_feat.empty
                        ):
                            sm[
                                asset
                            ].update_on_price(
                                pos,
                                current_price,
                                df_feat,
                                atr,
                            )

                        exit_due_to_time = (
                            hold_counter[asset]
                            >= hold_bars_max
                        )

                        if (
                            pos.state
                            in (
                                PositionState.STOPPED,
                                PositionState.PARTIAL_CLOSE,
                            )
                            or exit_due_to_time
                        ):
                            sell_qty = (
                                pos.quantity
                            )

                            if (
                                pos.state
                                == PositionState.PARTIAL_CLOSE
                            ):
                                sell_qty = (
                                    pos.quantity
                                    * sm[
                                        asset
                                    ].partial_close_ratio
                                )

                            if sell_qty > 0:
                                result = (
                                    executor.execute(
                                        {
                                            "symbol": asset,
                                            "side": "SELL",
                                            "quantity": sell_qty,
                                        },
                                        current_price,
                                    )
                                )

                                if result.get(
                                    "executed"
                                ):
                                    fill_price = float(
                                        result[
                                            "fill_price"
                                        ]
                                    )

                                    fill_qty = float(
                                        result.get(
                                            "fill_quantity",
                                            sell_qty,
                                        )
                                    )

                                    pnl = (
                                        trader.apply_fill(
                                            asset,
                                            "SELL",
                                            fill_qty,
                                            fill_price,
                                            result.get(
                                                "fee_usdt",
                                                0.0,
                                            ),
                                        )
                                    )

                                    sm[
                                        asset
                                    ].on_order_filled(
                                        pos,
                                        "SELL",
                                        fill_qty,
                                        fill_price,
                                        atr,
                                    )

                                    trader.record_trade(
                                        asset,
                                        "SELL",
                                        fill_price,
                                        fill_qty,
                                        fill_qty * fill_price,
                                        result.get(
                                            "order_id",
                                            "unknown",
                                        ),
                                        pnl,
                                    )

                                    event_store.append_event(
                                        "ORDER_FILLED",
                                        {
                                            "symbol": asset,
                                            "side": "SELL",
                                            "quantity": fill_qty,
                                            "price": fill_price,
                                            "order_id": result.get(
                                                "order_id"
                                            ),
                                            "pnl": pnl,
                                        },
                                    )

                                    monitor.record_trade(
                                        asset,
                                        "SELL",
                                        pnl,
                                    )

                                    daily_pnl += pnl
                                    daily_trades += 1

                                    hold_counter[
                                        asset
                                    ] = 0

                                    risk_manager.update_trade_result(
                                        pnl > 0
                                    )

                                    log_trade(
                                        asset,
                                        "SELL",
                                        fill_price,
                                        fill_qty,
                                        fill_qty * fill_price,
                                        result.get(
                                            "order_id",
                                            "unknown",
                                        ),
                                        pnl_usdt=pnl,
                                    )

                                    decision_stats[
                                        "fills"
                                    ] += 1

                                    logger.success(
                                        "{} 平仓成交 {:.8f} @ {:.4f} PnL={:+.4f}",
                                        asset,
                                        fill_qty,
                                        fill_price,
                                        pnl,
                                    )

                                else:
                                    decision_stats[
                                        "execution_reject"
                                    ] += 1

                        continue

                    # ========================================================
                    # C. 非空仓但还不能新开
                    # ========================================================
                    if pos.state == PositionState.COOLDOWN:
                        sm[
                            asset
                        ].allow_new_entry(pos)

                    if pos.state != PositionState.EMPTY:
                        if is_new_bar:
                            last_bar[asset] = (
                                bar_ts
                            )
                            decision_stats[
                                "confirmed_bars"
                            ] += 1
                        continue

                    # ========================================================
                    # D. 空仓 + 没有新15m K线
                    # 直接跳过，不计算特征，不跑ML
                    # ========================================================
                    if not is_new_bar:
                        continue

                    # ========================================================
                    # E. 新15m K线：才拉300根完整数据
                    # ========================================================
                    raw = collector.fetch_klines_rest(
                        asset,
                        interval=timeframe,
                        limit=int(
                            config.get(
                                "market",
                                {},
                            ).get(
                                "lookback",
                                300,
                            )
                        ),
                    )

                    if not raw:
                        decision_stats[
                            "reasons"
                        ][
                            "data:full_fetch_empty"
                        ] = (
                            decision_stats[
                                "reasons"
                            ].get(
                                "data:full_fetch_empty",
                                0,
                            ) + 1
                        )
                        continue

                    df = cleaner.clean_klines(
                        raw
                    )

                    if len(df) < 80:
                        decision_stats[
                            "reasons"
                        ][
                            "data:insufficient_bars"
                        ] = (
                            decision_stats[
                                "reasons"
                            ].get(
                                "data:insufficient_bars",
                                0,
                            ) + 1
                        )
                        continue

                    full_bar_ts = int(
                        df["timestamp"].iloc[-1]
                    )

                    if full_bar_ts != bar_ts:
                        continue

                    df_feat = (
                        engineer.calculate_features(
                            df
                        )
                    )

                    if df_feat.empty:
                        continue

                    save_klines(
                        asset,
                        raw[-200:],
                    )

                    feature_cache[
                        asset
                    ] = df_feat

                    atr = float(
                        df_feat["atr_14"].iloc[-1]
                    ) if (
                        "atr_14" in df_feat.columns
                        and pd.notna(
                            df_feat["atr_14"].iloc[-1]
                        )
                    ) else float(
                        df["close"].iloc[-1]
                    ) * 0.005

                    vol = float(
                        df_feat["volatility_20"].iloc[-1]
                    ) if (
                        "volatility_20"
                        in df_feat.columns
                        and pd.notna(
                            df_feat[
                                "volatility_20"
                            ].iloc[-1]
                        )
                    ) else 0.0

                    atr_cache[asset] = atr
                    vol_cache[asset] = vol

                    regime_info = (
                        regime_detector.detect_regime(
                            df
                        )
                    )

                    regime = regime_info[
                        "market_regime"
                    ]

                    regime_cache[
                        asset
                    ] = regime

                    ticker = collector.fetch_ticker(
                        asset
                    )

                    current_price = float(
                        ticker
                        or df["close"].iloc[-1]
                    )

                    price_cache[
                        asset
                    ] = current_price

                    last_bar[
                        asset
                    ] = bar_ts

                    decision_stats[
                        "confirmed_bars"
                    ] += 1

                    decision_stats[
                        "signal_evaluations"
                    ] += 1

                    # ========================================================
                    # F. ML
                    # ========================================================
                    model, scaler, selector, calibrator, feature_cols = (
                        model_bundles[asset]
                    )

                    if model is None:
                        event_store.append_event(
                            "SIGNAL",
                            {
                                "symbol": asset,
                                "bar_ts": bar_ts,
                                "p_up": 0.5,
                                "direction": "HOLD",
                                "regime": regime,
                                "reason": "model_missing_safe_mode",
                            },
                        )
                        continue

                    X_selected = (
                        _prepare_model_input(
                            df_feat,
                            scaler,
                            selector,
                            feature_cols,
                        )
                    )

                    raw_p_up = float(
                        model.predict_proba(
                            X_selected
                        )[0]
                    )

                    use_calibration = bool(
                        config.get(
                            "signal",
                            {}
                        ).get(
                            "use_probability_calibration",
                            False,
                        )
                    )

                    p_up = (
                        _calibrate_probability(
                            calibrator,
                            raw_p_up,
                        )
                        if use_calibration
                        else max(
                            0.0,
                            min(
                                1.0,
                                raw_p_up,
                            ),
                        )
                    )

                    threshold_up = float(
                        config.get(
                            "signal",
                            {}
                        ).get(
                            "threshold_up",
                            0.55,
                        )
                    )

                    strong_threshold_up = float(
                        config.get(
                            "signal",
                            {}
                        ).get(
                            "strong_threshold_up",
                            0.68,
                        )
                    )

                    decision_stats[
                        "candidate_ge_50"
                    ] += int(
                        p_up >= 0.50
                    )

                    decision_stats[
                        "candidate_ge_55"
                    ] += int(
                        p_up >= 0.55
                    )

                    decision_stats[
                        "candidate_ge_threshold"
                    ] += int(
                        p_up >= threshold_up
                    )

                    decision_stats[
                        "candidate_ge_strong"
                    ] += int(
                        p_up
                        >= strong_threshold_up
                    )

                    # ========================================================
                    # G. 主信号
                    # ========================================================
                    micro_adj = (
                        micro_analyzer.analyze()
                    )

                    signal = (
                        signal_gen.generate_signal(
                            p_up,
                            micro_adj=micro_adj,
                            sentiment_adj=0.0,
                            symbol=asset,
                            bar_ts=bar_ts,
                        )
                    )

                    # 给Layer10提供市场反转判断所需信息
                    signal[
                        "rsi_14"
                    ] = float(
                        df_feat[
                            "rsi_14"
                        ].iloc[-1]
                    ) if (
                        "rsi_14" in df_feat.columns
                        and pd.notna(
                            df_feat[
                                "rsi_14"
                            ].iloc[-1]
                        )
                    ) else 50.0

                    signal[
                        "bb_pos"
                    ] = float(
                        df_feat[
                            "bb_pos"
                        ].iloc[-1]
                    ) if (
                        "bb_pos" in df_feat.columns
                        and pd.notna(
                            df_feat[
                                "bb_pos"
                            ].iloc[-1]
                        )
                    ) else 0.5

                    signal[
                        "strong_threshold_up"
                    ] = strong_threshold_up

                    # ========================================================
                    # H. 窄幅反转
                    # ========================================================
                    if (
                        signal["direction"]
                        == "HOLD"
                        and regime
                        == "narrow_range"
                    ):
                        rsi = signal[
                            "rsi_14"
                        ]

                        rsi_prev = (
                            float(
                                df_feat[
                                    "rsi_14"
                                ].iloc[-2]
                            )
                            if len(df_feat) >= 2
                            and pd.notna(
                                df_feat[
                                    "rsi_14"
                                ].iloc[-2]
                            )
                            else rsi
                        )

                        bb_pos = signal[
                            "bb_pos"
                        ]

                        mr_min = float(
                            config.get(
                                "signal",
                                {}
                            ).get(
                                "mean_reversion_min_prob",
                                threshold_up,
                            )
                        )

                        if (
                            p_up >= mr_min
                            and rsi <= 42
                            and rsi > rsi_prev
                            and bb_pos < 0.35
                        ):
                            signal[
                                "direction"
                            ] = "BUY"

                            signal[
                                "valid"
                            ] = True

                            signal[
                                "reason"
                            ] = "mean_reversion_confirmed"

                    # ========================================================
                    # I. 信号日志
                    # ========================================================
                    event_store.append_event(
                        "SIGNAL",
                        {
                            "symbol": asset,
                            "bar_ts": bar_ts,
                            "raw_p_up": raw_p_up,
                            "p_up": p_up,
                            "threshold_up": threshold_up,
                            "direction": signal[
                                "direction"
                            ],
                            "regime": regime,
                            "rsi_14": signal[
                                "rsi_14"
                            ],
                            "bb_pos": signal[
                                "bb_pos"
                            ],
                        },
                    )

                    logger.info(
                        "{} 新15m bar={} p_up={:.4f} th={:.4f} edge={:.4f} regime={} rsi={:.1f} bb={:.3f} signal={} reason={}",
                        asset,
                        bar_ts,
                        p_up,
                        threshold_up,
                        float(
                            signal.get(
                                "ev_edge",
                                0.0,
                            )
                        ),
                        regime,
                        signal[
                            "rsi_14"
                        ],
                        signal[
                            "bb_pos"
                        ],
                        signal[
                            "direction"
                        ],
                        signal.get(
                            "reason",
                            "",
                        ),
                    )

                    if (
                        signal[
                            "direction"
                        ]
                        != "BUY"
                    ):
                        continue

                    decision_stats[
                        "buy_signals"
                    ] += 1

                    # ========================================================
                    # J. 风控
                    # ========================================================
                    if daily_trades >= int(
                        config.get(
                            "risk",
                            {}
                        ).get(
                            "max_daily_trades",
                            30,
                        )
                    ):
                        decision_stats[
                            "reasons"
                        ][
                            "risk:max_daily_trades"
                        ] = (
                            decision_stats[
                                "reasons"
                            ].get(
                                "risk:max_daily_trades",
                                0,
                            ) + 1
                        )
                        continue

                    if daily_pnl <= (
                        -starting_cash
                        * float(
                            config.get(
                                "risk",
                                {}
                            ).get(
                                "max_daily_loss_rate",
                                0.02,
                            )
                        )
                    ):
                        decision_stats[
                            "reasons"
                        ][
                            "risk:daily_loss_limit"
                        ] = (
                            decision_stats[
                                "reasons"
                            ].get(
                                "risk:daily_loss_limit",
                                0,
                            ) + 1
                        )
                        continue

                    position_notional = (
                        risk_manager.calculate_position_size(
                            asset,
                            "BUY",
                            current_price,
                            atr,
                            trader.capital,
                        )
                    )

                    max_entry = (
                        trader.capital
                        * float(
                            config.get(
                                "risk",
                                {}
                            ).get(
                                "max_single_entry_pct",
                                0.10,
                            )
                        )
                    )

                    position_notional = min(
                        float(
                            position_notional
                            or 0
                        ),
                        max_entry,
                        float(
                            execution_cfg.get(
                                "max_order_value",
                                500,
                            )
                        ),
                    )

                    if position_notional < float(
                        execution_cfg.get(
                            "min_order_value",
                            10,
                        )
                    ):
                        decision_stats[
                            "reasons"
                        ][
                            "risk:position_below_min"
                        ] = (
                            decision_stats[
                                "reasons"
                            ].get(
                                "risk:position_below_min",
                                0,
                            ) + 1
                        )
                        continue

                    portfolio = {
                        "total_value": trader.equity(
                            price_cache
                        ),
                        "positions": trader.positions.copy(),
                        "today_pnl": daily_pnl,
                    }

                    # ========================================================
                    # K. Layer10
                    # ========================================================
                    filter_result = (
                        entry_filter.check(
                            signal,
                            regime,
                            trader.capital,
                            position_notional,
                        )
                    )

                    if not filter_result[
                        "passed"
                    ]:
                        decision_stats[
                            "entry_reject"
                        ] += 1

                        for reason in filter_result.get(
                            "reasons",
                            [],
                        ):
                            key = (
                                f"entry:{reason}"
                            )

                            decision_stats[
                                "reasons"
                            ][key] = (
                                decision_stats[
                                    "reasons"
                                ].get(
                                    key,
                                    0,
                                ) + 1
                            )

                        continue

                    # ========================================================
                    # L. RiskFuse
                    # ========================================================
                    order_qty = (
                        position_notional
                        / current_price
                    )

                    order = {
                        "symbol": asset,
                        "side": "BUY",
                        "quantity": order_qty,
                        "notional_usdt": position_notional,
                        "leverage": 1,
                        "order_type": "market",
                        "client_order_id": (
                            f"qa_{asset}_{bar_ts}_"
                            f"{uuid.uuid4().hex[:8]}"
                        ),
                    }

                    market_data = {
                        "current_price": current_price,
                        "prices": price_cache,
                        "volatility": vol,
                        "liquidity_score": 1.0,
                        "panic": (
                            regime
                            == "extreme_liquidation"
                        ),
                    }

                    risk_result = (
                        risk_fuse.check(
                            order,
                            portfolio,
                            market_data,
                        )
                    )

                    if not risk_result[
                        "allowed"
                    ]:
                        decision_stats[
                            "risk_reject"
                        ] += 1

                        for reason in risk_result.get(
                            "reasons",
                            [],
                        ):
                            key = (
                                f"risk:{reason}"
                            )

                            decision_stats[
                                "reasons"
                            ][key] = (
                                decision_stats[
                                    "reasons"
                                ].get(
                                    key,
                                    0,
                                ) + 1
                            )

                        continue

                    # ========================================================
                    # M. Executor
                    # ========================================================
                    result = executor.execute(
                        order,
                        current_price,
                    )

                    if not result.get(
                        "executed"
                    ):
                        decision_stats[
                            "execution_reject"
                        ] += 1

                        reason = result.get(
                            "reason",
                            "unknown",
                        )

                        key = (
                            f"execution:{reason}"
                        )

                        decision_stats[
                            "reasons"
                        ][key] = (
                            decision_stats[
                                "reasons"
                            ].get(
                                key,
                                0,
                            ) + 1
                        )

                        continue

                    # ========================================================
                    # N. 只有真实fill才更新账本
                    # ========================================================
                    fill_price = float(
                        result[
                            "fill_price"
                        ]
                    )

                    fill_qty = float(
                        result.get(
                            "fill_quantity",
                            order_qty,
                        )
                    )

                    trader.apply_fill(
                        asset,
                        "BUY",
                        fill_qty,
                        fill_price,
                        result.get(
                            "fee_usdt",
                            position_notional
                            * fee_rate,
                        ),
                    )

                    sm[
                        asset
                    ].on_order_filled(
                        positions[asset],
                        "BUY",
                        fill_qty,
                        fill_price,
                        atr,
                    )

                    hold_counter[
                        asset
                    ] = 0

                    trader.record_trade(
                        asset,
                        "BUY",
                        fill_price,
                        fill_qty,
                        fill_qty
                        * fill_price,
                        result.get(
                            "order_id",
                            "unknown",
                        ),
                    )

                    event_store.append_event(
                        "ORDER_FILLED",
                        {
                            "symbol": asset,
                            "side": "BUY",
                            "quantity": fill_qty,
                            "price": fill_price,
                            "order_id": result.get(
                                "order_id"
                            ),
                        },
                    )

                    monitor.notify_trade(
                        asset,
                        "BUY",
                        fill_price,
                        fill_qty,
                    )

                    log_trade(
                        asset,
                        "BUY",
                        fill_price,
                        fill_qty,
                        fill_qty
                        * fill_price,
                        result.get(
                            "order_id",
                            "unknown",
                        ),
                    )

                    daily_trades += 1

                    decision_stats[
                        "fills"
                    ] += 1

                    logger.success(
                        "{} 开仓成交 {:.8f} @ {:.4f} notional={:.2f}",
                        asset,
                        fill_qty,
                        fill_price,
                        fill_qty
                        * fill_price,
                    )

                except Exception as exc:
                    decision_stats[
                        "errors"
                    ] += 1

                    logger.error(
                        "处理 {} 异常: {}\n{}",
                        asset,
                        exc,
                        traceback.format_exc(),
                    )

'''

s = (
    s[:loop_start]
    + new_loop
    + s[loop_end:]
)


# ------------------------------------------------------------
# 1.6 修复信号漏斗
# ------------------------------------------------------------

old_funnel = '''            equity = trader.equity(price_cache)
            equity_history.append(equity)
            if decision_stats["bars"] and decision_stats["bars"] % 10 == 0:
                logger.info("信号漏斗 bars=%s p>=.50=%s p>=.55=%s p>=th=%s p>=strong=%s buys=%s entry_reject=%s risk_reject=%s fills=%s reasons=%s", decision_stats["bars"], decision_stats["candidate_ge_50"], decision_stats["candidate_ge_55"], decision_stats["candidate_ge_threshold"], decision_stats["candidate_ge_strong"], decision_stats["buy_signals"], decision_stats["entry_reject"], decision_stats["risk_reject"], decision_stats["fills"], decision_stats["reasons"])
'''

new_funnel = '''            equity = trader.equity(price_cache)
            equity_history.append(equity)

            evals = decision_stats[
                "signal_evaluations"
            ]

            if evals and evals % 3 == 0:
                logger.info(
                    "信号漏斗 confirmed={} eval={} p>=.50={} p>=.55={} p>=th={} p>=strong={} buys={} entry_reject={} risk_reject={} execution_reject={} fills={} errors={} reasons={}",
                    decision_stats[
                        "confirmed_bars"
                    ],
                    decision_stats[
                        "signal_evaluations"
                    ],
                    decision_stats[
                        "candidate_ge_50"
                    ],
                    decision_stats[
                        "candidate_ge_55"
                    ],
                    decision_stats[
                        "candidate_ge_threshold"
                    ],
                    decision_stats[
                        "candidate_ge_strong"
                    ],
                    decision_stats[
                        "buy_signals"
                    ],
                    decision_stats[
                        "entry_reject"
                    ],
                    decision_stats[
                        "risk_reject"
                    ],
                    decision_stats[
                        "execution_reject"
                    ],
                    decision_stats[
                        "fills"
                    ],
                    decision_stats[
                        "errors"
                    ],
                    decision_stats[
                        "reasons"
                    ],
                )
'''

if old_funnel not in s:
    raise RuntimeError(
        "找不到旧信号漏斗日志区域。"
    )

s = s.replace(
    old_funnel,
    new_funnel,
    1
)


# ------------------------------------------------------------
# 保存 main
# ------------------------------------------------------------

MAIN.write_text(
    s,
    encoding="utf-8",
)


# ============================================================
# 2. 修改 Layer10
# ============================================================

l = LAYER10.read_text(
    encoding="utf-8"
)

old_regime = '''        if direction == "BUY" and market_regime in {"strong_down", "extreme_liquidation"}:
            passed = False
            reasons.append(f"市场状态 {market_regime} 禁止追多")
'''

new_regime = '''        # strong_down 不再一刀切。
        # 普通多头继续拒绝；
        # 只有“高模型概率 + 明显超卖”才允许逆势尝试。
        if direction == "BUY" and market_regime == "strong_down":
            p_up = float(
                signal.get(
                    "p_up",
                    signal.get(
                        "base_p_up",
                        0.5,
                    ),
                )
            )

            strong_threshold = float(
                signal.get(
                    "strong_threshold_up",
                    0.68,
                )
            )

            rsi_14 = float(
                signal.get(
                    "rsi_14",
                    50.0,
                )
            )

            bb_pos = float(
                signal.get(
                    "bb_pos",
                    0.5,
                )
            )

            countertrend_ok = (
                p_up >= strong_threshold
                and rsi_14 <= 38.0
                and bb_pos <= 0.25
            )

            if not countertrend_ok:
                passed = False
                reasons.append(
                    "strong_down禁止普通追多 "
                    f"(p_up={p_up:.3f}, "
                    f"rsi={rsi_14:.1f}, "
                    f"bb={bb_pos:.3f})"
                )

        if direction == "BUY" and market_regime == "extreme_liquidation":
            passed = False
            reasons.append(
                "极端清算状态下禁止新增多头"
            )
'''

if old_regime not in l:
    raise RuntimeError(
        "找不到 Layer10 strong_down 规则。"
    )

l = l.replace(
    old_regime,
    new_regime,
    1
)

LAYER10.write_text(
    l,
    encoding="utf-8",
)


# ============================================================
# 3. Python语法检查
# ============================================================

for p in (
    MAIN,
    LAYER10,
):
    py_compile.compile(
        str(p),
        doraise=True,
    )
    print(
        f"[OK] syntax: {p}"
    )

print()
print("=" * 72)
print("FINAL REALTIME FIX COMPLETE")
print("=" * 72)
print()
print("已修复：")
print("1. 同一根15m K线不再每30秒重复做完整特征工程")
print("2. 同一根15m K线不再重复跑ML")
print("3. 持仓期间继续实时监控ticker")
print("4. 统计改为真实15m信号样本")
print("5. 增加逐层拒绝原因")
print("6. 修复LightGBM feature-name warning")
print("7. strong_down不再100%封杀BUY")
print("8. strong_down仅允许高概率+超卖逆势入场")
print()
print("备份文件已生成。")
