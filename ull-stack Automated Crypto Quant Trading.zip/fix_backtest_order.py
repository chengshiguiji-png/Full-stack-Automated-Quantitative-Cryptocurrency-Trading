﻿# -*- coding: utf-8 -*-
from pathlib import Path
p = Path("backtest_engine.py")
s = p.read_text(encoding="utf-8")

old = '''            direction = signal["direction"]
            size = 0.001 if direction == "SELL" else 10
            order = {"symbol": self.symbol, "side": direction, "size": size, "leverage": 1, "order_type": "market"}
'''

new = '''            direction = signal["direction"]
            size = 0.001 if direction == "SELL" else 10
            # 兼容新版 RiskFuse：它需要 quantity / notional_usdt，不能只有 size
            if direction == "BUY":
                notional_usdt = float(size)
                quantity = notional_usdt / current_price if current_price > 0 else 0.0
            else:
                quantity = float(size)
                notional_usdt = quantity * current_price
            order = {
                "symbol": self.symbol,
                "side": direction,
                "size": size,
                "quantity": quantity,
                "notional_usdt": notional_usdt,
                "leverage": 1,
                "order_type": "market",
            }
'''

if old not in s:
    print("[FAIL] 未找到目标行，请确认 backtest_engine.py 第 131-133 行")
else:
    s = s.replace(old, new, 1)
    p.write_text(s, encoding="utf-8")
    print("[OK] 已修复 order 字段")
