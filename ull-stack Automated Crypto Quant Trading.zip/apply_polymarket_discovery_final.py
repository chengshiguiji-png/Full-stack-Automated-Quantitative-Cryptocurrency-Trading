﻿from pathlib import Path
import re
import shutil
import py_compile
from datetime import datetime

ROOT = Path.cwd()

CLOB = ROOT / "layers" / "polymarket_clob.py"
SHADOW = ROOT / "layers" / "polymarket_shadow.py"

STAMP = datetime.now().strftime("%Y%m%d_%H%M%S")

for p in (CLOB, SHADOW):
    if not p.exists():
        raise FileNotFoundError(str(p))
    shutil.copy2(
        p,
        p.with_suffix(p.suffix + f".bak_{STAMP}")
    )

# ============================================================
# 1. polymarket_clob.py
# ============================================================

s = CLOB.read_text(encoding="utf-8")

start = s.index(
    "    def discover_btc_updown("
)

end = s.index(
    "    # ------------------------------------------------------------------\n    # CLOB REST orderbook",
    start,
)

new_discovery = r'''
    def discover_btc_updown(
        self,
        window: str = "15m",
    ) -> Optional[dict[str, Any]]:
        """
        Discover the nearest active BTC Up/Down market.

        Important:
        - Do NOT require literal "15m" in slug.
        - Prefer official public-search.
        - Fall back to /markets.
        - Select by actual start/end timestamps.
        """
        now = time.time()

        with self._lock:
            cached = self._market_cache.get("market")
            cached_ts = float(
                self._market_cache.get(
                    "ts",
                    0.0,
                )
            )

        if (
            cached
            and now - cached_ts
            < self.refresh_sec
        ):
            return cached

        now_dt = dt.datetime.now(
            dt.timezone.utc
        )

        payloads: list[Any] = []

        # ========================================================
        # 1) Official public-search
        # ========================================================
        for query in (
            "Bitcoin Up or Down",
            "BTC Up or Down",
        ):
            try:
                payload = self._get_json(
                    "https://gamma-api.polymarket.com/public-search",
                    params={
                        "q": query,
                        "limit_per_type": 50,
                        "page": 1,
                        "search_profiles": False,
                        "search_tags": False,
                    },
                )

                payloads.append(payload)

                logger.debug(
                    "Polymarket public-search OK: {}",
                    query,
                )

            except Exception as exc:
                logger.debug(
                    "Polymarket public-search failed {}: {}",
                    query,
                    exc,
                )

        # ========================================================
        # 2) Fallback /markets
        # ========================================================
        try:
            payloads.append(
                self._get_json(
                    self.GAMMA_URL,
                    params={
                        "closed": "false",
                        "active": "true",
                        "limit": 100,
                        "order": "endDate",
                        "ascending": "true",
                    },
                )
            )

        except Exception as exc:

            logger.warning(
                "Polymarket /markets fallback failed: {}",
                exc,
            )

        # ========================================================
        # 3) Flatten nested market objects
        # ========================================================
        markets: list[
            dict[str, Any]
        ] = []

        seen: set[str] = set()

        def walk(obj: Any) -> None:

            if isinstance(
                obj,
                dict,
            ):

                has_market_shape = (
                    (
                        "clobTokenIds"
                        in obj
                        or
                        "clob_token_ids"
                        in obj
                    )
                    and
                    (
                        "endDate"
                        in obj
                        or
                        "endDateIso"
                        in obj
                    )
                    and
                    (
                        "question"
                        in obj
                        or
                        "slug"
                        in obj
                    )
                )

                if has_market_shape:

                    key = str(
                        obj.get("id")
                        or
                        obj.get("conditionId")
                        or
                        obj.get("condition_id")
                        or
                        obj.get("slug")
                        or
                        ""
                    )

                    if (
                        key
                        and key not in seen
                    ):

                        seen.add(
                            key
                        )

                        markets.append(
                            obj
                        )

                for value in obj.values():

                    if isinstance(
                        value,
                        (
                            dict,
                            list,
                        ),
                    ):
                        walk(value)

            elif isinstance(
                obj,
                list,
            ):

                for value in obj:
                    walk(value)

        for payload in payloads:
            walk(payload)

        # ========================================================
        # 4) Candidate selection
        # ========================================================
        candidates: list[
            tuple[
                float,
                dict[str, Any]
            ]
        ] = []

        for market in markets:

            slug = str(
                market.get(
                    "slug"
                )
                or
                ""
            )

            question = str(
                market.get(
                    "question"
                )
                or
                market.get(
                    "title"
                )
                or
                ""
            )

            text = (
                f"{slug} {question}"
                .lower()
            )

            # BTC / Bitcoin
            if (
                "btc" not in text
                and
                "bitcoin" not in text
            ):
                continue

            # Up / Down
            is_up_down = (
                "up or down"
                in text
                or
                "up-or-down"
                in text
                or
                "updown"
                in text
                or
                (
                    "up" in text
                    and
                    "down" in text
                )
            )

            if not is_up_down:
                continue

            # Status
            if (
                market.get("active")
                is False
            ):
                continue

            if (
                market.get("closed")
                is True
            ):
                continue

            if (
                market.get("archived")
                is True
            ):
                continue

            if (
                market.get(
                    "acceptingOrders"
                )
                is False
            ):
                continue

            # ----------------------------------------------------
            # Start
            # ----------------------------------------------------
            start_dt = self._parse_dt(
                market.get(
                    "startDate"
                )
                or
                market.get(
                    "startDateIso"
                )
                or
                market.get(
                    "startTime"
                )
            )

            # ----------------------------------------------------
            # End
            # ----------------------------------------------------
            end_dt = self._parse_dt(
                market.get(
                    "endDate"
                )
                or
                market.get(
                    "endDateIso"
                )
            )

            if end_dt is None:
                continue

            if end_dt <= now_dt:
                continue

            # 某些市场没有startDate，按15分钟倒推，
            # 只作为发现层fallback。
            if start_dt is None:
                start_dt = (
                    end_dt
                    - dt.timedelta(
                        minutes=15
                    )
                )

            # ----------------------------------------------------
            # Tokens
            # ----------------------------------------------------
            token_raw = (
                market.get(
                    "clobTokenIds"
                )
                or
                market.get(
                    "clob_token_ids"
                )
            )

            token_raw = (
                self._parse_jsonish(
                    token_raw
                )
            )

            if not isinstance(
                token_raw,
                list,
            ):
                continue

            token_ids = [
                str(x)
                for x in token_raw
                if x
            ]

            if len(token_ids) < 2:
                continue

            # ----------------------------------------------------
            # Outcomes
            # ----------------------------------------------------
            outcomes = (
                self._parse_jsonish(
                    market.get(
                        "outcomes"
                    )
                )
            )

            if not isinstance(
                outcomes,
                list,
            ):
                outcomes = [
                    "Up",
                    "Down",
                ]

            outcomes = [
                str(x)
                for x in outcomes
            ]

            # 按API outcomes 顺序校正token顺序
            ordered_tokens = (
                token_ids[:2]
            )

            lower_outcomes = [
                x.lower()
                for x in outcomes
            ]

            up_index = next(
                (
                    i
                    for i, x
                    in enumerate(
                        lower_outcomes
                    )
                    if x in {
                        "up",
                        "yes",
                    }
                ),
                None,
            )

            down_index = next(
                (
                    i
                    for i, x
                    in enumerate(
                        lower_outcomes
                    )
                    if x in {
                        "down",
                        "no",
                    }
                ),
                None,
            )

            if (
                up_index is not None
                and
                down_index is not None
                and
                up_index < len(
                    token_ids
                )
                and
                down_index < len(
                    token_ids
                )
            ):

                ordered_tokens = [
                    token_ids[
                        up_index
                    ],
                    token_ids[
                        down_index
                    ],
                ]

            # ----------------------------------------------------
            # Duration scoring
            # ----------------------------------------------------
            duration_sec = max(
                1.0,
                (
                    end_dt
                    - start_dt
                ).total_seconds(),
            )

            # 15m target
            duration_error = abs(
                duration_sec
                - 900.0
            ) / 900.0

            # 当前已经进入市场周期，优先级最高
            currently_live = (
                start_dt
                <= now_dt
                < end_dt
            )

            # 未开始市场的距离
            until_start = max(
                0.0,
                (
                    start_dt
                    - now_dt
                ).total_seconds(),
            )

            # 最终分数越低越优先
            score = (
                duration_error * 4.0
                + until_start / 1800.0
                + (
                    -2.0
                    if currently_live
                    else 0.0
                )
                + (
                    -0.25
                    if market.get(
                        "acceptingOrders"
                    )
                    is True
                    else 0.0
                )
            )

            normalized = {
                "condition_id": (
                    market.get(
                        "conditionId"
                    )
                    or
                    market.get(
                        "condition_id"
                    )
                ),
                "market_id": market.get(
                    "id"
                ),
                "slug": slug,
                "question": question,
                "start_time": start_dt.isoformat(),
                "end_time": end_dt.isoformat(),
                "token_ids": ordered_tokens,
                "outcomes": outcomes[:2],
                "duration_sec": duration_sec,
                "volume": float(
                    market.get(
                        "volumeNum"
                    )
                    or
                    market.get(
                        "volume"
                    )
                    or
                    0.0
                ),
                "raw": market,
            }

            candidates.append(
                (
                    score,
                    normalized,
                )
            )

        if not candidates:

            logger.warning(
                "Polymarket: no active BTC Up/Down market found"
            )

            return None

        candidates.sort(
            key=lambda x: x[0]
        )

        market = candidates[0][1]

        with self._lock:

            self._market_cache = {
                "ts": now,
                "market": market,
            }

        logger.info(
            "Polymarket market discovered: {} | start={} | end={} | duration={}s",
            market.get("slug"),
            market.get("start_time"),
            market.get("end_time"),
            int(
                market.get(
                    "duration_sec",
                    0,
                )
            ),
        )

        return market

'''

s = s[:start] + new_discovery + s[end:]

CLOB.write_text(
    s,
    encoding="utf-8"
)


# ============================================================
# 2. polymarket_shadow.py
# ============================================================

s = SHADOW.read_text(
    encoding="utf-8"
)

start = s.index(
    "    @staticmethod\n    def _start_ts("
)

end = s.index(
    "\n    def start",
    start,
)

new_start = '''    @staticmethod
    def _start_ts(
        market: dict[str, Any]
    ) -> Optional[float]:

        # 优先使用discover层标准化后的start_time
        value = market.get(
            "start_time"
        )

        if value:

            try:

                parsed = (
                    dt.datetime.fromisoformat(
                        str(value).replace(
                            "Z",
                            "+00:00",
                        )
                    )
                )

                if parsed.tzinfo is None:
                    parsed = parsed.replace(
                        tzinfo=dt.timezone.utc
                    )

                return parsed.timestamp()

            except Exception:
                pass

        # 再从原始market字段读取
        raw = market.get(
            "raw"
        )

        if isinstance(
            raw,
            dict,
        ):

            value = (
                raw.get(
                    "startDate"
                )
                or
                raw.get(
                    "startDateIso"
                )
                or
                raw.get(
                    "startTime"
                )
            )

            if value:

                try:

                    parsed = (
                        dt.datetime.fromisoformat(
                            str(value).replace(
                                "Z",
                                "+00:00",
                            )
                        )
                    )

                    if parsed.tzinfo is None:
                        parsed = parsed.replace(
                            tzinfo=dt.timezone.utc
                        )

                    return parsed.timestamp()

                except Exception:
                    pass

        return None
'''

s = (
    s[:start]
    + new_start
    + s[end:]
)

SHADOW.write_text(
    s,
    encoding="utf-8"
)


# ============================================================
# 3. Syntax check
# ============================================================

for p in (
    CLOB,
    SHADOW,
):

    py_compile.compile(
        str(p),
        doraise=True,
    )

    print(
        "[OK] syntax:",
        p.name,
    )


print()
print("=" * 72)
print("POLYMARKET DISCOVERY FINAL FIX SUCCESS")
print("=" * 72)
print()
print("Discovery:")
print("  public-search -> /markets fallback")
print("  no hard 15m slug requirement")
print("  timestamp-based 15m candidate scoring")
print("  active + open + token validation")
print()
print("Shadow:")
print("  start_time/end_time from API")
print("  no slug timestamp dependency")
print()
print("Backups created:", STAMP)
print()
