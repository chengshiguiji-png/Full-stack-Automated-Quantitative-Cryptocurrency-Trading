﻿from main_strategy import load_config

cfg = load_config()
okx = cfg.get("exchange", {}).get("okx", {})
execution = cfg.get("execution", {})

print("=" * 72)
print("OKX EFFECTIVE CONFIG")
print("=" * 72)

for k in ["api_key", "api_secret", "passphrase"]:
    v = okx.get(k)
    print(
        f"exchange.okx.{k}:",
        "SET" if v else "MISSING",
        f"(length={len(str(v))})" if v else ""
    )

print("exchange.okx.flag =", okx.get("flag"))
print("exchange.okx.instrument_type =", okx.get("instrument_type"))
print("execution.dry_run =", execution.get("dry_run"))
print("=" * 72)
