﻿from __future__ import annotations

import json
import os
import time
from urllib.parse import urlparse

import requests
import websocket


GAMMA_URL = "https://gamma-api.polymarket.com/markets"
WS_URL = "wss://ws-subscriptions-clob.polymarket.com/ws/market"

PROXY = os.getenv(
    "POLYMARKET_PROXY",
    "http://127.0.0.1:12450",
).strip()


def discover_btc_market_tokens():
    params = {
        "closed": "false",
        "limit": 100,
        "order": "endDate",
        "ascending": "true",
    }

    s = requests.Session()
    s.trust_env = True

    print("[HTTP] discovering active Polymarket BTC markets...")

    r = s.get(
        GAMMA_URL,
        params=params,
        timeout=20,
    )

    r.raise_for_status()

    markets = r.json()

    print(
        "[HTTP] STATUS=",
        r.status_code,
        "COUNT=",
        len(markets),
    )

    candidates = []

    for m in markets:
        question = str(
            m.get("question", "")
        ).lower()

        slug = str(
            m.get("slug", "")
        ).lower()

        text = f"{question} {slug}"

        # 尽量寻找 Bitcoin/BTC Up or Down 类市场
        is_btc = (
            "bitcoin" in text
            or "btc" in text
        )

        is_directional = (
            "up" in text
            and "down" in text
        )

        if not (
            is_btc
            and is_directional
        ):
            continue

        token_ids = m.get(
            "clobTokenIds",
            m.get("clob_token_ids", []),
        )

        if isinstance(
            token_ids,
            str,
        ):
            try:
                token_ids = json.loads(
                    token_ids
                )
            except Exception:
                continue

        if not isinstance(
            token_ids,
            list,
        ):
            continue

        token_ids = [
            str(x)
            for x in token_ids
            if x
        ]

        if len(token_ids) < 1:
            continue

        candidates.append(
            {
                "question": m.get(
                    "question",
                    "",
                ),
                "slug": m.get(
                    "slug",
                    "",
                ),
                "market": m.get(
                    "conditionId",
                    m.get(
                        "condition_id",
                        "",
                    ),
                ),
                "tokens": token_ids,
            }
        )

    if not candidates:
        print(
            "[HTTP] 未在当前100个市场中找到BTC Up/Down市场。"
        )
        return []

    print()
    print(
        "[HTTP] BTC market candidates:"
    )

    for i, c in enumerate(
        candidates[:5],
        1,
    ):
        print(
            f"{i}. {c['question']}"
        )
        print(
            f"   slug={c['slug']}"
        )
        print(
            f"   tokens={len(c['tokens'])}"
        )

    selected = candidates[0]

    print()
    print(
        "[SELECT]",
        selected["question"],
    )

    return selected["tokens"][:2]


tokens = discover_btc_market_tokens()

if not tokens:
    print()
    print(
        "[FAIL] 没有发现可订阅BTC市场token。"
    )
    print(
        "[INFO] HTTP网络正常，但本次无法继续验证CLOB实时订阅。"
    )
    raise SystemExit(2)


parsed = urlparse(PROXY)

proxy_host = parsed.hostname
proxy_port = parsed.port

proxy_type = "http"

if parsed.scheme.lower().startswith(
    "socks"
):
    proxy_type = "socks5"


print()
print("=" * 72)
print("POLYMARKET CLOB REALTIME TEST")
print("=" * 72)

print(
    "WS_URL =",
    WS_URL,
)

print(
    "PROXY =",
    PROXY,
)

print(
    "TOKENS =",
    len(tokens),
)

for t in tokens:
    print(
        "TOKEN =",
        t,
    )

print()


stats = {
    "connect": 0,
    "message": 0,
    "error": 0,
    "close": 0,
    "book": 0,
    "price_change": 0,
    "last_trade": 0,
}

start_time = time.time()
last_message = None


def on_open(wsapp):
    stats["connect"] += 1

    print(
        f"[OPEN] WebSocket connected "
        f"connection#{stats['connect']}"
    )

    subscribe = {
        "assets_ids": tokens,
        "type": "market",
    }

    wsapp.send(
        json.dumps(
            subscribe
        )
    )

    print(
        "[SUBSCRIBE]",
        json.dumps(
            subscribe,
            ensure_ascii=False,
        ),
    )


def on_message(
    wsapp,
    message,
):
    global last_message

    stats["message"] += 1
    last_message = time.time()

    try:
        data = json.loads(
            message
        )

        event_type = data.get(
            "event_type",
            data.get(
                "type",
                "unknown",
            ),
        )

        if event_type == "book":
            stats["book"] += 1

        elif event_type == "price_change":
            stats["price_change"] += 1

        elif event_type in {
            "last_trade_price",
            "last_trade",
        }:
            stats["last_trade"] += 1

        print(
            f"[MESSAGE #{stats['message']}] "
            f"type={event_type} "
            f"{message[:700]}"
        )

    except Exception:
        print(
            f"[MESSAGE #{stats['message']}] "
            f"{str(message)[:700]}"
        )


def on_error(
    wsapp,
    error,
):
    stats["error"] += 1

    print(
        "[ERROR]",
        repr(error),
    )


def on_close(
    wsapp,
    code,
    msg,
):
    stats["close"] += 1

    print(
        "[CLOSE]",
        "code=",
        code,
        "msg=",
        msg,
    )


wsapp = websocket.WebSocketApp(
    WS_URL,
    on_open=on_open,
    on_message=on_message,
    on_error=on_error,
    on_close=on_close,
)


deadline = (
    time.time()
    + 120
)

attempt = 0


while time.time() < deadline:

    attempt += 1

    print()
    print(
        f"[CONNECT] attempt={attempt}"
    )

    kwargs = {
        "ping_interval": 20,
        "ping_timeout": 10,
    }

    if proxy_host and proxy_port:

        kwargs[
            "http_proxy_host"
        ] = proxy_host

        kwargs[
            "http_proxy_port"
        ] = proxy_port

        kwargs[
            "proxy_type"
        ] = proxy_type

    try:

        wsapp.run_forever(
            **kwargs
        )

    except KeyboardInterrupt:

        print(
            "[STOP] 用户终止测试"
        )

        break

    except Exception as exc:

        stats["error"] += 1

        print(
            "[EXCEPTION]",
            repr(exc),
        )

    if time.time() >= deadline:
        break

    print(
        "[RECONNECT] "
        "5秒后重新连接..."
    )

    time.sleep(5)

    wsapp = websocket.WebSocketApp(
        WS_URL,
        on_open=on_open,
        on_message=on_message,
        on_error=on_error,
        on_close=on_close,
    )


elapsed = (
    time.time()
    - start_time
)

print()
print("=" * 72)
print("RESULT")
print("=" * 72)

print(
    "connect        =",
    stats["connect"],
)

print(
    "message        =",
    stats["message"],
)

print(
    "book           =",
    stats["book"],
)

print(
    "price_change   =",
    stats["price_change"],
)

print(
    "last_trade     =",
    stats["last_trade"],
)

print(
    "error          =",
    stats["error"],
)

print(
    "close          =",
    stats["close"],
)

print(
    "elapsed_sec    =",
    round(
        elapsed,
        2,
    ),
)

if last_message:
    print(
        "last_message_age_sec =",
        round(
            time.time()
            - last_message,
            2,
        ),
    )
else:
    print(
        "last_message_age_sec = N/A"
    )

print("=" * 72)
