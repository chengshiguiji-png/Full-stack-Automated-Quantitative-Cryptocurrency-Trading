﻿from pathlib import Path
import py_compile
import importlib
import time

ROOT = Path.cwd()
P = ROOT / "layers" / "polymarket_clob.py"

if not P.exists():
    raise RuntimeError(
        f"找不到 {P}"
    )

source = P.read_text(
    encoding="utf-8-sig"
)

MARKER = "# FINAL_PM_STABILITY_V3"

if MARKER in source:

    print(
        "[INFO] FINAL_PM_STABILITY_V3 already installed"
    )

else:

    patch = r'''
# FINAL_PM_STABILITY_V3

# ============================================================
# V3:
# 1. WSS startup grace 8s
# 2. fallback only after real market-event silence
# 3. health uses market-event age
# ============================================================

_PM_V3_GRACE_SEC = 8.0
_PM_V3_STALE_SEC = 15.0
_PM_V3_REST_INTERVAL_SEC = 5.0


def _pm_v3_rest_fallback_loop(
    self
):

    started_at = time.time()

    stop_event = getattr(
        self,
        "_pm_v3_rest_stop",
        None,
    )

    if stop_event is None:
        return

    fallback_active = False

    while not (
        self._stop.is_set()
        or
        stop_event.is_set()
    ):

        if stop_event.wait(
            1.0
        ):
            break

        now = time.time()

        # ----------------------------------------------------
        # 8秒启动宽限
        # ----------------------------------------------------

        if (
            now
            -
            started_at
            <
            _PM_V3_GRACE_SEC
        ):
            continue

        with self._lock:

            tokens = list(
                getattr(
                    self,
                    "_subscribed_assets",
                    [],
                )
            )

            connected = bool(
                getattr(
                    self,
                    "_connected",
                    False,
                )
            )

            last_event = float(
                getattr(
                    self,
                    "_last_market_event",
                    0.0,
                )
                or
                0.0
            )

        if not tokens:
            continue

        event_age = (
            now
            -
            last_event
            if last_event > 0
            else 999999.0
        )

        # ----------------------------------------------------
        # WSS真正健康：
        # 必须是connected + 最近15秒有市场事件
        # ----------------------------------------------------

        wss_healthy = bool(
            connected
            and
            event_age >= 0.0
            and
            event_age <= _PM_V3_STALE_SEC
        )

        if wss_healthy:

            if fallback_active:

                logger.info(
                    "Polymarket REST fallback stopped; WSS market event stream healthy"
                )

                fallback_active = False

            continue

        # ----------------------------------------------------
        # WSS数据真正过期
        # ----------------------------------------------------

        if not fallback_active:

            fallback_active = True

            logger.warning(
                "Polymarket WSS market-event stale/disconnected "
                "(event_age={:.1f}s, connected={}); "
                "activating REST /book fallback every {:.1f}s",
                event_age,
                connected,
                _PM_V3_REST_INTERVAL_SEC,
            )

        try:

            success = self.initial_sync(
                tokens
            )

            logger.debug(
                "Polymarket REST fallback V3 sync: {}/{} books",
                success,
                len(tokens),
            )

        except Exception as exc:

            logger.warning(
                "Polymarket REST fallback V3 exception: {}",
                exc,
            )


# ============================================================
# V3启动
# ============================================================

_PM_V3_BASE_START = PolymarketCLOB.start
_PM_V3_BASE_STOP = PolymarketCLOB.stop


def _pm_v3_start(
    self,
    token_ids,
):

    _PM_V3_BASE_START(
        self,
        token_ids,
    )

    with self._lock:

        stop_event = getattr(
            self,
            "_pm_v3_rest_stop",
            None,
        )

        if stop_event is None:

            stop_event = (
                threading.Event()
            )

            self._pm_v3_rest_stop = (
                stop_event
            )

        stop_event.clear()

        thread = getattr(
            self,
            "_pm_v3_rest_thread",
            None,
        )

    if not (
        thread
        and
        thread.is_alive()
    ):

        thread = threading.Thread(
            target=_pm_v3_rest_fallback_loop,
            args=(self,),
            name="polymarket-rest-fallback-v3",
            daemon=True,
        )

        with self._lock:

            self._pm_v3_rest_thread = (
                thread
            )

        thread.start()


def _pm_v3_stop(
    self,
):

    with self._lock:

        stop_event = getattr(
            self,
            "_pm_v3_rest_stop",
            None,
        )

    if stop_event is not None:

        stop_event.set()

    thread = getattr(
        self,
        "_pm_v3_rest_thread",
        None,
    )

    _PM_V3_BASE_STOP(
        self
    )

    if (
        thread
        and
        thread.is_alive()
    ):

        thread.join(
            timeout=1.5
        )


# ============================================================
# V3 health
# ============================================================

_PM_V3_BASE_HEALTH = (
    PolymarketCLOB.health_snapshot
)


def _pm_v3_health(
    self,
    max_book_age_sec=30.0,
):

    base = _PM_V3_BASE_HEALTH(
        self,
        max_book_age_sec,
    )

    now = time.time()

    with self._lock:

        connected = bool(
            getattr(
                self,
                "_connected",
                False,
            )
        )

        last_event = float(
            getattr(
                self,
                "_last_market_event",
                0.0,
            )
            or
            0.0
        )

    # --------------------------------------------------------
    # 只使用本地收到市场事件的时间
    # --------------------------------------------------------

    if last_event > 0:

        event_age = max(
            0.0,
            now - last_event,
        )

    else:

        event_age = None

    wss_fresh = bool(
        connected
        and
        event_age is not None
        and
        event_age <= _PM_V3_STALE_SEC
    )

    # REST是否仍然足够新
    rest_age = base.get(
        "rest_fallback_age_sec"
    )

    if rest_age is None:

        raw_rest = base.get(
            "rest_fallback_age_sec"
        )

        rest_age = raw_rest

    try:

        rest_fresh = bool(
            rest_age is not None
            and
            float(rest_age)
            <= 10.0
        )

    except Exception:

        rest_fresh = False

    status_ok = bool(
        base.get(
            "status",
            {}
        ).get(
            "ok",
            False,
        )
    )

    books_fresh = bool(
        base.get(
            "books_fresh",
            False,
        )
    )

    if wss_fresh:

        transport = (
            "WSS"
        )

    elif rest_fresh and books_fresh:

        transport = (
            "REST_FALLBACK"
        )

    else:

        transport = (
            "STALE"
        )

    base[
        "last_market_event_age_sec"
    ] = event_age

    base[
        "wss_stream_fresh"
    ] = wss_fresh

    base[
        "rest_fallback_fresh"
    ] = rest_fresh

    base[
        "transport"
    ] = transport

    base[
        "fresh"
    ] = bool(
        status_ok
        and
        books_fresh
        and
        (
            wss_fresh
            or
            rest_fresh
        )
    )

    # 防止旧实现产生负的age
    old_ws_age = base.get(
        "ws_activity_age_sec"
    )

    if (
        old_ws_age is not None
        and
        old_ws_age < 0
    ):

        base[
            "ws_activity_age_sec"
        ] = 0.0

    return base


PolymarketCLOB.start = (
    _pm_v3_start
)

PolymarketCLOB.stop = (
    _pm_v3_stop
)

PolymarketCLOB.health_snapshot = (
    _pm_v3_health
)
'''

    P.write_text(
        source.rstrip()
        + "\n\n"
        + patch,
        encoding="utf-8"
    )

    print(
        "[PATCH] FINAL_PM_STABILITY_V3"
    )


# ------------------------------------------------------------
# compile
# ------------------------------------------------------------

py_compile.compile(
    str(P),
    doraise=True,
)

import layers.polymarket_clob as mod

mod = importlib.reload(
    mod
)

cls = mod.PolymarketCLOB

print()
print("=" * 72)
print(
    "FINAL POLYMARKET STABILITY V3 CHECK"
)
print("=" * 72)

print(
    "DISCOVER=",
    hasattr(
        cls,
        "discover_btc_updown",
    )
)

print(
    "START=",
    hasattr(
        cls,
        "start",
    )
)

print(
    "STOP=",
    hasattr(
        cls,
        "stop",
    )
)

print(
    "HEALTH=",
    hasattr(
        cls,
        "health_snapshot",
    )

)

print(
    "V3_MARKER=",
    MARKER in P.read_text(
        encoding="utf-8-sig"
    )
)

if not all(
    [
        hasattr(
            cls,
            "discover_btc_updown",
        ),
        hasattr(
            cls,
            "start",
        ),
        hasattr(
            cls,
            "stop",
        ),
        hasattr(
            cls,
            "health_snapshot",
        ),
    ]
):

    raise RuntimeError(
        "V3安装失败"
    )

print(
    "=" * 72
)

print(
    "FINAL POLYMARKET STABILITY V3 SUCCESS"
)

print(
    "startup grace = 8s"
)

print(
    "stale trigger = 15s market-event silence"
)

print(
    "REST fallback = 5s"
)

print(
    "health source = last_market_event"
)

print(
    "=" * 72
)
