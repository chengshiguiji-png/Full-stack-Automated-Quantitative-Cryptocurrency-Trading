﻿import pandas as pd
import numpy as np
from layers.layer1_data_collector import DataCollector
from layers.layer3_data_clean import DataCleaner
from layers.layer4_feature_engineer import FeatureEngineer
from layers.layer7_market_regime import MarketRegimeDetector

def fetch_history(symbol, limit=800):
    collector = DataCollector()
    klines = collector.fetch_klines_rest(symbol=symbol, limit=limit)
    if not klines:
        print("拉取失败")
        return None
    df = pd.DataFrame(klines)
    df = df.rename(columns={'ts': 'timestamp', 'vol': 'volume'})
    df['timestamp'] = pd.to_datetime(df['timestamp'].astype(float), unit='ms')
    df['open']   = df['open'].astype(float)
    df['high']   = df['high'].astype(float)
    df['low']    = df['low'].astype(float)
    df['close']  = df['close'].astype(float)
    df['volume'] = df['volume'].astype(float)
    print(f"拉取到 {len(df)} 根K线，时间范围 {df['timestamp'].min()} ~ {df['timestamp'].max()}")
    return df

def simulate_trading(symbol, klines_df, initial_capital=1000):
    capital = initial_capital
    position = 0.0
    entry_price = 0.0
    bars_held = 0
    trades = []
    cleaner = DataCleaner()
    engineer = FeatureEngineer()
    regime_detector = MarketRegimeDetector()
    potential_buys = 0
    blocked_by_regime = 0

    for i in range(50, len(klines_df)-1):
        window = klines_df.iloc[max(0,i-100):i+1]
        records = window.to_dict('records')
        try:
            df_clean = cleaner.clean_klines(records)
            df_feat = engineer.calculate_features(df_clean)
        except:
            continue
        if df_feat is None or len(df_feat) < 2:
            continue

        current_price = klines_df.iloc[i]['close']
        regime = regime_detector.detect_regime(df_clean).get('market_regime', 'unknown')

        rsi = df_feat['rsi_14'].iloc[-1] if 'rsi_14' in df_feat.columns else 50
        bb_mid = df_feat['bb_mid'].iloc[-1] if 'bb_mid' in df_feat.columns else current_price
        vol_ratio = df_feat['volume'].iloc[-1] / df_feat['volume'].rolling(20).mean().iloc[-1] if 'volume' in df_feat.columns and df_feat['volume'].rolling(20).mean().iloc[-1] > 0 else 1.0

        claude_buy = False
        if (current_price <= bb_mid * 1.005 and rsi < 55) or (vol_ratio > 1.5 and current_price <= bb_mid * 1.02):
            claude_buy = True
            potential_buys += 1

        if claude_buy and position == 0:
            if regime not in ['narrow_range', 'trend']:
                blocked_by_regime += 1
                continue
            position = capital / current_price
            entry_price = current_price
            capital = 0
            bars_held = 0

        if position > 0:
            bars_held += 1
            pnl_pct = (current_price - entry_price) / entry_price
            should_exit = False
            if pnl_pct > 0.008 or pnl_pct < -0.003 or bars_held >= 24:
                should_exit = True

            if should_exit:
                capital = position * current_price
                trades.append({
                    'entry': entry_price,
                    'exit': current_price,
                    'pnl': (current_price - entry_price) * position,
                    'type': 'LONG'
                })
                position = 0

    print(f"\n===== 诊断 =====")
    print(f"总遍历K线数: {len(klines_df)-51}")
    print(f"潜在买入信号(宽松): {potential_buys}")
    print(f"被市场状态否决: {blocked_by_regime}")
    print(f"最终交易笔数: {len(trades)}")
    if trades:
        df_trades = pd.DataFrame(trades)
        win_rate = (df_trades['pnl'] > 0).mean()
        total_pnl = df_trades['pnl'].sum()
        avg_win = df_trades[df_trades['pnl'] > 0]['pnl'].mean()
        avg_loss = df_trades[df_trades['pnl'] < 0]['pnl'].mean()
        print(f"品种: {symbol}  胜率: {win_rate:.2%}  累计盈亏: {total_pnl:.2f} USDT")
        if pd.notna(avg_win) and pd.notna(avg_loss):
            print(f"平均盈利: {avg_win:.4f}  平均亏损: {avg_loss:.4f}  盈亏比: {abs(avg_win/avg_loss):.2f}")
    else:
        print("无交易记录，可能是行情波动极小，连宽松的止盈止损都没触发。")
    return trades

if __name__ == "__main__":
    symbol = "ETH-USDT"
    print(f"开始回测 {symbol}...")
    klines = fetch_history(symbol, limit=800)
    if klines is not None:
        simulate_trading(symbol, klines)
