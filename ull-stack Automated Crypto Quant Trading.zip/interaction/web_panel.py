﻿# interaction/web_panel.py
from flask import Flask, render_template_string, request
from collections import deque

app = Flask(__name__)
trader = None
position_states = None
equity_history = deque(maxlen=50)

HTML = r'''
<!DOCTYPE html>
<html><head>
<title>量化控制台</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<style>
body{font-family:Consolas,monospace;margin:20px;background:#1e1e1e;color:#ddd}
.card{background:#2d2d2d;padding:15px;margin:10px 0;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,.5)}
.btn{display:block;width:100%;padding:15px;margin:10px 0;background:#d9534f;color:#fff;font-size:18px;border:none;border-radius:8px;cursor:pointer}
svg{width:100%;height:200px;background:#1a1a1a;border-radius:6px}
polyline{fill:none;stroke:#4fc3f7;stroke-width:2}
.info{color:#aaa;font-size:14px}
</style></head>
<body>
<h2>📊 量化控制台</h2>
<div class="card">
  <strong>资金：</strong><span id="capital">--</span> USDT
</div>
<div class="card">
  <svg id="chart" viewBox="0 0 800 200">
    <polyline id="line" points=""/>
  </svg>
</div>
<div class="card">
  <strong>持仓：</strong><br>
  <div id="positions" class="info"></div>
</div>
<form method="POST" action="/closeall">
  <button class="btn" type="submit" onclick="return confirm('确定清仓？')">⚠️ 一键清仓</button>
</form>
<p class="info">自动刷新中（10秒）</p>
<script>
function drawChart(values){
  if(!values || values.length<2) return;
  const svg = document.getElementById('chart');
  const line = document.getElementById('line');
  const w = 800, h = 200;
  const maxVal = Math.max(...values, 1);
  const minVal = Math.min(...values, 0);
  const range = maxVal - minVal || 1;
  const points = values.map((v,i) => {
    const x = (i / (values.length-1)) * w;
    const y = h - ((v - minVal) / range) * h;
    return x+','+y;
  }).join(' ');
  line.setAttribute('points', points);
}

async function loadData(){
  try {
    const res = await fetch('/api/data');
    const data = await res.json();
    const latest = data.equity_values && data.equity_values.length>0 
      ? data.equity_values[data.equity_values.length-1] 
      : data.capital || 0;
    document.getElementById('capital').innerText = latest.toFixed(2);
    
    let posHtml = '';
    if(data.positions && data.positions.length>0){
      data.positions.forEach(p => {
        posHtml += `${p.symbol}: ${p.qty} (止损 ${p.sl})<br>`;
      });
    } else {
      posHtml = '无持仓';
    }
    document.getElementById('positions').innerHTML = posHtml;

    if(data.equity_values) drawChart(data.equity_values);
  } catch(e) {
    console.error('加载失败', e);
  }
}
loadData();
setInterval(loadData, 10000);
</script>
</body></html>
'''

@app.route('/')
def index():
    return render_template_string(HTML)

@app.route('/api/data')
def api_data():
    capital = trader.capital if trader else 0
    positions = []
    if trader and position_states:
        for sym in trader.assets:
            qty = trader.positions.get(sym, 0)
            sl = position_states[sym].current_sl if position_states.get(sym) else 0
            positions.append({"symbol": sym, "qty": round(qty, 6), "sl": round(sl, 2)})
    return {
        "capital": capital,
        "positions": positions,
        "equity_times": list(range(len(equity_history))),
        "equity_values": list(equity_history)
    }

@app.route('/closeall', methods=['POST'])
def closeall():
    from main_strategy import place_order_via_cli
    from layers.layer17_position_state_machine import PositionState
    if trader and position_states:
        for sym in trader.assets:
            qty = trader.positions.get(sym, 0)
            if qty > 0:
                place_order_via_cli(sym, "sell", qty, profile="demo")
                trader.update_position(sym, "SELL", qty, 0)
                position_states[sym].state = PositionState.COOLDOWN
    return '<script>alert("已执行");window.location.href="/";</script>'

def run_web_panel(host='0.0.0.0', port=5000):
    app.run(host=host, port=port, debug=False, use_reloader=False)
