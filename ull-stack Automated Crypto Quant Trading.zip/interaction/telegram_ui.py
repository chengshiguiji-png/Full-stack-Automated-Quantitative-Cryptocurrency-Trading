﻿# interaction/telegram_ui.py
"""
层25：人机协作（Telegram Bot）
- 查看信号、持仓、绩效
- 一键紧急清仓
- 每日简报推送（已在监控层实现，此处提供交互命令）
"""
import threading, requests, time
from loguru import logger

class TelegramUI:
    def __init__(self, token, chat_id):
        self.token = "***"
        self.chat_id = chat_id
        self.base_url = f"https://api.telegram.org/bot{token}"
        self.enabled = bool(token and chat_id)

    def send_message(self, text):
        if not self.enabled: return
        try:
            url = f"{self.base_url}/sendMessage"
            requests.post(url, json={"chat_id": self.chat_id, "text": text, "parse_mode": "Markdown"}, timeout=10)
        except Exception as e:
            logger.error(f"Telegram消息发送失败: {e}")

    def start_polling(self, command_handler):
        if not self.enabled: return
        def poll():
            last_update_id = 0
            while True:
                try:
                    url = f"{self.base_url}/getUpdates?offset={last_update_id+1}&timeout=30"
                    resp = requests.get(url, timeout=35).json()
                    for upd in resp.get("result", []):
                        last_update_id = upd["update_id"]
                        msg = upd.get("message", {}).get("text", "")
                        if msg.startswith("/"):
                            command_handler(msg, self)
                except Exception as e:
                    logger.error(f"Telegram轮询异常: {e}")
                    time.sleep(10)
        threading.Thread(target=poll, daemon=True).start()
        logger.info("Telegram 命令监听已启动")
