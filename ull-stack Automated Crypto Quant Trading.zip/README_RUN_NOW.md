# 最终版：OKX Demo 15m 验证

## 目标
这个版本用于验证“模型选出来的交易候选”在 OKX 模拟盘中的真实成交与结果，不接入实盘。

## 第一步：配置 OKX Demo
`.env.example` 仅是模板。把以下变量放入你本机环境变量：

```text
OKX_DEMO_TRADING=true
OKX_FLAG=1
OKX_DRY_RUN=false
OKX_API_KEY=你的Demo API Key
OKX_API_SECRET=你的Demo API Secret
OKX_API_PASSPHRASE=你的Demo Passphrase
LIVE_TRADING_ENABLED=false
```

`OKX_FLAG=1` + `x-simulated-trading: 1` 表示 OKX 模拟交易；真实交易还受到 `LIVE_TRADING_ENABLED=false` 的独立安全门保护。

## 第二步：重新训练
训练目标已经改成：未来 16 根 15m K 线内，是否先达到 `1.5 ATR` 目标、而不是使用与真实退出规则不一致的固定未来涨幅标签。

Windows PowerShell：

```powershell
python train_model.py --all --lookback 6000
```

只验证 BTC：

```powershell
python train_model.py --symbol BTC-USDT --lookback 6000
```

## 第三步：运行 Demo

```powershell
python main_strategy.py
```

如果你的电脑有多个 Python，直接指定 3.11：

```powershell
& C:\Users\mi\AppData\Local\Programs\Python\Python311\python.exe main_strategy.py
```

## 重要
1. 先训练，再运行；缺模型不会自动造模型。
2. Spot BUY 按 quote_ccy 发送 USDT 名义金额，SELL 按 base_ccy 发送币数量。
3. 只有 OKX 返回 `filled` 后才更新本地账本。
4. 信号日志会记录 p>=0.50、p>=0.55、p>=阈值、p>=strong、Layer10 拒绝、RiskFuse 拒绝和实际成交。
5. `use_probability_calibration` 默认 false。校准结果只保留用于监控与后续研究，防止在当前数据上再次把交易分布压成 0。
