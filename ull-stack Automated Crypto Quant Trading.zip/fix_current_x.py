﻿from pathlib import Path
p = Path("backtest_engine.py")
s = p.read_text(encoding="utf-8")
old = "            current_scaled = scaler.transform(current_X)"
new = "            current_X = current_X[prod_cols].dropna(axis=1, how='any')\n            if current_X.shape[1] != len(prod_cols):\n                continue\n            current_scaled = scaler.transform(current_X)"
if old in s:
    s = s.replace(old, new, 1)
    p.write_text(s, encoding="utf-8")
    print("[OK] 已改 current_X 处理")
else:
    print("[FAIL] 未找到 current_scaled 行")
