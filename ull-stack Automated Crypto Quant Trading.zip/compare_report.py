﻿# -*- coding: utf-8 -*-
"""深度优缺点对比报告生成器"""
from pathlib import Path
import datetime, html, re, os

GEN1 = Path(r"C:\Users\mi\zuizhongban\quant_ai_original_final_hotfix")
GEN3 = Path(r"C:\Users\mi\最终修改版二版\最终稿修改版2版\quant_ai_final_okx_demo")

# 自动探测桌面
candidates = [
    Path(os.environ.get("USERPROFILE", "")) / "OneDrive" / "Desktop",
    Path(os.environ.get("USERPROFILE", "")) / "Desktop",
    Path(r"C:\Users\mi\OneDrive\Desktop"),
    Path(r"C:\Users\mi\Desktop"),
]
OUT_DIR = next((p for p in candidates if p.exists()), Path.cwd())
OUT = OUT_DIR / "code_compare_report.html"

# ============================================================
# 分析工具
# ============================================================

def read(path):
    if not path.exists(): return ""
    return path.read_text(encoding="utf-8", errors="replace")

def lines(path):
    t = read(path)
    return len(t.splitlines()) if t else None

def has(path, *kw):
    t = read(path)
    return all(k in t for k in kw)

def count_occurrences(path, kw):
    return read(path).count(kw)

def find_value(path, key):
    """从 python 或 yaml 里提取 xxx: value 或 xxx = value"""
    t = read(path)
    for line in t.splitlines():
        s = line.strip()
        if s.startswith("#"): continue
        m = re.match(rf"{re.escape(key)}\s*[:=]\s*([^,\n#]+)", s)
        if m:
            return m.group(1).strip().strip("\"'")
    return None

# ============================================================
# 模块分析规则
# ============================================================

modules = [
    {
        "name": "主策略入口",
        "file": "main_strategy.py",
        "desc": "整个交易系统的调度中枢",
        "checks": [
            ("主循环结构", lambda p: "while True" in read(p)),
            ("轻量探测（只拉3根）", lambda p: "limit=3" in read(p)),
            ("特征缓存", lambda p: "feature_cache" in read(p)),
            ("bar_ts 去重", lambda p: "is_new_confirmed_bar" in read(p) or "bar_ts == last_bar" in read(p)),
            ("信号漏斗统计", lambda p: "信号漏斗" in read(p)),
            ("逐层拒绝原因统计", lambda p: "decision_stats" in read(p) and "reasons" in read(p)),
            ("AI辅助（TCN/Transformer）", lambda p: "ai_aux" in read(p) or "_load_optional_ai" in read(p)),
            ("LLM情绪接入", lambda p: "llm.run_once" in read(p) or "SentimentRiskAnalyzer" in read(p)),
            ("PPO接入", lambda p: "ppo" in read(p).lower() or "PPO" in read(p)),
            ("MetaDecision接入", lambda p: "MetaDecision" in read(p) or "meta_decision" in read(p)),
            ("Polymarket Shadow", lambda p: "PolymarketShadow" in read(p) or "polymarket_shadow" in read(p)),
            ("Web面板", lambda p: "web_panel" in read(p)),
        ]
    },
    {
        "name": "执行层（下单）",
        "file": "layers/layer12_executor.py",
        "desc": "订单提交、成交确认、账本更新",
        "checks": [
            ("等待真实成交", lambda p: "wait_for_fill" in read(p)),
            ("检查 state==filled", lambda p: "filled" in read(p) and "state" in read(p)),
            ("读取 accFillSz", lambda p: "accFillSz" in read(p)),
            ("读取 avgPx", lambda p: "avgPx" in read(p)),
            ("手续费换算 USDT", lambda p: "feeCcy" in read(p) or "fee_usdt" in read(p)),
            ("client_order_id 去重", lambda p: "processed_ids" in read(p)),
            ("min/max 订单价值校验", lambda p: "min_order_value" in read(p) and "max_order_value" in read(p)),
            ("dry_run 支持", lambda p: "dry_run" in read(p)),
            ("tgtCcy 处理", lambda p: "tgt_ccy" in read(p) or "tgtCcy" in read(p)),
        ]
    },
    {
        "name": "风控熔断",
        "file": "layers/layer11_risk_fuse.py",
        "desc": "最终风险闸门，所有订单必经",
        "checks": [
            ("单日亏损熔断", lambda p: "max_daily_loss" in read(p)),
            ("杠杆上限", lambda p: "leverage_max" in read(p)),
            ("单品种仓位上限", lambda p: "single_symbol_max" in read(p)),
            ("总敞口上限", lambda p: "total_exposure" in read(p)),
            ("波动率过滤", lambda p: "volatility" in read(p)),
            ("恐慌模式", lambda p: "panic" in read(p)),
        ]
    },
    {
        "name": "入场过滤",
        "file": "layers/layer10_filter.py",
        "desc": "信号生成后的二次筛选",
        "checks": [
            ("EV优势检查", lambda p: "min_ev_edge" in read(p)),
            ("市场状态检查", lambda p: "market_regime" in read(p)),
            ("strong_down 逆势条件", lambda p: "strong_down" in read(p)),
            ("extreme_liquidation 禁止", lambda p: "extreme_liquidation" in read(p)),
            ("同品种冷却", lambda p: "cooldown" in read(p)),
            ("资金/仓位校验", lambda p: "available_capital" in read(p) or "position_size" in read(p)),
            ("RSI/BB 辅助判断", lambda p: "rsi" in read(p).lower() or "bb_pos" in read(p)),
        ]
    },
    {
        "name": "信号生成",
        "file": "layers/layer9_signal_generator.py",
        "desc": "把 ML 概率翻译成 BUY/SELL/HOLD",
        "checks": [
            ("双向 BUY/SELL", lambda p: "BUY" in read(p) and "SELL" in read(p)),
            ("EV edge 条件", lambda p: "ev_edge" in read(p) or "min_ev_edge" in read(p)),
            ("bar_ts 去重", lambda p: "bar_ts" in read(p)),
            ("冷却控制", lambda p: "cooldown" in read(p)),
            ("信号 TTL", lambda p: "ttl" in read(p)),
            ("strong/normal 分级", lambda p: "strong" in read(p).lower()),
        ]
    },
    {
        "name": "ML集成模型",
        "file": "layers/layer6_ml_model.py",
        "desc": "多模型集成 + 特征名保留",
        "checks": [
            ("RandomForest", lambda p: "RandomForest" in read(p)),
            ("LogisticRegression", lambda p: "LogisticRegression" in read(p)),
            ("LightGBM", lambda p: "LGBM" in read(p) or "lightgbm" in read(p)),
            ("特征名保留（DataFrame）", lambda p: "feature_names_in_" in read(p) or "pd.DataFrame" in read(p)),
            ("权重归一化", lambda p: "_normalize_weights" in read(p) or "normalize" in read(p)),
            ("预测失败降级", lambda p: "predict_proba" in read(p)),
        ]
    },
    {
        "name": "特征工程",
        "file": "layers/layer4_feature_engineer.py",
        "desc": "从 K 线生成模型输入特征",
        "checks": [
            ("RSI", lambda p: "rsi" in read(p).lower()),
            ("MACD", lambda p: "macd" in read(p).lower()),
            ("布林带", lambda p: "bb_" in read(p) or "bollinger" in read(p).lower()),
            ("ATR", lambda p: "atr" in read(p).lower()),
            ("波动率多周期", lambda p: "volatility_" in read(p)),
            ("成交量比率", lambda p: "vol_ratio" in read(p)),
            ("VWAP", lambda p: "vwap" in read(p).lower()),
            ("动量特征", lambda p: "momentum" in read(p).lower() or "ret_" in read(p)),
            ("长趋势特征（96/192）", lambda p: "trend_" in read(p) or "long_trend" in read(p)),
            ("订单流代理", lambda p: "order_flow" in read(p) or "signed_volume" in read(p)),
        ]
    },
    {
        "name": "市场状态识别",
        "file": "layers/layer7_market_regime.py",
        "desc": "识别趋势/震荡/极端行情",
        "checks": [
            ("strong_up/strong_down", lambda p: "strong_up" in read(p) and "strong_down" in read(p)),
            ("narrow_range", lambda p: "narrow_range" in read(p)),
            ("volatile", lambda p: "volatile" in read(p)),
            ("extreme_liquidation", lambda p: "extreme_liquidation" in read(p)),
            ("多周期波动率对比", lambda p: "volatility_ratio" in read(p) or "vol96" in read(p)),
        ]
    },
    {
        "name": "训练脚本",
        "file": "train_model.py",
        "desc": "模型训练与保存",
        "checks": [
            ("ATR-based 标签", lambda p: "atr" in read(p).lower() and "label" in read(p).lower()),
            ("时间序列切分（无未来）", lambda p: "0.80" in read(p) or "split" in read(p)),
            ("SelectKBest 特征选择", lambda p: "SelectKBest" in read(p)),
            ("StandardScaler", lambda p: "StandardScaler" in read(p)),
            ("每币种独立模型", lambda p: "_symbol_key" in read(p) or "{symbol}" in read(p) or "{key}" in read(p)),
            ("校准器", lambda p: "calibrator" in read(p).lower() or "calibration" in read(p)),
            ("OOS 评估", lambda p: "OOS" in read(p) or "log_loss" in read(p)),
        ]
    },
    {
        "name": "配置",
        "file": "config.yaml",
        "desc": "全局参数",
        "checks": [
            ("单日亏损<2%", lambda p: "max_daily_loss_rate" in read(p)),
            ("杠杆<=1", lambda p: "leverage_max" in read(p)),
            ("dry_run 存在", lambda p: "dry_run" in read(p)),
            ("AI确认开关", lambda p: "ai_confirmation" in read(p)),
            ("Polymarket开关", lambda p: "polymarket_shadow" in read(p)),
            ("情绪开关", lambda p: "sentiment" in read(p)),
        ]
    },
]

# ============================================================
# 独有文件分析
# ============================================================

def list_py(root):
    return {str(p.relative_to(root)).replace("\\","/") for p in root.rglob("*.py")
            if "__pycache__" not in str(p) and ".bak" not in str(p)}

g1_files = list_py(GEN1)
g3_files = list_py(GEN3)
only1 = sorted(g1_files - g3_files)
only3 = sorted(g3_files - g1_files)

# ============================================================
# 生成 HTML
# ============================================================

H = ['<!DOCTYPE html><html><head><meta charset="utf-8"><title>新旧量化代码优缺点对比报告</title>']
H.append('''<style>
body{font-family:"Microsoft YaHei",sans-serif;margin:30px;background:#f5f5f7;color:#222;line-height:1.6}
h1{color:#1a1a1a;border-bottom:3px solid #4a90d9;padding-bottom:8px}
h2{color:#2c5282;border-left:4px solid #4a90d9;padding-left:12px;margin-top:0}
h3{color:#4a5568;margin-top:20px;margin-bottom:8px}
.card{background:#fff;padding:22px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,.08);margin-bottom:22px}
table{width:100%;border-collapse:collapse;margin-top:8px}
th,td{padding:8px 12px;text-align:left;border-bottom:1px solid #eee;font-size:14px}
th{background:#4a90d9;color:#fff;font-weight:normal}
tr:hover{background:#f9f9fb}
.g1{color:#c0392b;font-weight:bold}
.g3{color:#27ae60;font-weight:bold}
.ok{color:#27ae60;font-weight:bold}
.no{color:#c0392b}
.tag{display:inline-block;padding:2px 8px;border-radius:10px;font-size:12px}
.up{background:#d4f4dd;color:#1e7e34}.down{background:#fdd;color:#a00}.same{background:#eee;color:#666}
.legend{font-size:13px;color:#666;margin:8px 0}
ul{margin:8px 0;padding-left:22px}
li{margin:4px 0;font-size:13px}
.good{background:#e8f5e9;padding:10px 14px;border-left:4px solid #27ae60;margin:8px 0;border-radius:4px}
.bad{background:#fdecea;padding:10px 14px;border-left:4px solid #c0392b;margin:8px 0;border-radius:4px}
.rec{background:#e3f2fd;padding:10px 14px;border-left:4px solid #1976d2;margin:8px 0;border-radius:4px}
.bar{display:inline-block;height:14px;vertical-align:middle;margin-right:6px}
.summary-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:12px}
.summary-box{background:#fafafa;padding:14px;border-radius:6px;border:1px solid #e0e0e0}
.pct{font-size:22px;font-weight:bold}
</style></head><body>''')

ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
H.append('<h1>新旧量化代码优缺点对比报告</h1>')
H.append(f'<p class="legend">生成时间: {ts}</p>')
H.append(f'<p><b>Gen1（旧版）</b>: <code>{html.escape(str(GEN1))}</code><br>')
H.append(f'<b>Gen3（新版）</b>: <code>{html.escape(str(GEN3))}</code></p>')

# ========== 概览 ==========
H.append('<div class="card"><h2>📊 一、概览</h2>')
H.append('<table><tr><th>指标</th><th>Gen1（旧）</th><th>Gen3（新）</th></tr>')
H.append(f'<tr><td>Python 文件数</td><td class="g1">{len(g1_files)}</td><td class="g3">{len(g3_files)}</td></tr>')
H.append(f'<tr><td>Gen1 独有文件</td><td colspan="2">{len(only1)} 个</td></tr>')
H.append(f'<tr><td>Gen3 独有文件</td><td colspan="2">{len(only3)} 个</td></tr>')
H.append('</table></div>')

# ========== 模块功能矩阵 ==========
H.append('<div class="card"><h2>📋 二、模块功能矩阵（逐项检查）</h2>')
H.append('<p class="legend">✓ = 具备此功能；✗ = 缺失。这是"优缺点"的客观依据。</p>')

for mod in modules:
    p1 = GEN1 / mod["file"]
    p3 = GEN3 / mod["file"]
    H.append(f'<h3>{mod["name"]} — <code>{mod["file"]}</code></h3>')
    H.append(f'<p style="color:#666;font-size:13px">{mod["desc"]}</p>')
    H.append('<table><tr><th style="width:40%">功能</th><th style="width:15%">Gen1</th><th style="width:15%">Gen3</th><th>说明</th></tr>')
    for label, fn in mod["checks"]:
        try:
            r1 = fn(p1) if p1.exists() else False
            r3 = fn(p3) if p3.exists() else False
        except Exception:
            r1, r3 = False, False
        s1 = '<span class="ok">✓</span>' if r1 else '<span class="no">✗</span>'
        s3 = '<span class="ok">✓</span>' if r3 else '<span class="no">✗</span>'
        note = ""
        if r1 and not r3:
            note = '<span style="color:#c0392b">仅旧版有 — 建议融合</span>'
        elif r3 and not r1:
            note = '<span style="color:#27ae60">仅新版有 — 新版优势</span>'
        elif r1 and r3:
            note = '两版都有'
        else:
            note = '两版都无'
        H.append(f'<tr><td>{html.escape(label)}</td><td>{s1}</td><td>{s3}</td><td>{note}</td></tr>')
    H.append('</table>')

H.append('</div>')

# ========== 独有文件 ==========
def file_block(title, items, color, desc):
    H.append(f'<h3>{title}</h3>')
    H.append(f'<p style="color:#666;font-size:13px">{desc}</p>')
    if not items:
        H.append('<p>无</p>'); return
    H.append('<ul>')
    for x in items[:120]:
        H.append(f'<li><code style="color:{color}">{html.escape(x)}</code></li>')
    if len(items)>120:
        H.append(f'<li>... 还有 {len(items)-120} 个</li>')
    H.append('</ul>')

H.append('<div class="card"><h2>🔍 三、独有文件清单</h2>')
file_block(f'🔴 Gen1 独有 ({len(only1)} 个) — 新版缺失的能力', only1, "#c0392b", "这些是旧版有、新版没有的模块")
file_block(f'🟢 Gen3 独有 ({len(only3)} 个) — 新版新增的能力', only3, "#27ae60", "这些是新版有、旧版没有的模块")
H.append('</div>')

# ========== config 参数对比 ==========
CFG_KEYS = [
    ("max_daily_loss_rate", "单日最大亏损率", "越小越保守"),
    ("leverage_max", "最大杠杆", "越小越保守"),
    ("risk_per_trade", "单笔风险占比", "越小越保守"),
    ("max_single_entry_pct", "单品种最大仓位", "越小越保守"),
    ("max_total_exposure_rate", "总敞口上限", "越小越保守"),
    ("stop_loss_pct", "止损比例", "越小越严格"),
    ("take_profit_pct", "止盈比例", "—"),
    ("threshold_up", "BUY 概率阈值", "越高越保守"),
    ("threshold_down", "SELL 概率阈值", "越低越保守"),
    ("min_ev_edge", "最小 EV edge", "越高越保守"),
    ("strong_threshold_up", "强信号阈值", "越高越严格"),
    ("check_interval_seconds", "主循环间隔(秒)", "—"),
    ("max_daily_trades", "日交易上限", "越小越保守"),
]

H.append('<div class="card"><h2>⚙️ 四、config.yaml 关键参数对比</h2>')
H.append('<table><tr><th>参数</th><th>含义</th><th>Gen1（旧）</th><th>Gen3（新）</th><th>取向</th></tr>')
for k, label, direction in CFG_KEYS:
    v1 = find_value(GEN1/"config.yaml", k) or "—"
    v3 = find_value(GEN3/"config.yaml", k) or "—"
    H.append(f'<tr><td><code>{k}</code></td><td>{label}</td><td class="g1">{html.escape(v1)}</td><td class="g3">{html.escape(v3)}</td><td>{direction}</td></tr>')
H.append('</table></div>')

# ========== 优缺点总结 ==========
H.append('<div class="card"><h2>🎯 五、综合优缺点分析</h2>')

H.append('<h3>Gen1（旧版）优缺点</h3>')
H.append('<div class="good"><b>✅ 优点</b><ul>')
H.append('<li>独有的训练工具链：train_ppo / train_genetic / train_transformer / optuna_optimizer</li>')
H.append('<li>独有 Polymarket 跨市场信号（如存在）</li>')
H.append('<li>代码行数更少，单文件更易读</li>')
H.append('</ul></div>')
H.append('<div class="bad"><b>❌ 缺点</b><ul>')
H.append('<li>主策略缺特征缓存，可能每 30 秒重算 64 列特征（性能差）</li>')
H.append('<li>缺少逐层拒绝原因统计（漏斗不可见）</li>')
H.append('<li>部分模块存在"伪 AI"（随机数、未训练模型）</li>')
H.append('<li>训练样本可能不足</li>')
H.append('</ul></div>')

H.append('<h3>Gen3（新版）优缺点</h3>')
H.append('<div class="good"><b>✅ 优点</b><ul>')
H.append('<li>feature_cache + bar_ts 去重：同一根 15m K 线不重复算特征（性能好）</li>')
H.append('<li>信号漏斗统计：bars / p>=.50 / p>=th / buys / entry_reject / risk_reject / fills 全链路可见</li>')
H.append('<li>每币种独立模型（BTC/ETH/SOL 分别训练）</li>')
H.append('<li>ATR-based 标签，与真实退出结构对齐</li>')
H.append('<li>Polymarket Shadow 模块（跨市场观察）</li>')
H.append('<li>执行层完整性更好</li>')
H.append('</ul></div>')
H.append('<div class="bad"><b>❌ 缺点</b><ul>')
H.append('<li>TCN/Transformer/PPO/MetaDecision 等 AI 层默认关闭或缺失</li>')
H.append('<li>无 LLM 情绪接入（旧版有）</li>')
H.append('<li>无多资产配置（跨品种风控）</li>')
H.append('<li>无自适应学习（动态调参）</li>')
H.append('</ul></div>')

H.append('<h3>🚀 融合建议（按收益排序）</h3>')
H.append('<div class="rec"><b>包 1（低风险高收益）</b>：执行层安全升级 —— 确认 Gen3 的 layer12_executor 等真实成交、有手续费换算、有去重</div>')
H.append('<div class="rec"><b>包 2（低风险）</b>：移植 Gen1 独有训练工具 —— train_ppo / train_genetic / train_transformer / optuna_optimizer 到 Gen3</div>')
H.append('<div class="rec"><b>包 3（中风险）</b>：AI 辅助层接入 —— 启用 Gen3 的 TCN/Transformer 并升级为"可否决"，接入 LLM 情绪</div>')
H.append('<div class="rec"><b>包 4（中风险）</b>：风控参数对齐 —— 取两版中更保守的值</div>')
H.append('<div class="rec"><b>包 5（高风险）</b>：多资产配置 —— 把 Gen1 的 layer16_multi_asset_allocation 移植并适配</div>')

H.append('</div>')

H.append('<p style="text-align:center;color:#999;margin-top:40px;font-size:12px">— 报告结束 —</p>')
H.append('</body></html>')

OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text("\n".join(H), encoding="utf-8")
print("="*70)
print("报告已生成:", OUT)
print(f"Gen1 文件={len(g1_files)}, Gen3 文件={len(g3_files)}")
print(f"Gen1 独有={len(only1)}, Gen3 独有={len(only3)}")
print("="*70)
