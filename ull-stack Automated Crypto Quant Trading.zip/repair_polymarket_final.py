﻿from __future__ import annotations

import ast
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path


ROOT = Path.cwd()

ZIP_PATH = (
    ROOT.parent
    / "quant_ai_final_okx_demo_CURRENT.zip"
)

TARGET = (
    ROOT
    / "layers"
    / "polymarket_clob.py"
)

BACKUP_DIR = (
    ROOT
    / "_FINAL_BACKUP"
)

BACKUP_DIR.mkdir(
    exist_ok=True
)

if not ZIP_PATH.exists():
    raise RuntimeError(
        f"找不到当前ZIP: {ZIP_PATH}"
    )

if not TARGET.exists():
    raise RuntimeError(
        f"找不到当前文件: {TARGET}"
    )

STAMP = time.strftime(
    "%Y%m%d_%H%M%S"
)


# ============================================================
# 1. 备份当前损坏版本
# ============================================================

backup = (
    BACKUP_DIR
    / f"polymarket_clob.py.before_repair_{STAMP}"
)

shutil.copy2(
    TARGET,
    backup
)

print(
    "[BACKUP]",
    backup
)


# ============================================================
# 2. 从 CURRENT ZIP 恢复原始 polymarket_clob.py
# ============================================================

with zipfile.ZipFile(
    ZIP_PATH,
    "r"
) as z:

    names = z.namelist()

    candidates = [
        n
        for n in names
        if n.lower().endswith(
            r"layers\polymarket_clob.py".lower()
        )
        or n.lower().endswith(
            "layers/polymarket_clob.py"
        )
    ]

    if not candidates:

        raise RuntimeError(
            "CURRENT ZIP中找不到 layers/polymarket_clob.py"
        )

    source_name = candidates[0]

    source_bytes = z.read(
        source_name
    )

TARGET.write_bytes(
    source_bytes
)

print(
    "[RESTORE]",
    source_name
)


# ============================================================
# 3. 注入 event-by-slug 常量
# ============================================================

source = TARGET.read_text(
    encoding="utf-8-sig"
)

if (
    "GAMMA_EVENT_SLUG_URL"
    not in source
):

    marker = (
        '    GAMMA_URL = "https://gamma-api.polymarket.com/markets"\n'
    )

    if marker not in source:

        raise RuntimeError(
            "无法定位 GAMMA_URL"
        )

    source = source.replace(
        marker,
        marker
        + (
            '    GAMMA_EVENT_SLUG_URL = "https://gamma-api.polymarket.com/events/slug/{slug}"\n'
        ),
        1
    )


# ============================================================
# 4. AST定位 discover_btc_updown
# ============================================================

tree = ast.parse(
    source
)

klass = None

for node in tree.body:

    if (
        isinstance(
            node,
            ast.ClassDef
        )
        and node.name
        == "PolymarketCLOB"
    ):

        klass = node
        break

if klass is None:

    raise RuntimeError(
        "找不到 class PolymarketCLOB"
    )

method = None

for node in klass.body:

    if (
        isinstance(
            node,
            ast.FunctionDef
        )
        and node.name
        == "discover_btc_updown"
    ):

        method = node
        break

if method is None:

    raise RuntimeError(
        "恢复后的ZIP仍然没有 discover_btc_updown"
    )


# ============================================================
# 5. 最终BTC 15m discovery
# ============================================================

new_method = r'''
def discover_btc_updown(
    self,
    window="15m",
):
    """
    最终BTC 15m市场发现。

    关键原则：
    1. 15m窗口以slug中的Unix timestamp为准。
    2. 不使用market.startDate判断15m窗口开始。
       Polymarket的startDate可能是市场创建时间。
    3. 第一优先级直接访问当前btc-updown-15m-<timestamp>。
    4. public-search与/markets仅作为fallback。
    """

    now = time.time()

    # --------------------------------------------------------
    # 当前15分钟窗口起点
    # --------------------------------------------------------

    bucket = (
        int(now)
        // 900
    ) * 900

    def normalize_market(
        market,
        event=None,
        slug_hint="",
    ):
        """
        把Gamma event中的market标准化。
        """

        if not isinstance(
            market,
            dict,
        ):
            return None

        event = (
            event
            if isinstance(
                event,
                dict,
            )
            else {}
        )

        slug = str(
            market.get(
                "slug"
            )
            or event.get(
                "slug"
            )
            or slug_hint
            or ""
        ).lower()

        # ----------------------------------------------------
        # 必须是BTC 15m up/down slug
        # ----------------------------------------------------

        match = re.search(
            r"btc-updown-15m-(\d{10})$",
            slug,
        )

        if not match:
            return None

        window_start = float(
            match.group(1)
        )

        window_end = (
            window_start
            + 900.0
        )

        # ----------------------------------------------------
        # 真正的15m窗口判断
        # ----------------------------------------------------

        if not (
            window_start
            <= now
            <
            window_end
        ):
            return None

        if market.get(
            "closed"
        ) is True:
            return None

        if market.get(
            "archived"
        ) is True:
            return None

        # ----------------------------------------------------
        # Token IDs
        # ----------------------------------------------------

        token_raw = (
            market.get(
                "clobTokenIds"
            )
            or
            market.get(
                "clob_token_ids"
            )
        )

        token_raw = (
            self._jsonish(
                token_raw
            )
        )

        if not isinstance(
            token_raw,
            list,
        ):
            return None

        token_ids = [
            str(x)
            for x in token_raw
            if x
        ]

        if len(
            token_ids
        ) < 2:

            return None

        # ----------------------------------------------------
        # Outcomes
        # ----------------------------------------------------

        outcomes = (
            self._jsonish(
                market.get(
                    "outcomes"
                )
            )
        )

        if not isinstance(
            outcomes,
            list,
        ):

            outcomes = [
                "Up",
                "Down",
            ]

        outcomes = [
            str(x)
            for x in outcomes
        ]

        # ----------------------------------------------------
        # 保证Up / Down token顺序
        # ----------------------------------------------------

        ordered_tokens = (
            token_ids[:2]
        )

        lowered = [
            x.lower()
            for x in outcomes
        ]

        up_index = next(
            (
                i
                for i, x
                in enumerate(
                    lowered
                )
                if x
                in {
                    "up",
                    "yes",
                }
            ),
            None,
        )

        down_index = next(
            (
                i
                for i, x
                in enumerate(
                    lowered
                )
                if x
                in {
                    "down",
                    "no",
                }
            ),
            None,
        )

        if (
            up_index is not None
            and
            down_index is not None
            and
            up_index < len(
                token_ids
            )
            and
            down_index < len(
                token_ids
            )
        ):

            ordered_tokens = [
                token_ids[
                    up_index
                ],
                token_ids[
                    down_index
                ],
            ]

        return {
            "condition_id":
                (
                    market.get(
                        "conditionId"
                    )
                    or
                    market.get(
                        "condition_id"
                    )
                ),

            "market_id":
                market.get(
                    "id"
                ),

            "event_id":
                event.get(
                    "id"
                ),

            "slug":
                (
                    market.get(
                        "slug"
                    )
                    or
                    event.get(
                        "slug"
                    )
                    or
                    slug
                ),

            "question":
                (
                    market.get(
                        "question"
                    )
                    or
                    event.get(
                        "title"
                    )
                    or
                    "Bitcoin Up or Down"
                ),

            # 注意：
            # 这里的start/end是预测窗口，
            # 不是market创建时间。
            "start_time":
                dt.datetime.fromtimestamp(
                    window_start,
                    tz=dt.timezone.utc,
                ).isoformat(),

            "end_time":
                dt.datetime.fromtimestamp(
                    window_end,
                    tz=dt.timezone.utc,
                ).isoformat(),

            "window_start_ts":
                window_start,

            "window_end_ts":
                window_end,

            "token_ids":
                ordered_tokens,

            "outcomes":
                outcomes[:2],

            "duration_sec":
                900.0,

            "volume":
                float(
                    market.get(
                        "volumeNum"
                    )
                    or
                    market.get(
                        "volume"
                    )
                    or
                    0.0
                ),

            "raw":
                market,
        }

    def accept(
        result,
        source,
    ):

        if not result:
            return None

        with self._lock:

            self._market_cache = {
                "ts":
                    now,
                "market":
                    result,
            }

        logger.success(
            "Polymarket LIVE 15m market discovered via {}: {} | start={} | end={} | tokens={}",
            source,
            result.get(
                "slug"
            ),
            result.get(
                "start_time"
            ),
            result.get(
                "end_time"
            ),
            len(
                result.get(
                    "token_ids",
                    []
                )
            ),
        )

        return result

    # ========================================================
    # 1. 直接请求当前15m event slug
    # ========================================================

    # 当前窗口优先。
    # 同时尝试前一窗口和后一窗口，
    # 应对切换瞬间的边界情况。
    for start_ts in (
        bucket,
        bucket - 900,
        bucket + 900,
    ):

        slug = (
            f"btc-updown-15m-{start_ts}"
        )

        try:

            payload = (
                self._get_json(
                    self.GAMMA_EVENT_SLUG_URL.format(
                        slug=slug
                    )
                )
            )

            if not isinstance(
                payload,
                dict,
            ):
                continue

            markets = (
                payload.get(
                    "markets"
                )
                or
                []
            )

            if not isinstance(
                markets,
                list,
            ):

                markets = []

            # 某些响应自身就是market
            if (
                not markets
                and
                (
                    payload.get(
                        "clobTokenIds"
                    )
                    or
                    payload.get(
                        "clob_token_ids"
                    )
                )
            ):

                markets = [
                    payload
                ]

            for market in markets:

                result = (
                    normalize_market(
                        market,
                        payload,
                        slug,
                    )
                )

                if result:

                    return accept(
                        result,
                        "event-slug",
                    )

        except Exception as exc:

            logger.debug(
                "Polymarket event-slug lookup failed {}: {}",
                slug,
                exc,
            )

    # ========================================================
    # 2. public-search fallback
    # ========================================================

    search_url = (
        "https://gamma-api.polymarket.com/public-search"
    )

    for query in (
        "Bitcoin Up or Down",
        "BTC Up or Down",
    ):

        try:

            payload = (
                self._get_json(
                    search_url,
                    {
                        "q":
                            query,
                        "limit_per_type":
                            100,
                        "page":
                            1,
                    },
                )
            )

            stack = [
                payload
            ]

            visited = set()

            while stack:

                obj = stack.pop()

                if isinstance(
                    obj,
                    dict,
                ):

                    has_token_field = (
                        "clobTokenIds"
                        in obj
                        or
                        "clob_token_ids"
                        in obj
                    )

                    if has_token_field:

                        key = id(
                            obj
                        )

                        if key not in visited:

                            visited.add(
                                key
                            )

                            result = (
                                normalize_market(
                                    obj
                                )
                            )

                            if result:

                                return accept(
                                    result,
                                    "public-search",
                                )

                    for value in obj.values():

                        if isinstance(
                            value,
                            (
                                dict,
                                list,
                            ),
                        ):

                            stack.append(
                                value
                            )

                elif isinstance(
                    obj,
                    list,
                ):

                    stack.extend(
                        obj
                    )

        except Exception as exc:

            logger.debug(
                "Polymarket public-search failed {}: {}",
                query,
                exc,
            )

    # ========================================================
    # 3. /markets fallback
    # ========================================================

    try:

        payload = (
            self._get_json(
                self.GAMMA_URL,
                {
                    "closed":
                        "false",
                    "active":
                        "true",
                    "limit":
                        100,
                    "order":
                        "endDate",
                    "ascending":
                        "false",
                },
            )
        )

        if isinstance(
            payload,
            list,
        ):

            for market in payload:

                result = (
                    normalize_market(
                        market
                    )
                )

                if result:

                    return accept(
                        result,
                        "markets",
                    )

    except Exception as exc:

        logger.debug(
            "Polymarket /markets fallback failed: {}",
            exc,
        )

    logger.warning(
        "Polymarket: API reachable but current BTC 15m market not found"
    )

    return None
'''


# ============================================================
# 6. 使用AST真实行号替换函数
# ============================================================

lines = source.splitlines(
    keepends=True
)

lines[
    method.lineno - 1:
    method.end_lineno
] = [
    (
        new_method
        .strip(
            "\n"
        )
        + "\n"
    )
]

TARGET.write_text(
    "".join(lines),
    encoding="utf-8"
)


# ============================================================
# 7. 编译检查
# ============================================================

py_compile = (
    ROOT
    / "layers"
    / "__pycache__"
)

import py_compile as _pc

_pc.compile(
    str(TARGET),
    doraise=True,
)

# ============================================================
# 8. Attribute检查
# ============================================================

sys.path.insert(
    0,
    str(ROOT)
)

from layers.polymarket_clob import (
    PolymarketCLOB
)

if not hasattr(
    PolymarketCLOB,
    "discover_btc_updown",
):

    raise RuntimeError(
        "最终检查失败：discover_btc_updown不存在"
    )

print()
print(
    "=" * 72
)
print(
    "METHOD_REPAIR=OK"
)
print(
    "discover_btc_updown=PRESENT"
)
print(
    "syntax=PASS"
)
print(
    "=" * 72
)


# ============================================================
# 9. 真实Polymarket市场发现
# ============================================================

print()
print(
    "开始测试当前Polymarket BTC 15m..."
)

pm = PolymarketCLOB(
    refresh_sec=0,
    request_timeout=15,
)

market = (
    pm.discover_btc_updown(
        "15m"
    )
)

if market is None:

    pm.stop()

    print(
        "DISCOVERY=FAIL"
    )

    raise SystemExit(2)

print(
    "DISCOVERY=OK"
)

print(
    "SLUG=",
    market.get(
        "slug"
    )
)

print(
    "QUESTION=",
    market.get(
        "question"
    )
)

print(
    "WINDOW_START=",
    market.get(
        "start_time"
    )
)

print(
    "WINDOW_END=",
    market.get(
        "end_time"
    )
)

print(
    "TOKEN_COUNT=",
    len(
        market.get(
            "token_ids",
            []
        )
    )
)

for i, token in enumerate(
    market.get(
        "token_ids",
        []
    ),
    1,
):

    print(
        f"TOKEN_{i}=",
        token
    )


# ============================================================
# 10. CLOB REST实时订单簿
# ============================================================

book_ok = (
    pm.initial_sync(
        market[
            "token_ids"
        ]
    )
)

print(
    "CLOB_BOOK_SYNC=",
    book_ok
)

if book_ok < 2:

    pm.stop()

    print(
        "BOOK_SYNC=FAIL"
    )

    raise SystemExit(3)

print(
    "BOOK_SYNC=OK"
)

for token in market[
    "token_ids"
]:

    snapshot = (
        pm.snapshot(
            token
        )
    )

    if snapshot:

        print(
            "BOOK",
            token,
            "bid=",
            snapshot.get(
                "best_bid"
            ),
            "ask=",
            snapshot.get(
                "best_ask"
            ),
            "mid=",
            snapshot.get(
                "midpoint"
            ),
            "spread=",
            snapshot.get(
                "spread"
            ),
        )

pm.stop()

print()
print(
    "=" * 72
)
print(
    "POLYMARKET FINAL DISCOVERY TEST SUCCESS"
)
print(
    "=" * 72
)
