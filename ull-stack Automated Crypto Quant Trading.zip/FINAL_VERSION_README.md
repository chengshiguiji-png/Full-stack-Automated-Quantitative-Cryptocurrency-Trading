# Quant AI Final Demo Validation

这是当前面向 OKX Demo 15m 验证的最终候选版。核心目标是：保持工程安全边界，同时避免过度过滤导致有效样本和开仓机会塌缩。

## 最终决策链

OKX confirmed 15m bars
-> causal features
-> per-symbol ensemble score
-> OOS-derived threshold 0.62
-> regime safety gate
-> position sizing
-> EntryFilter
-> RiskFuse
-> OKX Demo market order
-> wait for fill
-> local ledger/state update

## 关键调整
- 每个交易品种独立模型，避免 BTC 模型直接套用 ETH/SOL。
- 训练标签与 Layer 17 的 1.5 ATR TP / 1.0 ATR SL 结构对齐。
- 采用未来 16 根 K 线作为交易窗口；无命中按 0，双触发同一根K线排除。
- 默认 threshold_up=0.62，strong=0.68；Layer10 不再重复施加一个隐含的 0.60 门槛。
- TCN/Transformer 只做确认记录，不再单独否决主模型 BUY。
- OKX Spot 市价单显式指定 tgtCcy。
- 历史K线训练支持超过 300 根的分页。
- 信号漏斗统计用于定位“为什么不开仓”。

## 关于模型分数
默认交易使用 ensemble 的 OOS 验证分数，而不是强制套用概率校准器。校准器会保存并记录，待 Demo 收集足够新样本后再重新验证。
