﻿import json
import requests
from datetime import datetime, timezone

PROXY = "http://127.0.0.1:12450"

GAMMA_SEARCH = "https://gamma-api.polymarket.com/public-search"
GAMMA_MARKETS = "https://gamma-api.polymarket.com/markets"

session = requests.Session()
session.trust_env = False
session.proxies.update({
    "http": PROXY,
    "https": PROXY,
})

print("=" * 100)
print("POLYMARKET FINAL DIAGNOSTIC")
print("=" * 100)

print("\n[1] PUBLIC SEARCH\n")

for query in ["Bitcoin", "BTC", "Bitcoin Up or Down", "BTC Up or Down"]:

    try:
        r = session.get(
            GAMMA_SEARCH,
            params={
                "q": query,
                "limit_per_type": 100,
                "page": 1,
            },
            timeout=20,
        )

        print("QUERY =", query)
        print("STATUS =", r.status_code)

        data = r.json()

        events = data.get("events", [])
        direct_markets = data.get("markets", [])

        print(
            "events =",
            len(events),
            "direct_markets =",
            len(direct_markets),
        )

        shown = 0

        def inspect_market(m, source):
            global shown

            if not isinstance(m, dict):
                return

            q = str(
                m.get("question")
                or m.get("title")
                or ""
            )

            slug = str(
                m.get("slug")
                or ""
            )

            text = (
                q + " " + slug
            ).lower()

            if (
                "btc" not in text
                and "bitcoin" not in text
            ):
                return

            if (
                "up" not in text
                and "down" not in text
            ):
                return

            print()
            print("-" * 90)
            print("SOURCE      =", source)
            print("QUESTION    =", q)
            print("SLUG        =", slug)
            print("ACTIVE      =", m.get("active"))
            print("CLOSED      =", m.get("closed"))
            print("ARCHIVED    =", m.get("archived"))
            print(
                "ACCEPTING   =",
                m.get("acceptingOrders"),
            )
            print(
                "START       =",
                m.get("startDate")
                or m.get("startDateIso")
            )
            print(
                "END         =",
                m.get("endDate")
                or m.get("endDateIso")
            )
            print(
                "TOKENS      =",
                m.get("clobTokenIds")
                or m.get("clob_token_ids")
            )
            print(
                "OUTCOMES    =",
                m.get("outcomes")
            )
            print(
                "ENABLE_BOOK =",
                m.get("enableOrderBook")
            )
            print(
                "VOLUME      =",
                m.get("volumeNum")
                or m.get("volume")
            )
            print(
                "LIQUIDITY   =",
                m.get("liquidityNum")
                or m.get("liquidity")
            )

        for event in events:

            inspect_market(
                event,
                "EVENT",
            )

            nested = (
                event.get("markets", [])
                if isinstance(event, dict)
                else []
            )

            for m in nested:

                inspect_market(
                    m,
                    "EVENT.MARKETS",
                )

                shown += 1

                if shown >= 20:
                    break

            if shown >= 20:
                break

        for m in direct_markets[:20]:

            inspect_market(
                m,
                "DIRECT_MARKET",
            )

    except Exception as e:

        print(
            "ERROR =",
            repr(e)
        )

    print()
    print("=" * 100)


print("\n[2] DIRECT /markets\n")

try:

    r = session.get(
        GAMMA_MARKETS,
        params={
            "closed": "false",
            "active": "true",
            "limit": 100,
            "order": "endDate",
            "ascending": "true",
        },
        timeout=20,
    )

    print(
        "STATUS =",
        r.status_code,
    )

    markets = r.json()

    print(
        "COUNT =",
        len(markets),
    )

    now = datetime.now(
        timezone.utc
    )

    found = 0

    for m in markets:

        if not isinstance(
            m,
            dict,
        ):
            continue

        q = str(
            m.get(
                "question",
                "",
            )
        )

        slug = str(
            m.get(
                "slug",
                "",
            )
        )

        text = (
            q + " " + slug
        ).lower()

        if (
            "btc" not in text
            and "bitcoin" not in text
        ):
            continue

        if (
            "up" not in text
            and "down" not in text
        ):
            continue

        print()
        print("-" * 90)
        print(
            "QUESTION    =",
            q,
        )
        print(
            "SLUG        =",
            slug,
        )
        print(
            "ACTIVE      =",
            m.get("active"),
        )
        print(
            "CLOSED      =",
            m.get("closed"),
        )
        print(
            "ACCEPTING   =",
            m.get(
                "acceptingOrders"
            ),
        )
        print(
            "START       =",
            m.get("startDate")
            or m.get("startDateIso"),
        )
        print(
            "END         =",
            m.get("endDate")
            or m.get("endDateIso"),
        )
        print(
            "TOKENS      =",
            m.get("clobTokenIds")
            or m.get("clob_token_ids"),
        )
        print(
            "OUTCOMES    =",
            m.get("outcomes"),
        )

        end_value = (
            m.get("endDate")
            or m.get("endDateIso")
        )

        if end_value:

            try:

                end_dt = (
                    datetime.fromisoformat(
                        str(
                            end_value
                        ).replace(
                            "Z",
                            "+00:00",
                        )
                    )
                )

                if end_dt.tzinfo is None:
                    end_dt = end_dt.replace(
                        tzinfo=timezone.utc
                    )

                print(
                    "SECONDS_TO_END =",
                    round(
                        (
                            end_dt
                            - now
                        ).total_seconds(),
                        2,
                    ),
                )

            except Exception:
                pass

        found += 1

        if found >= 20:
            break

    print()
    print(
        "BTC_UPDOWN_FOUND =",
        found,
    )

except Exception as e:

    print(
        "MARKETS_ERROR =",
        repr(e),
    )


print()
print(
    "=" * 100
)
print(
    "END DIAGNOSTIC"
)
print(
    "=" * 100
)
