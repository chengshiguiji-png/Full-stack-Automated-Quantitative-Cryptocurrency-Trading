﻿from pathlib import Path
import shutil
import py_compile
from datetime import datetime

ROOT = Path.cwd()

MAIN = ROOT / "main_strategy.py"
ML = ROOT / "layers" / "layer6_ml_model.py"
L10 = ROOT / "layers" / "layer10_filter.py"

STAMP = datetime.now().strftime("%Y%m%d_%H%M%S")

for p in (MAIN, ML, L10):
    if not p.exists():
        raise FileNotFoundError(f"文件不存在: {p}")
    backup = p.with_suffix(p.suffix + f".bak_{STAMP}")
    shutil.copy2(p, backup)
    print(f"[BACKUP] {backup}")


# ============================================================
# 1. main_strategy.py
# ============================================================

s = MAIN.read_text(encoding="utf-8")


# ------------------------------------------------------------
# 1.1 模型输入：Selector 后继续保留 DataFrame feature names
# ------------------------------------------------------------

old = '''def _prepare_model_input(df_feat, scaler, selector, feature_cols):
    if feature_cols:
        missing = [c for c in feature_cols if c not in df_feat.columns]
        if missing:
            raise ValueError(f"模型依赖特征缺失: {missing}")
        cols = feature_cols
    else:
        cols = [c for c in df_feat.columns if c not in {"timestamp", "datetime"} and pd.api.types.is_numeric_dtype(df_feat[c])]
    row = df_feat[cols].tail(1)
    if row.empty or row.isna().any(axis=1).iloc[0]:
        raise ValueError("最新模型输入包含 NaN")
    scaled = scaler.transform(row)
    selected = selector.transform(scaled)
    return selected
'''

new = '''def _prepare_model_input(df_feat, scaler, selector, feature_cols):
    """准备最新一根确认K线的模型输入，并尽量保留特征名。"""
    if feature_cols:
        missing = [
            c for c in feature_cols
            if c not in df_feat.columns
        ]
        if missing:
            raise ValueError(
                f"模型依赖特征缺失: {missing}"
            )
        cols = list(feature_cols)
    else:
        cols = [
            c
            for c in df_feat.columns
            if c not in {"timestamp", "datetime"}
            and pd.api.types.is_numeric_dtype(df_feat[c])
        ]

    row = df_feat[cols].tail(1).copy()

    if row.empty:
        raise ValueError(
            "最新模型输入为空"
        )

    if row.isna().any(axis=1).iloc[0]:
        bad = [
            c
            for c in row.columns
            if pd.isna(row.iloc[0][c])
        ]
        raise ValueError(
            f"最新模型输入包含 NaN: {bad}"
        )

    scaled = scaler.transform(row)

    try:
        support = selector.get_support(indices=True)
        selected_cols = [
            cols[int(i)]
            for i in support
        ]
    except Exception:
        selected_cols = [
            f"selected_{i}"
            for i in range(scaled.shape[1])
        ]

    selected = selector.transform(scaled)

    return pd.DataFrame(
        selected,
        columns=selected_cols,
        index=row.index,
    )
'''

if old not in s:
    raise RuntimeError(
        "找不到 _prepare_model_input；已停止。"
    )

s = s.replace(old, new, 1)


# ------------------------------------------------------------
# 1.2 实时缓存
# ------------------------------------------------------------

old = '''    hold_counter = {a: 0 for a in assets}
    last_bar = {a: None for a in assets}
    daily_pnl = 0.0
'''

new = '''    hold_counter = {a: 0 for a in assets}
    last_bar = {a: None for a in assets}

    # 同一根15m确认K线：
    # 不重复计算完整特征，不重复运行ML。
    feature_cache = {a: None for a in assets}
    atr_cache = {a: None for a in assets}
    vol_cache = {a: 0.0 for a in assets}
    regime_cache = {a: "unknown" for a in assets}

    daily_pnl = 0.0
'''

if old not in s:
    raise RuntimeError(
        "找不到实时缓存初始化区域；已停止。"
    )

s = s.replace(old, new, 1)


# ------------------------------------------------------------
# 1.3 decision_stats 增加真实信号评估计数
# ------------------------------------------------------------

old = '''    decision_stats = {"bars": 0, "candidate_ge_50": 0, "candidate_ge_55": 0, "candidate_ge_threshold": 0, "candidate_ge_strong": 0, "buy_signals": 0, "entry_reject": 0, "risk_reject": 0, "fills": 0, "reasons": {}}
'''

new = '''    decision_stats = {
        "bars": 0,
        "signal_evaluations": 0,
        "candidate_ge_50": 0,
        "candidate_ge_55": 0,
        "candidate_ge_threshold": 0,
        "candidate_ge_strong": 0,
        "buy_signals": 0,
        "entry_reject": 0,
        "risk_reject": 0,
        "fills": 0,
        "reasons": {},
    }
'''

if old not in s:
    raise RuntimeError(
        "找不到 decision_stats；已停止。"
    )

s = s.replace(old, new, 1)


# ------------------------------------------------------------
# 1.4 替换真实主循环
# ------------------------------------------------------------

loop_start = s.find(
    "            for asset in assets:\n",
    s.find("    while True:")
)

loop_end = s.find(
    "            # 持久化本地状态；它不是成交真相源，成交仍以 executor fill 为准。",
    loop_start
)

if loop_start < 0 or loop_end < 0:
    raise RuntimeError(
        "找不到 main_strategy.py 主资产循环；已停止。"
    )


loop = '''            for asset in assets:
                try:
                    # ========================================================
                    # A. 每30秒只探测最近3根K线
                    # ========================================================
                    probe_raw = collector.fetch_klines_rest(
                        asset,
                        interval=timeframe,
                        limit=3,
                    )

                    if not probe_raw:
                        continue

                    probe_df = cleaner.clean_klines(
                        probe_raw
                    )

                    if probe_df.empty:
                        continue

                    bar_ts = int(
                        probe_df["timestamp"].iloc[-1]
                    )

                    is_new_bar = (
                        bar_ts != last_bar[asset]
                    )

                    # ticker继续每30秒更新
                    ticker = collector.fetch_ticker(
                        asset
                    )

                    current_price = float(
                        ticker
                        or probe_df["close"].iloc[-1]
                    )

                    if current_price <= 0:
                        continue

                    price_cache[asset] = current_price


                    # ========================================================
                    # B. 只有新15m确认K线才拉完整数据、计算64列特征
                    # ========================================================
                    if (
                        is_new_bar
                        or feature_cache[asset] is None
                    ):

                        raw = collector.fetch_klines_rest(
                            asset,
                            interval=timeframe,
                            limit=int(
                                config.get(
                                    "market",
                                    {}
                                ).get(
                                    "lookback",
                                    300
                                )
                            )
                        )

                        if not raw:
                            continue

                        df = cleaner.clean_klines(
                            raw
                        )

                        if len(df) < 80:
                            continue

                        full_bar_ts = int(
                            df["timestamp"].iloc[-1]
                        )

                        if full_bar_ts != bar_ts:
                            logger.debug(
                                "{} probe/full bar不一致: {} != {}，本轮跳过",
                                asset,
                                bar_ts,
                                full_bar_ts,
                            )
                            continue

                        df_feat = (
                            engineer.calculate_features(
                                df
                            )
                        )

                        if df_feat.empty:
                            continue

                        save_klines(
                            asset,
                            raw[-200:]
                        )

                        feature_cache[
                            asset
                        ] = df_feat

                        if (
                            "atr_14"
                            in df_feat.columns
                            and pd.notna(
                                df_feat[
                                    "atr_14"
                                ].iloc[-1]
                            )
                        ):
                            atr = float(
                                df_feat[
                                    "atr_14"
                                ].iloc[-1]
                            )
                        else:
                            atr = (
                                current_price
                                * 0.005
                            )

                        if (
                            "volatility_20"
                            in df_feat.columns
                            and pd.notna(
                                df_feat[
                                    "volatility_20"
                                ].iloc[-1]
                            )
                        ):
                            vol = float(
                                df_feat[
                                    "volatility_20"
                                ].iloc[-1]
                            )
                        else:
                            vol = 0.0

                        try:
                            regime = (
                                regime_detector
                                .detect_regime(
                                    df
                                )["market_regime"]
                            )
                        except Exception:
                            regime = "unknown"

                        atr_cache[
                            asset
                        ] = atr

                        vol_cache[
                            asset
                        ] = vol

                        regime_cache[
                            asset
                        ] = regime

                        last_bar[
                            asset
                        ] = bar_ts

                        decision_stats[
                            "bars"
                        ] += 1

                    else:

                        # 同一根15m：
                        # 完全复用已有特征。
                        df_feat = (
                            feature_cache[
                                asset
                            ]
                        )

                        atr = float(
                            atr_cache[
                                asset
                            ]
                            or current_price * 0.005
                        )

                        vol = float(
                            vol_cache[
                                asset
                            ]
                        )

                        regime = (
                            regime_cache[
                                asset
                            ]
                        )


                    pos = positions[
                        asset
                    ]


                    # ========================================================
                    # C. 持仓管理
                    # ========================================================

                    if pos.state in (
                        PositionState.HOLDING,
                        PositionState.PARTIAL_CLOSE,
                    ):

                        if is_new_bar:
                            hold_counter[
                                asset
                            ] += 1

                        sm[
                            asset
                        ].update_on_price(
                            pos,
                            current_price,
                            df_feat,
                            atr,
                        )

                        exit_due_to_time = (
                            hold_counter[
                                asset
                            ] >= hold_bars_max
                        )

                        if (
                            pos.state
                            in (
                                PositionState.STOPPED,
                                PositionState.PARTIAL_CLOSE,
                            )
                            or exit_due_to_time
                        ):

                            sell_qty = (
                                pos.quantity
                            )

                            if (
                                pos.state
                                == PositionState.PARTIAL_CLOSE
                            ):
                                sell_qty = (
                                    pos.quantity
                                    * sm[
                                        asset
                                    ].partial_close_ratio
                                )

                            if sell_qty > 0:

                                result = (
                                    executor.execute(
                                        {
                                            "symbol": asset,
                                            "side": "SELL",
                                            "quantity": sell_qty,
                                        },
                                        current_price,
                                    )
                                )

                                if result.get(
                                    "executed"
                                ):

                                    fill_price = float(
                                        result[
                                            "fill_price"
                                        ]
                                    )

                                    fill_qty = float(
                                        result.get(
                                            "fill_quantity",
                                            sell_qty,
                                        )
                                    )

                                    pnl = (
                                        trader.apply_fill(
                                            asset,
                                            "SELL",
                                            fill_qty,
                                            fill_price,
                                            result.get(
                                                "fee_usdt",
                                                0.0,
                                            ),
                                        )
                                    )

                                    sm[
                                        asset
                                    ].on_order_filled(
                                        pos,
                                        "SELL",
                                        fill_qty,
                                        fill_price,
                                        atr,
                                    )

                                    trader.record_trade(
                                        asset,
                                        "SELL",
                                        fill_price,
                                        fill_qty,
                                        fill_qty * fill_price,
                                        result.get(
                                            "order_id",
                                            "unknown",
                                        ),
                                        pnl,
                                    )

                                    event_store.append_event(
                                        "ORDER_FILLED",
                                        {
                                            "symbol": asset,
                                            "side": "SELL",
                                            "quantity": fill_qty,
                                            "price": fill_price,
                                            "order_id": result.get(
                                                "order_id"
                                            ),
                                            "pnl": pnl,
                                        },
                                    )

                                    monitor.record_trade(
                                        asset,
                                        "SELL",
                                        pnl,
                                    )

                                    daily_pnl += pnl
                                    daily_trades += 1

                                    hold_counter[
                                        asset
                                    ] = 0

                                    risk_manager.update_trade_result(
                                        pnl > 0
                                    )

                                    log_trade(
                                        asset,
                                        "SELL",
                                        fill_price,
                                        fill_qty,
                                        fill_qty * fill_price,
                                        result.get(
                                            "order_id",
                                            "unknown",
                                        ),
                                        pnl_usdt=pnl,
                                    )

                                    decision_stats[
                                        "fills"
                                    ] += 1

                                    logger.success(
                                        "%s 平仓成交 %.8f @ %.4f PnL=%+.4f",
                                        asset,
                                        fill_qty,
                                        fill_price,
                                        pnl,
                                    )

                                else:

                                    reason = result.get(
                                        "reason",
                                        "unknown",
                                    )

                                    decision_stats[
                                        "reasons"
                                    ][
                                        f"execution:SELL:{reason}"
                                    ] = (
                                        decision_stats[
                                            "reasons"
                                        ].get(
                                            f"execution:SELL:{reason}",
                                            0,
                                        )
                                        + 1
                                    )

                        continue


                    # ========================================================
                    # D. 非空闲状态
                    # ========================================================

                    if pos.state == PositionState.COOLDOWN:
                        sm[
                            asset
                        ].allow_new_entry(pos)

                    if pos.state != PositionState.EMPTY:
                        continue


                    # ========================================================
                    # E. 没有新15m：
                    # 绝对不再运行ML。
                    # ========================================================

                    if not is_new_bar:
                        continue


                    decision_stats[
                        "signal_evaluations"
                    ] += 1


                    # ========================================================
                    # F. AI主模型
                    # ========================================================

                    model, scaler, selector, calibrator, feature_cols = (
                        model_bundles[asset]
                    )

                    if model is None:

                        event_store.append_event(
                            "SIGNAL",
                            {
                                "symbol": asset,
                                "bar_ts": bar_ts,
                                "p_up": 0.5,
                                "direction": "HOLD",
                                "regime": regime,
                                "reason": "model_missing_safe_mode",
                            },
                        )

                        continue


                    X_selected = (
                        _prepare_model_input(
                            df_feat,
                            scaler,
                            selector,
                            feature_cols,
                        )
                    )

                    raw_p_up = float(
                        model.predict_proba(
                            X_selected
                        )[0]
                    )

                    use_calibration = bool(
                        config.get(
                            "signal",
                            {}
                        ).get(
                            "use_probability_calibration",
                            False,
                        )
                    )

                    p_up = (
                        _calibrate_probability(
                            calibrator,
                            raw_p_up,
                        )
                        if use_calibration
                        else max(
                            0.0,
                            min(
                                1.0,
                                raw_p_up,
                            )
                        )
                    )


                    threshold_up = float(
                        config.get(
                            "signal",
                            {}
                        ).get(
                            "threshold_up",
                            0.55,
                        )
                    )

                    strong_threshold_up = float(
                        config.get(
                            "signal",
                            {}
                        ).get(
                            "strong_threshold_up",
                            0.68,
                        )
                    )


                    # ========================================================
                    # G. 信号统计
                    # ========================================================

                    decision_stats[
                        "candidate_ge_50"
                    ] += int(
                        p_up >= 0.50
                    )

                    decision_stats[
                        "candidate_ge_55"
                    ] += int(
                        p_up >= 0.55
                    )

                    decision_stats[
                        "candidate_ge_threshold"
                    ] += int(
                        p_up >= threshold_up
                    )

                    decision_stats[
                        "candidate_ge_strong"
                    ] += int(
                        p_up >= strong_threshold_up
                    )


                    # ========================================================
                    # H. 辅助AI
                    # ========================================================

                    aux_conflict = False

                    if ai_aux[
                        "tcn"
                    ] is not None:

                        try:
                            tcn_p = float(
                                ai_aux[
                                    "tcn"
                                ].predict(
                                    df_feat
                                )
                            )

                            aux_conflict |= (
                                tcn_p < 0.40
                                and p_up >= 0.65
                            )

                        except Exception:
                            tcn_p = None

                    else:
                        tcn_p = None


                    if ai_aux[
                        "transformer"
                    ] is not None:

                        try:
                            tf_p = float(
                                ai_aux[
                                    "transformer"
                                ].predict(
                                    df_feat
                                )
                            )

                            aux_conflict |= (
                                tf_p < 0.40
                                and p_up >= 0.65
                            )

                        except Exception:
                            tf_p = None

                    else:
                        tf_p = None


                    # ========================================================
                    # I. 外部情绪
                    # ========================================================

                    sentiment_adj = 0.0

                    if config.get(
                        "sentiment",
                        {}
                    ).get(
                        "enable",
                        False,
                    ):

                        try:

                            ext = (
                                external
                                .get_combined_sentiment()
                            )

                            sentiment_adj = float(
                                ext.get(
                                    "external_sentiment",
                                    0.0,
                                )
                            )

                        except Exception as exc:

                            logger.debug(
                                "外部情绪不可用: %s",
                                exc,
                            )


                    # ========================================================
                    # J. LLM确认
                    # ========================================================

                    if config.get(
                        "sentiment",
                        {}
                    ).get(
                        "llm_confirmation",
                        False,
                    ):

                        try:

                            llm_result = (
                                llm.run_once(
                                    asset,
                                    df_feat,
                                )
                            )

                            sentiment_adj = max(
                                -1.0,
                                min(
                                    1.0,
                                    sentiment_adj
                                    + float(
                                        llm_result.get(
                                            "sentiment_adj",
                                            0.0,
                                        )
                                    ),
                                ),
                            )

                        except Exception as exc:

                            logger.debug(
                                "LLM确认不可用: %s",
                                exc,
                            )


                    # ========================================================
                    # K. Layer9
                    # ========================================================

                    micro_adj = (
                        micro_analyzer.analyze()
                    )

                    signal = (
                        signal_gen.generate_signal(
                            p_up,
                            micro_adj=micro_adj,
                            sentiment_adj=sentiment_adj,
                            symbol=asset,
                            bar_ts=bar_ts,
                        )
                    )


                    # 这些值只提供给Layer10使用
                    signal[
                        "p_up"
                    ] = p_up

                    signal[
                        "rsi_14"
                    ] = (
                        float(
                            df_feat[
                                "rsi_14"
                            ].iloc[-1]
                        )
                        if (
                            "rsi_14"
                            in df_feat.columns
                            and pd.notna(
                                df_feat[
                                    "rsi_14"
                                ].iloc[-1]
                            )
                        )
                        else 50.0
                    )

                    signal[
                        "bb_pos"
                    ] = (
                        float(
                            df_feat[
                                "bb_pos"
                            ].iloc[-1]
                        )
                        if (
                            "bb_pos"
                            in df_feat.columns
                            and pd.notna(
                                df_feat[
                                    "bb_pos"
                                ].iloc[-1]
                            )
                        )
                        else 0.5
                    )

                    signal[
                        "strong_threshold_up"
                    ] = strong_threshold_up


                    if aux_conflict:

                        signal[
                            "aux_conflict"
                        ] = True

                        signal[
                            "aux_conflict_reason"
                        ] = (
                            "辅助AI冲突，仅记录，不直接否决主模型"
                        )


                    # ========================================================
                    # L. 窄幅反转
                    # ========================================================

                    if (
                        signal["direction"]
                        == "HOLD"
                        and regime == "narrow_range"
                    ):

                        rsi = signal[
                            "rsi_14"
                        ]

                        rsi_prev = (
                            float(
                                df_feat[
                                    "rsi_14"
                                ].iloc[-2]
                            )
                            if (
                                len(df_feat) >= 2
                                and pd.notna(
                                    df_feat[
                                        "rsi_14"
                                    ].iloc[-2]
                                )
                            )
                            else rsi
                        )

                        bb_pos = signal[
                            "bb_pos"
                        ]

                        mr_min = float(
                            config.get(
                                "signal",
                                {}
                            ).get(
                                "mean_reversion_min_prob",
                                threshold_up,
                            )
                        )

                        if (
                            p_up >= mr_min
                            and rsi <= 42
                            and rsi > rsi_prev
                            and bb_pos < 0.35
                        ):

                            signal[
                                "direction"
                            ] = "BUY"

                            signal[
                                "valid"
                            ] = True

                            signal[
                                "reason"
                            ] = (
                                "mean_reversion_confirmed"
                            )

                            signal[
                                "ev_edge"
                            ] = p_up - 0.5


                    # ========================================================
                    # M. 详细信号日志
                    # ========================================================

                    event_store.append_event(
                        "SIGNAL",
                        {
                            "symbol": asset,
                            "bar_ts": bar_ts,
                            "raw_p_up": raw_p_up,
                            "p_up": p_up,
                            "threshold_up": threshold_up,
                            "direction": signal[
                                "direction"
                            ],
                            "regime": regime,
                            "rsi_14": signal[
                                "rsi_14"
                            ],
                            "bb_pos": signal[
                                "bb_pos"
                            ],
                            "tcn_p": tcn_p,
                            "transformer_p": tf_p,
                            "aux_conflict": aux_conflict,
                        },
                    )


                    logger.info(
                        "%s 新15m bar=%s p_up=%.4f th=%.4f edge=%.4f regime=%s rsi=%.1f bb=%.3f signal=%s reason=%s",
                        asset,
                        bar_ts,
                        p_up,
                        threshold_up,
                        float(
                            signal.get(
                                "ev_edge",
                                0.0,
                            )
                        ),
                        regime,
                        signal[
                            "rsi_14"
                        ],
                        signal[
                            "bb_pos"
                        ],
                        signal[
                            "direction"
                        ],
                        signal.get(
                            "reason",
                            "",
                        ),
                    )


                    # ========================================================
                    # N. 非BUY不继续
                    # ========================================================

                    if signal[
                        "direction"
                    ] != "BUY":
                        continue


                    decision_stats[
                        "buy_signals"
                    ] += 1


                    # ========================================================
                    # O. 每日风险保护
                    # ========================================================

                    if daily_trades >= int(
                        config.get(
                            "risk",
                            {}
                        ).get(
                            "max_daily_trades",
                            30,
                        )
                    ):

                        decision_stats[
                            "reasons"
                        ][
                            "risk:max_daily_trades"
                        ] = (
                            decision_stats[
                                "reasons"
                            ].get(
                                "risk:max_daily_trades",
                                0,
                            )
                            + 1
                        )

                        continue


                    if daily_pnl <= (
                        -starting_cash
                        * float(
                            config.get(
                                "risk",
                                {}
                            ).get(
                                "max_daily_loss_rate",
                                0.02,
                            )
                        )
                    ):

                        decision_stats[
                            "reasons"
                        ][
                            "risk:daily_loss_limit"
                        ] = (
                            decision_stats[
                                "reasons"
                            ].get(
                                "risk:daily_loss_limit",
                                0,
                            )
                            + 1
                        )

                        logger.warning(
                            "日亏损熔断，停止开仓"
                        )

                        continue


                    # ========================================================
                    # P. 动态仓位
                    # ========================================================

                    position_notional = (
                        risk_manager.calculate_position_size(
                            asset,
                            "BUY",
                            current_price,
                            atr,
                            trader.capital,
                        )
                    )

                    max_entry = (
                        trader.capital
                        * float(
                            config.get(
                                "risk",
                                {}
                            ).get(
                                "max_single_entry_pct",
                                0.10,
                            )
                        )
                    )

                    position_notional = min(
                        float(
                            position_notional
                            or 0
                        ),
                        max_entry,
                        float(
                            execution_cfg.get(
                                "max_order_value",
                                500,
                            )
                        ),
                    )

                    if position_notional < float(
                        execution_cfg.get(
                            "min_order_value",
                            10,
                        )
                    ):

                        decision_stats[
                            "reasons"
                        ][
                            "risk:position_below_min"
                        ] = (
                            decision_stats[
                                "reasons"
                            ].get(
                                "risk:position_below_min",
                                0,
                            )
                            + 1
                        )

                        continue


                    portfolio = {
                        "total_value": trader.equity(
                            price_cache
                        ),
                        "positions": trader.positions.copy(),
                        "today_pnl": daily_pnl,
                    }


                    # ========================================================
                    # Q. Layer10
                    # ========================================================

                    filter_result = (
                        entry_filter.check(
                            signal,
                            regime,
                            trader.capital,
                            position_notional,
                        )
                    )

                    if not filter_result[
                        "passed"
                    ]:

                        decision_stats[
                            "entry_reject"
                        ] += 1

                        for reason in filter_result.get(
                            "reasons",
                            [],
                        ):

                            key = (
                                f"entry:{reason}"
                            )

                            decision_stats[
                                "reasons"
                            ][key] = (
                                decision_stats[
                                    "reasons"
                                ].get(
                                    key,
                                    0,
                                )
                                + 1
                            )

                        continue


                    # ========================================================
                    # R. RiskFuse
                    # ========================================================

                    order_qty = (
                        position_notional
                        / current_price
                    )

                    order = {
                        "symbol": asset,
                        "side": "BUY",
                        "quantity": order_qty,
                        "notional_usdt": position_notional,
                        "leverage": 1,
                        "order_type": "market",
                        "client_order_id": (
                            f"qa_{asset}_{bar_ts}_{uuid.uuid4().hex[:8]}"
                        ),
                    }

                    market_data = {
                        "current_price": current_price,
                        "prices": price_cache,
                        "volatility": vol,
                        "liquidity_score": 1.0,
                        "panic": (
                            regime
                            == "extreme_liquidation"
                        ),
                    }

                    risk_result = (
                        risk_fuse.check(
                            order,
                            portfolio,
                            market_data,
                        )
                    )

                    if not risk_result[
                        "allowed"
                    ]:

                        decision_stats[
                            "risk_reject"
                        ] += 1

                        for reason in risk_result.get(
                            "reasons",
                            [],
                        ):

                            key = (
                                f"risk:{reason}"
                            )

                            decision_stats[
                                "reasons"
                            ][key] = (
                                decision_stats[
                                    "reasons"
                                ].get(
                                    key,
                                    0,
                                )
                                + 1
                            )

                        continue


                    # ========================================================
                    # S. OKX Executor
                    # ========================================================

                    result = executor.execute(
                        order,
                        current_price,
                    )

                    if not result.get(
                        "executed"
                    ):

                        reason = result.get(
                            "reason",
                            "unknown",
                        )

                        decision_stats[
                            "reasons"
                        ][
                            f"execution:{reason}"
                        ] = (
                            decision_stats[
                                "reasons"
                            ].get(
                                f"execution:{reason}",
                                0,
                            )
                            + 1
                        )

                        continue


                    # ========================================================
                    # T. 只有fill后才更新本地账本
                    # ========================================================

                    fill_price = float(
                        result[
                            "fill_price"
                        ]
                    )

                    fill_qty = float(
                        result.get(
                            "fill_quantity",
                            order_qty,
                        )
                    )

                    trader.apply_fill(
                        asset,
                        "BUY",
                        fill_qty,
                        fill_price,
                        result.get(
                            "fee_usdt",
                            position_notional
                            * fee_rate,
                        ),
                    )

                    sm[
                        asset
                    ].on_order_filled(
                        positions[asset],
                        "BUY",
                        fill_qty,
                        fill_price,
                        atr,
                    )

                    hold_counter[
                        asset
                    ] = 0

                    trader.record_trade(
                        asset,
                        "BUY",
                        fill_price,
                        fill_qty,
                        fill_qty * fill_price,
                        result.get(
                            "order_id",
                            "unknown",
                        ),
                    )

                    event_store.append_event(
                        "ORDER_FILLED",
                        {
                            "symbol": asset,
                            "side": "BUY",
                            "quantity": fill_qty,
                            "price": fill_price,
                            "order_id": result.get(
                                "order_id"
                            ),
                        },
                    )

                    monitor.notify_trade(
                        asset,
                        "BUY",
                        fill_price,
                        fill_qty,
                    )

                    log_trade(
                        asset,
                        "BUY",
                        fill_price,
                        fill_qty,
                        fill_qty * fill_price,
                        result.get(
                            "order_id",
                            "unknown",
                        ),
                    )

                    daily_trades += 1

                    decision_stats[
                        "fills"
                    ] += 1

                    logger.success(
                        "%s 开仓成交 %.8f @ %.4f notional=%.2f order_id=%s",
                        asset,
                        fill_qty,
                        fill_price,
                        fill_qty * fill_price,
                        result.get(
                            "order_id",
                            "unknown",
                        ),
                    )

                except Exception as exc:

                    decision_stats[
                        "reasons"
                    ]["exception"] = (
                        decision_stats[
                            "reasons"
                        ].get(
                            "exception",
                            0,
                        )
                        + 1
                    )

                    logger.error(
                        "处理 %s 异常: %s\\n%s",
                        asset,
                        exc,
                        traceback.format_exc(),
                    )

'''

s = (
    s[:loop_start]
    + loop
    + s[loop_end:]
)


# ------------------------------------------------------------
# 1.5 替换信号漏斗
# ------------------------------------------------------------

old = '''            if decision_stats["bars"] and decision_stats["bars"] % 10 == 0:
                logger.info("信号漏斗 bars=%s p>=.50=%s p>=.55=%s p>=th=%s p>=strong=%s buys=%s entry_reject=%s risk_reject=%s fills=%s reasons=%s", decision_stats["bars"], decision_stats["candidate_ge_50"], decision_stats["candidate_ge_55"], decision_stats["candidate_ge_threshold"], decision_stats["candidate_ge_strong"], decision_stats["buy_signals"], decision_stats["entry_reject"], decision_stats["risk_reject"], decision_stats["fills"], decision_stats["reasons"])
'''

new = '''            evals = decision_stats.get(
                "signal_evaluations",
                0,
            )

            if evals and evals % 3 == 0:
                logger.info(
                    "信号漏斗 confirmed15m=%s eval=%s p>=.50=%s p>=.55=%s p>=th=%s p>=strong=%s buys=%s entry_reject=%s risk_reject=%s fills=%s reasons=%s",
                    decision_stats["bars"],
                    evals,
                    decision_stats["candidate_ge_50"],
                    decision_stats["candidate_ge_55"],
                    decision_stats["candidate_ge_threshold"],
                    decision_stats["candidate_ge_strong"],
                    decision_stats["buy_signals"],
                    decision_stats["entry_reject"],
                    decision_stats["risk_reject"],
                    decision_stats["fills"],
                    decision_stats["reasons"],
                )
'''

if old not in s:
    raise RuntimeError(
        "找不到旧信号漏斗区域；已停止。"
    )

s = s.replace(
    old,
    new,
    1
)


MAIN.write_text(
    s,
    encoding="utf-8"
)


# ============================================================
# 2. Layer6 ML
# ============================================================

m = ML.read_text(
    encoding="utf-8"
)

if "import pandas as pd" not in m:
    m = m.replace(
        "import numpy as np\n",
        "import numpy as np\nimport pandas as pd\n",
        1
    )

old = '''    def predict_proba(self, X):
        X_arr = np.asarray(X)
        available = [(name, model) for name, model in self.models.items() if model is not None]
        if not available:
            raise RuntimeError("没有已加载模型；请先训练或加载已验证的模型 artifact")

        probs = []
        names = []
        for name, model in available:
            try:
                p = model.predict_proba(X_arr)[:, 1]
                probs.append(p)
                names.append(name)
            except Exception as exc:
                logger.warning("模型 %s 预测失败: %s", name, exc)
        if not probs:
            raise RuntimeError("所有模型预测均失败")
        weights = self._normalize_weights(self.model_weights, names)
        return np.sum([weights[n] * p for n, p in zip(names, probs)], axis=0)

    def predict_components(self, X):
        X_arr = np.asarray(X)
        result = {}
        for name, model in self.models.items():
            if model is not None:
                try:
                    result[name] = float(model.predict_proba(X_arr)[0, 1])
                except Exception:
                    continue
        return result
'''

new = '''    @staticmethod
    def _predict_one(model, X):
        if isinstance(X, pd.DataFrame):

            expected = getattr(
                model,
                "feature_names_in_",
                None,
            )

            if expected is not None:
                expected = [
                    str(x)
                    for x in expected
                ]

                current = [
                    str(x)
                    for x in X.columns
                ]

                if expected == current:
                    X_input = X

                elif len(expected) == X.shape[1]:
                    X_input = pd.DataFrame(
                        X.to_numpy(),
                        columns=expected,
                        index=X.index,
                    )

                else:
                    X_input = X.to_numpy()

            else:

                booster = getattr(
                    model,
                    "booster_",
                    None,
                )

                expected = None

                if booster is not None:
                    try:
                        expected = [
                            str(x)
                            for x in booster.feature_name()
                        ]
                    except Exception:
                        expected = None

                if expected and len(expected) == X.shape[1]:

                    X_input = pd.DataFrame(
                        X.to_numpy(),
                        columns=expected,
                        index=X.index,
                    )

                else:
                    X_input = X

        else:
            X_input = np.asarray(X)

        return model.predict_proba(
            X_input
        )[:, 1]


    def predict_proba(self, X):

        available = [
            (name, model)
            for name, model
            in self.models.items()
            if model is not None
        ]

        if not available:
            raise RuntimeError(
                "没有已加载模型；请先训练或加载已验证的模型 artifact"
            )

        probs = []
        names = []

        for name, model in available:

            try:

                p = self._predict_one(
                    model,
                    X,
                )

                probs.append(
                    np.asarray(
                        p,
                        dtype=float,
                    )
                )

                names.append(name)

            except Exception as exc:

                logger.warning(
                    "模型 %s 预测失败: %s",
                    name,
                    exc,
                )

        if not probs:
            raise RuntimeError(
                "所有模型预测均失败"
            )

        weights = self._normalize_weights(
            self.model_weights,
            names,
        )

        return np.sum(
            [
                weights[n] * p
                for n, p
                in zip(
                    names,
                    probs,
                )
            ],
            axis=0,
        )


    def predict_components(self, X):

        result = {}

        for name, model in self.models.items():

            if model is None:
                continue

            try:

                result[name] = float(
                    self._predict_one(
                        model,
                        X,
                    )[0]
                )

            except Exception:
                continue

        return result
'''

if old not in m:
    raise RuntimeError(
        "找不到 Layer6 predict_proba；已停止。"
    )

m = m.replace(
    old,
    new,
    1
)

ML.write_text(
    m,
    encoding="utf-8"
)


# ============================================================
# 3. Layer10
# ============================================================

l = L10.read_text(
    encoding="utf-8"
)

old = '''        if direction == "BUY" and market_regime in {"strong_down", "extreme_liquidation"}:
            passed = False
            reasons.append(f"市场状态 {market_regime} 禁止追多")
'''

new = '''        if direction == "BUY" and market_regime == "strong_down":

            p_up = float(
                signal.get(
                    "p_up",
                    signal.get(
                        "base_p_up",
                        0.5,
                    ),
                )
            )

            strong_threshold = float(
                signal.get(
                    "strong_threshold_up",
                    0.68,
                )
            )

            rsi_14 = float(
                signal.get(
                    "rsi_14",
                    50.0,
                )
            )

            bb_pos = float(
                signal.get(
                    "bb_pos",
                    0.5,
                )
            )

            # strong_down下保留极少数高质量反转机会。
            # 普通BUY继续拒绝。
            countertrend_ok = (
                p_up >= strong_threshold
                and rsi_14 <= 38.0
                and bb_pos <= 0.25
            )

            if not countertrend_ok:

                passed = False

                reasons.append(
                    "strong_down禁止普通追多 "
                    f"(p_up={p_up:.3f}, "
                    f"rsi={rsi_14:.1f}, "
                    f"bb={bb_pos:.3f})"
                )

        if direction == "BUY" and market_regime == "extreme_liquidation":

            passed = False

            reasons.append(
                "极端清算状态下禁止新增多头"
            )
'''

if old not in l:
    raise RuntimeError(
        "找不到 Layer10 strong_down 规则；已停止。"
    )

l = l.replace(
    old,
    new,
    1
)

L10.write_text(
    l,
    encoding="utf-8"
)


# ============================================================
# 4. 最终语法检查
# ============================================================

for p in (MAIN, ML, L10):

    py_compile.compile(
        str(p),
        doraise=True,
    )

    print(
        f"[OK] syntax: {p}"
    )


print()
print("=" * 72)
print("FINAL PATCH V3 SUCCESS")
print("=" * 72)
print()
print("已完成：")
print("1. 同一根15m K线不再重复计算完整64列特征")
print("2. 同一根15m K线不再重复运行ML")
print("3. 每30秒仅探测最新确认K线 + ticker")
print("4. 统计改成真实15m信号评估")
print("5. 保存详细信号漏斗")
print("6. 修复LightGBM/sklearn feature names路径")
print("7. strong_down不再一刀切封杀BUY")
print("8. strong_down仅允许高概率+超卖反转")
print("9. extreme_liquidation继续禁止新增BUY")
print()
print("原文件已经自动备份。")
