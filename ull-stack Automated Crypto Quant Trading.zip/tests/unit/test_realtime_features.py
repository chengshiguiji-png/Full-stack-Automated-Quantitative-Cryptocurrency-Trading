import math
import time

from layers.market_data_bus import MarketDataBus
from layers.fair_probability import FairProbabilityModel


def test_market_bus_keeps_venue_tapes_separate():
    bus = MarketDataBus("BTC-USDT", history_size=20)
    now = time.time()
    bus._update("binance", {"price": 100.0, "trade_ts": now - 5})
    bus._update("binance", {"price": 101.0, "trade_ts": now})
    bus._update("okx", {"price": 100.0, "trade_ts": now - 5})
    bus._update("okx", {"price": 100.5, "trade_ts": now})
    assert bus.binance_return(5) >= 0
    assert bus.okx_return(5) >= 0
    assert len(bus._history["binance"]) == 2
    assert len(bus._history["okx"]) == 2


def test_orderbook_imbalance_is_bounded():
    bus = MarketDataBus()
    bus._update("okx", {
        "bids": [(100.0, 8.0), (99.0, 2.0)],
        "asks": [(101.0, 1.0), (102.0, 1.0)],
    })
    x = bus.okx_flow_imbalance()
    assert 0.0 < x <= 1.0


def test_fair_probability_volatility_shock_only_increases_uncertainty():
    model = FairProbabilityModel()
    base = model.estimate(
        current_price=101.0,
        reference_price=100.0,
        seconds_to_expiry=300,
        sigma_annualized=0.8,
    )
    shocked = model.estimate(
        current_price=101.0,
        reference_price=100.0,
        seconds_to_expiry=300,
        sigma_annualized=0.8,
        volatility_shock=1.0,
    )
    assert shocked["uncertainty"] >= base["uncertainty"]
    assert 0.0 < shocked["fair_probability"] < 1.0
