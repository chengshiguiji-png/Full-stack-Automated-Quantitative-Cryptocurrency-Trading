import json
from pathlib import Path

from layers.polymarket_alpha_engine import PolymarketAlphaEngine
from layers.polymarket_rtds import PolymarketRTDSChainlink


def test_rtds_tick_parser_supports_single_and_batch_payloads():
    single = {"topic": "crypto_prices_chainlink", "payload": {"symbol": "btc/usd", "timestamp": 1000, "value": 70000}}
    assert PolymarketRTDSChainlink._ticks(single)[0]["price"] == 70000
    batch = {"topic": "crypto_prices_chainlink", "payload": {"data": [{"symbol": "btc/usd", "timestamp": 1001, "value": 70001}]}}
    assert PolymarketRTDSChainlink._ticks(batch)[0]["timestamp_ms"] == 1001


def test_alpha_uses_dynamic_crypto_taker_fee():
    engine = PolymarketAlphaEngine({"min_net_edge": 0.0, "fee_rate": 0.07})
    book = {"best_bid": 0.49, "best_ask": 0.50, "asks": [(0.50, 100)], "timestamp": 100.0}
    out = engine.evaluate(fair_probability=0.70, uncertainty=0.0, yes_book=book, no_book=book, requested_size=100, timestamp=100.0)
    assert out["yes"]["fee"] > 1.0
    assert out["yes"]["net_edge"] < out["yes"]["gross_edge"]


def test_shadow_is_marked_non_executing():
    assert True
