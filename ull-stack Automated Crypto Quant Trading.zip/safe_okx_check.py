﻿from pathlib import Path
import os
from dotenv import load_dotenv

print("=" * 72)
print("SAFE OKX CREDENTIAL CHECK")
print("=" * 72)

env = Path(".env")
print(".env =", env.resolve())
print("exists =", env.exists())

if env.exists():
    print("size_bytes =", env.stat().st_size)

load_dotenv(
    dotenv_path=env,
    override=False
)

for name in [
    "OKX_API_KEY",
    "OKX_API_SECRET",
    "OKX_API_PASSPHRASE",
]:
    value = os.getenv(name)
    print(
        name,
        "=",
        "SET" if value else "MISSING",
        f"(length={len(value)})" if value else ""
    )

print(
    "OKX_FLAG =",
    os.getenv("OKX_FLAG")
)

print(
    "OKX_DEMO_TRADING =",
    os.getenv("OKX_DEMO_TRADING")
)

print(
    "OKX_DRY_RUN =",
    os.getenv("OKX_DRY_RUN")
)

print(
    "LIVE_TRADING_ENABLED =",
    os.getenv("LIVE_TRADING_ENABLED")
)

print("=" * 72)
