﻿from pathlib import Path
import re
import shutil
from datetime import datetime

ROOT = Path(__file__).resolve().parent
MAIN = ROOT / "main_strategy.py"
ML = ROOT / "layers" / "layer6_ml_model.py"

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

for src in (MAIN, ML):
    backup = src.with_suffix(src.suffix + f".bak_{stamp}")
    shutil.copy2(src, backup)
    print(f"[BACKUP] {backup.name}")


# ============================================================
# 1. 修复 layer6_ml_model.py
#    目的：
#    - 保留 DataFrame feature names
#    - 兼容旧模型（numpy训练）
#    - 消除 LightGBM / sklearn feature names warning
# ============================================================

ml_code = r'''# -*- coding: utf-8 -*-
"""第6层：多模型 ML 集成。

最终生产原则：
1. 禁止预测阶段自动生成模拟训练数据。
2. 缺失模型不得自动伪造。
3. 保留 DataFrame feature names，避免 LightGBM/sklearn 特征名警告。
4. 兼容旧版 numpy 拟合模型。
5. 模型之间按实际存在模型重新归一化权重。
6. 技术面、情绪、微结构不直接篡改 ML 概率。
"""
from __future__ import annotations

import os
from typing import Dict, Optional

import joblib
import numpy as np
import pandas as pd
from loguru import logger
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
import lightgbm as lgb


class MLModelEnsemble:
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

        self.models = {
            "random_forest": None,
            "logistic": None,
            "lightgbm": None,
        }

        self.model_weights = self.config.get(
            "model_weights",
            self.config.get(
                "model_weight",
                {
                    "random_forest": 0.33,
                    "logistic": 0.33,
                    "lightgbm": 0.34,
                },
            ),
        )

        self.version = "v3.0"
        self.model_dir = self.config.get(
            "model_dir",
            "ml_lib/trained_models",
        )

        os.makedirs(self.model_dir, exist_ok=True)
        self.loaded_from_artifact = False

    @staticmethod
    def _normalize_weights(weights: Dict[str, float], available):
        vals = {
            k: max(0.0, float(weights.get(k, 0.0)))
            for k in available
        }

        total = sum(vals.values())

        if total <= 0:
            w = 1.0 / len(available)
            return {k: w for k in available}

        return {
            k: v / total
            for k, v in vals.items()
        }

    def train(self, X, y):
        if X is None or y is None:
            raise ValueError(
                "训练必须显式提供真实 X/y，不允许自动生成模拟数据"
            )

        X_fit = (
            X.copy()
            if isinstance(X, pd.DataFrame)
            else np.asarray(X)
        )

        y_arr = np.asarray(y)

        if len(X_fit) < 100:
            raise ValueError("训练样本不足100")

        if len(np.unique(y_arr)) < 2:
            raise ValueError("训练标签只有一个类别")

        logger.info(
            "训练 ML ensemble，样本={} 特征={}",
            X_fit.shape[0],
            X_fit.shape[1],
        )

        self.models["random_forest"] = RandomForestClassifier(
            n_estimators=300,
            max_depth=6,
            min_samples_leaf=5,
            class_weight="balanced_subsample",
            random_state=42,
            n_jobs=-1,
        ).fit(X_fit, y_arr)

        self.models["logistic"] = LogisticRegression(
            max_iter=2000,
            class_weight="balanced",
            random_state=42,
        ).fit(X_fit, y_arr)

        self.models["lightgbm"] = lgb.LGBMClassifier(
            n_estimators=250,
            learning_rate=0.04,
            max_depth=5,
            num_leaves=31,
            min_child_samples=30,
            subsample=0.85,
            colsample_bytree=0.85,
            reg_alpha=0.2,
            reg_lambda=1.0,
            random_state=42,
            verbose=-1,
        ).fit(X_fit, y_arr)

        self.loaded_from_artifact = False

        return self.models

    @staticmethod
    def _expected_feature_names(model):
        # sklearn
        names = getattr(model, "feature_names_in_", None)

        if names is not None and len(names):
            return [str(x) for x in names]

        # LightGBM
        booster = getattr(model, "booster_", None)

        if booster is not None:
            try:
                names = booster.feature_name()

                if names:
                    return [str(x) for x in names]
            except Exception:
                pass

        return None

    @classmethod
    def _predict_model_proba(cls, model, X):
        if isinstance(X, pd.DataFrame):
            expected = cls._expected_feature_names(model)
            current = [str(x) for x in X.columns]

            # 新模型：训练和预测特征名一致
            if expected and expected == current:
                return model.predict_proba(X)[:, 1]

            # 老模型：可能用 numpy 拟合，没有可匹配列名
            return model.predict_proba(X.to_numpy())[:, 1]

        return model.predict_proba(np.asarray(X))[:, 1]

    def load_models(self):
        loaded = False

        for name in self.models:
            path = os.path.join(
                self.model_dir,
                f"{name}_{self.version}.pkl",
            )

            if os.path.exists(path):
                try:
                    self.models[name] = joblib.load(path)
                    loaded = True

                    logger.info(
                        "加载模型成功: {}",
                        path,
                    )

                except Exception as exc:
                    logger.error(
                        "加载模型失败 {}: {}",
                        path,
                        exc,
                    )

        self.loaded_from_artifact = loaded
        return loaded

    def predict_proba(self, X):
        available = [
            (name, model)
            for name, model in self.models.items()
            if model is not None
        ]

        if not available:
            raise RuntimeError(
                "没有已加载模型；请先训练或加载已验证的模型 artifact"
            )

        probs = []
        names = []

        for name, model in available:
            try:
                p = self._predict_model_proba(model, X)
                probs.append(np.asarray(p, dtype=float))
                names.append(name)

            except Exception as exc:
                logger.warning(
                    "模型 {} 预测失败: {}",
                    name,
                    exc,
                )

        if not probs:
            raise RuntimeError(
                "所有模型预测均失败"
            )

        weights = self._normalize_weights(
            self.model_weights,
            names,
        )

        return np.sum(
            [
                weights[name] * p
                for name, p in zip(names, probs)
            ],
            axis=0,
        )

    def predict_components(self, X):
        result = {}

        for name, model in self.models.items():
            if model is None:
                continue

            try:
                p = self._predict_model_proba(model, X)

                result[name] = float(p[0])

            except Exception as exc:
                logger.debug(
                    "组件模型 {} 预测失败: {}",
                    name,
                    exc,
                )

        return result

    def save_models(self):
        os.makedirs(self.model_dir, exist_ok=True)

        for name, model in self.models.items():
            if model is not None:
                joblib.dump(
                    model,
                    os.path.join(
                        self.model_dir,
                        f"{name}_{self.version}.pkl",
                    ),
                )

    @staticmethod
    def evaluate_binary(y_true, p_up):
        y_true = np.asarray(y_true)

        p_up = np.clip(
            np.asarray(p_up),
            1e-6,
            1 - 1e-6,
        )

        pred = (
            p_up >= 0.5
        ).astype(int)

        return {
            "accuracy": float(
                (pred == y_true).mean()
            ),
            "logloss": float(
                log_loss(y_true, p_up)
            ),
        }
'''

ML.write_text(ml_code, encoding="utf-8")


# ============================================================
# 2. 修改 main_strategy.py
# ============================================================

s = MAIN.read_text(encoding="utf-8")


# ---------- 2.1 替换 _prepare_model_input ----------

pattern_prepare = re.compile(
    r"def _prepare_model_input\(df_feat, scaler, selector, feature_cols\):.*?"
    r"\n\n\ndef _load_optional_ai",
    re.S,
)

replacement_prepare = r'''def _prepare_model_input(df_feat, scaler, selector, feature_cols):
    """准备单行模型输入，并尽可能保留选中特征名。"""
    if feature_cols:
        missing = [
            c for c in feature_cols
            if c not in df_feat.columns
        ]

        if missing:
            raise ValueError(
                f"模型依赖特征缺失: {missing}"
            )

        cols = list(feature_cols)

    else:
        cols = [
            c
            for c in df_feat.columns
            if c not in {"timestamp", "datetime"}
            and pd.api.types.is_numeric_dtype(
                df_feat[c]
            )
        ]

    row = df_feat[cols].tail(1).copy()

    if row.empty:
        raise ValueError(
            "最新模型输入为空"
        )

    if row.isna().any(axis=1).iloc[0]:
        bad_cols = [
            c
            for c in row.columns
            if pd.isna(row.iloc[0][c])
        ]

        raise ValueError(
            f"最新模型输入包含 NaN: {bad_cols}"
        )

    scaled = scaler.transform(row)

    if hasattr(selector, "get_support"):
        try:
            support = selector.get_support(
                indices=True
            )

            selected_cols = [
                cols[int(i)]
                for i in support
            ]

        except Exception:
            selected_cols = [
                f"selected_{i}"
                for i in range(scaled.shape[1])
            ]
    else:
        selected_cols = [
            f"selected_{i}"
            for i in range(scaled.shape[1])
        ]

    selected = selector.transform(
        scaled
    )

    return pd.DataFrame(
        selected,
        columns=selected_cols,
        index=row.index,
    )


def _load_optional_ai'''

s2, n = pattern_prepare.subn(
    replacement_prepare,
    s,
)

if n != 1:
    raise RuntimeError(
        "无法定位 _prepare_model_input，请不要继续执行。"
    )

s = s2


# ---------- 2.2 增加实时缓存变量 ----------

old_cache = '''    last_bar = {a: None for a in assets}
    daily_pnl = 0.0
'''

new_cache = '''    last_bar = {a: None for a in assets}

    # 实时循环优化：
    # - feature_cache：同一根15m K线不重复计算
    # - atr_cache：持仓期间30秒轮询直接复用
    # - volatility_cache：风险监控复用
    # - regime_cache：同理
    feature_cache = {a: None for a in assets}
    atr_cache = {a: None for a in assets}
    volatility_cache = {a: 0.0 for a in assets}
    regime_cache = {a: "unknown" for a in assets}

    daily_pnl = 0.0
'''

if old_cache not in s:
    raise RuntimeError(
        "无法找到 last_bar 初始化位置。"
    )

s = s.replace(
    old_cache,
    new_cache,
    1,
)


# ---------- 2.3 替换 statistics ----------

old_stats = '''    decision_stats = {
        "bars": 0,
        "candidate_ge_50": 0,
        "candidate_ge_55": 0,
        "candidate_ge_threshold": 0,
        "candidate_ge_strong": 0,
        "buy_signals": 0,
        "entry_reject": 0,
        "risk_reject": 0,
        "fills": 0,
        "reasons": {},
    }
'''

new_stats = '''    decision_stats = {
        # confirmed_bars = 真正的新15m确认K线
        # signal_evaluations = 实际跑ML/Signal的次数
        # 不再把30秒轮询次数当成样本数
        "confirmed_bars": 0,
        "signal_evaluations": 0,
        "candidate_ge_50": 0,
        "candidate_ge_55": 0,
        "candidate_ge_threshold": 0,
        "candidate_ge_strong": 0,
        "buy_signals": 0,
        "entry_reject": 0,
        "risk_reject": 0,
        "execution_reject": 0,
        "fills": 0,
        "errors": 0,
        "reasons": {},
    }
'''

if old_stats not in s:
    raise RuntimeError(
        "无法找到 decision_stats。"
    )

s = s.replace(
    old_stats,
    new_stats,
    1,
)


# ---------- 2.4 替换主循环中的 for asset ----------

start_marker = "            for asset in assets:\n"
end_marker = "            # 持久化本地状态；它不是成交真相源"

start = s.find(
    start_marker,
    s.find("    while True:")
)

end = s.find(
    end_marker,
    start,
)

if start < 0 or end < 0:
    raise RuntimeError(
        "无法定位 main_strategy.py 的资产循环。"
    )

new_asset_loop = r'''            for asset in assets:
                try:
                    # ========================================================
                    # A. 轻量K线探测
                    # 每30秒只拿最近3根已确认K线。
                    # 不再每30秒重复做299行/64列完整特征工程。
                    # ========================================================
                    probe_raw = collector.fetch_klines_rest(
                        asset,
                        interval=timeframe,
                        limit=3,
                    )

                    if not probe_raw:
                        decision_stats["reasons"]["data:probe_empty"] = (
                            decision_stats["reasons"].get(
                                "data:probe_empty",
                                0,
                            )
                            + 1
                        )
                        continue

                    probe_df = cleaner.clean_klines(
                        probe_raw
                    )

                    if probe_df.empty:
                        decision_stats["reasons"]["data:no_confirmed_bar"] = (
                            decision_stats["reasons"].get(
                                "data:no_confirmed_bar",
                                0,
                            )
                            + 1
                        )
                        continue

                    bar_ts = int(
                        probe_df["timestamp"].iloc[-1]
                    )

                    # ========================================================
                    # B. ticker 每30秒更新
                    # 持仓管理需要实时价格。
                    # ========================================================
                    ticker = collector.fetch_ticker(
                        asset
                    )

                    current_price = float(
                        ticker
                        or probe_df["close"].iloc[-1]
                    )

                    if current_price <= 0:
                        decision_stats["reasons"]["data:invalid_price"] = (
                            decision_stats["reasons"].get(
                                "data:invalid_price",
                                0,
                            )
                            + 1
                        )
                        continue

                    price_cache[asset] = current_price

                    is_new_bar = (
                        last_bar[asset] != bar_ts
                    )

                    pos = positions[asset]

                    # ========================================================
                    # C. 持仓管理
                    #
                    # 同一根15m K线：
                    # - 不重复计算特征
                    # - 不重复跑ML
                    # - 只监控实时ticker
                    #
                    # 新15m K线：
                    # - 刷新一次完整特征
                    # - 更新ATR
                    # - 更新market regime
                    # ========================================================
                    if pos.state in (
                        PositionState.HOLDING,
                        PositionState.PARTIAL_CLOSE,
                    ):
                        if is_new_bar:
                            raw = collector.fetch_klines_rest(
                                asset,
                                interval=timeframe,
                                limit=int(
                                    config.get(
                                        "market",
                                        {},
                                    ).get(
                                        "lookback",
                                        300,
                                    )
                                ),
                            )

                            if raw:
                                df = cleaner.clean_klines(
                                    raw
                                )

                                if len(df) >= 80:
                                    df_feat = (
                                        engineer.calculate_features(
                                            df
                                        )
                                    )

                                    if not df_feat.empty:
                                        feature_cache[asset] = df_feat

                                        if (
                                            "atr_14"
                                            in df_feat.columns
                                            and pd.notna(
                                                df_feat[
                                                    "atr_14"
                                                ].iloc[-1]
                                            )
                                        ):
                                            atr_cache[asset] = float(
                                                df_feat[
                                                    "atr_14"
                                                ].iloc[-1]
                                            )
                                        else:
                                            atr_cache[asset] = (
                                                current_price * 0.005
                                            )

                                        if (
                                            "volatility_20"
                                            in df_feat.columns
                                            and pd.notna(
                                                df_feat[
                                                    "volatility_20"
                                                ].iloc[-1]
                                            )
                                        ):
                                            volatility_cache[asset] = float(
                                                df_feat[
                                                    "volatility_20"
                                                ].iloc[-1]
                                            )
                                        else:
                                            volatility_cache[asset] = 0.0

                                        try:
                                            regime_cache[asset] = (
                                                regime_detector.detect_regime(
                                                    df
                                                )["market_regime"]
                                            )
                                        except Exception:
                                            regime_cache[asset] = "unknown"

                                        save_klines(
                                            asset,
                                            raw[-200:],
                                        )

                            hold_counter[asset] += 1
                            last_bar[asset] = bar_ts
                            decision_stats[
                                "confirmed_bars"
                            ] += 1

                        df_feat = feature_cache.get(
                            asset
                        )

                        atr = float(
                            atr_cache.get(asset)
                            or current_price * 0.005
                        )

                        # 实时价格风控，复用最近确认K线的特征
                        if (
                            df_feat is not None
                            and not df_feat.empty
                        ):
                            sm[asset].update_on_price(
                                pos,
                                current_price,
                                df_feat,
                                atr,
                            )

                        exit_due_to_time = (
                            hold_counter[asset]
                            >= hold_bars_max
                        )

                        if (
                            pos.state
                            in (
                                PositionState.STOPPED,
                                PositionState.PARTIAL_CLOSE,
                            )
                            or exit_due_to_time
                        ):
                            sell_qty = pos.quantity

                            if (
                                pos.state
                                == PositionState.PARTIAL_CLOSE
                            ):
                                sell_qty = (
                                    pos.quantity
                                    * sm[
                                        asset
                                    ].partial_close_ratio
                                )

                            if sell_qty > 0:
                                result = executor.execute(
                                    {
                                        "symbol": asset,
                                        "side": "SELL",
                                        "quantity": sell_qty,
                                    },
                                    current_price,
                                )

                                if result.get("executed"):
                                    fill_price = float(
                                        result["fill_price"]
                                    )

                                    fill_qty = float(
                                        result.get(
                                            "fill_quantity",
                                            sell_qty,
                                        )
                                    )

                                    pnl = trader.apply_fill(
                                        asset,
                                        "SELL",
                                        fill_qty,
                                        fill_price,
                                        result.get(
                                            "fee_usdt",
                                            0.0,
                                        ),
                                    )

                                    sm[asset].on_order_filled(
                                        pos,
                                        "SELL",
                                        fill_qty,
                                        fill_price,
                                        atr,
                                    )

                                    trader.record_trade(
                                        asset,
                                        "SELL",
                                        fill_price,
                                        fill_qty,
                                        fill_qty * fill_price,
                                        result.get(
                                            "order_id",
                                            "unknown",
                                        ),
                                        pnl,
                                    )

                                    event_store.append_event(
                                        "ORDER_FILLED",
                                        {
                                            "symbol": asset,
                                            "side": "SELL",
                                            "quantity": fill_qty,
                                            "price": fill_price,
                                            "order_id": result.get(
                                                "order_id"
                                            ),
                                            "pnl": pnl,
                                        },
                                    )

                                    monitor.record_trade(
                                        asset,
                                        "SELL",
                                        pnl,
                                    )

                                    daily_pnl += pnl
                                    daily_trades += 1
                                    hold_counter[asset] = 0

                                    risk_manager.update_trade_result(
                                        pnl > 0
                                    )

                                    log_trade(
                                        asset,
                                        "SELL",
                                        fill_price,
                                        fill_qty,
                                        fill_qty * fill_price,
                                        result.get(
                                            "order_id",
                                            "unknown",
                                        ),
                                        pnl_usdt=pnl,
                                    )

                                    decision_stats[
                                        "fills"
                                    ] += 1

                                    logger.success(
                                        "{} 平仓成交 {:.8f} @ {:.4f} PnL={:+.4f}",
                                        asset,
                                        fill_qty,
                                        fill_price,
                                        pnl,
                                    )

                                else:
                                    decision_stats[
                                        "execution_reject"
                                    ] += 1

                                    event_store.add_to_dlq(
                                        {
                                            "symbol": asset,
                                            "side": "SELL",
                                            "quantity": sell_qty,
                                        }
                                    )

                        continue

                    # ========================================================
                    # D. 冷却 / 非空闲状态
                    # ========================================================
                    if pos.state == PositionState.COOLDOWN:
                        sm[asset].allow_new_entry(pos)

                    if pos.state != PositionState.EMPTY:
                        if is_new_bar:
                            last_bar[asset] = bar_ts
                            decision_stats[
                                "confirmed_bars"
                            ] += 1
                        continue

                    # ========================================================
                    # E. 空仓：
                    # 没有新15m确认K线，完全跳过特征和ML。
                    # ========================================================
                    if not is_new_bar:
                        continue

                    # ========================================================
                    # F. 只有真正的新15m K线，才做完整特征工程
                    # ========================================================
                    raw = collector.fetch_klines_rest(
                        asset,
                        interval=timeframe,
                        limit=int(
                            config.get(
                                "market",
                                {},
                            ).get(
                                "lookback",
                                300,
                            )
                        ),
                    )

                    if not raw:
                        decision_stats["reasons"]["data:full_fetch_empty"] = (
                            decision_stats["reasons"].get(
                                "data:full_fetch_empty",
                                0,
                            )
                            + 1
                        )
                        continue

                    df = cleaner.clean_klines(
                        raw
                    )

                    if len(df) < 80:
                        decision_stats["reasons"]["data:insufficient_bars"] = (
                            decision_stats["reasons"].get(
                                "data:insufficient_bars",
                                0,
                            )
                            + 1
                        )
                        continue

                    full_bar_ts = int(
                        df["timestamp"].iloc[-1]
                    )

                    # 探测K线和完整K线必须一致
                    if full_bar_ts != bar_ts:
                        logger.debug(
                            "{} probe/full bar_ts 不一致: probe={} full={}",
                            asset,
                            bar_ts,
                            full_bar_ts,
                        )
                        continue

                    df_feat = engineer.calculate_features(
                        df
                    )

                    if df_feat.empty:
                        decision_stats["reasons"]["data:features_empty"] = (
                            decision_stats["reasons"].get(
                                "data:features_empty",
                                0,
                            )
                            + 1
                        )
                        continue

                    save_klines(
                        asset,
                        raw[-200:],
                    )

                    # ========================================================
                    # G. 缓存本根K线的特征
                    # ========================================================
                    feature_cache[asset] = df_feat

                    if (
                        "atr_14" in df_feat.columns
                        and pd.notna(
                            df_feat[
                                "atr_14"
                            ].iloc[-1]
                        )
                    ):
                        atr = float(
                            df_feat[
                                "atr_14"
                            ].iloc[-1]
                        )
                    else:
                        atr = current_price * 0.005

                    if (
                        "volatility_20"
                        in df_feat.columns
                        and pd.notna(
                            df_feat[
                                "volatility_20"
                            ].iloc[-1]
                        )
                    ):
                        vol = float(
                            df_feat[
                                "volatility_20"
                            ].iloc[-1]
                        )
                    else:
                        vol = 0.0

                    atr_cache[asset] = atr
                    volatility_cache[asset] = vol

                    try:
                        regime_info = (
                            regime_detector.detect_regime(
                                df
                            )
                        )

                        regime = regime_info[
                            "market_regime"
                        ]

                    except Exception:
                        regime = "unknown"

                    regime_cache[asset] = regime

                    last_bar[asset] = bar_ts

                    decision_stats[
                        "confirmed_bars"
                    ] += 1

                    decision_stats[
                        "signal_evaluations"
                    ] += 1

                    # ========================================================
                    # H. ML
                    # ========================================================
                    model, scaler, selector, calibrator, feature_cols = (
                        model_bundles[asset]
                    )

                    if model is None:
                        event_store.append_event(
                            "SIGNAL",
                            {
                                "symbol": asset,
                                "bar_ts": bar_ts,
                                "p_up": 0.5,
                                "direction": "HOLD",
                                "regime": regime,
                                "reason": "model_missing_safe_mode",
                            },
                        )

                        logger.warning(
                            "{} bar={} 模型缺失，SAFE HOLD",
                            asset,
                            bar_ts,
                        )

                        continue

                    X_selected = _prepare_model_input(
                        df_feat,
                        scaler,
                        selector,
                        feature_cols,
                    )

                    raw_p_up = float(
                        model.predict_proba(
                            X_selected
                        )[0]
                    )

                    use_calibration = bool(
                        config.get(
                            "signal",
                            {},
                        ).get(
                            "use_probability_calibration",
                            False,
                        )
                    )

                    p_up = (
                        _calibrate_probability(
                            calibrator,
                            raw_p_up,
                        )
                        if use_calibration
                        else max(
                            0.0,
                            min(
                                1.0,
                                raw_p_up,
                            ),
                        )
                    )

                    threshold_up = float(
                        config.get(
                            "signal",
                            {},
                        ).get(
                            "threshold_up",
                            0.55,
                        )
                    )

                    strong_up = float(
                        config.get(
                            "signal",
                            {},
                        ).get(
                            "strong_threshold_up",
                            0.68,
                        )
                    )

                    decision_stats[
                        "candidate_ge_50"
                    ] += int(
                        p_up >= 0.50
                    )

                    decision_stats[
                        "candidate_ge_55"
                    ] += int(
                        p_up >= 0.55
                    )

                    decision_stats[
                        "candidate_ge_threshold"
                    ] += int(
                        p_up >= threshold_up
                    )

                    decision_stats[
                        "candidate_ge_strong"
                    ] += int(
                        p_up >= strong_up
                    )

                    # ========================================================
                    # I. 辅助AI：只记录，不修改主概率
                    # ========================================================
                    aux_conflict = False

                    if ai_aux["tcn"] is not None:
                        try:
                            tcn_p = float(
                                ai_aux[
                                    "tcn"
                                ].predict(
                                    df_feat
                                )
                            )

                            aux_conflict |= (
                                tcn_p < 0.40
                                and p_up >= 0.65
                            )

                        except Exception:
                            tcn_p = None

                    else:
                        tcn_p = None

                    if ai_aux[
                        "transformer"
                    ] is not None:
                        try:
                            tf_p = float(
                                ai_aux[
                                    "transformer"
                                ].predict(
                                    df_feat
                                )
                            )

                            aux_conflict |= (
                                tf_p < 0.40
                                and p_up >= 0.65
                            )

                        except Exception:
                            tf_p = None

                    else:
                        tf_p = None

                    # ========================================================
                    # J. 情绪
                    # ========================================================
                    sentiment_adj = 0.0
                    sentiment_conf = 0.0

                    if config.get(
                        "sentiment",
                        {},
                    ).get(
                        "enable",
                        False,
                    ):
                        try:
                            ext = (
                                external.get_combined_sentiment()
                            )

                            sentiment_adj = float(
                                ext.get(
                                    "external_sentiment",
                                    0.0,
                                )
                            )

                            sentiment_conf = float(
                                ext.get(
                                    "external_confidence",
                                    0.0,
                                )
                            )

                        except Exception as exc:
                            logger.debug(
                                "外部情绪不可用: {}",
                                exc,
                            )

                    if config.get(
                        "sentiment",
                        {},
                    ).get(
                        "llm_confirmation",
                        False,
                    ):
                        try:
                            llm_result = (
                                llm.run_once(
                                    asset,
                                    df_feat,
                                )
                            )

                            sentiment_adj = max(
                                -1.0,
                                min(
                                    1.0,
                                    sentiment_adj
                                    + float(
                                        llm_result.get(
                                            "sentiment_adj",
                                            0.0,
                                        )
                                    ),
                                ),
                            )

                        except Exception as exc:
                            logger.debug(
                                "LLM确认不可用: {}",
                                exc,
                            )

                    # ========================================================
                    # K. 主信号
                    # ========================================================
                    micro_adj = (
                        micro_analyzer.analyze()
                    )

                    signal = (
                        signal_gen.generate_signal(
                            p_up,
                            micro_adj=micro_adj,
                            sentiment_adj=sentiment_adj,
                            symbol=asset,
                            bar_ts=bar_ts,
                        )
                    )

                    if aux_conflict:
                        signal["aux_conflict"] = True
                        signal[
                            "aux_conflict_reason"
                        ] = (
                            "独立AI确认冲突，仅记录，不直接否决主模型"
                        )

                    # ========================================================
                    # L. 窄幅反转辅助策略
                    # ========================================================
                    if (
                        signal["direction"]
                        == "HOLD"
                        and regime
                        == "narrow_range"
                    ):
                        rsi = float(
                            df_feat[
                                "rsi_14"
                            ].iloc[-1]
                        )

                        rsi_prev = float(
                            df_feat[
                                "rsi_14"
                            ].iloc[-2]
                        )

                        bb_pos = float(
                            df_feat[
                                "bb_pos"
                            ].iloc[-1]
                        ) if pd.notna(
                            df_feat[
                                "bb_pos"
                            ].iloc[-1]
                        ) else 0.5

                        mr_min = float(
                            config.get(
                                "signal",
                                {},
                            ).get(
                                "mean_reversion_min_prob",
                                threshold_up,
                            )
                        )

                        if (
                            p_up >= mr_min
                            and rsi <= 42
                            and rsi > rsi_prev
                            and bb_pos < 0.35
                        ):
                            signal[
                                "direction"
                            ] = "BUY"

                            signal[
                                "valid"
                            ] = True

                            signal[
                                "reason"
                            ] = "mean_reversion_confirmed"

                            signal[
                                "ev_edge"
                            ] = p_up - 0.5

                    # ========================================================
                    # M. 信号日志
                    # ========================================================
                    event_store.append_event(
                        "SIGNAL",
                        {
                            "symbol": asset,
                            "bar_ts": bar_ts,
                            "raw_p_up": raw_p_up,
                            "p_up": p_up,
                            "threshold_up": threshold_up,
                            "direction": signal[
                                "direction"
                            ],
                            "regime": regime,
                            "tcn_p": tcn_p,
                            "transformer_p": tf_p,
                            "aux_conflict": aux_conflict,
                        },
                    )

                    logger.info(
                        "{} 新15m bar={} p_up={:.4f} "
                        "th={:.4f} edge={:.4f} "
                        "regime={} signal={} reason={}",
                        asset,
                        bar_ts,
                        p_up,
                        threshold_up,
                        float(
                            signal.get(
                                "ev_edge",
                                0.0,
                            )
                        ),
                        regime,
                        signal[
                            "direction"
                        ],
                        signal.get(
                            "reason",
                            "",
                        ),
                    )

                    # ========================================================
                    # N. 非 BUY 不开仓
                    # ========================================================
                    if signal[
                        "direction"
                    ] != "BUY":
                        continue

                    decision_stats[
                        "buy_signals"
                    ] += 1

                    # ========================================================
                    # O. 每日风险保护
                    # ========================================================
                    if daily_trades >= int(
                        config.get(
                            "risk",
                            {},
                        ).get(
                            "max_daily_trades",
                            30,
                        )
                    ):
                        decision_stats[
                            "reasons"
                        ][
                            "risk:max_daily_trades"
                        ] = (
                            decision_stats[
                                "reasons"
                            ].get(
                                "risk:max_daily_trades",
                                0,
                            )
                            + 1
                        )

                        continue

                    if daily_pnl <= (
                        -starting_cash
                        * float(
                            config.get(
                                "risk",
                                {},
                            ).get(
                                "max_daily_loss_rate",
                                0.02,
                            )
                        )
                    ):
                        decision_stats[
                            "reasons"
                        ][
                            "risk:daily_loss_limit"
                        ] = (
                            decision_stats[
                                "reasons"
                            ].get(
                                "risk:daily_loss_limit",
                                0,
                            )
                            + 1
                        )

                        logger.warning(
                            "日亏损熔断，停止开仓"
                        )

                        continue

                    # ========================================================
                    # P. 仓位计算
                    # ========================================================
                    position_notional = (
                        risk_manager.calculate_position_size(
                            asset,
                            "BUY",
                            current_price,
                            atr,
                            trader.capital,
                        )
                    )

                    max_entry = (
                        trader.capital
                        * float(
                            config.get(
                                "risk",
                                {},
                            ).get(
                                "max_single_entry_pct",
                                0.10,
                            )
                        )
                    )

                    position_notional = min(
                        float(
                            position_notional
                            or 0
                        ),
                        max_entry,
                    )

                    max_order_value = float(
                        execution_cfg.get(
                            "max_order_value",
                            500,
                        )
                    )

                    position_notional = min(
                        position_notional,
                        max_order_value,
                    )

                    min_order_value = float(
                        execution_cfg.get(
                            "min_order_value",
                            10,
                        )
                    )

                    if position_notional < min_order_value:
                        decision_stats[
                            "reasons"
                        ][
                            "risk:position_below_min"
                        ] = (
                            decision_stats[
                                "reasons"
                            ].get(
                                "risk:position_below_min",
                                0,
                            )
                            + 1
                        )

                        continue

                    # ========================================================
                    # Q. Entry Filter
                    # ========================================================
                    portfolio = {
                        "total_value": trader.equity(
                            price_cache
                        ),
                        "positions": trader.positions.copy(),
                        "today_pnl": daily_pnl,
                    }

                    filter_result = (
                        entry_filter.check(
                            signal,
                            regime,
                            trader.capital,
                            position_notional,
                        )
                    )

                    if not filter_result[
                        "passed"
                    ]:
                        decision_stats[
                            "entry_reject"
                        ] += 1

                        for reason in filter_result.get(
                            "reasons",
                            [],
                        ):
                            key = (
                                f"entry:{reason}"
                            )

                            decision_stats[
                                "reasons"
                            ][key] = (
                                decision_stats[
                                    "reasons"
                                ].get(
                                    key,
                                    0,
                                )
                                + 1
                            )

                        continue

                    # ========================================================
                    # R. Risk Fuse
                    # ========================================================
                    order_qty = (
                        position_notional
                        / current_price
                    )

                    order = {
                        "symbol": asset,
                        "side": "BUY",
                        "quantity": order_qty,
                        "notional_usdt": position_notional,
                        "leverage": 1,
                        "order_type": "market",
                        "client_order_id": (
                            f"qa_{asset}_{bar_ts}_"
                            f"{uuid.uuid4().hex[:8]}"
                        ),
                    }

                    market_data = {
                        "current_price": current_price,
                        "prices": price_cache,
                        "volatility": vol,
                        "liquidity_score": 1.0,
                        "panic": (
                            regime
                            == "extreme_liquidation"
                        ),
                    }

                    risk_result = (
                        risk_fuse.check(
                            order,
                            portfolio,
                            market_data,
                        )
                    )

                    if not risk_result[
                        "allowed"
                    ]:
                        decision_stats[
                            "risk_reject"
                        ] += 1

                        for reason in risk_result.get(
                            "reasons",
                            [],
                        ):
                            key = (
                                f"risk:{reason}"
                            )

                            decision_stats[
                                "reasons"
                            ][key] = (
                                decision_stats[
                                    "reasons"
                                ].get(
                                    key,
                                    0,
                                )
                                + 1
                            )

                        continue

                    # ========================================================
                    # S. OKX执行
                    # ========================================================
                    result = executor.execute(
                        order,
                        current_price,
                    )

                    if not result.get(
                        "executed"
                    ):
                        decision_stats[
                            "execution_reject"
                        ] += 1

                        reason = result.get(
                            "reason",
                            "unknown",
                        )

                        key = (
                            f"execution:{reason}"
                        )

                        decision_stats[
                            "reasons"
                        ][key] = (
                            decision_stats[
                                "reasons"
                            ].get(
                                key,
                                0,
                            )
                            + 1
                        )

                        event_store.add_to_dlq(
                            {
                                "symbol": asset,
                                "side": "BUY",
                                "quantity": order_qty,
                            }
                        )

                        logger.warning(
                            "{} 下单未成交: {}",
                            asset,
                            reason,
                        )

                        continue

                    # ========================================================
                    # T. 只有真实 fill 后才记账
                    # ========================================================
                    fill_price = float(
                        result["fill_price"]
                    )

                    fill_qty = float(
                        result.get(
                            "fill_quantity",
                            order_qty,
                        )
                    )

                    trader.apply_fill(
                        asset,
                        "BUY",
                        fill_qty,
                        fill_price,
                        result.get(
                            "fee_usdt",
                            position_notional * fee_rate,
                        ),
                    )

                    sm[asset].on_order_filled(
                        positions[asset],
                        "BUY",
                        fill_qty,
                        fill_price,
                        atr,
                    )

                    hold_counter[
                        asset
                    ] = 0

                    trader.record_trade(
                        asset,
                        "BUY",
                        fill_price,
                        fill_qty,
                        fill_qty * fill_price,
                        result.get(
                            "order_id",
                            "unknown",
                        ),
                    )

                    event_store.append_event(
                        "ORDER_FILLED",
                        {
                            "symbol": asset,
                            "side": "BUY",
                            "quantity": fill_qty,
                            "price": fill_price,
                            "order_id": result.get(
                                "order_id"
                            ),
                        },
                    )

                    monitor.notify_trade(
                        asset,
                        "BUY",
                        fill_price,
                        fill_qty,
                    )

                    log_trade(
                        asset,
                        "BUY",
                        fill_price,
                        fill_qty,
                        fill_qty * fill_price,
                        result.get(
                            "order_id",
                            "unknown",
                        ),
                    )

                    daily_trades += 1

                    decision_stats[
                        "fills"
                    ] += 1

                    logger.success(
                        "{} 开仓成交 {:.8f} @ {:.4f} "
                        "notional={:.2f} order_id={}",
                        asset,
                        fill_qty,
                        fill_price,
                        fill_qty * fill_price,
                        result.get(
                            "order_id",
                            "unknown",
                        ),
                    )

                except Exception as exc:
                    decision_stats[
                        "errors"
                    ] += 1

                    logger.error(
                        "处理 {} 异常: {}\n{}",
                        asset,
                        exc,
                        traceback.format_exc(),
                    )

'''

s = (
    s[:start]
    + new_asset_loop
    + s[end:]
)


# ---------- 2.5 替换信号漏斗日志 ----------

pattern_funnel = re.compile(
    r"            if decision_stats\[\"bars\"\].*?"
    r"\n            metrics_path = Path\(\"metrics\.prom\"\)",
    re.S,
)

replacement_funnel = r'''            signal_eval = decision_stats[
                "signal_evaluations"
            ]

            # 只按真正的15m信号评估次数统计，
            # 不再被30秒轮询次数污染。
            if signal_eval and signal_eval % 3 == 0:
                logger.info(
                    "信号漏斗 confirmed={} eval={} "
                    "p>=.50={} p>=.55={} p>=th={} "
                    "p>=strong={} buys={} "
                    "entry_reject={} risk_reject={} "
                    "execution_reject={} fills={} "
                    "errors={} reasons={}",
                    decision_stats[
                        "confirmed_bars"
                    ],
                    decision_stats[
                        "signal_evaluations"
                    ],
                    decision_stats[
                        "candidate_ge_50"
                    ],
                    decision_stats[
                        "candidate_ge_55"
                    ],
                    decision_stats[
                        "candidate_ge_threshold"
                    ],
                    decision_stats[
                        "candidate_ge_strong"
                    ],
                    decision_stats[
                        "buy_signals"
                    ],
                    decision_stats[
                        "entry_reject"
                    ],
                    decision_stats[
                        "risk_reject"
                    ],
                    decision_stats[
                        "execution_reject"
                    ],
                    decision_stats[
                        "fills"
                    ],
                    decision_stats[
                        "errors"
                    ],
                    decision_stats[
                        "reasons"
                    ],
                )

            metrics_path = Path("metrics.prom")'''

s2, n = pattern_funnel.subn(
    replacement_funnel,
    s,
)

if n != 1:
    raise RuntimeError(
        "无法定位旧信号漏斗日志。"
    )

s = s2


# ---------- 2.6 确保不存在 decision_stats["bars"] ----------

s = s.replace(
    'decision_stats["bars"]',
    'decision_stats["signal_evaluations"]',
)


# ---------- 2.7 统一 main_strategy 中 logger %s 格式 ----------
# 只处理明显的普通logger格式，不碰日志文本里的百分号。

s = s.replace(
    'logger.info("资产=%s | 周期=%s | dry_run=%s", assets, timeframe, dry_run)',
    'logger.info("资产={} | 周期={} | dry_run={}", assets, timeframe, dry_run)',
)

s = s.replace(
    'logger.error("兼容下单接口失败: %s", exc)',
    'logger.error("兼容下单接口失败: {}", exc)',
)

s = s.replace(
    'logger.warning("%s 未发现完整训练模型包：安全观察模式，不产生交易信号。请先执行 train_model.py --symbol %s", symbol, symbol)',
    'logger.warning("{} 未发现完整训练模型包：安全观察模式，不产生交易信号。请先执行 train_model.py --symbol {}", symbol, symbol)',
)

s = s.replace(
    'logger.error("模型加载失败 %s: %s", path, exc)',
    'logger.error("模型加载失败 {}: {}", path, exc)',
)

MAIN.write_text(s, encoding="utf-8")


# ============================================================
# 3. 语法检查
# ============================================================

import py_compile

for check_file in (MAIN, ML):
    py_compile.compile(
        str(check_file),
        doraise=True,
    )
    print(f"[OK] syntax: {check_file.name}")


print()
print("=" * 70)
print("实时循环优化完成")
print("=" * 70)
print()
print("已经完成：")
print("1. 同一根15m K线不再每30秒重复跑完整特征工程")
print("2. 空仓状态没有新K线时不再运行ML")
print("3. 持仓状态每30秒继续监控ticker，但复用ATR/特征缓存")
print("4. 信号样本统计改成真实15m确认K线")
print("5. 加入 execution_reject / errors / reasons 统计")
print("6. LightGBM feature-name warning 已处理")
print("7. 原文件已自动备份")
print()
print("下一步：")
print("python train_model.py --all --lookback 6000")
print("python main_strategy.py")
print()
