﻿# monitoring/monitor.py
import threading, requests, time
from collections import deque
from datetime import datetime
from loguru import logger

class StrategyMonitor:
    def __init__(self, config):
        self.wechat_key = config.get("alert", {}).get("serverchan_key", "")
        self.max_loss_cnt = config.get("alert", {}).get("max_consecutive_loss", 5)
        self.loss_cnt = 0
        self.trades = 0
        self.wins = 0
        self.last_brief = None

    def _send_wechat(self, title, msg=""):
        if not self.wechat_key:
            return
        try:
            requests.post(
                f"https://sctapi.ftqq.com/{self.wechat_key}.send",
                data={"title": title, "desp": msg},
                timeout=10
            )
        except Exception as e:
            logger.error(f"微信通知失败: {e}")

    def record_trade(self, symbol, side, pnl):
        self.trades += 1
        if pnl > 0:
            self.wins += 1
        if pnl < 0:
            self.loss_cnt += 1
            if self.loss_cnt >= self.max_loss_cnt:
                self._send_wechat(f"连续亏损{self.loss_cnt}笔", f"{symbol} {side} {pnl:.2f}")
                self.loss_cnt = 0
                return True
        else:
            self.loss_cnt = 0
        return False

    def notify_trade(self, symbol, side, price, size, reason=""):
        self._send_wechat(f"{side.upper()} {symbol}", f"价格:{price:.2f} 数量:{size:.6f} {reason}")

    def notify_stop(self, symbol, price, reason):
        self._send_wechat(f"止损 {symbol}", f"价格:{price:.2f} 原因:{reason}")

    def export_metrics_prometheus(self, equity, positions, pnl):
        lines = [f"strategy_equity {equity:.2f}"]
        for s, q in positions.items():
            lines.append(f'strategy_position{{symbol="{s}"}} {q}')
        return "\n".join(lines) + "\n"

    def daily_brief(self, equity, pnl, positions):
        now = datetime.now()
        if self.last_brief and (now - self.last_brief).seconds < 86400:
            return
        self.last_brief = now
        wr = self.wins / self.trades if self.trades > 0 else 0
        self._send_wechat(
            f"每日简报 {now.strftime('%m-%d')}",
            f"权益:{equity:.2f}\n盈亏:{pnl:+.2f}\n胜率:{wr:.1%}"
        )
