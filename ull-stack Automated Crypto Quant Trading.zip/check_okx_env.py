﻿import os
from pathlib import Path
from dotenv import load_dotenv

print("=" * 72)
print("OKX ENV DIAGNOSTIC")
print("=" * 72)

print(".env exists =", Path(".env").exists())

loaded = load_dotenv(
    override=False
)

print("dotenv loaded =", loaded)

keys = [
    "OKX_DEMO_TRADING",
    "OKX_API_KEY",
    "OKX_API_SECRET",
    "OKX_API_PASSPHRASE",
    "OKX_FLAG",
    "OKX_DRY_RUN",
    "LIVE_TRADING_ENABLED",
]

for key in keys:

    value = os.getenv(key)

    if value:
        print(
            f"{key}: SET length={len(value)}"
        )
    else:
        print(
            f"{key}: MISSING"
        )

print("=" * 72)
