﻿from pathlib import Path
GEN1 = Path(r"C:\Users\mi\zuizhongban\quant_ai_original_final_hotfix")
GEN3 = Path(r"C:\Users\mi\最终修改版二版\最终稿修改版2版\quant_ai_final_okx_demo")
FILES = ["main_strategy.py","layers/layer1_data_collector.py","layers/layer4_feature_engineer.py","layers/layer6_ml_model.py","layers/layer9_signal_generator.py","layers/layer10_filter.py","layers/layer11_risk_fuse.py","layers/layer12_executor.py","layers/layer17_position_state_machine.py","risk_manager.py","train_model.py","config.yaml"]
def n(p):
    if not p.exists(): return None
    return len(p.read_text(encoding="utf-8", errors="replace").splitlines())
print("="*82)
print(f"{'文件':<48} {'Gen1':>8} {'Gen3':>8} {'变化':>8}")
print("-"*82)
for r in FILES:
    a, b = n(GEN1/r), n(GEN3/r)
    sa = str(a) if a is not None else "缺失"
    sb = str(b) if b is not None else "缺失"
    d = f"{b-a:+d}" if (a is not None and b is not None) else "-"
    print(f"{r:<48} {sa:>8} {sb:>8} {d:>8}")
print("="*82)
