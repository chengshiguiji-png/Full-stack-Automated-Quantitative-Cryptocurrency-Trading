﻿from pathlib import Path
p = Path("backtest_engine.py")
s = p.read_text(encoding="utf-8")

old = '''            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(X_train_aligned)
            selector = SelectKBest(f_classif, k=min(20, X_scaled.shape[1]))
            X_selected = selector.fit_transform(X_scaled, labels)

            model = MLModelEnsemble()
            model.train(X_selected, labels)
'''

new = '''            # === 使用 ml_lib 生产模型，而不是每窗口自训 ===
            import joblib
            from pathlib import Path as _P
            _key = self.symbol.replace("-", "_")
            _mp = _P(f"ml_lib/trained_models/{_key}_ensemble_model.pkl")
            _sp = _P(f"ml_lib/transformers/{_key}_scaler.pkl")
            _lp = _P(f"ml_lib/transformers/{_key}_selector.pkl")
            _fp = _P(f"ml_lib/transformers/{_key}_feature_columns.txt")
            if not (_mp.exists() and _sp.exists() and _lp.exists() and _fp.exists()):
                logger.warning(f"缺少 {_key} 生产模型，跳过")
                continue
            model = joblib.load(_mp)
            scaler = joblib.load(_sp)
            selector = joblib.load(_lp)
            prod_cols = [x.strip() for x in _fp.read_text(encoding="utf-8").splitlines() if x.strip()]
            # 对齐生产模型的特征列
            X_train_aligned = X_train_aligned[prod_cols]
            X_train_aligned = X_train_aligned.dropna()
'''

if old not in s:
    print("[FAIL] 未找到自训块")
else:
    s = s.replace(old, new, 1)
    p.write_text(s, encoding="utf-8")
    print("[OK] 已改为使用生产模型")
