﻿from pathlib import Path
import shutil
import py_compile
import sys
import subprocess

ROOT = Path.cwd()

FILES = [
    ROOT / "main_strategy.py",
    ROOT / "layers" / "polymarket_clob.py",
    ROOT / "layers" / "polymarket_rtds.py",
    ROOT / "layers" / "polymarket_shadow.py",
    ROOT / "layers" / "layer6_ml_model.py",
    ROOT / "layers" / "layer10_filter.py",
    ROOT / "config.yaml",
]

for path in FILES:
    if not path.exists():
        raise FileNotFoundError(
            f"缺少文件: {path}"
        )

STAMP = __import__("datetime").datetime.now().strftime(
    "%Y%m%d_%H%M%S"
)

BACKUP_DIR = ROOT / "_FINAL_BACKUP"
BACKUP_DIR.mkdir(exist_ok=True)

print("=" * 72)
print("FINAL QUANT SYSTEM PATCH")
print("=" * 72)

# ============================================================
# 备份
# ============================================================

for path in FILES:
    backup = (
        BACKUP_DIR
        / f"{path.name}.bak_{STAMP}"
    )
    shutil.copy2(
        path,
        backup,
    )
    print(
        "[BACKUP]",
        backup,
    )


def replace_once(
    source,
    old,
    new,
    label,
):
    count = source.count(old)

    if count != 1:
        raise RuntimeError(
            f"{label}: expected 1 match, got {count}"
        )

    return source.replace(
        old,
        new,
        1,
    )


# ============================================================
# 1. main_strategy.py
# ============================================================

path = ROOT / "main_strategy.py"
s = path.read_text(
    encoding="utf-8-sig"
)

# ------------------------------------------------------------
# config 使用脚本目录，不依赖当前工作目录
# ------------------------------------------------------------

s = replace_once(
    s,
'''def load_config():
    load_dotenv(override=False)
    with open("config.yaml", "r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}
    return apply_env_overrides(config)
''',
'''def load_config():
    load_dotenv(override=False)
    config_path = Path(__file__).resolve().parent / "config.yaml"
    with config_path.open("r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}
    return apply_env_overrides(config)
''',
    "main load_config",
)

# ------------------------------------------------------------
# feature cache
# ------------------------------------------------------------

s = replace_once(
    s,
'''    hold_counter = {a: 0 for a in assets}
    last_bar = {a: None for a in assets}
    daily_pnl = 0.0
''',
'''    hold_counter = {a: 0 for a in assets}
    last_bar = {a: None for a in assets}

    # 每个币种只在新的“已确认15m K线”出现时重新计算：
    # 特征工程 / ATR / volatility / regime / ML。
    # ticker 与持仓管理仍然每30秒实时执行。
    feature_cache = {
        a: None
        for a in assets
    }

    daily_pnl = 0.0
''',
    "main feature cache",
)

# ------------------------------------------------------------
# 30秒重复特征工程 -> 快速探测 + 新K线才完整计算
# ------------------------------------------------------------

old_block = '''                    decision_stats["bars"] += 1
                    raw = collector.fetch_klines_rest(asset, interval=timeframe, limit=int(config.get("market", {}).get("lookback", 300)))
                    if not raw:
                        continue
                    df = cleaner.clean_klines(raw)
                    if len(df) < 80:
                        continue
                    df_feat = engineer.calculate_features(df)
                    if df_feat.empty:
                        continue
                    save_klines(asset, raw[-200:])

                    ticker = collector.fetch_ticker(asset)
                    current_price = float(ticker or df["close"].iloc[-1])
                    price_cache[asset] = current_price
                    bar_ts = int(df["timestamp"].iloc[-1])
                    atr = float(df_feat["atr_14"].iloc[-1]) if pd.notna(df_feat["atr_14"].iloc[-1]) else current_price * 0.005
                    vol = float(df_feat["volatility_20"].iloc[-1]) if pd.notna(df_feat["volatility_20"].iloc[-1]) else 0.0
                    regime_info = regime_detector.detect_regime(df)
                    regime = regime_info["market_regime"]
                    pos = positions[asset]
'''

new_block = '''                    # ------------------------------------------------
                    # 轻量探测：只判断最新“已确认15m K线”有没有变化。
                    # 不再每30秒重新计算299x64特征。
                    # ------------------------------------------------
                    probe_raw = collector.fetch_klines_rest(
                        asset,
                        interval=timeframe,
                        limit=3,
                    )

                    if not probe_raw:
                        continue

                    probe_df = cleaner.clean_klines(
                        probe_raw
                    )

                    if probe_df.empty:
                        continue

                    bar_ts = int(
                        probe_df["timestamp"].iloc[-1]
                    )

                    cached = feature_cache.get(
                        asset
                    )

                    is_new_confirmed_bar = (
                        cached is None
                        or int(
                            cached["bar_ts"]
                        ) != bar_ts
                    )

                    # ticker 每一轮都获取，保证持仓管理继续实时。
                    ticker = collector.fetch_ticker(
                        asset
                    )

                    fallback_price = float(
                        probe_df["close"].iloc[-1]
                    )

                    current_price = float(
                        ticker or fallback_price
                    )

                    price_cache[asset] = (
                        current_price
                    )

                    if is_new_confirmed_bar:

                        # 只有新的确认K线出现时才重新拉300根。
                        raw = collector.fetch_klines_rest(
                            asset,
                            interval=timeframe,
                            limit=int(
                                config.get(
                                    "market",
                                    {}
                                ).get(
                                    "lookback",
                                    300,
                                )
                            ),
                        )

                        if not raw:
                            continue

                        df = cleaner.clean_klines(
                            raw
                        )

                        if len(df) < 80:
                            continue

                        df_feat = (
                            engineer.calculate_features(
                                df
                            )
                        )

                        if df_feat.empty:
                            continue

                        save_klines(
                            asset,
                            raw[-200:],
                        )

                        full_bar_ts = int(
                            df["timestamp"].iloc[-1]
                        )

                        bar_ts = full_bar_ts

                        atr = (
                            float(
                                df_feat[
                                    "atr_14"
                                ].iloc[-1]
                            )
                            if pd.notna(
                                df_feat[
                                    "atr_14"
                                ].iloc[-1]
                            )
                            else current_price * 0.005
                        )

                        vol = (
                            float(
                                df_feat[
                                    "volatility_20"
                                ].iloc[-1]
                            )
                            if pd.notna(
                                df_feat[
                                    "volatility_20"
                                ].iloc[-1]
                            )
                            else 0.0
                        )

                        regime_info = (
                            regime_detector.detect_regime(
                                df
                            )
                        )

                        regime = regime_info[
                            "market_regime"
                        ]

                        feature_cache[
                            asset
                        ] = {
                            "bar_ts":
                                bar_ts,
                            "df":
                                df,
                            "df_feat":
                                df_feat,
                            "atr":
                                atr,
                            "vol":
                                vol,
                            "regime":
                                regime,
                        }

                        # 只有新的确认K线才计入真实signal sample。
                        decision_stats[
                            "bars"
                        ] += 1

                    else:

                        # 同一根15m K线复用缓存。
                        df = cached["df"]
                        df_feat = cached["df_feat"]
                        atr = float(
                            cached["atr"]
                        )
                        vol = float(
                            cached["vol"]
                        )
                        regime = str(
                            cached["regime"]
                        )

                    pos = positions[
                        asset
                    ]
'''

s = replace_once(
    s,
    old_block,
    new_block,
    "main repeated feature block",
)

# ------------------------------------------------------------
# Layer10 需要拿到模型原始上下文
# ------------------------------------------------------------

s = replace_once(
    s,
'''                    event_store.append_event("SIGNAL", {
                        "symbol": asset, "bar_ts": bar_ts, "raw_p_up": raw_p_up, "p_up": p_up,
''',
'''                    # 仅把真实模型上下文传给Layer10。
                    # 不修改p_up本身。
                    signal["p_up"] = float(p_up)
                    signal["raw_p_up"] = float(raw_p_up)

                    signal["rsi_14"] = (
                        float(
                            df_feat[
                                "rsi_14"
                            ].iloc[-1]
                        )
                        if (
                            "rsi_14"
                            in df_feat.columns
                            and
                            pd.notna(
                                df_feat[
                                    "rsi_14"
                                ].iloc[-1]
                            )
                        )
                        else None
                    )

                    signal["bb_pos"] = (
                        float(
                            df_feat[
                                "bb_pos"
                            ].iloc[-1]
                        )
                        if (
                            "bb_pos"
                            in df_feat.columns
                            and
                            pd.notna(
                                df_feat[
                                    "bb_pos"
                                ].iloc[-1]
                            )
                        )
                        else None
                    )

                    signal[
                        "strong_threshold_up"
                    ] = max(
                        0.65,
                        float(
                            config.get(
                                "signal",
                                {}
                            ).get(
                                "strong_threshold_up",
                                0.68,
                            )
                        )
                    )

                    event_store.append_event("SIGNAL", {
                        "symbol": asset, "bar_ts": bar_ts, "raw_p_up": raw_p_up, "p_up": p_up,
''',
    "main Layer10 signal context",
)

# ------------------------------------------------------------
# 修复 loguru % 格式
# ------------------------------------------------------------

s = replace_once(
    s,
'''                                    logger.success("{} 平仓成交 %.8f @ %.4f PnL=%+.4f", asset, fill_qty, fill_price, pnl)
''',
'''                                    logger.success("{} 平仓成交 {:.8f} @ {:.4f} PnL={:+.4f}", asset, fill_qty, fill_price, pnl)
''',
    "main close log",
)

s = replace_once(
    s,
'''                    logger.success("{} 开仓成交 %.8f @ %.4f notional=%.2f", asset, fill_qty, fill_price, fill_qty * fill_price)
''',
'''                    logger.success("{} 开仓成交 {:.8f} @ {:.4f} notional={:.2f}", asset, fill_qty, fill_price, fill_qty * fill_price)
''',
    "main open log",
)

path.write_text(
    s,
    encoding="utf-8"
)

print(
    "[PATCH] main_strategy.py"
)


# ============================================================
# 2. layer6_ml_model.py
# ============================================================

path = ROOT / "layers" / "layer6_ml_model.py"
s = path.read_text(
    encoding="utf-8-sig"
)

old = '''    @classmethod
    def _predict_model_proba(cls, model, X):
        if isinstance(X, pd.DataFrame):
            expected = cls._expected_feature_names(model)
            current = [str(x) for x in X.columns]

            # 新模型：训练和预测特征名一致
            if expected and expected == current:
                return model.predict_proba(X)[:, 1]

            # 老模型：可能用 numpy 拟合，没有可匹配列名
            return model.predict_proba(X.to_numpy())[:, 1]

        return model.predict_proba(np.asarray(X))[:, 1]
'''

new = '''    @classmethod
    def _predict_model_proba(cls, model, X):
        """
        保持已训练模型的feature-name语义。

        - 老的numpy模型继续收到ndarray。
        - 用feature names训练的LightGBM/sklearn模型收到
          同样名字的DataFrame。
        """
        expected = cls._expected_feature_names(
            model
        )

        if isinstance(
            X,
            pd.DataFrame,
        ):

            if expected:

                if (
                    X.shape[1]
                    != len(expected)
                ):
                    raise ValueError(
                        "模型特征数不匹配: "
                        f"X={X.shape[1]} "
                        f"expected={len(expected)}"
                    )

                frame = X.copy()

                frame.columns = (
                    expected
                )

                return (
                    model.predict_proba(
                        frame
                    )[:, 1]
                )

            return (
                model.predict_proba(
                    X.to_numpy()
                )[:, 1]
            )

        array = np.asarray(
            X
        )

        if expected:

            if (
                array.ndim != 2
                or
                array.shape[1]
                != len(expected)
            ):
                raise ValueError(
                    "模型特征数不匹配: "
                    f"X={array.shape} "
                    f"expected={len(expected)}"
                )

            frame = pd.DataFrame(
                array,
                columns=expected,
            )

            return (
                model.predict_proba(
                    frame
                )[:, 1]
            )

        return (
            model.predict_proba(
                array
            )[:, 1]
        )
'''

s = replace_once(
    s,
    old,
    new,
    "Layer6 feature names",
)

path.write_text(
    s,
    encoding="utf-8"
)

print(
    "[PATCH] layer6_ml_model.py"
)


# ============================================================
# 3. layer10_filter.py
# ============================================================

path = (
    ROOT
    / "layers"
    / "layer10_filter.py"
)

s = path.read_text(
    encoding="utf-8-sig"
)

old = '''        if direction == "BUY" and market_regime in {"strong_down", "extreme_liquidation"}:
            passed = False
            reasons.append(f"市场状态 {market_regime} 禁止追多")
'''

new = '''        if (
            direction == "BUY"
            and
            market_regime == "extreme_liquidation"
        ):
            passed = False
            reasons.append(
                "极端清算状态下禁止新增 BUY"
            )

        if (
            direction == "BUY"
            and
            market_regime == "strong_down"
        ):
            # strong_down不再100%封杀BUY。
            #
            # 只允许非常有限的逆势反转：
            # 1. 主模型达到强信号
            # 2. RSI明显超卖
            # 3. 价格处于布林带低位
            # 4. edge至少达到0.05
            #
            # 这样不会把普通逆势BUY放进去，
            # 但不会再造成strong_down期间开仓机会永久归零。

            p_up = float(
                signal.get(
                    "p_up",
                    0.0,
                )
                or 0.0
            )

            rsi = signal.get(
                "rsi_14"
            )

            bb_pos = signal.get(
                "bb_pos"
            )

            strong_threshold = max(
                0.65,
                float(
                    signal.get(
                        "strong_threshold_up",
                        0.68,
                    )
                ),
            )

            countertrend_ok = (
                p_up
                >= strong_threshold
                and
                rsi is not None
                and
                float(rsi)
                <= 38.0
                and
                bb_pos is not None
                and
                float(bb_pos)
                <= 0.25
                and
                ev_edge
                >= max(
                    0.05,
                    self.min_ev_edge,
                )
            )

            if not countertrend_ok:

                passed = False

                reasons.append(
                    "strong_down逆势BUY条件不足"
                    f"(p_up={p_up:.3f}, "
                    f"rsi={rsi}, "
                    f"bb_pos={bb_pos})"
                )
'''

s = replace_once(
    s,
    old,
    new,
    "Layer10 strong_down",
)

s = replace_once(
    s,
'''            logger.info("过滤通过: {} {} edge=%.3f", direction, symbol, ev_edge)
''',
'''            logger.info("过滤通过: {} {} edge={:.3f}", direction, symbol, ev_edge)
''',
    "Layer10 log format",
)

path.write_text(
    s,
    encoding="utf-8"
)

print(
    "[PATCH] layer10_filter.py"
)


# ============================================================
# 4. polymarket_clob.py
# ============================================================

path = (
    ROOT
    / "layers"
    / "polymarket_clob.py"
)

s = path.read_text(
    encoding="utf-8-sig"
)

s = replace_once(
    s,
'''class PolymarketCLOB:
    GAMMA_URL = "https://gamma-api.polymarket.com/markets"
''',
'''class PolymarketCLOB:
    GAMMA_URL = "https://gamma-api.polymarket.com/markets"
    GAMMA_SEARCH_URL = "https://gamma-api.polymarket.com/public-search"
''',
    "Polymarket public search constant",
)

start_marker = (
    "    def discover_btc_updown("
)

end_marker = (
    "    # ============================================================\n"
    "    # Book"
)

start = s.index(
    start_marker
)

end = s.index(
    end_marker,
    start,
)

new_discovery = r'''    def discover_btc_updown(
        self,
        window="15m",
    ):
        """
        Discover the currently relevant active BTC Up/Down market.

        IMPORTANT:
        Do not require literal "15m" in the slug.
        Use actual start/end times and token IDs.
        """

        now = time.time()

        with self._lock:

            cached = (
                self._market_cache.get(
                    "market"
                )
            )

            cached_ts = float(
                self._market_cache.get(
                    "ts",
                    0.0,
                )
            )

        if (
            cached
            and
            now - cached_ts
            < self.refresh_sec
        ):
            return cached

        now_dt = (
            dt.datetime.now(
                dt.timezone.utc
            )
        )

        payloads = []

        # ========================================================
        # A. public-search
        # ========================================================

        for query in (
            "Bitcoin Up or Down",
            "BTC Up or Down",
        ):

            try:

                payload = (
                    self._get_json(
                        self.GAMMA_SEARCH_URL,
                        {
                            "q":
                                query,
                            "limit_per_type":
                                100,
                            "page":
                                1,
                        },
                    )
                )

                payloads.append(
                    payload
                )

            except Exception as exc:

                logger.debug(
                    "Polymarket public-search failed {}: {}",
                    query,
                    exc,
                )

        # ========================================================
        # B. /markets fallback
        # ========================================================

        try:

            payload = (
                self._get_json(
                    self.GAMMA_URL,
                    {
                        "closed":
                            "false",
                        "active":
                            "true",
                        "limit":
                            100,
                        "order":
                            "endDate",
                        "ascending":
                            "true",
                    },
                )
            )

            payloads.append(
                payload
            )

        except Exception as exc:

            logger.warning(
                "Polymarket /markets fallback failed: {}",
                exc,
            )

        # ========================================================
        # C. flatten public-search nested structure
        # ========================================================

        markets = []

        seen = set()

        def walk(
            obj
        ):

            if isinstance(
                obj,
                dict,
            ):

                has_tokens = (
                    "clobTokenIds"
                    in obj
                    or
                    "clob_token_ids"
                    in obj
                )

                has_end = (
                    "endDate"
                    in obj
                    or
                    "endDateIso"
                    in obj
                )

                if (
                    has_tokens
                    and
                    has_end
                ):

                    key = str(
                        obj.get(
                            "id"
                        )
                        or
                        obj.get(
                            "conditionId"
                        )
                        or
                        obj.get(
                            "condition_id"
                        )
                        or
                        obj.get(
                            "slug"
                        )
                        or
                        ""
                    )

                    if (
                        key
                        and
                        key not in seen
                    ):

                        seen.add(
                            key
                        )

                        markets.append(
                            obj
                        )

                for value in obj.values():

                    if isinstance(
                        value,
                        (
                            dict,
                            list,
                        ),
                    ):

                        walk(
                            value
                        )

            elif isinstance(
                obj,
                list,
            ):

                for value in obj:

                    walk(
                        value
                    )

        for payload in payloads:

            walk(
                payload
            )

        # ========================================================
        # D. candidate selection
        # ========================================================

        candidates = []

        for market in markets:

            slug = str(
                market.get(
                    "slug",
                    "",
                )
            )

            question = str(
                market.get(
                    "question"
                )
                or
                market.get(
                    "title",
                    "",
                )
            )

            text = (
                f"{slug} {question}"
                .lower()
            )

            # BTC
            if (
                "btc" not in text
                and
                "bitcoin"
                not in text
            ):
                continue

            # Up / Down
            is_updown = (
                "up or down"
                in text
                or
                "up-or-down"
                in text
                or
                "updown"
                in text
                or
                (
                    "up" in text
                    and
                    "down" in text
                )
            )

            if not is_updown:
                continue

            # status
            if market.get(
                "closed"
            ) is True:
                continue

            if market.get(
                "archived"
            ) is True:
                continue

            if market.get(
                "active"
            ) is False:
                continue

            if market.get(
                "acceptingOrders"
            ) is False:
                continue

            # start
            start_dt = (
                self._parse_dt(
                    market.get(
                        "startDate"
                    )
                    or
                    market.get(
                        "startDateIso"
                    )
                    or
                    market.get(
                        "startTime"
                    )
                )
            )

            # end
            end_dt = (
                self._parse_dt(
                    market.get(
                        "endDate"
                    )
                    or
                    market.get(
                        "endDateIso"
                    )
                )
            )

            if (
                end_dt is None
                or
                end_dt <= now_dt
            ):
                continue

            if start_dt is None:

                start_dt = (
                    end_dt
                    -
                    dt.timedelta(
                        minutes=15
                    )
                )

            # token ids
            token_raw = (
                market.get(
                    "clobTokenIds"
                )
                or
                market.get(
                    "clob_token_ids"
                )
            )

            token_raw = (
                self._jsonish(
                    token_raw
                )
            )

            if not isinstance(
                token_raw,
                list,
            ):
                continue

            token_ids = [
                str(x)
                for x in token_raw
                if x
            ]

            if len(token_ids) < 2:
                continue

            # outcomes
            outcomes = (
                self._jsonish(
                    market.get(
                        "outcomes"
                    )
                )
            )

            if not isinstance(
                outcomes,
                list,
            ):

                outcomes = [
                    "Up",
                    "Down",
                ]

            outcomes = [
                str(x)
                for x in outcomes
            ]

            # align token order with Up / Down
            ordered_tokens = (
                token_ids[:2]
            )

            lowered = [
                x.lower()
                for x in outcomes
            ]

            up_index = next(
                (
                    i
                    for i, x
                    in enumerate(
                        lowered
                    )
                    if x
                    in {
                        "up",
                        "yes",
                    }
                ),
                None,
            )

            down_index = next(
                (
                    i
                    for i, x
                    in enumerate(
                        lowered
                    )
                    if x
                    in {
                        "down",
                        "no",
                    }
                ),
                None,
            )

            if (
                up_index is not None
                and
                down_index is not None
                and
                up_index
                < len(
                    token_ids
                )
                and
                down_index
                < len(
                    token_ids
                )
            ):

                ordered_tokens = [
                    token_ids[
                        up_index
                    ],
                    token_ids[
                        down_index
                    ],
                ]

            duration_sec = max(
                1.0,
                (
                    end_dt
                    -
                    start_dt
                ).total_seconds(),
            )

            currently_live = (
                start_dt
                <= now_dt
                <
                end_dt
            )

            until_start = max(
                0.0,
                (
                    start_dt
                    -
                    now_dt
                ).total_seconds(),
            )

            # 最接近15m，同时优先当前正在进行的市场
            duration_error = (
                abs(
                    duration_sec
                    - 900.0
                )
                /
                900.0
            )

            score = (
                duration_error * 5.0
                +
                until_start / 1800.0
                +
                (
                    -10.0
                    if currently_live
                    else 0.0
                )
                +
                (
                    -1.0
                    if market.get(
                        "acceptingOrders"
                    ) is True
                    else 0.0
                )
            )

            normalized = {
                "condition_id":
                    (
                        market.get(
                            "conditionId"
                        )
                        or
                        market.get(
                            "condition_id"
                        )
                    ),
                "market_id":
                    market.get(
                        "id"
                    ),
                "slug":
                    slug,
                "question":
                    question,
                "start_time":
                    start_dt.isoformat(),
                "end_time":
                    end_dt.isoformat(),
                "token_ids":
                    ordered_tokens,
                "outcomes":
                    outcomes[:2],
                "duration_sec":
                    duration_sec,
                "volume":
                    float(
                        market.get(
                            "volumeNum"
                        )
                        or
                        market.get(
                            "volume"
                        )
                        or
                        0.0
                    ),
                "raw":
                    market,
            }

            candidates.append(
                (
                    score,
                    normalized,
                )
            )

        if not candidates:

            logger.warning(
                "Polymarket: no active BTC Up/Down market found"
            )

            return None

        candidates.sort(
            key=lambda x: x[0]
        )

        market = (
            candidates[0][1]
        )

        with self._lock:

            self._market_cache = {
                "ts":
                    now,
                "market":
                    market,
            }

        logger.info(
            "Polymarket market discovered: {} | start={} | end={} | duration={}s | tokens={}",
            market.get(
                "slug"
            ),
            market.get(
                "start_time"
            ),
            market.get(
                "end_time"
            ),
            int(
                market.get(
                    "duration_sec",
                    0,
                )
            ),
            len(
                market.get(
                    "token_ids",
                    []
                )
            ),
        )

        return market

'''

s = (
    s[:start]
    +
    new_discovery
    +
    s[end:]
)

# ------------------------------------------------------------
# WebSocket重连后用REST重新同步订单簿
# ------------------------------------------------------------

s = replace_once(
    s,
'''                    logger.success(
                        "Polymarket CLOB WSS connected; subscribed {} assets",
                        len(
                            self._subscribed_assets
                        ),
                    )

                    threading.Thread(
''',
'''                    logger.success(
                        "Polymarket CLOB WSS connected; subscribed {} assets",
                        len(
                            self._subscribed_assets
                        ),
                    )

                    # 重连后重新取REST快照，修复离线期间丢失的delta。
                    threading.Thread(
                        target=lambda: self.initial_sync(
                            list(
                                self._subscribed_assets
                            )
                        ),
                        name="polymarket-rest-resync",
                        daemon=True,
                    ).start()

                    threading.Thread(
''',
    "Polymarket WSS REST resync",
)

path.write_text(
    s,
    encoding="utf-8"
)

print(
    "[PATCH] polymarket_clob.py"
)


# ============================================================
# 5. polymarket_rtds.py
# ============================================================

path = (
    ROOT
    / "layers"
    / "polymarket_rtds.py"
)

s = path.read_text(
    encoding="utf-8-sig"
)

s = replace_once(
    s,
'''    def __init__(self, symbol: str = SYMBOL, history_size: int = 10000):
        self.symbol = symbol.lower()
        self.history: deque[dict[str, Any]] = deque(maxlen=int(history_size))
''',
'''    def __init__(
        self,
        symbol: str = SYMBOL,
        history_size: int = 10000,
        proxy_url: Optional[str] = None,
    ):
        self.symbol = symbol.lower()

        self.proxy_url = (
            proxy_url
            if proxy_url is not None
            else "http://127.0.0.1:12450"
        ).strip()

        self.history: deque[dict[str, Any]] = deque(
            maxlen=int(
                history_size
            )
        )
''',
    "RTDS proxy",
)

s = replace_once(
    s,
'''    def _loop(self) -> None:
''',
'''    def _proxy_kwargs(self) -> dict[str, Any]:
        if not self.proxy_url:
            return {}

        from urllib.parse import urlparse

        try:
            parsed = urlparse(
                self.proxy_url
            )

            if not parsed.hostname:
                return {}

            result = {
                "http_proxy_host":
                    parsed.hostname,
                "http_proxy_port":
                    parsed.port,
                "proxy_type":
                    (
                        "socks5"
                        if parsed.scheme.lower().startswith(
                            "socks"
                        )
                        else "http"
                    ),
            }

            if parsed.username:
                result[
                    "http_proxy_auth"
                ] = (
                    parsed.username,
                    parsed.password
                    or "",
                )

            return result

        except Exception:
            return {}

    def _loop(self) -> None:
''',
    "RTDS proxy helper",
)

s = replace_once(
    s,
'''                self._ws.run_forever(ping_interval=5, ping_timeout=3)
''',
'''                run_kwargs = {
                    "ping_interval":
                        20,
                    "ping_timeout":
                        10,
                }

                run_kwargs.update(
                    self._proxy_kwargs()
                )

                self._ws.run_forever(
                    **run_kwargs
                )
''',
    "RTDS websocket proxy",
)

path.write_text(
    s,
    encoding="utf-8"
)

print(
    "[PATCH] polymarket_rtds.py"
)


# ============================================================
# 6. polymarket_shadow.py
# ============================================================

path = (
    ROOT
    / "layers"
    / "polymarket_shadow.py"
)

s = path.read_text(
    encoding="utf-8-sig"
)

s = replace_once(
    s,
'''        self.rtds = PolymarketRTDSChainlink()
''',
'''        self.rtds = PolymarketRTDSChainlink(
            proxy_url=cfg.get(
                "proxy_url"
            )
        )
''',
    "Shadow RTDS proxy",
)

s = replace_once(
    s,
'''        end_ts = start_ts + 900.0
''',
'''        end_ts = self._end_ts(
            market,
            start_ts,
        )
''',
    "Shadow market end time",
)

# _end_ts helper
s = replace_once(
    s,
'''        return None

    def start(self) -> None:
''',
'''        return None

    @staticmethod
    def _end_ts(
        market: dict[str, Any],
        start_ts: float,
    ) -> float:
        """
        优先使用Gamma返回的真实end_time。
        不再强制假设所有市场都精确900秒。
        """

        value = market.get(
            "end_time"
        )

        if value:
            try:
                parsed = (
                    dt.datetime.fromisoformat(
                        str(
                            value
                        ).replace(
                            "Z",
                            "+00:00",
                        )
                    )
                )

                if parsed.tzinfo is None:
                    parsed = parsed.replace(
                        tzinfo=dt.timezone.utc
                    )

                return parsed.timestamp()

            except Exception:
                pass

        raw = market.get(
            "raw"
        )

        if isinstance(
            raw,
            dict,
        ):

            value = (
                raw.get(
                    "endDate"
                )
                or
                raw.get(
                    "endDateIso"
                )
            )

            if value:

                try:

                    parsed = (
                        dt.datetime.fromisoformat(
                            str(
                                value
                            ).replace(
                                "Z",
                                "+00:00",
                            )
                        )
                    )

                    if parsed.tzinfo is None:
                        parsed = parsed.replace(
                            tzinfo=dt.timezone.utc
                        )

                    return parsed.timestamp()

                except Exception:
                    pass

        return (
            start_ts
            + 900.0
        )

    def start(self) -> None:
''',
    "Shadow end_ts helper",
)

path.write_text(
    s,
    encoding="utf-8"
)

print(
    "[PATCH] polymarket_shadow.py"
)


# ============================================================
# 7. config.yaml
# ============================================================

path = ROOT / "config.yaml"

s = path.read_text(
    encoding="utf-8-sig"
)

s = replace_once(
    s,
    "  min_ev_edge: -0.20",
    "  min_ev_edge: 0.05",
    "config min_ev_edge",
)

s = replace_once(
    s,
    "  threshold_up: 0.25",
    "  threshold_up: 0.55",
    "config threshold_up",
)

s = replace_once(
    s,
    "  strong_threshold_up: 0.25",
    "  strong_threshold_up: 0.68",
    "config strong_threshold_up",
)

path.write_text(
    s,
    encoding="utf-8"
)

print(
    "[PATCH] config.yaml"
)


# ============================================================
# 8. Compile validation
# ============================================================

compile_targets = [
    ROOT / "main_strategy.py",
    ROOT / "layers" / "layer6_ml_model.py",
    ROOT / "layers" / "layer10_filter.py",
    ROOT / "layers" / "polymarket_clob.py",
    ROOT / "layers" / "polymarket_rtds.py",
    ROOT / "layers" / "polymarket_shadow.py",
    ROOT / "layers" / "layer9_signal_generator.py",
    ROOT / "risk_manager.py",
]

print()
print(
    "=" * 72
)
print(
    "PYTHON COMPILE CHECK"
)
print(
    "=" * 72
)

for target in compile_targets:

    py_compile.compile(
        str(target),
        doraise=True,
    )

    print(
        "[PASS]",
        target.relative_to(
            ROOT
        ),
    )


# ============================================================
# 9. LightGBM warning regression test
# ============================================================

print()
print(
    "=" * 72
)
print(
    "ML FEATURE-NAME CHECK"
)
print(
    "=" * 72
)

ml_test = r'''
import sys
import warnings
import joblib
import numpy as np

from layers.layer6_ml_model import MLModelEnsemble

model_path = (
    "ml_lib/trained_models/"
    "BTC_USDT_ensemble_model.pkl"
)

bundle = joblib.load(
    model_path
)

X = np.zeros(
    (1, 20),
    dtype=float,
)

warning_count = 0

for name, model in bundle.models.items():

    if model is None:
        continue

    with warnings.catch_warnings(
        record=True
    ) as captured:

        warnings.simplefilter(
            "always"
        )

        result = (
            MLModelEnsemble
            ._predict_model_proba(
                model,
                X,
            )
        )

        print(
            name,
            "prob=",
            float(
                result[0]
            ),
            "warnings=",
            len(
                captured
            ),
        )

        warning_count += len(
            captured
        )

print(
    "ML_WARNING_COUNT=",
    warning_count,
)

if warning_count:
    raise SystemExit(2)
'''

ml_result = subprocess.run(
    [
        sys.executable,
        "-c",
        ml_test,
    ],
    cwd=str(
        ROOT
    ),
    text=True,
)

if ml_result.returncode != 0:
    raise RuntimeError(
        "ML feature-name regression test failed"
    )


# ============================================================
# 10. FINAL summary
# ============================================================

print()
print(
    "=" * 72
)
print(
    "FINAL PATCH SUCCESS"
)
print(
    "=" * 72
)

print(
    "1. 同一确认15m K线不再重复完整特征工程"
)

print(
    "2. 同一确认15m K线不再重复ML"
)

print(
    "3. 持仓ticker继续实时30秒监控"
)

print(
    "4. bars统计改为真实15m确认信号样本"
)

print(
    "5. Layer10 strong_down不再100%封杀BUY"
)

print(
    "6. Layer10只允许高概率+超卖逆势BUY"
)

print(
    "7. LightGBM feature-name warning修复"
)

print(
    "8. Polymarket public-search + markets fallback"
)

print(
    "9. Polymarket CLOB REST初始同步"
)

print(
    "10. Polymarket Market WSS自动重连"
)

print(
    "11. Polymarket RTDS也使用127.0.0.1:12450"
)

print(
    "12. Polymarket断线后自动REST重新同步"
)

print(
    "13. 市场切换使用真实start/end时间"
)

print(
    "14. config threshold_up=0.55"
)

print(
    "15. config min_ev_edge=0.05"
)

print(
    "16. config strong_threshold_up=0.68"
)

print(
    "Backups:",
    BACKUP_DIR,
)

print(
    "=" * 72
)
