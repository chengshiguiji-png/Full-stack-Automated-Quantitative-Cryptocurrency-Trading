﻿from pathlib import Path
import ast
import shutil
import zipfile
import py_compile
from datetime import datetime

ROOT = Path.cwd()
ZIP_PATH = ROOT.parent / "quant_ai_final_okx_demo_CURRENT.zip"
TARGET = ROOT / "layers" / "polymarket_clob.py"
BACKUP_DIR = ROOT / "_FINAL_BACKUP"

if not ZIP_PATH.exists():
    raise RuntimeError(
        f"找不到 CURRENT ZIP: {ZIP_PATH}"
    )

if not TARGET.exists():
    raise RuntimeError(
        f"找不到目标文件: {TARGET}"
    )

BACKUP_DIR.mkdir(
    exist_ok=True
)

stamp = datetime.now().strftime(
    "%Y%m%d_%H%M%S"
)

backup = (
    BACKUP_DIR
    / f"polymarket_clob_BEFORE_CLEAN_RESTORE_{stamp}.py"
)

shutil.copy2(
    TARGET,
    backup
)

print("[BACKUP]", backup)


# ============================================================
# 1. 从 CURRENT ZIP 恢复干净 polymarket_clob.py
# ============================================================

with zipfile.ZipFile(
    ZIP_PATH,
    "r"
) as z:

    names = [
        n
        for n in z.namelist()
        if n.replace("\\", "/")
        .lower()
        .endswith(
            "layers/polymarket_clob.py"
        )
    ]

    if not names:
        raise RuntimeError(
            "CURRENT ZIP 中没有 layers/polymarket_clob.py"
        )

    source_name = names[0]

    source_bytes = z.read(
        source_name
    )

TARGET.write_bytes(
    source_bytes
)

print(
    "[RESTORE]",
    source_name
)


# ============================================================
# 2. 读取干净文件
# ============================================================

source = TARGET.read_text(
    encoding="utf-8-sig"
)


# ============================================================
# 3. 增加 re
# ============================================================

if "\nimport re\n" not in source:

    source = source.replace(
        "import os\n",
        "import os\nimport re\n",
        1
    )


# ============================================================
# 4. 增加 event-by-slug URL
# ============================================================

if "GAMMA_EVENT_SLUG_URL" not in source:

    marker = (
        '    GAMMA_URL = '
        '"https://gamma-api.polymarket.com/markets"\n'
    )

    if marker not in source:

        raise RuntimeError(
            "找不到 GAMMA_URL"
        )

    source = source.replace(
        marker,
        marker
        + (
            '    GAMMA_EVENT_SLUG_URL = '
            '"https://gamma-api.polymarket.com/events/slug/{slug}"\n'
        ),
        1
    )


# ============================================================
# 5. AST 找到 PolymarketCLOB.discover_btc_updown
# ============================================================

tree = ast.parse(
    source
)

clob = None
discover_node = None

for node in tree.body:

    if (
        isinstance(
            node,
            ast.ClassDef
        )
        and
        node.name
        == "PolymarketCLOB"
    ):

        clob = node

        for child in node.body:

            if (
                isinstance(
                    child,
                    ast.FunctionDef
                )
                and
                child.name
                == "discover_btc_updown"
            ):

                discover_node = child
                break

        break

if clob is None:
    raise RuntimeError(
        "找不到 PolymarketCLOB"
    )

if discover_node is None:
    raise RuntimeError(
        "干净 CURRENT ZIP 中没有 discover_btc_updown"
    )


# ============================================================
# 6. 已验证的最终 BTC 15m discovery
# ============================================================

new_method = r'''
    def discover_btc_updown(
        self,
        window="15m",
    ):
        """
        Final BTC 15m market discovery.

        15m窗口的真实起点来自：
            btc-updown-15m-<unix_timestamp>

        不使用 Gamma market.startDate 作为预测窗口起点。
        """

        if str(window).lower() != "15m":

            logger.warning(
                "Polymarket discovery optimized for 15m, requested={}",
                window,
            )

        now = time.time()

        with self._lock:

            cached = (
                self._market_cache.get(
                    "market"
                )
            )

            cached_ts = float(
                self._market_cache.get(
                    "ts",
                    0.0
                )
            )

        # ----------------------------------------------------
        # cache only while the cached 15m window is still live
        # ----------------------------------------------------

        if (
            cached
            and
            now
            - cached_ts
            <
            self.refresh_sec
        ):

            slug = str(
                cached.get(
                    "slug",
                    ""
                )
            ).lower()

            cached_match = re.search(
                r"btc-updown-15m-(\d{10})$",
                slug,
            )

            if cached_match:

                start_ts = float(
                    cached_match.group(1)
                )

                if (
                    start_ts
                    <= now
                    <
                    start_ts + 900.0
                ):

                    return cached

        # ----------------------------------------------------
        # 当前15分钟窗口
        # ----------------------------------------------------

        bucket = (
            int(now)
            // 900
        ) * 900

        def normalize(
            market,
            event=None,
            slug_hint="",
        ):

            if not isinstance(
                market,
                dict,
            ):

                return None

            event = (
                event
                if isinstance(
                    event,
                    dict,
                )
                else {}
            )

            slug = str(
                market.get(
                    "slug"
                )
                or
                event.get(
                    "slug"
                )
                or
                slug_hint
                or
                ""
            ).lower()

            match = re.search(
                r"btc-updown-15m-(\d{10})$",
                slug,
            )

            if not match:
                return None

            start_ts = float(
                match.group(1)
            )

            end_ts = (
                start_ts
                + 900.0
            )

            # 真正的15m预测窗口
            if not (
                start_ts
                <= now
                <
                end_ts
            ):

                return None

            if market.get(
                "closed"
            ) is True:

                return None

            if market.get(
                "archived"
            ) is True:

                return None

            token_raw = (
                market.get(
                    "clobTokenIds"
                )
                or
                market.get(
                    "clob_token_ids"
                )
            )

            try:

                token_raw = (
                    self._jsonish(
                        token_raw
                    )
                )

            except Exception:
                pass

            if not isinstance(
                token_raw,
                list,
            ):

                return None

            token_ids = [
                str(x)
                for x in token_raw
                if x
            ]

            if len(
                token_ids
            ) < 2:

                return None

            outcomes = (
                market.get(
                    "outcomes"
                )
            )

            try:

                outcomes = (
                    self._jsonish(
                        outcomes
                    )
                )

            except Exception:
                pass

            if not isinstance(
                outcomes,
                list,
            ):

                outcomes = [
                    "Up",
                    "Down",
                ]

            outcomes = [
                str(x)
                for x in outcomes
            ]

            # ------------------------------------------------
            # 保证 token 顺序为 Up / Down
            # ------------------------------------------------

            ordered = (
                token_ids[:2]
            )

            lowered = [
                x.lower()
                for x in outcomes
            ]

            up_index = next(
                (
                    i
                    for i, x
                    in enumerate(
                        lowered
                    )
                    if x
                    in {
                        "up",
                        "yes",
                    }
                ),
                None,
            )

            down_index = next(
                (
                    i
                    for i, x
                    in enumerate(
                        lowered
                    )
                    if x
                    in {
                        "down",
                        "no",
                    }
                ),
                None,
            )

            if (
                up_index is not None
                and
                down_index is not None
                and
                up_index
                < len(token_ids)
                and
                down_index
                < len(token_ids)
            ):

                ordered = [
                    token_ids[
                        up_index
                    ],
                    token_ids[
                        down_index
                    ],
                ]

            start_dt = (
                dt.datetime.fromtimestamp(
                    start_ts,
                    tz=dt.timezone.utc,
                )
            )

            end_dt = (
                dt.datetime.fromtimestamp(
                    end_ts,
                    tz=dt.timezone.utc,
                )
            )

            return {
                "condition_id":
                    (
                        market.get(
                            "conditionId"
                        )
                        or
                        market.get(
                            "condition_id"
                        )
                    ),

                "market_id":
                    market.get(
                        "id"
                    ),

                "event_id":
                    event.get(
                        "id"
                    ),

                "slug":
                    (
                        market.get(
                            "slug"
                        )
                        or
                        event.get(
                            "slug"
                        )
                        or
                        slug
                    ),

                "question":
                    (
                        market.get(
                            "question"
                        )
                        or
                        event.get(
                            "title"
                        )
                        or
                        "Bitcoin Up or Down"
                    ),

                "start_time":
                    start_dt.isoformat(),

                "end_time":
                    end_dt.isoformat(),

                "window_start_ts":
                    start_ts,

                "window_end_ts":
                    end_ts,

                "token_ids":
                    ordered,

                "outcomes":
                    outcomes[:2],

                "duration_sec":
                    900.0,

                "volume":
                    float(
                        market.get(
                            "volumeNum"
                        )
                        or
                        market.get(
                            "volume"
                        )
                        or
                        0.0
                    ),

                "raw":
                    market,
            }

        def accept(
            result,
            source_name,
        ):

            if not result:
                return None

            with self._lock:

                self._market_cache = {
                    "ts":
                        now,
                    "market":
                        result,
                }

            logger.success(
                "Polymarket LIVE BTC 15m discovered via {}: {} | start={} | end={} | tokens={}",
                source_name,
                result.get(
                    "slug"
                ),
                result.get(
                    "start_time"
                ),
                result.get(
                    "end_time"
                ),
                len(
                    result.get(
                        "token_ids",
                        []
                    )
                ),
            )

            return result

        # ====================================================
        # A. 直接当前窗口 event slug
        # ====================================================

        for start_ts in (
            bucket,
            bucket - 900,
            bucket + 900,
        ):

            slug = (
                f"btc-updown-15m-{start_ts}"
            )

            try:

                payload = (
                    self._get_json(
                        self.GAMMA_EVENT_SLUG_URL.format(
                            slug=slug
                        )
                    )
                )

                if not isinstance(
                    payload,
                    dict,
                ):

                    continue

                markets = (
                    payload.get(
                        "markets"
                    )
                    or
                    []
                )

                if not isinstance(
                    markets,
                    list,
                ):

                    markets = []

                if (
                    not markets
                    and
                    (
                        payload.get(
                            "clobTokenIds"
                        )
                        or
                        payload.get(
                            "clob_token_ids"
                        )
                    )
                ):

                    markets = [
                        payload
                    ]

                for market in markets:

                    result = normalize(
                        market,
                        payload,
                        slug,
                    )

                    if result:

                        return accept(
                            result,
                            "event-slug",
                        )

            except Exception as exc:

                logger.debug(
                    "Polymarket event-slug lookup {} failed: {}",
                    slug,
                    exc,
                )

        # ====================================================
        # B. public-search fallback
        # ====================================================

        search_url = (
            "https://gamma-api.polymarket.com/public-search"
        )

        for query in (
            "Bitcoin Up or Down",
            "BTC Up or Down",
        ):

            try:

                payload = (
                    self._get_json(
                        search_url,
                        {
                            "q":
                                query,
                            "limit_per_type":
                                100,
                            "page":
                                1,
                        },
                    )
                )

                stack = [
                    payload
                ]

                seen = set()

                while stack:

                    obj = stack.pop()

                    if isinstance(
                        obj,
                        dict,
                    ):

                        if (
                            "clobTokenIds"
                            in obj
                            or
                            "clob_token_ids"
                            in obj
                        ):

                            key = id(
                                obj
                            )

                            if key not in seen:

                                seen.add(
                                    key
                                )

                                result = (
                                    normalize(
                                        obj
                                    )
                                )

                                if result:

                                    return accept(
                                        result,
                                        "public-search",
                                    )

                        for value in obj.values():

                            if isinstance(
                                value,
                                (
                                    dict,
                                    list,
                                ),
                            ):

                                stack.append(
                                    value
                                )

                    elif isinstance(
                        obj,
                        list,
                    ):

                        stack.extend(
                            obj
                        )

            except Exception as exc:

                logger.debug(
                    "Polymarket public-search {} failed: {}",
                    query,
                    exc,
                )

        # ====================================================
        # C. /markets fallback
        # ====================================================

        try:

            payload = (
                self._get_json(
                    self.GAMMA_URL,
                    {
                        "closed":
                            "false",
                        "active":
                            "true",
                        "limit":
                            100,
                        "order":
                            "endDate",
                        "ascending":
                            "false",
                    },
                )
            )

            if isinstance(
                payload,
                list,
            ):

                for market in payload:

                    result = normalize(
                        market
                    )

                    if result:

                        return accept(
                            result,
                            "markets",
                        )

        except Exception as exc:

            logger.debug(
                "Polymarket /markets failed: {}",
                exc,
            )

        logger.warning(
            "Polymarket: API reachable but current BTC 15m market not found"
        )

        return None
'''


# ============================================================
# 7. 用AST真实行号替换原方法
# ============================================================

lines = source.splitlines(
    keepends=True
)

lines[
    discover_node.lineno - 1:
    discover_node.end_lineno
] = [
    new_method
    .strip("\n")
    + "\n"
]

source = "".join(
    lines
)

TARGET.write_text(
    source,
    encoding="utf-8"
)


# ============================================================
# 8. 编译
# ============================================================

py_compile.compile(
    str(TARGET),
    doraise=True
)

print(
    "[PASS] polymarket_clob.py syntax"
)


# ============================================================
# 9. Runtime verify
# ============================================================

import importlib
import layers.polymarket_clob as mod

mod = importlib.reload(
    mod
)

cls = mod.PolymarketCLOB

print()
print(
    "=" * 72
)
print(
    "CLEAN POLYMARKET RESTORE + DISCOVERY CHECK"
)
print(
    "=" * 72
)

print(
    "MODULE =",
    mod.__file__
)

print(
    "DISCOVER =",
    hasattr(
        cls,
        "discover_btc_updown"
    )
)

print(
    "START =",
    hasattr(
        cls,
        "start"
    )
)

print(
    "STOP =",
    hasattr(
        cls,
        "stop"
    )
)

print(
    "HEALTH =",
    hasattr(
        cls,
        "health_snapshot"
    )
)

if not hasattr(
    cls,
    "discover_btc_updown"
):

    raise RuntimeError(
        "discover_btc_updown恢复失败"
    )

print(
    "=" * 72
)

print(
    "CLEAN RESTORE SUCCESS"
)

print(
    "=" * 72
)
