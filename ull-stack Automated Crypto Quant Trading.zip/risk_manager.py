﻿# risk_manager.py
# -*- coding: utf-8 -*-
import numpy as np
from loguru import logger

class RiskManager:
    def __init__(self, initial_capital=100000, risk_per_trade=0.02, atr_multiplier=1.5,
                 stop_loss_pct=0.02, take_profit_pct=0.04, trailing_stop_pct=0.015):
        self.initial_capital = initial_capital
        self.risk_per_trade = risk_per_trade
        self.atr_multiplier = atr_multiplier
        self.stop_loss_pct = stop_loss_pct
        self.take_profit_pct = take_profit_pct
        self.trailing_stop_pct = trailing_stop_pct

    def calculate_position_size(self, symbol: str, side: str, price: float, atr: float, capital: float, regime_boost: float = 1.0) -> float:
        if atr <= 0:
            atr = price * 0.01
        max_loss = capital * self.risk_per_trade
        stop_distance = self.atr_multiplier * atr
        if side.upper() == "BUY":
            # 理论仓位
            position_usdt = max_loss * (price / stop_distance)
            # 限制最大下单金额：不超过当前可用资金的 5% 且不超过 500 USDT
            # regime_boost：确认的强趋势行情下小幅放宽这个硬上限（默认1.0=不变）。
            # 之所以要动这个上限而不只是靠止损止盈管理：500U封顶在10万本金下只占0.5%，
            # 就算移动止损让利润完全奔跑，单笔仓位这么小也很难缩小和满仓买入持有的差距——
            # 仅靠"退出管理"补不齐这个量级的差距，仓位上限也得跟着市场状态一起调，
            # 但仍然保留在 RiskFuse 的总敞口限制之内，不是无限放大。
            regime_boost = max(1.0, min(float(regime_boost), 2.0))  # 硬夹在[1.0, 2.0]，防止配置失误放出过大仓位
            max_position_usdt = min(capital * 0.05, 500.0) * regime_boost   # 关键修改
            position_usdt = min(position_usdt, max_position_usdt)
            # 最小下单金额 10 USDT
            position_usdt = max(position_usdt, 10)
            logger.debug(f"动态仓位计算 BUY: ATR={atr:.2f}, 止损距离={stop_distance:.2f}, "
                         f"允许亏损={max_loss:.2f}, 计算下单USDT={position_usdt:.2f}, 资金上限={max_position_usdt:.2f}, regime_boost={regime_boost}")
            return position_usdt
        else:
            return None

    def check_stop_loss_take_profit(self, entry_price: float, current_price: float, side: str,
                                    trailing_stop_active: bool = False, highest_price: float = None) -> dict:
        if side.upper() == "BUY":
            pnl_pct = (current_price - entry_price) / entry_price
            if pnl_pct <= -self.stop_loss_pct:
                return {'action': 'close', 'reason': f'固定止损触发 (亏损{abs(pnl_pct):.2%})'}
            if pnl_pct >= self.take_profit_pct:
                return {'action': 'close', 'reason': f'固定止盈触发 (盈利{pnl_pct:.2%})'}
            if trailing_stop_active and highest_price is not None:
                drawdown = (highest_price - current_price) / highest_price
                if drawdown >= self.trailing_stop_pct:
                    return {'action': 'close', 'reason': f'移动止损触发 (回撤{drawdown:.2%})'}
            return {'action': 'hold', 'reason': ''}
        else:
            return {'action': 'hold', 'reason': ''}