﻿from pathlib import Path
from datetime import datetime
import shutil
import py_compile

FILES = [
    Path("layers/polymarket_clob.py"),
    Path("layers/polymarket_shadow.py"),
]

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

replacements = {
    # -----------------------------
    # polymarket_clob.py
    # -----------------------------
    "Polymarket network proxy=":
        "Polymarket 网络代理=",

    "Polymarket LIVE BTC 15m discovered via":
        "Polymarket 已发现实时 BTC 15m 市场，来源=",

    "Polymarket CLOB REST book synced:":
        "Polymarket CLOB REST 盘口已同步：",

    "Polymarket CLOB WSS connected; subscribed":
        "Polymarket CLOB WSS 已连接；已订阅",

    "Polymarket CLOB WSS stale; forcing reconnect":
        "Polymarket CLOB WSS 数据过期；强制重连",

    "Polymarket CLOB reconnect in":
        "Polymarket CLOB 将在",

    "Polymarket CLOB WSS error:":
        "Polymarket CLOB WSS 错误：",

    "Polymarket CLOB WSS closed:":
        "Polymarket CLOB WSS 已关闭：",

    "Polymarket HTTP retry":
        "Polymarket HTTP 重试",

    "Polymarket: no active BTC Up/Down market found":
        "Polymarket：未找到当前活跃的 BTC Up/Down 市场",

    "Polymarket REST fallback sync:":
        "Polymarket REST 兜底同步：",

    "Polymarket REST fallback stopped; WSS stream healthy":
        "Polymarket REST 兜底已停止；WSS 实时流健康",

    "Polymarket WSS stale/disconnected":
        "Polymarket WSS 数据过期/连接断开",

    "Polymarket API reachable but current BTC 15m market not found":
        "Polymarket API 可访问，但未找到当前 BTC 15m 市场",

    # -----------------------------
    # polymarket_shadow.py
    # -----------------------------
    "Polymarket Shadow Mode enabled: read-only / no executor":
        "Polymarket Shadow 模式已启用：只读 / 不执行交易",

    "Shadow market:":
        "Shadow 市场：",

    "Polymarket Shadow stale:":
        "Polymarket Shadow 数据过期：",

    "Polymarket Shadow cycle unavailable:":
        "Polymarket Shadow 周期不可用：",
}

for path in FILES:

    if not path.exists():
        print(f"[SKIP] {path} 不存在")
        continue

    backup = path.with_name(
        f"{path.stem}.before_cn_logs_{stamp}{path.suffix}"
    )

    shutil.copy2(path, backup)

    source = path.read_text(
        encoding="utf-8-sig"
    )

    original = source

    for old, new in replacements.items():
        source = source.replace(
            old,
            new,
        )

    if source == original:
        print(f"[INFO] {path} 没有发现可替换的英文日志")
    else:
        path.write_text(
            source,
            encoding="utf-8"
        )
        print(f"[PATCH] {path}")
        print(f"[BACKUP] {backup}")

    py_compile.compile(
        str(path),
        doraise=True
    )

print()
print("=" * 72)
print("POLYMARKET 中文日志补丁成功")
print("=" * 72)
print("已修改：Polymarket CLOB / Shadow 日志")
print("交易逻辑：未修改")
print("Discovery：未修改")
print("REST：未修改")
print("WSS：未修改")
print("Fallback：未修改")
print("Syntax：PASS")
print("=" * 72)
