﻿# -*- coding: utf-8 -*-
from pathlib import Path
import joblib, yaml
import numpy as np

from layers.layer1_data_collector import DataCollector
from layers.layer3_data_clean import DataCleaner
from layers.layer4_feature_engineer import FeatureEngineer

cfg = yaml.safe_load(Path("config.yaml").read_text(encoding="utf-8")) or {}
collector = DataCollector(cfg)
cleaner   = DataCleaner()
fe        = FeatureEngineer(cfg.get("features", {}))

for symbol in ["BTC-USDT", "ETH-USDT", "SOL-USDT"]:
    key = symbol.replace("-", "_")
    print("=" * 65)
    print(f"资产: {symbol} (key={key})")

    feat_cols_path = Path(f"ml_lib/transformers/{key}_feature_columns.txt")
    model_path     = Path(f"ml_lib/trained_models/{key}_ensemble_model.pkl")
    scaler_path    = Path(f"ml_lib/transformers/{key}_scaler.pkl")
    selector_path  = Path(f"ml_lib/transformers/{key}_selector.pkl")
    calib_path     = Path(f"ml_lib/transformers/{key}_calibrator.pkl")

    for p in [feat_cols_path, model_path, scaler_path, selector_path]:
        if not p.exists():
            print(f"  ❌ 缺失: {p}")
            break
    else:
        feat_cols = [x.strip() for x in feat_cols_path.read_text(encoding="utf-8").splitlines() if x.strip()]
        print(f"  特征数: {len(feat_cols)}")

        # 拉实时数据
        raw = collector.fetch_klines_rest(symbol=symbol, interval=cfg.get("market_bar", "15m"), limit=300)
        df = cleaner.clean_klines(raw)
        feat = fe.calculate_features(df)

        missing = [c for c in feat_cols if c not in feat.columns]
        if missing:
            print(f"  ❌ 缺失特征: {missing[:5]}")
            continue

        row = feat[feat_cols].tail(1)
        if row.isna().any(axis=1).iloc[0]:
            print(f"  ❌ 最新行有 NaN")
            continue

        model    = joblib.load(model_path)
        scaler   = joblib.load(scaler_path)
        selector = joblib.load(selector_path)
        calib    = joblib.load(calib_path) if calib_path.exists() else None

        X = scaler.transform(row)
        X = selector.transform(X)
        raw_p = float(model.predict_proba(X)[0][1]) if model.predict_proba(X).ndim > 1 else float(model.predict_proba(X)[0])
        print(f"  raw_p_up       = {raw_p:.4f}")
        if calib is not None:
            try:
                cal_p = float(calib.predict([raw_p])[0])
                print(f"  calibrated_p_up= {cal_p:.4f}")
            except Exception as e:
                print(f"  calibrator 调用失败: {e}")

print("\n诊断完成。")
