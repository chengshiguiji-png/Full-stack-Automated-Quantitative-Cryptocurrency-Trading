# 最终方案（OKX Demo 15m）

## 核心目标
先用 OKX 模拟盘验证“信号质量 → 实际成交 → 实际平仓结果”，不以代码复杂度或回测最高胜率为目标。

## 最终决策链
OKX 已确认 15m K线 → 因果特征 → 每币种独立 ensemble → 信号阈值 → 市场状态安全门 → 仓位计算 → EntryFilter → RiskFuse → OKX Demo 市价单 → 等待 filled → 本地账本/状态更新 → TP/SL/移动止盈。

## 关键设计
1. 每个交易品种独立训练模型，避免 BTC 模型直接跨品种套用。
2. 标签与实际退出结构对齐：未来 16 根K线内是否先达到 1.5 ATR 目标；1.0 ATR 止损先触发则记失败；无命中记失败；同一根K线同时命中则排除。
3. 默认 BUY score=0.62，STRONG=0.68。Layer10 不再重复设置一个隐含的 0.60 门槛。
4. TCN/Transformer 仅记录确认冲突，不直接把主模型 BUY 强制改为 HOLD。
5. OKX Spot BUY 市价单明确按 quote_ccy 发送 USDT 名义金额；SELL 按 base_ccy 发送币数量。
6. 历史 K线超过 300 根时使用 history-candles 分页。
7. 概率校准默认关闭交易使用，但保留校准 artifact 和监控能力；这样避免当前数据上的校准把信号压到 0。
8. 所有拒绝原因进入信号漏斗统计，可以看到到底卡在 EntryFilter 还是 RiskFuse。
9. 默认仍为 OKX Demo；LIVE_TRADING_ENABLED=false 提供第二道实盘安全门。

## 为什么不恢复 DeepSeek 的全部复杂逻辑
DeepSeek 旧版机会多，但规则/模型/状态机叠加较重。本版只恢复“交易覆盖率”而不恢复无边界规则堆叠，以便 Demo 阶段能够做归因分析。
