﻿# security/vault_client.py
import os

def apply_env_overrides(config):
    for key in ["api_key", "api_secret", "passphrase"]:
        env_val = os.environ.get(f"OKX_{key.upper()}")
        if env_val:
            config.setdefault("exchange", {}).setdefault("okx", {})[key] = env_val
    return config
